## Vibe
- Brazilian Tropical Retail Modernism & Clean Commercial Catalog

## Color
- Primary: #04875F
- On Primary: #FFFFFF
- Accent: #1E40AF
- On Accent: #FFFFFF
- Background: #FFFFFF
- Foreground: #0F172A
- Muted: #F0F8F6
- Border: #E1F2ED
- Secondary: #10B981

## Typography
- Heading: Urbanist (family: Urbanist, sans-serif, weight: 700, url: https://resource-static.bj.bcebos.com/fonts-skill/Urbanist_Urbanist[wght].ttf)
- Body: Urbanist (family: Urbanist, sans-serif, weight: 400, url: https://resource-static.bj.bcebos.com/fonts-skill/Urbanist_Urbanist[wght].ttf)

## Visual Language
- Core visual signature: Painel de conformidade Meta Commerce com cards modulares de validação de catálogo (identificador, imagem, preço e EAN), além de canvas de simulação ao vivo de postagens para Instagram/Facebook (Feed 1:1 e Stories 9:16).
- Material & depth: Superfícies limpas com sombras sutis de elevação nos cartões de criativos e pré-visualização, fundos neutros com foco na foto dos produtos.
- Containers & buttons: Badges de status com bordas finas coloridas indicando conformidade para o catálogo Meta; botões de ação com ícones táteis de cópia de link e download direto em XML/CSV.
- Layout rhythm: Distribuição harmoniosa entre área de controle de sincronização do feed e espaço de trabalho interativo de geração de criativos e legendas promocionais.

## Animation
- Entrance: Fade-in suave com leve deslocamento vertical nos cartões de produtos ao carregar (200ms ease-out)
- Interaction: Feedback de clique com microtransição de escala nos botões de cópia de URL e download (150ms ease)
- Scroll / transition: Alternância fluida entre abas de Feed XML/CSV e Gerador de Posts Sociais

## Forbidden
- Proibido uso de grandes blocos de cores saturadas no fundo
- Proibido uso de emojis em títulos, botões e cabeçalhos de navegação
- Proibido estilos genéricos sem contraste adequado para conformidade WCAG AA

## Additional Notes
- Todo o texto de interface em português do Brasil (pt-BR)
- Geração de arquivos de feed compatíveis com as especificações oficiais do Meta Commerce Manager e Instagram Shopping
