# Documento de Requisitos

## 1. Visão Geral da Aplicação

**Nome da Aplicação**: App Móvel e PDV de Controle de Estoque - Mundo Limpo

**Descrição**: Aplicativo Web/PWA para controle de estoque e PDV integrado do Mundo Limpo. Permite leitura de código de barras responsiva (via câmera ou leitores USB/Bluetooth com feedback sonoro/visual), PDV com registro e cancelamento de vendas com estorno automático de estoque e financeiro, exportação de relatório em PDF de vendas canceladas, ajuste de estoque e preços, gestão de visibilidade de itens no catálogo online, contagem de inventário, consolidação de duplicados por código de barras e código interno, relatórios de lucratividade e curva ABC, entrada de mercadorias por NF-e/DANFE, impressão de etiquetas, portfólio de produtos com compartilhamento via WhatsApp, rastreamento via Meta Pixel, geração de Feed de Produtos para Meta Commerce Manager (Facebook e Instagram Shopping) nos formatos oficiais com URL pública e validação de catálogo, além de gerador e planejador de posts de Feed e Stories para redes sociais.

## 2. Usuários e Cenários de Uso

**Usuários-alvo**:
- Gestores de estoque e Administradores: gerenciam produtos, realizam contagens, ajustam preços e estoques, consolidam duplicidades, configuram e validam feeds de catálogo para Facebook/Instagram e geram criativos para redes sociais
- Operadores e Vendedores: consultam produtos e realizam vendas no PDV
- Clientes: visualizam catálogo visual no portfólio de produtos ativos

**Cenários principais**:
- Administrador acessa a tela de Feed de Produtos para Meta/Instagram Shopping, visualiza o status de conformidade dos produtos, copia a URL pública do feed dinâmico em XML/CSV ou faz o download do arquivo para sincronização no Meta Commerce Manager
- Gestor ou Administrador utiliza o Gerador de Posts para redes sociais, seleciona um produto ativo, gera pré-visualizações de posts para Feed e Stories com textos persuasivos e hashtags e copia ou faz download do conteúdo
- Operador utiliza o PDV para escanear itens e registrar vendas com feedback sonoro
- Administrador unifica produtos duplicados identificados por código de barras ou código interno idêntico

## 3. Estrutura de Páginas e Funcionalidades

### 3.1 Estrutura de Páginas

```
├── Tela Inicial
│   ├── Buscar Produto
│   ├── Escanear Código de Barras
│   ├── Lista de Produtos (Filtro e Status de Visibilidade no Site e Duplicidades)
│   ├── Resumo de Estoque
│   └── Banner Promocional
├── Frente de Caixa / PDV (/pdv)
│   ├── Leitor de Código de Barras (Câmera / USB / Bluetooth)
│   ├── Adição de Produtos e Carrinho
│   ├── Finalização de Venda
│   └── Histórico e Cancelamento de Vendas (/pdv/vendas)
├── Detalhes e Cadastro do Produto
│   ├── Edição de Dados, Preço, Estoque e Visibilidade no Catálogo
│   └── Alerta de Duplicidade (EAN e Código Interno)
├── Consolidação de Produtos Duplicados (/produtos/duplicados)
├── Entrada de Mercadorias / Importação de Nota Fiscal (/pdv/entrada)
├── Relatórios Financeiros e de Vendas (Admin)
├── Contagem de Inventário
├── Portfólio de Produtos (/portfolio)
├── Feed de Catálogo Meta Shopping (/marketing/feed-meta)
│   ├── URL Pública do Feed Dinâmico (XML RSS e CSV/TSV)
│   ├── Botões de Ação Rápida (Copiar URL e Download de Arquivos)
│   ├── Painel de Validação e Conformidade de Produtos para a Meta
│   └── Lista de Produtos Aptos e Pendências de Cadastro
├── Gerador de Posts para Redes Sociais (/marketing/gerador-posts)
│   ├── Seleção de Produto do Catálogo
│   ├── Visualizador de Formatos (Feed 1:1 e Stories 9:16)
│   ├── Gerador de Textos Persuasivos e Hashtags Sugeridas
│   └── Ações de Cópia de Legenda e Download de Imagem/Criativo
├── Integrações e Meta Pixel (Admin) (/configuracoes/marketing)
├── Configuração e Impressão de Etiquetas (Admin/Gestor)
└── Gerenciamento de Permissões e Exportações (Admin)
```

### 3.2 Funcionalidades por Página

#### 3.2.1 Tela Inicial e Gestão de Produtos
- Busca por código de barras, nome ou código interno e leitura via câmera
- Listagem de produtos com filtros de visibilidade:「Todos」,「No Site」e「Fora do Site」
- Badge indicador de visibilidade no catálogo e alerta visual de duplicidade de código
- Alternador rápido para ativar/desativar publicação no catálogo com um clique

#### 3.2.2 Detalhes e Cadastro do Produto
- Edição de descrição, código interno, código de barras/EAN, preços, estoque, marca, imagem e peso
- Validação em tempo real de duplicidade de código de barras ou código interno
- Chave seletora para visibilidade no catálogo online/site

#### 3.2.3 Feed de Catálogo Meta Shopping (/marketing/feed-meta)
- Exibição da URL pública dinâmica do feed nos padrões oficiais aceitos pelo Meta Commerce Manager e Instagram Shopping (formato XML RSS e CSV/TSV)
- Botão de cópia de link da URL pública com 1 clique para integração automática e programada
- Botões para download direto dos arquivos gerados nos formatos XML e CSV
- Painel de validação e checklist de conformidade dos produtos contendo status de prontidão (Apto / Pendente) para o catálogo da Meta
- Verificação de campos obrigatórios da Meta: Identificador único (id), Título (title), Descrição (description), Disponibilidade (availability - in stock / out of stock), Condição (condition - new), Preço formatado com moeda (price - BRL), Link da página (link), Link da imagem (image_link), Marca (brand) e Código de barras EAN/GTIN (gtin)
- Tabela de produtos com identificação visual dos itens com pendências (ex.: ausência de imagem, falta de código de barras/EAN, preço zerado ou sem descrição)

#### 3.2.4 Gerador de Posts para Redes Sociais (/marketing/gerador-posts)
- Seletor de produtos cadastrados e ativos no catálogo
- Pré-visualização gráfica de criativos nos formatos padrão para Instagram e Facebook: Feed (quadrado 1:1) e Stories (vertical 9:16), exibindo imagem do produto, nome, preço e marca
- Gerador de legendas e textos promocionais com sugestões de chamadas para ação (CTA)
- Bloco de hashtags sugeridas baseadas na categoria e nome do produto
- Botão de cópia rápida do texto/legenda para a área de transferência
- Botão de download do criativo montado em formato de imagem

#### 3.2.5 Frente de Caixa / PDV e Histórico de Vendas (/pdv e /pdv/vendas)
- Leitura contínua de código de barras via leitor USB/Bluetooth e câmera com feedback sonoro e visual
- Adição ao carrinho, finalização de venda com formas de pagamento e cancelamento com justificativa obrigatória e estorno de estoque/financeiro
- Exportação de relatório de vendas canceladas em PDF

#### 3.2.6 Consolidação de Produtos Duplicados (/produtos/duplicados)
- Agrupamento de produtos duplicados por EAN idêntico ou código interno idêntico
- Comparativo de dados e unificação de estoque e histórico para o produto principal selecionado

#### 3.2.7 Entrada de Mercadorias por Nota Fiscal (/pdv/entrada)
- Importação de XML NF-e e PDF DANFE com extração de itens e fornecedor
- Atualização de estoque, cálculo de custo real e rateio de despesas

#### 3.2.8 Relatórios, Portfólio e Integrações
- Relatórios de lucratividade, ranking de mais vendidos e curva ABC
- Portfólio de produtos (/portfolio) para clientes com link para WhatsApp
- Configuração do Meta Pixel ID com disparo de eventos (ViewContent, AddToCart, InitiateCheckout e Purchase)

## 4. Regras de Negócio e Lógica

### 4.1 Estrutura e Atualização do Feed Meta Commerce Manager
- O feed público deve gerar a lista dinâmica contendo todos os produtos ativos e marcados como「No Site」.
- Estrutura de campos obrigatórios no XML/CSV do Feed:
  - `id`: código interno ou identificador do produto
  - `title`: nome/descrição do produto
  - `description`: descrição detalhada do produto
  - `availability`:「in stock」se estoque > 0, senão「out of stock」
  - `condition`: fixado como「new」
  - `price`: valor no formato「X.XX BRL」
  - `link`: URL direta do produto no portfólio web
  - `image_link`: URL pública da imagem principal do produto
  - `brand`: marca informada ou「Mundo Limpo」quando não especificada
  - `gtin`: código de barras EAN cadastrado
- A URL pública dinâmica responde em tempo real com as alterações de preço, estoque e status de catálogo sem necessidade de intervenção manual.

### 4.2 Validação de Conformidade do Feed
- Um produto é classificado como「Apto para a Meta」se possuir: nome preenchido, preço > 0, link de imagem válido e código de barras/EAN preenchido.
- Produtos sem imagem ou sem preço válido são sinalizados no painel de validação com alerta visual de pendência e podem ser excluídos da exportação para evitar rejeição no Gerenciador de Comércio da Meta.

### 4.3 Geração de Criativos para Redes Sociais
- Os modelos de criativos (Feed e Stories) montam dinamicamente a foto do produto, destaque de preço em BRL e nome do item.
- As legendas sugeridas combinam o nome do produto, preço promocional, chamada para compra e bloco de hashtags relacionadas.

### 4.4 Consolidação de Duplicidades e Visibilidade
- Produtos com EAN ou código interno idêntico disparam alertas de duplicidade no cadastro.
- A consolidação soma os estoques no produto principal e migra históricos.
- Apenas produtos com status「No Site」ficam visíveis no portfólio público e entram no feed da Meta.

## 5. Exceções e Casos Limite

| Situação | Comportamento Esperado |
|----------|------------------------|
| Produto ativo no catálogo sem imagem cadastrada | Sinalizar status「Pendente」na tela de validação do feed informando a ausência de imagem obrigatória para a Meta |
| Acesso à URL pública do feed sem nenhum produto publicado no site | Retornar feed estruturado válido contendo cabeçalho padrão e lista de itens vazia sem gerar erro de servidor |
| Produto com estoque zerado no sistema | Incluir no feed com a tag de disponibilidade `availability` definida como `out of stock` |
| Tentativa de gerar post de produto sem imagem | Exibir aviso na tela de criação solicitando o upload prévio de foto do produto |
| Cadastro de produto com código de barras já existente | Apresentar alerta visual imediato indicando o item conflitante e opção de ir para a tela de consolidação |
| Tentativa de cancelar venda sem justificativa | Bloquear a confirmação até o preenchimento obrigatório da justificativa |

## 6. Critérios de Aceitação

1. O administrador acessa a tela de Feed de Catálogo Meta (/marketing/feed-meta) e visualiza a URL pública gerada para sincronização
2. O botão de cópia de URL copia o link dinâmico diretamente para a área de transferência com confirmação visual
3. O usuário realiza o download do arquivo nos formatos XML RSS e CSV e o arquivo exportado contém os campos obrigatórios da Meta (id, title, description, availability, condition, price, link, image_link, brand e gtin)
4. O painel de validação lista os produtos aptos e destaca os produtos com pendências (falta de imagem, preço ou EAN)
5. Na tela do Gerador de Posts (/marketing/gerador-posts), o usuário seleciona um produto e visualiza a prévia nos formatos Feed (1:1) e Stories (9:16)
6. O usuário clica para copiar a legenda sugerida com hashtags e realiza o download da imagem do criativo gerado
7. Ao alterar o status de visibilidade de um produto para「No Site」, o item passa a constar imediatamente no feed dinâmico e no portfólio
8. Ao registrar uma venda no PDV via leitor de código de barras, o sistema adiciona o item ao carrinho com feedback sonoro e conclui a venda

## 7. Funcionalidades Não Implementadas Neste Período

- Publicação direta e automática na API do Instagram Graph/Facebook Graph sem ação do usuário
- Criação e gestão de campanhas de anúncios pagos da Meta dentro do sistema
- Integração com API de Conversões da Meta (CAPI via servidor)
- Edição avançada de camadas de imagem estilo Photoshop
- Integração com marketplaces externos adicionais (Mercado Livre, Shopee)