const fs = require('fs');
const path = require('path');
const dotenv = require('dotenv');

// Load environment variables if available
const envPath = path.join(__dirname, '..', '.env');
const envConfig = fs.existsSync(envPath) ? dotenv.parse(fs.readFileSync(envPath)) : process.env;

const { createClient } = require('@supabase/supabase-js');
const supabaseUrl = envConfig.VITE_SUPABASE_URL || process.env.VITE_SUPABASE_URL;
const supabaseKey = envConfig.VITE_SUPABASE_ANON_KEY || process.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.log('Skipping feed generation: Supabase credentials not found.');
  process.exit(0);
}

const supabase = createClient(supabaseUrl, supabaseKey);

function escapeXml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

async function buildStaticFeeds() {
  try {
    const { data: onlineProducts } = await supabase
      .from('products')
      .select('id, name, slug, description, price, stock_quantity, is_available, images, barcode')
      .eq('is_available', true);

    const { data: pdvList } = await supabase
      .from('pdv_products')
      .select('name, code, barcode, site_product_id');

    const barcodeBySiteId = new Map();
    const barcodeByName = new Map();
    pdvList?.forEach(p => {
      if (p.barcode?.trim()) {
        if (p.site_product_id) barcodeBySiteId.set(p.site_product_id, p.barcode.trim());
        barcodeByName.set(p.name.trim().toLowerCase(), p.barcode.trim());
      }
    });

    const origin = 'https://mundolimpo.store';
    const items = (onlineProducts || []).map(p => {
      const barcode = (p.barcode || '').trim() || barcodeBySiteId.get(p.id) || barcodeByName.get(p.name.trim().toLowerCase()) || '';
      const filename = (p.slug || p.id) + '.jpg';
      const imgUrl = `${origin}/uploads/produtos/${filename}`;
      const link = `${origin}/produto/${p.slug || p.id}`;
      const priceFormatted = `${Number(p.price || 0).toFixed(2)} BRL`;

      return {
        id: p.id,
        title: p.name,
        description: p.description || p.name,
        availability: (p.stock_quantity || 0) > 0 ? 'in stock' : 'out of stock',
        condition: 'new',
        price: priceFormatted,
        link,
        image_link: imgUrl,
        brand: 'Mundo Limpo',
        gtin: barcode,
        fb_product_category: 'Health & Beauty > Personal Care'
      };
    });

    const itemsXml = items.map(item => {
      return `    <item>
      <g:id>${escapeXml(item.id)}</g:id>
      <g:title>${escapeXml(item.title)}</g:title>
      <g:description>${escapeXml(item.description || item.title)}</g:description>
      <g:link>${escapeXml(item.link)}</g:link>
      <g:image_link>${escapeXml(item.image_link)}</g:image_link>
      <g:brand>${escapeXml(item.brand || 'Mundo Limpo')}</g:brand>
      <g:condition>${item.condition}</g:condition>
      <g:availability>${item.availability}</g:availability>
      <g:price>${escapeXml(item.price)}</g:price>
${item.gtin ? `      <g:gtin>${escapeXml(item.gtin)}</g:gtin>\n` : '      <g:identifier_exists>no</g:identifier_exists>\n'}      <g:fb_product_category>Health &amp; Beauty &gt; Personal Care</g:fb_product_category>
    </item>`;
    }).join('\n');

    const xmlContent = `<?xml version="1.0" encoding="UTF-8"?>
<rss xmlns:g="http://base.google.com/ns/1.0" version="2.0">
  <channel>
    <title>Mundo Limpo</title>
    <link>${origin}</link>
    <description>Catálogo oficial de produtos Mundo Limpo para Facebook e Instagram Shopping</description>
${itemsXml}
  </channel>
</rss>`;

    const escapeCsv = val => {
      if (!val) return '""';
      return `"${String(val).replace(/"/g, '""')}"`;
    };
    const headers = ['id','title','description','availability','condition','price','link','image_link','brand','gtin','fb_product_category'];
    const rows = items.map(item => [
      escapeCsv(item.id),
      escapeCsv(item.title),
      escapeCsv(item.description || item.title),
      escapeCsv(item.availability),
      escapeCsv(item.condition || 'new'),
      escapeCsv(item.price),
      escapeCsv(item.link),
      escapeCsv(item.image_link),
      escapeCsv(item.brand || 'Mundo Limpo'),
      escapeCsv(item.gtin || ''),
      escapeCsv('Health & Beauty > Personal Care')
    ].join(','));
    const csvContent = [headers.join(','), ...rows].join('\n');

    const targetDir = path.join(__dirname, '..', 'public', 'feed', 'meta');
    fs.mkdirSync(targetDir, { recursive: true });

    fs.writeFileSync(path.join(targetDir, 'format=xml'), xmlContent, 'utf8');
    fs.writeFileSync(path.join(targetDir, 'format=csv'), csvContent, 'utf8');
    fs.writeFileSync(path.join(__dirname, '..', 'public', 'feed', 'meta.xml'), xmlContent, 'utf8');
    fs.writeFileSync(path.join(__dirname, '..', 'public', 'feed', 'meta.csv'), csvContent, 'utf8');
    fs.writeFileSync(path.join(__dirname, '..', 'public', 'feed.xml'), xmlContent, 'utf8');

    console.log(`[FeedGenerator] Generated XML and CSV feeds with ${items.length} products.`);
  } catch (err) {
    console.error('[FeedGenerator] Error building static feeds:', err);
  }
}

buildStaticFeeds();
