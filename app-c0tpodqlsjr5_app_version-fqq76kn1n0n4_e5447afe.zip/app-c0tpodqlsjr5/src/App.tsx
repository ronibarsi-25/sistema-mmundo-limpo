import React, { Suspense, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { Loader2 } from 'lucide-react';
import IntersectObserver from '@/components/common/IntersectObserver';
import { Toaster } from '@/components/ui/sonner';
import { AuthProvider } from '@/contexts/AuthContext';
import { TenantProvider } from '@/contexts/TenantContext';
import { CartProvider } from '@/contexts/CartContext';
import { CompareProvider } from '@/contexts/CompareContext';
import { StoreProvider } from '@/contexts/StoreContext';
import { ThemeProvider } from '@/contexts/ThemeContext';
import { I18nProvider } from '@/i18n';
import { WhatsAppFAB } from '@/components/common/WhatsAppFAB';
import { LiveChatWidget } from '@/components/common/LiveChatWidget';
import { RouteGuard } from '@/components/common/RouteGuard';
import { AdminGuard } from '@/components/common/AdminGuard';
import { SubscriptionStatusGuard } from '@/components/common/SubscriptionStatusGuard';
import { metaPixel } from '@/utils/metaPixel';

import { routes } from './routes';

function MetaPixelTracker() {
  const location = useLocation();

  useEffect(() => {
    metaPixel.loadFromSupabase();
  }, []);

  useEffect(() => {
    metaPixel.trackPageView(location.pathname + location.search);
  }, [location.pathname, location.search]);

  return null;
}

function LoadingScreen() {
  return (
    <div className="flex min-h-screen w-full items-center justify-center bg-background">
      <div className="flex flex-col items-center gap-3">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <p className="text-sm text-muted-foreground">Carregando...</p>
      </div>
    </div>
  );
}

const App: React.FC = () => {
  return (
    <Router>
      <MetaPixelTracker />
      <I18nProvider>
      <AuthProvider>
        <TenantProvider>
          <StoreProvider>
          <ThemeProvider>
            <CartProvider>
              <CompareProvider>
                <RouteGuard>
                  <AdminGuard>
                    <SubscriptionStatusGuard>
                      <IntersectObserver />
                      <div className="flex flex-col min-h-screen">
                        <main className="flex-grow">
                          <Suspense fallback={<LoadingScreen />}>
                            <Routes>
                              {routes.map((route, index) => (
                                <Route key={index} path={route.path} element={route.element} />
                              ))}
                              <Route path="*" element={<Navigate to="/" replace />} />
                            </Routes>
                          </Suspense>
                        </main>
                      </div>
                      <Toaster />
                    </SubscriptionStatusGuard>
                  </AdminGuard>
                </RouteGuard>
              </CompareProvider>
            </CartProvider>
          </ThemeProvider>
        </StoreProvider>
        </TenantProvider>
      </AuthProvider>
      </I18nProvider>
      <WhatsAppFAB />
      <LiveChatWidget />
    </Router>
  );
};

export default App;
