import { useState, useRef, useCallback } from 'react';
import { Upload, Link, X, ImageIcon, Loader2, CheckCircle2, AlertCircle, Crop } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import Cropper from 'react-easy-crop';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { getCroppedImg } from '@/lib/cropImage';

interface ImageUploaderProps {
  value: string;
  onChange: (url: string) => void;
  label?: string;
  aspectRatio?: 'square' | 'video' | 'banner' | 'free';
  folder?: string;
  enableCrop?: boolean;
}

type Mode = 'url' | 'upload';

export function ImageUploader({
  value,
  onChange,
  label = 'Imagem',
  aspectRatio = 'square',
  folder = 'uploads',
  enableCrop = true,
}: ImageUploaderProps) {
  const [mode, setMode] = useState<Mode>('url');
  const [urlInput, setUrlInput] = useState(value || '');
  const [uploading, setUploading] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  // Crop state
  const [cropModalOpen, setCropModalOpen] = useState(false);
  const [imageToCrop, setImageToCrop] = useState<string | null>(null);
  const [crop, setCrop] = useState({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(1);
  const [croppedAreaPixels, setCroppedAreaPixels] = useState<any>(null);

  const aspectClass = {
    square: 'aspect-square',
    video: 'aspect-video',
    banner: 'aspect-[3/1]',
    free: 'aspect-video',
  }[aspectRatio];

  const aspectValue = {
    square: 1,
    video: 16 / 9,
    banner: 3 / 1,
    free: undefined,
  }[aspectRatio];

  // Commit URL digitada
  const handleUrlConfirm = () => {
    const trimmed = urlInput.trim();
    if (trimmed) {
      onChange(trimmed);
    }
  };

  // Upload arquivo para Supabase Storage
  const handleFileUpload = useCallback(async (file: File) => {
    if (!file.type.startsWith('image/')) {
      toast.error('Apenas imagens são permitidas.');
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      toast.error('Arquivo muito grande. Limite: 5 MB.');
      return;
    }

    if (enableCrop && aspectValue) {
      // Abre o modal de recorte em vez de fazer upload imediato
      const url = URL.createObjectURL(file);
      setImageToCrop(url);
      setCropModalOpen(true);
      return;
    }

    await performUpload(file);
  }, [enableCrop, aspectValue]);

  const performUpload = async (file: File) => {
    setUploading(true);
    try {
      const ext = file.name.split('.').pop()?.toLowerCase() || 'jpg';
      const fileName = `${folder}/${Date.now()}_${Math.random().toString(36).slice(2)}.${ext}`;

      const { error } = await supabase.storage
        .from('store-images')
        .upload(fileName, file, { upsert: false, cacheControl: '3600' });

      if (error) {
        toast.error('Erro ao enviar imagem: ' + error.message);
        return;
      }

      const { data } = supabase.storage
        .from('store-images')
        .getPublicUrl(fileName);

      if (data?.publicUrl) {
        onChange(data.publicUrl);
        setUrlInput(data.publicUrl);
        toast.success('Imagem enviada com sucesso!');
      }
    } catch (e) {
      toast.error('Erro inesperado ao enviar imagem.');
    } finally {
      setUploading(false);
    }
  };

  const onCropComplete = useCallback((croppedArea: any, croppedAreaPixels: any) => {
    setCroppedAreaPixels(croppedAreaPixels);
  }, []);

  const handleCropAndUpload = async () => {
    if (!imageToCrop || !croppedAreaPixels) return;
    
    try {
      setUploading(true);
      setCropModalOpen(false);
      
      const croppedFile = await getCroppedImg(imageToCrop, croppedAreaPixels);
      if (croppedFile) {
        await performUpload(croppedFile);
      }
    } catch (e) {
      console.error(e);
      toast.error('Erro ao processar imagem para corte.');
      setUploading(false);
    } finally {
      URL.revokeObjectURL(imageToCrop);
      setImageToCrop(null);
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleFileUpload(file);
    // reset input so same file can be re-selected
    e.target.value = '';
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) handleFileUpload(file);
  };

  const handleClear = () => {
    onChange('');
    setUrlInput('');
  };

  return (
    <div className="space-y-2">
      {label && <p className="text-sm font-normal text-muted-foreground">{label}</p>}

      {/* Preview */}
      <div className={cn('relative w-full rounded-xl overflow-hidden bg-muted border border-border', aspectClass)}>
        {value ? (
          <>
            <img src={value} alt="Pré-visualização" className="w-full h-full object-cover" />
            <button
              type="button"
              onClick={handleClear}
              className="absolute top-2 right-2 h-7 w-7 rounded-full bg-background/80 border border-border flex items-center justify-center hover:bg-background transition-colors"
            >
              <X className="h-3.5 w-3.5 text-foreground" />
            </button>
          </>
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center gap-2 text-muted-foreground">
            <ImageIcon className="h-8 w-8 opacity-30" />
            <p className="text-xs">Sem imagem</p>
          </div>
        )}
        {uploading && (
          <div className="absolute inset-0 bg-background/70 flex items-center justify-center">
            <Loader2 className="h-7 w-7 animate-spin text-accent" />
          </div>
        )}
      </div>

      {/* Mode toggle */}
      <div className="flex rounded-lg border border-border overflow-hidden">
        <button
          type="button"
          onClick={() => setMode('url')}
          className={cn(
            'flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-medium transition-colors',
            mode === 'url' ? 'bg-accent text-accent-foreground' : 'bg-card text-muted-foreground hover:bg-muted'
          )}
        >
          <Link className="h-3.5 w-3.5" />
          URL
        </button>
        <button
          type="button"
          onClick={() => setMode('upload')}
          className={cn(
            'flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-medium transition-colors',
            mode === 'upload' ? 'bg-accent text-accent-foreground' : 'bg-card text-muted-foreground hover:bg-muted'
          )}
        >
          <Upload className="h-3.5 w-3.5" />
          Arquivo Local
        </button>
      </div>

      {/* URL mode */}
      {mode === 'url' && (
        <div className="flex gap-2">
          <Input
            value={urlInput}
            onChange={e => setUrlInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && (e.preventDefault(), handleUrlConfirm())}
            placeholder="https://exemplo.com/imagem.jpg"
            className="h-9 text-xs flex-1"
          />
          <Button type="button" size="sm" variant="secondary" className="h-9 shrink-0" onClick={handleUrlConfirm}>
            Usar
          </Button>
        </div>
      )}

      {/* Upload mode */}
      {mode === 'upload' && (
        <div
          onDrop={handleDrop}
          onDragOver={e => { e.preventDefault(); setDragOver(true); }}
          onDragLeave={() => setDragOver(false)}
          className={cn(
            'relative rounded-xl border-2 border-dashed p-4 flex flex-col items-center justify-center gap-2 transition-colors cursor-pointer',
            dragOver ? 'border-accent bg-accent/5' : 'border-border bg-muted/30 hover:border-accent/60 hover:bg-accent/5'
          )}
          onClick={() => !uploading && inputRef.current?.click()}
        >
          {uploading ? (
            <Loader2 className="h-6 w-6 animate-spin text-accent" />
          ) : dragOver ? (
            <CheckCircle2 className="h-6 w-6 text-accent" />
          ) : (
            <Upload className="h-6 w-6 text-muted-foreground" />
          )}
          <div className="text-center">
            <p className="text-xs font-medium text-foreground">
              {uploading ? 'Enviando...' : 'Clique ou arraste uma imagem'}
            </p>
            <p className="text-[11px] text-muted-foreground mt-0.5">JPG, PNG, WebP, GIF — até 5 MB</p>
          </div>
          <input
            ref={inputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={handleFileInputChange}
          />
        </div>
      )}

      {/* Warning if external URL has potential issue */}
      {mode === 'url' && value && !value.startsWith('http') && (
        <div className="flex items-center gap-1.5 text-[11px] text-warning-foreground">
          <AlertCircle className="h-3 w-3" />
          URL inválida. Verifique o endereço da imagem.
        </div>
      )}

      {/* Crop Dialog */}
      <Dialog open={cropModalOpen} onOpenChange={(open) => {
        if (!open) {
          setCropModalOpen(false);
          if (imageToCrop) URL.revokeObjectURL(imageToCrop);
          setImageToCrop(null);
        }
      }}>
        <DialogContent className="max-w-2xl w-full p-0 overflow-hidden bg-background">
          <DialogHeader className="p-4 pb-2 border-b border-border">
            <DialogTitle className="text-lg font-bold flex items-center gap-2">
              <Crop className="w-5 h-5 text-primary" />
              Ajustar Imagem
            </DialogTitle>
          </DialogHeader>
          <div className="relative w-full h-[60vh] bg-black/90">
            {imageToCrop && (
              <Cropper
                image={imageToCrop}
                crop={crop}
                zoom={zoom}
                aspect={aspectValue || 1}
                onCropChange={setCrop}
                onZoomChange={setZoom}
                onCropComplete={onCropComplete}
                objectFit="contain"
              />
            )}
          </div>
          <div className="p-4 border-t border-border flex flex-col gap-4">
            <div className="flex items-center gap-4">
              <span className="text-sm font-medium text-muted-foreground w-12">Zoom</span>
              <input
                type="range"
                value={zoom}
                min={1}
                max={3}
                step={0.1}
                aria-label="Zoom"
                onChange={(e) => setZoom(Number(e.target.value))}
                className="flex-1 accent-primary"
              />
            </div>
            <DialogFooter className="flex items-center justify-end gap-2">
              <Button variant="outline" onClick={() => setCropModalOpen(false)}>
                Cancelar
              </Button>
              <Button onClick={handleCropAndUpload} className="gap-2">
                <Crop className="w-4 h-4" />
                Cortar e Enviar
              </Button>
            </DialogFooter>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
