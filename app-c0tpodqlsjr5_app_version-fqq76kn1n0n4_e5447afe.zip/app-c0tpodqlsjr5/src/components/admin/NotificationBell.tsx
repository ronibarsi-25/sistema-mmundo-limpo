import { useState, useEffect } from 'react';
import { Bell, Package, CheckCircle2, Clock } from 'lucide-react';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';

interface Notification {
  id: string;
  title: string;
  message: string;
  time: Date;
  read: boolean;
  type: 'order' | 'system';
  data?: any;
}

export function NotificationBell() {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const navigate = useNavigate();

  useEffect(() => {
    // Carregar notificações salvas no localStorage (opcional, para persistência simples)
    const saved = localStorage.getItem('admin_notifications');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setNotifications(parsed.map((n: any) => ({ ...n, time: new Date(n.time) })));
        setUnreadCount(parsed.filter((n: any) => !n.read).length);
      } catch (e) {
        console.error('Erro ao carregar notificações', e);
      }
    }

    // Inscrever para novos pedidos
    const channel = supabase
      .channel('admin-orders')
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'orders' },
        (payload) => {
          const newOrder = payload.new as any;
          const notification: Notification = {
            id: crypto.randomUUID(),
            title: 'Novo Pedido!',
            message: `Pedido #${newOrder.order_number || newOrder.id.slice(0, 8)} de ${newOrder.customer_name || 'Cliente'}`,
            time: new Date(),
            read: false,
            type: 'order',
            data: { orderId: newOrder.id }
          };

          setNotifications(prev => {
            const updated = [notification, ...prev].slice(0, 20); // Manter as últimas 20
            localStorage.setItem('admin_notifications', JSON.stringify(updated));
            return updated;
          });
          setUnreadCount(prev => prev + 1);

          // Alerta sonoro (opcional)
          try {
            const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3');
            audio.play();
          } catch (e) {
            console.warn('Erro ao tocar som de notificação', e);
          }

          // Toast visual
          toast.success('Novo pedido recebido!', {
            description: notification.message,
            action: {
              label: 'Ver Pedido',
              onClick: () => navigate(`/admin/pedidos`)
            }
          });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [navigate]);

  const markAsRead = (id: string) => {
    setNotifications(prev => {
      const updated = prev.map(n => n.id === id ? { ...n, read: true } : n);
      localStorage.setItem('admin_notifications', JSON.stringify(updated));
      return updated;
    });
    setUnreadCount(prev => Math.max(0, prev - 1));
  };

  const markAllAsRead = () => {
    setNotifications(prev => {
      const updated = prev.map(n => ({ ...n, read: true }));
      localStorage.setItem('admin_notifications', JSON.stringify(updated));
      return updated;
    });
    setUnreadCount(0);
  };

  const handleNotificationClick = (n: Notification) => {
    markAsRead(n.id);
    if (n.type === 'order') {
      navigate('/admin/pedidos');
    }
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="relative">
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <Badge 
              className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 bg-destructive text-destructive-foreground border-2 border-background animate-in zoom-in"
              variant="default"
            >
              {unreadCount > 9 ? '9+' : unreadCount}
            </Badge>
          )}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-80 p-0">
        <DropdownMenuLabel className="p-4 flex items-center justify-between">
          <span>Notificações</span>
          {unreadCount > 0 && (
            <Button variant="ghost" size="sm" className="h-auto p-0 text-xs text-primary" onClick={markAllAsRead}>
              Marcar todas como lidas
            </Button>
          )}
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <div className="max-h-[300px] overflow-y-auto">
          {notifications.length === 0 ? (
            <div className="p-8 text-center text-muted-foreground">
              <Clock className="h-8 w-8 mx-auto mb-2 opacity-20" />
              <p className="text-sm">Nenhuma notificação</p>
            </div>
          ) : (
            notifications.map(n => (
              <DropdownMenuItem 
                key={n.id} 
                className={cn(
                  "p-4 cursor-pointer flex gap-3 focus:bg-accent",
                  !n.read && "bg-accent/30"
                )}
                onSelect={() => handleNotificationClick(n)}
              >
                <div className={cn(
                  "h-8 w-8 rounded-full flex items-center justify-center shrink-0",
                  n.read ? "bg-muted" : "bg-primary/10"
                )}>
                  {n.type === 'order' ? (
                    <Package className={cn("h-4 w-4", !n.read ? "text-primary" : "text-muted-foreground")} />
                  ) : (
                    <CheckCircle2 className="h-4 w-4 text-muted-foreground" />
                  )}
                </div>
                <div className="flex-1 min-w-0 space-y-1">
                  <div className="flex items-center justify-between gap-2">
                    <p className={cn("text-sm font-medium leading-none truncate", !n.read && "font-bold")}>
                      {n.title}
                    </p>
                    <span className="text-[10px] text-muted-foreground whitespace-nowrap">
                      {n.time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground line-clamp-2">
                    {n.message}
                  </p>
                </div>
              </DropdownMenuItem>
            ))
          )}
        </div>
        <DropdownMenuSeparator />
        <div className="p-2">
          <Button variant="ghost" className="w-full text-xs" size="sm" onClick={() => navigate('/admin/pedidos')}>
            Ver todos os pedidos
          </Button>
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
