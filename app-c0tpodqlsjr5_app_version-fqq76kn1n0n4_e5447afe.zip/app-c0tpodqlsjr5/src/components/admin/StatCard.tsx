import { type LucideIcon } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';

interface StatCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  color: string;
  trend?: string;
  trendUp?: boolean;
  loading?: boolean;
}

const COLOR_BG: Record<string, string> = {
  primary: 'bg-primary/10 text-primary',
  accent: 'bg-accent/10 text-accent',
  success: 'bg-success/10 text-success',
  info: 'bg-info/10 text-info',
  warning: 'bg-warning/10 text-warning',
  destructive: 'bg-destructive/10 text-destructive',
};

export function StatCard({ title, value, icon: Icon, color, trend, trendUp, loading }: StatCardProps) {
  const bgClass = COLOR_BG[color] || COLOR_BG.primary;

  return (
    <Card className="card-hover">
      <CardContent className="p-4 md:p-5">
        {loading ? (
          <div className="space-y-3">
            <Skeleton className="h-9 bg-muted" />
            <Skeleton className="h-4 w-24 bg-muted" />
          </div>
        ) : (
          <div className="flex items-start justify-between">
            <div className="min-w-0 flex-1">
              <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">{title}</p>
              <p className="text-xl md:text-2xl font-bold text-foreground mt-1">{value}</p>
              {trend && (
                <p className={`text-xs font-medium mt-1.5 ${trendUp ? 'text-success' : 'text-destructive'}`}>
                  {trendUp ? '+' : ''}{trend}
                </p>
              )}
            </div>
            <div className={`h-10 w-10 rounded-xl flex items-center justify-center shrink-0 ${bgClass}`}>
              <Icon className="h-5 w-5" />
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
