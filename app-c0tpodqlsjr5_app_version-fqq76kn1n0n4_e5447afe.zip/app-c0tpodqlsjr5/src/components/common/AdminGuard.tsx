import { useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { ShieldOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

interface AdminGuardProps {
  children: React.ReactNode;
}

// Paths that start with /admin but do NOT require admin role
const ADMIN_PUBLIC_PATHS = ['/admin/login'];

export function AdminGuard({ children }: AdminGuardProps) {
  const { user, profile, loading } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const isAdminPublic = ADMIN_PUBLIC_PATHS.some(p => location.pathname === p);
  const isAdminPath = location.pathname.startsWith('/admin') && !isAdminPublic;

  useEffect(() => {
    if (loading) return;
    if (!isAdminPath) return;

    // Not logged in → admin login
    if (!user) {
      navigate('/admin/login', { replace: true });
      return;
    }
    // Logged in but not admin → redirect
    if (profile && profile.role !== 'admin') {
      // Will show access denied UI below
    }
  }, [user, profile, loading, location.pathname, isAdminPath, navigate]);

  if (loading || !isAdminPath) return <>{children}</>;

  // Not logged in: redirect handled by effect, show spinner
  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary" />
      </div>
    );
  }

  // Profile loading
  if (!profile) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary" />
      </div>
    );
  }

  // Logged in but not admin
  if (profile.role !== 'admin') {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen gap-5 px-4 text-center">
        <div className="h-16 w-16 rounded-full bg-destructive/10 flex items-center justify-center">
          <ShieldOff className="h-8 w-8 text-destructive" />
        </div>
        <div>
          <h1 className="text-xl font-bold text-foreground">Acesso Negado</h1>
          <p className="text-sm text-muted-foreground mt-1 max-w-xs text-pretty">
            Sua conta não tem permissão de administrador. Solicite acesso ou entre com uma conta admin.
          </p>
        </div>
        <div className="flex flex-col sm:flex-row gap-3">
          <Button asChild variant="outline">
            <Link to="/">Ir para a Loja</Link>
          </Button>
          <Button asChild className="bg-primary text-primary-foreground hover:bg-primary/90">
            <Link to="/admin/login">Login Admin</Link>
          </Button>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}
