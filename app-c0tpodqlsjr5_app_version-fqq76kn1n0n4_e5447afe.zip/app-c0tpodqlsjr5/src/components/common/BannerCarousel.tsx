import { useState, useEffect, useCallback, useRef } from 'react';
import { Link } from 'react-router-dom';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/db/supabase';
import type { Banner } from '@/types/types';

export function BannerCarousel() {
  const [banners, setBanners] = useState<Banner[]>([]);
  const [current, setCurrent] = useState(0);
  const [loading, setLoading] = useState(true);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const fetchBanners = useCallback(async () => {
    const { data } = await supabase
      .from('banners')
      .select('*')
      .eq('is_active', true)
      .order('sort_order', { ascending: true });
    setBanners(Array.isArray(data) ? data as Banner[] : []);
    setLoading(false);
  }, []);

  useEffect(() => { fetchBanners(); }, [fetchBanners]);

  // Auto-play
  useEffect(() => {
    if (banners.length <= 1) return;
    timerRef.current = setInterval(() => setCurrent(c => (c + 1) % banners.length), 5000);
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [banners.length]);

  const goTo = (idx: number) => {
    setCurrent(idx);
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = setInterval(() => setCurrent(c => (c + 1) % banners.length), 5000);
  };

  const prev = () => goTo((current - 1 + banners.length) % banners.length);
  const next = () => goTo((current + 1) % banners.length);

  if (loading) {
    return <div className="w-full aspect-[4/3] md:aspect-[16/5] bg-muted animate-pulse rounded-xl" />;
  }
  if (banners.length === 0) return null;

  const banner = banners[current];

  return (
    <div className="relative w-full overflow-hidden rounded-xl aspect-[4/3] md:aspect-[16/5] bg-muted group">
      {/* Imagens */}
      {banners.map((b, i) => (
        <div key={b.id}
          className={`absolute inset-0 transition-opacity duration-700 ${i === current ? 'opacity-100 z-10' : 'opacity-0 z-0'}`}>
          <img src={b.image_url} alt={b.title} className="w-full h-full object-cover" />
          {/* Overlay gradiente */}
          <div className="absolute inset-0 bg-gradient-to-r from-black/60 via-black/30 to-transparent" />
        </div>
      ))}

      {/* Conteúdo */}
      <div className="absolute inset-0 z-20 flex items-center">
        <div className="px-6 md:px-12 max-w-xl">
          <h2 className="text-xl md:text-3xl font-bold text-white text-balance leading-tight drop-shadow-md">
            {banner.title}
          </h2>
          {banner.subtitle && (
            <p className="text-sm md:text-base text-white/85 mt-2 text-pretty drop-shadow">
              {banner.subtitle}
            </p>
          )}
          {banner.cta_text && (
            <Link to={banner.cta_link} className="inline-block mt-4">
              <Button className="bg-primary text-primary-foreground hover:bg-primary/90 h-9 md:h-10 shadow-lg text-sm font-semibold">
                {banner.cta_text}
              </Button>
            </Link>
          )}
        </div>
      </div>

      {/* Controles de navegação (apenas quando mais de 1) */}
      {banners.length > 1 && (
        <>
          <button onClick={prev}
            className="absolute left-3 top-1/2 -translate-y-1/2 z-30 h-9 w-9 rounded-full bg-black/40 hover:bg-black/60 transition-colors flex items-center justify-center text-white opacity-0 group-hover:opacity-100">
            <ChevronLeft className="h-5 w-5" />
          </button>
          <button onClick={next}
            className="absolute right-3 top-1/2 -translate-y-1/2 z-30 h-9 w-9 rounded-full bg-black/40 hover:bg-black/60 transition-colors flex items-center justify-center text-white opacity-0 group-hover:opacity-100">
            <ChevronRight className="h-5 w-5" />
          </button>

          {/* Indicadores */}
          <div className="absolute bottom-3 left-1/2 -translate-x-1/2 z-30 flex gap-1.5">
            {banners.map((_, i) => (
              <button key={i} onClick={() => goTo(i)}
                className={`h-1.5 rounded-full transition-all ${i === current ? 'w-6 bg-white' : 'w-1.5 bg-white/50 hover:bg-white/75'}`} />
            ))}
          </div>
        </>
      )}
    </div>
  );
}
