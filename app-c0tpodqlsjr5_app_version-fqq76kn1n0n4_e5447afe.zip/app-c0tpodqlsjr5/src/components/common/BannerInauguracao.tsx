import { useState, useEffect } from 'react';
import { Copy, Check, MessageCircle, X, PartyPopper, Sparkles, Gift, Link2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';

interface InaugurationBanner {
  id: string;
  is_active: boolean;
  store_name: string;
  headline: string;
  subtitle: string | null;
  coupon_code: string;
  discount_text: string;
  whatsapp_message: string | null;
  expires_at: string | null;
}

export function BannerInauguracao() {
  const [banner, setBanner] = useState<InaugurationBanner | null>(null);
  const [dismissed, setDismissed] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const wasDismissed = sessionStorage.getItem('inauguration_banner_dismissed');
    if (wasDismissed) { setDismissed(true); return; }

    supabase
      .from('inauguration_banner')
      .select('*')
      .eq('is_active', true)
      .limit(1)
      .maybeSingle()
      .then(({ data }) => {
        if (!data) return;
        // Não exibir se expirado
        if (data.expires_at && new Date(data.expires_at) < new Date()) return;
        setBanner(data);
      });
  }, []);

  const handleDismiss = () => {
    sessionStorage.setItem('inauguration_banner_dismissed', '1');
    setDismissed(true);
  };

  const handleCopy = async () => {
    if (!banner) return;
    try {
      await navigator.clipboard.writeText(banner.coupon_code);
      setCopied(true);
      toast.success(`Cupom ${banner.coupon_code} copiado!`);
      setTimeout(() => setCopied(false), 3000);
    } catch {
      toast.error('Não foi possível copiar. Copie manualmente: ' + banner.coupon_code);
    }
  };

  const getShareText = () => {
    if (!banner) return '';
    const expiryStr = banner.expires_at
      ? new Date(banner.expires_at).toLocaleDateString('pt-BR')
      : 'em breve';
    const url = window.location.origin;
    return (banner.whatsapp_message || '🎉 Inauguração {store}! Use o cupom *{coupon}* e ganhe {discount}! Válido até {expiry}. Acesse: {url}')
      .replace('{store}', banner.store_name || 'Mundo Limpo')
      .replace('{coupon}', banner.coupon_code)
      .replace('{discount}', banner.discount_text)
      .replace('{expiry}', expiryStr)
      .replace('{url}', url);
  };

  const handleWhatsApp = () => {
    if (!banner) return;
    window.open(`https://wa.me/?text=${encodeURIComponent(getShareText())}`, '_blank');
  };

  const handleFacebook = () => {
    if (!banner) return;
    window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(window.location.origin)}`, '_blank');
  };

  const handleTwitter = () => {
    if (!banner) return;
    window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(getShareText())}`, '_blank');
  };

  const handleLinkedIn = () => {
    if (!banner) return;
    window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(window.location.origin)}`, '_blank');
  };

  const handleTelegram = () => {
    if (!banner) return;
    window.open(`https://t.me/share/url?url=${encodeURIComponent(window.location.origin)}&text=${encodeURIComponent(getShareText())}`, '_blank');
  };

  const handleCopyLink = async () => {
    if (!banner) return;
    try {
      await navigator.clipboard.writeText(getShareText());
      toast.success('Link e mensagem copiados!');
    } catch {
      toast.error('Não foi possível copiar.');
    }
  };

  if (!banner || dismissed) return null;

  const expiryDate = banner.expires_at
    ? new Date(banner.expires_at).toLocaleDateString('pt-BR')
    : null;

  return (
    <div className="w-full relative overflow-hidden">
      {/* Fundo com gradiente festivo */}
      <div className="bg-gradient-to-br from-emerald-600 via-green-700 to-teal-800 text-white">
        {/* Decoração de confetes em SVG */}
        <div className="absolute inset-0 opacity-10 pointer-events-none" aria-hidden>
          <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
            <circle cx="5%" cy="20%" r="4" fill="#fff" />
            <circle cx="15%" cy="70%" r="3" fill="#fbbf24" />
            <circle cx="25%" cy="40%" r="5" fill="#f472b6" />
            <circle cx="35%" cy="85%" r="3" fill="#fff" />
            <circle cx="50%" cy="15%" r="4" fill="#fbbf24" />
            <circle cx="65%" cy="60%" r="5" fill="#fff" />
            <circle cx="75%" cy="30%" r="3" fill="#f472b6" />
            <circle cx="85%" cy="75%" r="4" fill="#fbbf24" />
            <circle cx="95%" cy="45%" r="3" fill="#fff" />
            <rect x="10%" y="50%" width="6" height="6" fill="#fbbf24" transform="rotate(30)" />
            <rect x="45%" y="80%" width="8" height="4" fill="#f472b6" transform="rotate(-20)" />
            <rect x="70%" y="20%" width="6" height="6" fill="#fff" transform="rotate(45)" />
          </svg>
        </div>

        <div className="relative max-w-7xl mx-auto px-4 md:px-6 py-6 md:py-8">
          {/* Botão fechar */}
          <button
            onClick={handleDismiss}
            className="absolute top-3 right-3 md:top-4 md:right-4 h-7 w-7 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center transition-colors"
            aria-label="Fechar banner"
          >
            <X className="h-4 w-4" />
          </button>

          <div className="flex flex-col md:flex-row items-center gap-5 md:gap-8">
            {/* Ícone festivo */}
            <div className="shrink-0 hidden md:flex h-20 w-20 rounded-2xl bg-white/15 items-center justify-center shadow-lg">
              <PartyPopper className="h-10 w-10 text-yellow-300" />
            </div>

            {/* Conteúdo principal */}
            <div className="flex-1 min-w-0 text-center md:text-left space-y-2">
              <div className="flex items-center justify-center md:justify-start gap-2 flex-wrap">
                <PartyPopper className="h-5 w-5 text-yellow-300 md:hidden shrink-0" />
                <h2 className="text-lg md:text-2xl font-bold text-white text-balance leading-tight">
                  {banner.headline}
                </h2>
                <Sparkles className="h-5 w-5 text-yellow-300 shrink-0" />
              </div>
              {banner.subtitle && (
                <p className="text-sm md:text-base text-white/85 text-pretty max-w-lg">
                  {banner.subtitle}
                </p>
              )}
              {expiryDate && (
                <p className="text-xs text-white/70">
                  ⏰ Válido até {expiryDate}
                </p>
              )}
            </div>

            {/* Card do cupom */}
            <div className="shrink-0 w-full md:w-auto">
              <div className="bg-white/15 backdrop-blur-sm border border-white/30 rounded-2xl p-4 md:p-5 space-y-3 min-w-0 md:min-w-[260px]">
                {/* Badge desconto */}
                <div className="flex items-center justify-center gap-1.5">
                  <Gift className="h-4 w-4 text-yellow-300" />
                  <span className="text-sm font-bold text-yellow-300">{banner.discount_text}</span>
                </div>

                {/* Código do cupom */}
                <div className="bg-white/10 border-2 border-dashed border-white/50 rounded-xl px-4 py-3 flex items-center justify-between gap-3">
                  <span className="text-xl md:text-2xl font-black tracking-widest text-white font-mono">
                    {banner.coupon_code}
                  </span>
                  <button
                    onClick={handleCopy}
                    className="h-9 w-9 rounded-lg bg-white/20 hover:bg-white/35 flex items-center justify-center transition-colors shrink-0"
                    aria-label="Copiar cupom"
                  >
                    {copied
                      ? <Check className="h-4 w-4 text-green-300" />
                      : <Copy className="h-4 w-4 text-white" />}
                  </button>
                </div>

                {/* Botões de ação */}
                <div className="flex gap-2">
                  <Button
                    onClick={handleCopy}
                    size="sm"
                    className="flex-1 bg-white text-emerald-700 hover:bg-white/90 font-semibold h-9 text-xs"
                  >
                    {copied ? <><Check className="h-3.5 w-3.5 mr-1.5" /> Copiado!</> : <><Copy className="h-3.5 w-3.5 mr-1.5" /> Copiar Cupom</>}
                  </Button>
                  <Button
                    onClick={handleWhatsApp}
                    size="sm"
                    className="flex-1 bg-[#25D366] hover:bg-[#20b558] text-white font-semibold h-9 text-xs border-0"
                  >
                    <MessageCircle className="h-3.5 w-3.5 mr-1.5" /> WhatsApp
                  </Button>
                </div>

                {/* Redes sociais */}
                <div className="flex items-center justify-center gap-2 pt-1">
                  <button onClick={handleFacebook} className="h-8 w-8 rounded-lg bg-white/15 hover:bg-white/30 flex items-center justify-center transition-colors" aria-label="Facebook">
                    <svg className="h-4 w-4" fill="currentColor" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669c1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
                  </button>
                  <button onClick={handleTwitter} className="h-8 w-8 rounded-lg bg-white/15 hover:bg-white/30 flex items-center justify-center transition-colors" aria-label="Twitter">
                    <svg className="h-4 w-4" fill="currentColor" viewBox="0 0 24 24"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
                  </button>
                  <button onClick={handleLinkedIn} className="h-8 w-8 rounded-lg bg-white/15 hover:bg-white/30 flex items-center justify-center transition-colors" aria-label="LinkedIn">
                    <svg className="h-4 w-4" fill="currentColor" viewBox="0 0 24 24"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>
                  </button>
                  <button onClick={handleTelegram} className="h-8 w-8 rounded-lg bg-white/15 hover:bg-white/30 flex items-center justify-center transition-colors" aria-label="Telegram">
                    <svg className="h-4 w-4" fill="currentColor" viewBox="0 0 24 24"><path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.479.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/></svg>
                  </button>
                  <button onClick={handleCopyLink} className="h-8 w-8 rounded-lg bg-white/15 hover:bg-white/30 flex items-center justify-center transition-colors" aria-label="Copiar link">
                    <Link2 className="h-4 w-4" />
                  </button>
                </div>

                <p className="text-[10px] text-white/60 text-center">
                  Toque em "Copiar Cupom" e use no checkout
                </p>
              </div>
            </div>
          </div>

          {/* Badges decorativos no fundo */}
          <div className="mt-4 flex flex-wrap gap-2 justify-center md:justify-start">
            {['🎉 Inauguração Especial', '✅ Sem código mínimo', '🚚 Entrega para todo Brasil'].map(tag => (
              <Badge key={tag} className="bg-white/15 text-white border-white/30 text-xs font-normal hover:bg-white/20">
                {tag}
              </Badge>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
