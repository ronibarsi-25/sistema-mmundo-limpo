import { useState, useRef, useEffect } from 'react';
import { MessageSquare, X, Send, Bot, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

interface ChatMessage {
  id: string;
  role: 'user' | 'bot';
  text: string;
  time: string;
}

const WHATSAPP_NUMBER = '5531987774702';

const QUICK_REPLIES = [
  'Quais produtos vocês vendem?',
  'Qual o prazo de entrega?',
  'Vocês aceitam pix?',
  'Como faço para comprar?',
];

export function LiveChatWidget() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      role: 'bot',
      text: 'Olá! Bem-vindo à Mundo Limpo. Como posso ajudar você hoje?',
      time: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [input, setInput] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages, open]);

  const sendMessage = (text: string) => {
    if (!text.trim()) return;
    const now = new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
    const userMsg: ChatMessage = { id: Date.now().toString(), role: 'user', text: text.trim(), time: now };
    setMessages(prev => [...prev, userMsg]);
    setInput('');

    // Simular resposta do bot
    setTimeout(() => {
      const lower = text.trim().toLowerCase();
      let reply = 'Entendi! Para mais informações, posso te encaminhar para um de nossos atendentes no WhatsApp.';
      if (lower.includes('produto') || lower.includes('vend')) reply = 'Temos uma linha completa de produtos de limpeza! Acesse nosso catálogo em /produtos ou fale conosco no WhatsApp para recomendações personalizadas.';
      else if (lower.includes('entrega') || lower.includes('prazo') || lower.includes('frete')) reply = 'Fazemos entregas em toda a região. O prazo varia de 1 a 5 dias úteis dependendo da localidade. No WhatsApp podemos calcular o frete exato para você!';
      else if (lower.includes('pix') || lower.includes('pagamento') || lower.includes('cartão')) reply = 'Aceitamos Pix, cartão de crédito em até 12x, e boleto bancário. Na finalização do pedido você escolhe a forma de pagamento.';
      else if (lower.includes('comprar') || lower.includes('pedido')) reply = 'Para comprar, basta adicionar os produtos ao carrinho e finalizar o pedido. Se precisar de ajuda, nossos atendentes no WhatsApp estão prontos para auxiliar!';
      else if (lower.includes('horário') || lower.includes('funcionamento') || lower.includes('aberto')) reply = 'Nosso atendimento online funciona de segunda a sábado, das 8h às 18h. Fora desse horário, deixe uma mensagem no WhatsApp que respondemos assim que possível!';

      const botMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'bot',
        text: reply,
        time: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages(prev => [...prev, botMsg]);
    }, 1200);
  };

  const openWhatsApp = () => {
    const msg = encodeURIComponent('Olá! Estava conversando no chat do site e gostaria de falar com um atendente.');
    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${msg}`, '_blank');
  };

  return (
    <div className="fixed bottom-5 left-5 z-50 flex flex-col items-start gap-2">
      {open && (
        <div className="mb-2 bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-border/50 w-80 sm:w-96 overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-200 flex flex-col max-h-[70vh]">
          {/* Header */}
          <div className="bg-gradient-to-r from-emerald-600 to-teal-700 px-4 py-3 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="h-9 w-9 rounded-full bg-white/20 flex items-center justify-center">
                <Bot className="h-5 w-5 text-white" />
              </div>
              <div>
                <p className="text-sm font-bold text-white">Atendimento Mundo Limpo</p>
                <p className="text-[10px] text-white/80 flex items-center gap-1">
                  <span className="h-1.5 w-1.5 rounded-full bg-green-300 inline-block animate-pulse" />
                  Online
                </p>
              </div>
            </div>
            <button onClick={() => setOpen(false)} className="h-7 w-7 rounded-full bg-white/15 hover:bg-white/25 flex items-center justify-center transition-colors">
              <X className="h-4 w-4 text-white" />
            </button>
          </div>

          {/* Messages */}
          <div ref={scrollRef} className="flex-1 overflow-y-auto p-3 space-y-3 min-h-[200px]">
            {messages.map(m => (
              <div key={m.id} className={`flex gap-2 ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                {m.role === 'bot' && (
                  <div className="h-7 w-7 rounded-full bg-emerald-100 dark:bg-emerald-900 flex items-center justify-center shrink-0 mt-0.5">
                    <Bot className="h-3.5 w-3.5 text-emerald-600 dark:text-emerald-400" />
                  </div>
                )}
                <div className={`max-w-[75%] px-3 py-2 rounded-2xl text-sm ${m.role === 'user' ? 'bg-accent text-accent-foreground rounded-br-md' : 'bg-muted text-foreground rounded-bl-md'}`}>
                  <p className="text-sm leading-relaxed">{m.text}</p>
                  <p className={`text-[10px] mt-1 ${m.role === 'user' ? 'text-accent-foreground/60' : 'text-muted-foreground'}`}>{m.time}</p>
                </div>
                {m.role === 'user' && (
                  <div className="h-7 w-7 rounded-full bg-accent/20 flex items-center justify-center shrink-0 mt-0.5">
                    <User className="h-3.5 w-3.5 text-accent" />
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Quick replies */}
          <div className="px-3 pb-2 flex flex-wrap gap-1.5">
            {QUICK_REPLIES.map(qr => (
              <button
                key={qr}
                onClick={() => sendMessage(qr)}
                className="text-[11px] px-2.5 py-1 rounded-full bg-muted hover:bg-muted/80 text-muted-foreground transition-colors"
              >
                {qr}
              </button>
            ))}
          </div>

          {/* Input */}
          <div className="p-3 border-t border-border/50 flex items-center gap-2">
            <Input
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && sendMessage(input)}
              placeholder="Digite sua mensagem..."
              className="h-9 text-sm flex-1"
            />
            <Button size="icon" className="h-9 w-9 shrink-0 bg-emerald-600 hover:bg-emerald-700" onClick={() => sendMessage(input)}>
              <Send className="h-4 w-4" />
            </Button>
          </div>

          {/* WhatsApp CTA */}
          <button
            onClick={openWhatsApp}
            className="w-full py-2 bg-[#25D366]/10 hover:bg-[#25D366]/20 text-[#25D366] text-xs font-medium flex items-center justify-center gap-1.5 transition-colors"
          >
            <MessageSquare className="h-3.5 w-3.5" />
            Falar com atendente no WhatsApp
          </button>
        </div>
      )}

      <button
        onClick={() => setOpen(!open)}
        className={`h-14 w-14 rounded-full shadow-xl flex items-center justify-center transition-all duration-300 ${open ? 'bg-slate-700 hover:bg-slate-800' : 'bg-gradient-to-br from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700'}`}
        aria-label="Abrir chat"
      >
        {open ? <X className="h-6 w-6 text-white" /> : <MessageSquare className="h-6 w-6 text-white" />}
      </button>
    </div>
  );
}
