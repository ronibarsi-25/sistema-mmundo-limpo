import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Heart, ShoppingCart, GitCompare, Share2, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { useCart } from '@/contexts/CartContext';
import { useAuth } from '@/contexts/AuthContext';
import { useCompare } from '@/contexts/CompareContext';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import type { Product, Promotion } from '@/types/types';
import { cn } from '@/lib/utils';
import { getPromotionalPrice } from '@/hooks/usePromotions';

interface ProductCardProps {
  product: Product;
  className?: string;
  promotions?: Promotion[];
  inWishlist?: boolean;
}

export function ProductCard({ product, className, promotions = [], inWishlist: inWishlistProp = false }: ProductCardProps) {
  const { addItem } = useCart();
  const { user } = useAuth();
  const { addToCompare, isInCompare, removeFromCompare } = useCompare();
  const [inWishlist, setInWishlist] = useState(inWishlistProp);
  const [wishlistLoading, setWishlistLoading] = useState(false);
  const [added, setAdded] = useState(false);

  // Preço promocional calculado dinamicamente
  const promoPrice = getPromotionalPrice(product, promotions);
  const displayPrice = promoPrice ?? product.price;
  const originalPrice = promoPrice ? product.price : product.compare_at_price;

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    addItem(product);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  const handleWishlist = async (e: React.MouseEvent) => {
    e.preventDefault();
    if (!user) { toast.error('Faça login para adicionar à lista de desejos'); return; }
    setWishlistLoading(true);
    if (inWishlist) {
      await supabase.from('wishlist').delete().eq('user_id', user.id).eq('product_id', product.id);
      setInWishlist(false);
      toast.success('Removido da lista de desejos');
    } else {
      await supabase.from('wishlist').insert({ user_id: user.id, product_id: product.id });
      setInWishlist(true);
      toast.success('Adicionado à lista de desejos');
    }
    setWishlistLoading(false);
  };

  const stockLabel = product.stock_quantity <= 0
    ? 'Sem estoque'
    : product.stock_quantity <= 3
      ? `Últimas ${product.stock_quantity} un`
      : `${product.stock_quantity} em estoque`;

  const handleCompare = (e: React.MouseEvent) => {
    e.preventDefault();
    if (isInCompare(product.id)) removeFromCompare(product.id);
    else addToCompare(product);
  };

  const handleShare = async (e: React.MouseEvent) => {
    e.preventDefault();
    const url = `${window.location.origin}/produto/${product.slug}`;
    if (navigator.share) {
      await navigator.share({ title: product.name, url });
    } else {
      await navigator.clipboard.writeText(url);
      toast.success('Link copiado!');
    }
  };

  const discount = promoPrice
    ? Math.round((1 - promoPrice / product.price) * 100)
    : product.compare_at_price
      ? Math.round((1 - product.price / product.compare_at_price) * 100)
      : null;

  const imageUrl = product.images?.[0]?.url;

  return (
    <TooltipProvider>
      <Link to={`/produto/${product.slug}`}
        className={cn('group block bg-card rounded-xl border border-border overflow-hidden h-full flex flex-col transition-all duration-300 hover:-translate-y-1 hover:shadow-xl', className)}>
        {/* Image */}
        <div className="relative aspect-square overflow-hidden bg-muted">
          {imageUrl ? (
            <img src={imageUrl} alt={product.images?.[0]?.alt || product.name}
              loading="lazy"
              decoding="async"
              className="w-full h-full object-contain p-2 transition-transform duration-500 group-hover:scale-110" />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-muted">
              <ShoppingCart className="h-12 w-12 text-muted-foreground/30" />
            </div>
          )}
          {discount && <Badge className="absolute top-2 left-2 bg-destructive text-destructive-foreground border-0 text-xs font-bold shadow">-{discount}%</Badge>}
          {!product.is_available && <div className="absolute inset-0 bg-background/60 flex items-center justify-center"><Badge variant="secondary">Indisponível</Badge></div>}
          {product.stock_quantity <= 3 && product.stock_quantity > 0 && <Badge className="absolute bottom-2 left-2 bg-warning text-warning-foreground border-0 text-xs">Últimas unidades</Badge>}

          {/* Hover actions */}
          <div className="absolute top-2 right-2 flex flex-col gap-1.5 opacity-0 group-hover:opacity-100 translate-x-2 group-hover:translate-x-0 transition-all duration-200">
            <Tooltip>
              <TooltipTrigger asChild>
                <button onClick={handleWishlist} disabled={wishlistLoading}
                  className={cn('h-8 w-8 rounded-full bg-card/90 backdrop-blur-sm shadow-md flex items-center justify-center transition-colors',
                    inWishlist ? 'text-destructive' : 'text-muted-foreground hover:text-destructive')}>
                  <Heart className="h-4 w-4" fill={inWishlist ? 'currentColor' : 'none'} />
                </button>
              </TooltipTrigger>
              <TooltipContent side="left">{inWishlist ? 'Remover da lista' : 'Adicionar à lista'}</TooltipContent>
            </Tooltip>
            <Tooltip>
              <TooltipTrigger asChild>
                <button onClick={handleCompare}
                  className={cn('h-8 w-8 rounded-full bg-card/90 backdrop-blur-sm shadow-md flex items-center justify-center transition-colors',
                    isInCompare(product.id) ? 'text-primary' : 'text-muted-foreground hover:text-primary')}>
                  <GitCompare className="h-4 w-4" />
                </button>
              </TooltipTrigger>
              <TooltipContent side="left">{isInCompare(product.id) ? 'Remover comparação' : 'Comparar'}</TooltipContent>
            </Tooltip>
            <Tooltip>
              <TooltipTrigger asChild>
                <button onClick={handleShare}
                  className="h-8 w-8 rounded-full bg-card/90 backdrop-blur-sm shadow-md flex items-center justify-center text-muted-foreground hover:text-primary transition-colors">
                  <Share2 className="h-4 w-4" />
                </button>
              </TooltipTrigger>
              <TooltipContent side="left">Compartilhar</TooltipContent>
            </Tooltip>
          </div>
        </div>

        {/* Info */}
        <div className="p-3 flex flex-col flex-1 gap-2">
          <div className="flex items-center justify-between gap-1">
            <p className="text-xs text-muted-foreground truncate">{product.categories?.name || 'Sem categoria'}</p>
            {product.code && (
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-muted text-muted-foreground shrink-0">{product.code}</span>
            )}
          </div>
          <h3 className="text-sm font-medium text-card-foreground line-clamp-2 text-balance flex-1">{product.name}</h3>
          <div className="flex items-baseline gap-2 flex-wrap">
            <span className={cn('text-base font-bold', promoPrice ? 'text-destructive' : 'text-card-foreground')}>
              {displayPrice.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
            </span>
            {originalPrice && (
              <span className="text-xs text-muted-foreground line-through">
                {originalPrice.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
              </span>
            )}
            {promoPrice && (
              <span className="text-xs font-semibold text-destructive bg-destructive/10 px-1.5 py-0.5 rounded">
                -{discount}%
              </span>
            )}
          </div>
          <div className="flex items-center justify-between gap-2">
            <span className={cn('text-[11px] font-medium', product.stock_quantity <= 3 ? 'text-warning' : 'text-muted-foreground')}>
              {stockLabel}
            </span>
          </div>
          <Button onClick={handleAddToCart} disabled={!product.is_available || product.stock_quantity === 0}
            size="sm" className="w-full bg-accent text-accent-foreground hover:bg-accent/90 h-8 text-xs font-medium">
            {added ? <><Check className="h-3.5 w-3.5 mr-1" /> Adicionado</> : <><ShoppingCart className="h-3.5 w-3.5 mr-1" /> {product.is_available ? 'Adicionar' : 'Indisponível'}</>}
          </Button>
        </div>
      </Link>
    </TooltipProvider>
  );
}
