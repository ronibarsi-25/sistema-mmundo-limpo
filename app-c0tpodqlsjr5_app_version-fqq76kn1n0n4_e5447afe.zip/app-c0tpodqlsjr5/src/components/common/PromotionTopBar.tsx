import { useState } from 'react';
import { Link } from 'react-router-dom';
import { X, Tag } from 'lucide-react';
import { useActivePromotions } from '@/hooks/usePromotions';

export function PromotionTopBar() {
  const { promotions } = useActivePromotions();
  const [dismissed, setDismissed] = useState(false);

  // Usa a primeira promoção com banner_text
  const promo = promotions.find(p => p.banner_text);
  if (!promo || dismissed) return null;

  return (
    <div className="w-full py-2 px-4 flex items-center justify-center gap-2 text-white text-xs md:text-sm font-medium relative"
      style={{ backgroundColor: promo.banner_color }}>
      <Tag className="h-3.5 w-3.5 shrink-0" />
      <span>{promo.banner_text}</span>
      {promo.discount_type === 'percent'
        ? <span className="font-bold">{promo.discount_value}% OFF</span>
        : <span className="font-bold">R$ {promo.discount_value.toFixed(2)} OFF</span>}
      <Link to="/produtos" className="underline font-bold ml-1 hover:opacity-80 transition-opacity">
        Ver produtos
      </Link>
      <button onClick={() => setDismissed(true)}
        className="absolute right-3 top-1/2 -translate-y-1/2 hover:opacity-70 transition-opacity">
        <X className="h-4 w-4" />
      </button>
    </div>
  );
}
