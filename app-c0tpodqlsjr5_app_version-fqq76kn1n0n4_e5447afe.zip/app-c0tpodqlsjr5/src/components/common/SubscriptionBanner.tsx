import { AlertTriangle, Clock } from 'lucide-react';
import { useStore } from '@/contexts/StoreContext';

// Banner exibido para clientes quando a assinatura está próxima do vencimento ou expirada
export function SubscriptionBanner() {
  const { subscription, isExpired } = useStore();

  if (!subscription) return null;

  const now = new Date();
  const trialEnds = new Date(subscription.trial_ends_at);
  const expiresAt = new Date(subscription.expires_at);
  const isTrial = subscription.status === 'trial' && trialEnds > now;
  const activeExpiry = isTrial ? trialEnds : expiresAt;
  const daysLeft = Math.ceil((activeExpiry.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
  const isNearExpiry = !isExpired && daysLeft <= 7 && daysLeft >= 0;

  if (!isExpired && !isNearExpiry) return null;

  if (isExpired) {
    return (
      <div className="w-full bg-destructive text-destructive-foreground text-xs font-medium py-2 px-4 flex items-center justify-center gap-2 text-center">
        <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
        <span>
          Esta loja está temporariamente indisponível. Tente novamente em breve ou entre em contato com o suporte.
        </span>
      </div>
    );
  }

  if (isNearExpiry) {
    return (
      <div className="w-full bg-amber-500 text-white text-xs font-medium py-2 px-4 flex items-center justify-center gap-2 text-center">
        <Clock className="h-3.5 w-3.5 shrink-0" />
        <span>
          Aviso: esta loja pode ficar temporariamente indisponível em breve para manutenção.
        </span>
      </div>
    );
  }

  return null;
}
