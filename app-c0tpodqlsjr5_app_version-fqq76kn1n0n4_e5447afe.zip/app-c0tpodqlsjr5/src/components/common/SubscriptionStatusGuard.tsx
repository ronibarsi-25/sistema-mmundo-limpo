import { ReactNode, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useStore } from '@/contexts/StoreContext';

interface SubscriptionStatusGuardProps {
  children: ReactNode;
}

export function SubscriptionStatusGuard({ children }: { children: ReactNode }) {
  const { isExpired, loading } = useStore();
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && isExpired) {
      // Se for rota de feed público, admin ou loja suspensa, não redireciona
      const isFeedRoute = location.pathname.startsWith('/feed/');
      const isAdminRoute = location.pathname.startsWith('/admin');
      const isSuspendedPage = location.pathname === '/loja-suspensa';
      
      if (!isFeedRoute && !isAdminRoute && !isSuspendedPage) {
        navigate('/loja-suspensa');
      }
    }
  }, [isExpired, loading, location.pathname, navigate]);

  return <>{children}</>;
}
