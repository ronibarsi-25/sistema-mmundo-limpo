import { useState, useEffect } from 'react';
import { MessageCircle, X, ShoppingCart, HelpCircle, Send } from 'lucide-react';

const WHATSAPP_NUMBER = '5531987774702';

export function WhatsAppFAB() {
  const [open, setOpen] = useState(false);
  const [hidden, setHidden] = useState(false);

  useEffect(() => {
    const onScroll = () => setHidden(window.scrollY > 100);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const links = [
    { label: 'Fazer um Pedido', icon: ShoppingCart, msg: 'Olá! Gostaria de fazer um pedido.' },
    { label: 'Tirar Dúvidas', icon: HelpCircle, msg: 'Olá! Tenho uma dúvida sobre os produtos.' },
    { label: 'Enviar Mensagem', icon: Send, msg: 'Olá! Entrei em contato pelo site da Mundo Limpo.' },
  ];

  const handleOpenChat = (msg: string) => {
    const url = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(msg)}`;
    window.open(url, '_blank');
    setOpen(false);
  };

  return (
    <div className="fixed bottom-5 right-5 z-50 flex flex-col items-end gap-2">
      {open && (
        <div className="mb-2 bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-border/50 p-4 w-72 animate-in fade-in slide-in-from-bottom-4 duration-200">
          <div className="flex items-center gap-3 mb-3 pb-3 border-b border-border/50">
            <div className="h-10 w-10 rounded-full bg-[#25D366] flex items-center justify-center">
              <MessageCircle className="h-5 w-5 text-white" />
            </div>
            <div>
              <p className="text-sm font-bold text-foreground">Mundo Limpo</p>
              <p className="text-xs text-muted-foreground flex items-center gap-1">
                <span className="h-1.5 w-1.5 rounded-full bg-green-500 inline-block" />
                Online agora
              </p>
            </div>
          </div>
          <div className="space-y-2">
            {links.map(link => (
              <button
                key={link.label}
                onClick={() => handleOpenChat(link.msg)}
                className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl bg-muted/60 hover:bg-muted text-sm font-medium text-foreground transition-colors text-left"
              >
                <link.icon className="h-4 w-4 text-[#25D366] shrink-0" />
                {link.label}
              </button>
            ))}
          </div>
          <p className="text-[10px] text-muted-foreground text-center mt-3">
            Resposta em até 30 minutos
          </p>
        </div>
      )}
      <button
        onClick={() => setOpen(!open)}
        className={`h-14 w-14 rounded-full shadow-xl flex items-center justify-center transition-all duration-300 ${open ? 'bg-slate-700 hover:bg-slate-800 rotate-90' : 'bg-[#25D366] hover:bg-[#20b558]'} ${hidden && !open ? 'translate-y-20 opacity-0' : 'translate-y-0 opacity-100'}`}
        aria-label="Abrir WhatsApp"
      >
        {open ? <X className="h-6 w-6 text-white" /> : <MessageCircle className="h-7 w-7 text-white" />}
      </button>
    </div>
  );
}
