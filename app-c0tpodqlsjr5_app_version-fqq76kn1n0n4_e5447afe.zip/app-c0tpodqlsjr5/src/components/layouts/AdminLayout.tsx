import { useState, type ReactNode } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard, Package, ShoppingCart, Tag, Settings, BarChart3,
  Warehouse, MessageCircle, Menu, Store, LogOut, ChevronRight,
  Image as ImageIcon, Percent, Palette, Ticket, CreditCard, AlertTriangle, Zap, Wallet,
  MonitorSmartphone, Upload, ShieldCheck, Truck, ChevronDown,
  Users, Clock, CalendarCheck, FileSpreadsheet, PartyPopper, Bell, ArrowRightLeft,
  Download, History, Shield, Printer, Sparkles, ClipboardList
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent } from '@/components/ui/sheet';
import { NotificationBell } from '@/components/admin/NotificationBell';
import { useAuth } from '@/contexts/AuthContext';
import { useStore } from '@/contexts/StoreContext';
import { cn } from '@/lib/utils';

/* ─── Sidebar Navigation Groups ─── */
const NAV_GROUPS = [
  {
    label: 'Visão Geral',
    items: [
      { label: 'Dashboard', icon: LayoutDashboard, path: '/admin' },
    ],
  },
  {
    label: 'Loja',
    items: [
      { label: 'Produtos', icon: Package, path: '/admin/produtos' },
      { label: 'Categorias', icon: Tag, path: '/admin/categorias' },
      { label: 'Importar', icon: Upload, path: '/admin/importar' },
      { label: 'Importar Lote', icon: Upload, path: '/admin/importar-produtos' },
      { label: 'Estoque', icon: Warehouse, path: '/admin/estoque' },
      { label: 'Movimentações', icon: History, path: '/admin/movimentacoes' },
      { label: 'Pedido Eletrônico', icon: ClipboardList, path: '/admin/pedido-eletronico' },
      { label: 'Etiquetas', icon: Printer, path: '/admin/etiquetas' },
      { label: 'Sincronizar PDV', icon: ArrowRightLeft, path: '/admin/sincronizar-pdv' },
    ],
  },
  {
    label: 'Vendas',
    items: [
      { label: 'Pedidos', icon: ShoppingCart, path: '/admin/pedidos' },
      { label: 'Relatórios', icon: BarChart3, path: '/admin/relatorios' },
      { label: 'Atendimento', icon: MessageCircle, path: '/admin/chat' },
    ],
  },
  {
    label: 'Marketing',
    items: [
      { label: 'Banners', icon: ImageIcon, path: '/admin/banners' },
      { label: 'Banners Sociais', icon: Sparkles, path: '/admin/banners-sociais' },
      { label: 'Inauguração', icon: PartyPopper, path: '/admin/banner-inauguracao' },
      { label: 'Promoções', icon: Percent, path: '/admin/promocoes' },
      { label: 'Cupons', icon: Ticket, path: '/admin/cupons' },
      { label: 'Cupom Desconto', icon: Percent, path: '/admin/cupom-desconto' },
    ],
  },
  {
    label: 'Financeiro',
    items: [
      { label: 'Pagamentos', icon: Wallet, path: '/admin/gateways' },
      { label: 'Entregas', icon: Truck, path: '/admin/entregas' },
      { label: 'Assinatura', icon: CreditCard, path: '/admin/assinatura' },
    ],
  },
  {
    label: 'Gestão',
    items: [
      { label: 'Recursos Humanos', icon: Users, path: '/admin/rh' },
      { label: 'Folha de Pagamento', icon: FileSpreadsheet, path: '/admin/folha' },
      { label: 'Ponto Eletrônico', icon: Clock, path: '/admin/ponto' },
      { label: 'Agendamentos', icon: CalendarCheck, path: '/admin/agendamentos' },
    ],
  },
  {
    label: 'Dados',
    items: [
      { label: 'Exportar Dados', icon: Download, path: '/admin/exportar-dados' },
      { label: 'Permissões', icon: Shield, path: '/admin/permissoes' },
    ],
  },
  {
    label: 'Configurações',
    items: [
      { label: 'Notificações', icon: Bell, path: '/admin/notificacoes' },
      { label: 'Tema Visual', icon: Palette, path: '/admin/tema' },
      { label: 'White Label', icon: Zap, path: '/admin/white-label' },
      { label: 'Configurações', icon: Settings, path: '/admin/configuracoes' },
    ],
  },
  {
    label: 'Sistema',
    items: [
      { label: 'Super Admin', icon: ShieldCheck, path: '/super-admin' },
    ],
  },
];

function SidebarNav({ onItemClick }: { onItemClick?: () => void }) {
  const location = useLocation();
  const navigate = useNavigate();
  const { signOut, user, profile } = useAuth();
  const { settings } = useStore();

  const handleSignOut = async () => { await signOut(); navigate('/'); };

  const [collapsedGroups, setCollapsedGroups] = useState<Set<string>>(new Set());
  const toggleGroup = (label: string) => {
    setCollapsedGroups(prev => {
      const next = new Set(prev);
      if (next.has(label)) next.delete(label);
      else next.add(label);
      return next;
    });
  };

  // Avatar inicial
  const displayName = profile?.full_name || profile?.username || user?.email?.split('@')[0] || 'Admin';
  const initials = displayName.slice(0, 2).toUpperCase();

  return (
    <div className="flex flex-col h-full bg-sidebar">
      {/* Header / Brand */}
      <div className="flex items-center gap-3 px-4 py-4 border-b border-sidebar-border">
        <div className="h-9 w-9 rounded-lg bg-sidebar-primary flex items-center justify-center shrink-0 shadow-sm">
          <Store className="h-4.5 w-4.5 text-sidebar-primary-foreground" />
        </div>
        <div className="min-w-0">
          <p className="font-bold text-sidebar-foreground text-sm truncate leading-tight">{settings?.store_name || 'MinhaLoja'}</p>
          <p className="text-[10px] text-sidebar-foreground/50 font-medium uppercase tracking-wider">Painel Admin</p>
        </div>
      </div>

      {/* User mini profile */}
      <div className="px-4 py-3 border-b border-sidebar-border">
        <div className="flex items-center gap-3">
          <div className="h-8 w-8 rounded-full bg-sidebar-primary/30 flex items-center justify-center text-sidebar-primary text-xs font-bold shrink-0">
            {initials}
          </div>
          <div className="min-w-0">
            <p className="text-xs font-semibold text-sidebar-foreground truncate">{displayName}</p>
            <p className="text-[10px] text-sidebar-foreground/50 truncate">{user?.email}</p>
          </div>
        </div>
      </div>

      {/* Navigation Groups */}
      <nav className="flex-1 overflow-y-auto px-2 py-3 space-y-3">
        {NAV_GROUPS.map(group => (
          <div key={group.label}>
            <button
              onClick={() => toggleGroup(group.label)}
              className="flex items-center justify-between w-full px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-sidebar-foreground/40 hover:text-sidebar-foreground/60 transition-colors"
            >
              <span>{group.label}</span>
              <ChevronDown className={`h-3 w-3 transition-transform ${collapsedGroups.has(group.label) ? '-rotate-90' : ''}`} />
            </button>
            {!collapsedGroups.has(group.label) && (
              <div className="mt-1 space-y-0.5">
                {group.items.map(item => {
                  const active = location.pathname === item.path;
                  return (
                    <Link key={item.path} to={item.path} onClick={onItemClick}
                      className={cn(
                        'flex items-center gap-2.5 px-2.5 py-2 rounded-md text-sm transition-colors group',
                        active
                          ? 'bg-sidebar-accent text-sidebar-primary font-medium'
                          : 'text-sidebar-foreground/70 hover:bg-sidebar-accent/60 hover:text-sidebar-accent-foreground'
                      )}>
                      <item.icon className={cn('h-4 w-4 shrink-0', active ? 'text-sidebar-primary' : 'text-sidebar-foreground/50 group-hover:text-sidebar-foreground')} />
                      <span className="truncate">{item.label}</span>
                      {active && <div className="ml-auto h-1.5 w-1.5 rounded-full bg-sidebar-primary" />}
                    </Link>
                  );
                })}
              </div>
            )}
          </div>
        ))}
      </nav>

      {/* Bottom actions */}
      <div className="border-t border-sidebar-border px-2 py-2 space-y-1">
        <Link to="/pdv" onClick={onItemClick}
          className="flex items-center gap-2.5 px-2.5 py-2 rounded-md text-sm font-medium text-sidebar-primary bg-sidebar-primary/10 hover:bg-sidebar-primary/20 transition-colors">
          <MonitorSmartphone className="h-4 w-4 shrink-0" /> Acessar PDV
        </Link>
        <Link to="/" onClick={onItemClick}
          className="flex items-center gap-2.5 px-2.5 py-2 rounded-md text-sm text-sidebar-foreground/60 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground transition-colors">
          <Store className="h-4 w-4 shrink-0" /> Ver Loja
        </Link>
        <button onClick={handleSignOut}
          className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-md text-sm text-sidebar-foreground/60 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground transition-colors">
          <LogOut className="h-4 w-4 shrink-0" /> Sair
        </button>
      </div>
    </div>
  );
}

interface AdminLayoutProps { children: ReactNode; title?: string; subtitle?: string; breadcrumbs?: { label: string; path?: string }[]; }

export function AdminLayout({ children, title, subtitle, breadcrumbs }: AdminLayoutProps) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const { subscription, isExpired } = useStore();

  const trialEnds = subscription?.trial_ends_at ? new Date(subscription.trial_ends_at) : null;
  const now = new Date();
  const daysLeft = trialEnds ? Math.ceil((trialEnds.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)) : null;
  const isTrial = subscription?.status === 'trial' && daysLeft !== null && daysLeft > 0;

  return (
    <div className="flex min-h-screen w-full bg-background print:bg-white">
      {/* Desktop sidebar */}
      <aside className="hidden lg:flex flex-col w-64 shrink-0 border-r border-border sticky top-0 h-screen print:hidden">
        <SidebarNav />
      </aside>

      {/* Mobile sidebar */}
      <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
        <SheetContent side="left" className="p-0 w-64 bg-sidebar border-r border-sidebar-border print:hidden">
          <SidebarNav onItemClick={() => setMobileOpen(false)} />
        </SheetContent>
      </Sheet>

      {/* Main content */}
      <div className="flex-1 min-w-0 flex flex-col print:flex-none print:w-full print:block">
        {/* Top bar */}
        <header className="sticky top-0 z-40 bg-background/95 backdrop-blur border-b border-border flex flex-col print:hidden">
          {isTrial && (
            <div className="bg-primary/10 text-primary text-[11px] font-medium py-1.5 px-4 flex items-center justify-center gap-2 border-b border-primary/20">
              <Zap className="h-3 w-3" />
              Sua loja está no período de teste: {daysLeft} dias restantes.
              <Link to="/admin/assinatura" className="underline font-bold hover:text-primary/80 ml-1">Assinar agora</Link>
            </div>
          )}
          {isExpired && (
            <div className="bg-destructive text-destructive-foreground text-[11px] font-medium py-1.5 px-4 flex items-center justify-center gap-2">
              <AlertTriangle className="h-3 w-3" />
              Sua assinatura expirou! A loja está suspensa para os clientes.
              <Link to="/admin/assinatura" className="underline font-bold hover:text-white/80 ml-1">Regularizar agora</Link>
            </div>
          )}
          <div className="flex items-center gap-3 px-4 md:px-6 h-14">
            <Button variant="ghost" size="icon" className="lg:hidden shrink-0 h-9 w-9" onClick={() => setMobileOpen(true)}>
              <Menu className="h-5 w-5" />
            </Button>
            <div className="flex-1 min-w-0">
              {breadcrumbs && breadcrumbs.length > 0 && (
                <nav className="flex items-center gap-1 text-[11px] text-muted-foreground">
                  {breadcrumbs.map((crumb, i) => (
                    <span key={i} className="flex items-center gap-1">
                      {i > 0 && <ChevronRight className="h-2.5 w-2.5" />}
                      {crumb.path ? (
                        <Link to={crumb.path} className="hover:text-foreground transition-colors">{crumb.label}</Link>
                      ) : (
                        <span className="text-foreground font-semibold">{crumb.label}</span>
                      )}
                    </span>
                  ))}
                </nav>
              )}
              {title && (
                <h1 className="text-sm font-semibold text-foreground truncate leading-tight">{title}</h1>
              )}
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <NotificationBell />
            </div>
          </div>
        </header>
        <main className="flex-1 p-4 md:p-6 overflow-x-hidden print:overflow-visible print:p-0">
          {children}
        </main>
      </div>
    </div>
  );
}
