import { Link } from 'react-router-dom';
import { Store, Instagram, Facebook, Twitter, Mail, Phone, MapPin, ShieldCheck } from 'lucide-react';
import { useStore } from '@/contexts/StoreContext';
import { useAuth } from '@/contexts/AuthContext';

export function Footer() {
  const { settings } = useStore();
  const { profile } = useAuth();
  const storeName = settings?.store_name || 'MinhaLoja';

  return (
    <footer className="bg-primary text-primary-foreground mt-auto">
      <div className="container py-10 md:py-14">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <Link to="/" className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-md bg-accent flex items-center justify-center">
                <Store className="h-4 w-4 text-accent-foreground" />
              </div>
              <span className="font-bold text-lg">{storeName}</span>
            </Link>
            <p className="text-sm text-primary-foreground/70 text-pretty">
              Sua loja online completa, com os melhores produtos e atendimento de qualidade.
            </p>
            <div className="flex gap-3">
              {[Facebook, Instagram, Twitter].map((Icon, i) => (
                <a key={i} href="#" className="h-9 w-9 rounded-md border border-primary-foreground/20 flex items-center justify-center hover:bg-primary-foreground/10 transition-colors">
                  <Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>

          {/* Links */}
          <div className="space-y-3">
            <h3 className="font-semibold text-sm uppercase tracking-wide text-primary-foreground/60">Navegação</h3>
            <ul className="space-y-2">
              {[
                { label: 'Início', path: '/' },
                { label: 'Produtos', path: '/produtos' },
                { label: 'Minha Conta', path: '/minha-conta/pedidos' },
                { label: 'Lista de Desejos', path: '/lista-de-desejos' },
                { label: 'Comparar Produtos', path: '/comparar' },
              ].map(link => (
                <li key={link.path}>
                  <Link to={link.path} className="text-sm text-primary-foreground/70 hover:text-primary-foreground transition-colors">
                    {link.label}
                  </Link>
                </li>
              ))}
              {/* Admin link — always visible in footer */}
              <li className="pt-1 border-t border-primary-foreground/10">

              </li>
            </ul>
          </div>

          {/* Policies */}
          <div className="space-y-3">
            <h3 className="font-semibold text-sm uppercase tracking-wide text-primary-foreground/60">Informações</h3>
            <ul className="space-y-2">
              {['Política de Privacidade', 'Termos de Uso', 'Trocas e Devoluções', 'Frete e Entrega'].map(item => (
                <li key={item}>
                  <a href="#" className="text-sm text-primary-foreground/70 hover:text-primary-foreground transition-colors">{item}</a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div className="space-y-3">
            <h3 className="font-semibold text-sm uppercase tracking-wide text-primary-foreground/60">Contato</h3>
            <ul className="space-y-3">
              {settings?.store_email && (
                <li className="flex items-start gap-2 text-sm text-primary-foreground/70">
                  <Mail className="h-4 w-4 mt-0.5 shrink-0" /> <span className="break-words">{settings.store_email}</span>
                </li>
              )}
              {settings?.store_phone && (
                <li className="flex items-center gap-2 text-sm text-primary-foreground/70">
                  <Phone className="h-4 w-4 shrink-0" /> {settings.store_phone}
                </li>
              )}
              {settings?.store_address && (
                <li className="flex items-start gap-2 text-sm text-primary-foreground/70">
                  <MapPin className="h-4 w-4 mt-0.5 shrink-0" />
                  <span>{settings.store_address}{settings.store_city ? `, ${settings.store_city}` : ''}{settings.store_state ? ` - ${settings.store_state}` : ''}</span>
                </li>
              )}
            </ul>
          </div>
        </div>
      </div>
      <div className="border-t border-primary-foreground/10">
        <div className="container flex flex-col md:flex-row items-center justify-between gap-2 py-4">
          <p className="text-xs text-primary-foreground/50">&copy; {new Date().getFullYear()} {storeName}. Todos os direitos reservados.</p>
          <div className="flex items-center gap-3 text-xs text-primary-foreground/50">
            <span>Pagamentos seguros</span>
            <span>•</span>
            <span>Entrega em todo Brasil</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
