import { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import {
  ShoppingCart, Heart, User, Search, Menu, X, GitCompare, LogOut,
  Package, Settings, ChevronDown, Store, ShieldCheck
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuSeparator, DropdownMenuTrigger
} from '@/components/ui/dropdown-menu';
import { useCart } from '@/contexts/CartContext';
import { useAuth } from '@/contexts/AuthContext';
import { useCompare } from '@/contexts/CompareContext';
import { useStore } from '@/contexts/StoreContext';
import { useI18n } from '@/i18n';
import { supabase } from '@/db/supabase';
import type { Category } from '@/types/types';

function LanguageSelector() {
  const { lang, setLang } = useI18n();
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="sm" className="text-primary-foreground/80 hover:text-primary-foreground hover:bg-primary-foreground/10 h-8 w-8 md:h-9 md:w-auto md:px-2 text-xs font-medium">
          {lang === 'pt' ? 'PT' : 'EN'}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem onClick={() => setLang('pt')}>Português (PT)</DropdownMenuItem>
        <DropdownMenuItem onClick={() => setLang('en')}>English (EN)</DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

export function Header() {
  const { totalItems } = useCart();
  const { user, profile, signOut } = useAuth();
  const { compareItems } = useCompare();
  const { settings } = useStore();
  const navigate = useNavigate();
  const location = useLocation();
  const [search, setSearch] = useState('');
  const [categories, setCategories] = useState<Category[]>([]);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 10);
    window.addEventListener('scroll', handler);
    return () => window.removeEventListener('scroll', handler);
  }, []);

  useEffect(() => {
    supabase.from('categories').select('*').eq('is_active', true).order('name').then(({ data }) => {
      if (data) setCategories(data);
    });
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (search.trim()) { navigate(`/produtos?busca=${encodeURIComponent(search.trim())}`); setSearch(''); }
  };

  const handleSignOut = async () => { await signOut(); navigate('/'); };

  const storeName = settings?.store_name || 'MinhaLoja';

  const navLinks = [
    { label: 'Início', path: '/' },
    { label: 'Produtos', path: '/produtos' },
    { label: 'Portfólio', path: '/portfolio' },
  ];

  return (
    <header className="sticky top-0 z-50 w-full bg-primary shadow-sm">
      {/* Top bar */}
      <div className="border-b border-primary-foreground/10">
        <div className="w-full px-3 md:px-6 flex h-14 items-center gap-2 min-w-0">

          {/* Mobile menu trigger */}
          <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="lg:hidden shrink-0 border border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10 h-9 w-9">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="bg-sidebar w-[280px] max-w-[calc(100%-2rem)] p-0">
              <div className="flex flex-col h-full">
                <div className="flex items-center gap-2 px-4 py-4 border-b border-sidebar-border">
                  <Store className="h-5 w-5 text-sidebar-primary shrink-0" />
                  <span className="font-bold text-sidebar-foreground text-base truncate flex-1 min-w-0">{storeName}</span>
                  <Button variant="ghost" size="icon" className="shrink-0 text-sidebar-foreground hover:bg-sidebar-accent h-8 w-8" onClick={() => setMobileOpen(false)}>
                    <X className="h-4 w-4" />
                  </Button>
                </div>
                <nav className="flex-1 overflow-y-auto px-3 py-3 space-y-0.5">
                  {navLinks.map(link => (
                    <Link key={link.path} to={link.path} onClick={() => setMobileOpen(false)}
                      className={`flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors ${location.pathname === link.path ? 'bg-sidebar-accent text-sidebar-primary' : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'}`}>
                      {link.label}
                    </Link>
                  ))}
                  <div className="pt-2 pb-1">
                    <p className="px-3 text-xs font-semibold text-sidebar-foreground/50 uppercase tracking-wider mb-1">Categorias</p>
                    {categories.map(cat => (
                      <Link key={cat.id} to={`/produtos?categoria=${cat.slug}`} onClick={() => setMobileOpen(false)}
                        className="flex items-center gap-3 px-3 py-2 rounded-md text-sm text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground transition-colors">
                        {cat.name}
                      </Link>
                    ))}
                  </div>
                </nav>
                {user ? (
                  <div className="border-t border-sidebar-border px-3 py-3 space-y-0.5">
                    <Link to="/minha-conta/pedidos" onClick={() => setMobileOpen(false)} className="flex items-center gap-3 px-3 py-2.5 rounded-md text-sm text-sidebar-foreground hover:bg-sidebar-accent">
                      <Package className="h-4 w-4 shrink-0" /> Meus Pedidos
                    </Link>
                    <Link to="/lista-de-desejos" onClick={() => setMobileOpen(false)} className="flex items-center gap-3 px-3 py-2.5 rounded-md text-sm text-sidebar-foreground hover:bg-sidebar-accent">
                      <Heart className="h-4 w-4 shrink-0" /> Lista de Desejos
                    </Link>
                    {profile?.role === 'admin' && (
                      <Link to="/admin" onClick={() => setMobileOpen(false)}
                        className="flex items-center gap-3 px-3 py-2.5 rounded-md text-sm text-accent hover:bg-sidebar-accent font-semibold">
                        <ShieldCheck className="h-4 w-4 shrink-0" /> Painel Admin
                      </Link>
                    )}
                    <button onClick={() => { handleSignOut(); setMobileOpen(false); }} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-md text-sm text-destructive hover:bg-sidebar-accent">
                      <LogOut className="h-4 w-4 shrink-0" /> Sair
                    </button>
                  </div>
                ) : (
                  <div className="border-t border-sidebar-border px-3 py-3 space-y-2">
                    <Link to="/login" onClick={() => setMobileOpen(false)}>
                      <Button className="w-full bg-sidebar-primary text-sidebar-primary-foreground hover:bg-sidebar-primary/90">Entrar / Cadastrar</Button>
                    </Link>
                    <Link to="/admin/login" onClick={() => setMobileOpen(false)}
                      className="flex items-center justify-center gap-1.5 py-1.5 text-xs text-sidebar-foreground/50 hover:text-sidebar-foreground transition-colors">
                      <ShieldCheck className="h-3.5 w-3.5" /> Acesso Administrativo
                    </Link>
                  </div>
                )}
              </div>
            </SheetContent>
          </Sheet>

          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 shrink-0 min-w-0 max-w-[45%] sm:max-w-[200px] lg:max-w-none">
            <div className="h-7 w-7 rounded-md bg-accent flex items-center justify-center shrink-0">
              <Store className="h-4 w-4 text-accent-foreground" />
            </div>
            <span
              className="font-bold text-primary-foreground text-sm md:text-base truncate"
              data-href="/produtos">{storeName}</span>
          </Link>

          {/* Desktop nav */}
          <nav className="hidden lg:flex items-center gap-1 ml-2 shrink-0">
            {navLinks.map(link => (
              <Link key={link.path} to={link.path}
                className={`px-3 py-2 rounded-md text-sm font-medium transition-colors whitespace-nowrap ${location.pathname === link.path ? 'bg-primary-foreground/15 text-primary-foreground' : 'text-primary-foreground/80 hover:text-primary-foreground hover:bg-primary-foreground/10'}`}>
                {link.label}
              </Link>
            ))}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="text-primary-foreground/80 hover:text-primary-foreground hover:bg-primary-foreground/10 text-sm font-medium px-3 whitespace-nowrap">
                  Categorias <ChevronDown className="ml-1 h-3.5 w-3.5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-48">
                {categories.map(cat => (
                  <DropdownMenuItem key={cat.id} asChild>
                    <Link to={`/produtos?categoria=${cat.slug}`}>{cat.name}</Link>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          </nav>

          {/* Search — desktop */}
          <form onSubmit={handleSearch} className="flex-1 max-w-xs hidden md:flex ml-auto mr-2 min-w-0">
            <div className="relative w-full min-w-0">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-primary-foreground/50" />
              <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar..."
                className="pl-9 h-9 w-full bg-primary-foreground/10 border-primary-foreground/20 text-primary-foreground placeholder:text-primary-foreground/50 focus-visible:ring-accent focus-visible:border-accent" />
            </div>
          </form>

          {/* Actions */}
          <div className="flex items-center gap-1 ml-auto lg:ml-0 shrink-0">
            {/* Language selector */}
            <LanguageSelector />
            {compareItems.length > 0 && (
              <Link to="/comparar">
                <Button variant="ghost" size="icon" className="relative border border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10 h-8 w-8 md:h-9 md:w-9">
                  <GitCompare className="h-4 w-4" />
                  <Badge className="absolute -top-1.5 -right-1.5 h-4 w-4 p-0 flex items-center justify-center text-[10px] bg-accent text-accent-foreground border-0">{compareItems.length}</Badge>
                </Button>
              </Link>
            )}
            {user && (
              <Link to="/lista-de-desejos" className="hidden sm:block">
                <Button variant="ghost" size="icon" className="border border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10 h-8 w-8 md:h-9 md:w-9">
                  <Heart className="h-4 w-4" />
                </Button>
              </Link>
            )}
            <Link to="/carrinho">
              <Button variant="ghost" size="icon" className="relative border border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10 h-8 w-8 md:h-9 md:w-9">
                <ShoppingCart className="h-4 w-4" />
                {totalItems > 0 && <Badge className="absolute -top-1.5 -right-1.5 h-4 w-4 p-0 flex items-center justify-center text-[10px] bg-accent text-accent-foreground border-0">{totalItems}</Badge>}
              </Button>
            </Link>
            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="border border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10 h-8 w-8 md:h-9 md:w-9">
                    <User className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  <div className="px-3 py-2">
                    <p className="text-sm font-medium truncate">{profile?.full_name || user.email}</p>
                    <p className="text-xs text-muted-foreground truncate">{user.email}</p>
                  </div>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild><Link to="/minha-conta/pedidos"><Package className="mr-2 h-4 w-4" /> Meus Pedidos</Link></DropdownMenuItem>
                  <DropdownMenuItem asChild><Link to="/lista-de-desejos"><Heart className="mr-2 h-4 w-4" /> Lista de Desejos</Link></DropdownMenuItem>
                  <DropdownMenuItem asChild><Link to="/minha-conta/perfil"><Settings className="mr-2 h-4 w-4" /> Meu Perfil</Link></DropdownMenuItem>
                  {profile?.role === 'admin' && (
                    <>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem asChild>
                        <Link to="/admin" className="text-accent font-medium">
                          <ShieldCheck className="mr-2 h-4 w-4" /> Painel Admin
                        </Link>
                      </DropdownMenuItem>
                    </>
                  )}
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleSignOut} className="text-destructive focus:text-destructive">
                    <LogOut className="mr-2 h-4 w-4" /> Sair
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Link to="/login">
                <Button size="sm" className="bg-accent text-accent-foreground hover:bg-accent/90 border-0 h-8 md:h-9 text-xs md:text-sm">
                  <User className="h-4 w-4 sm:mr-1.5" />
                  <span className="hidden sm:inline">Entrar</span>
                </Button>
              </Link>
            )}
          </div>
        </div>
      </div>
      {/* Mobile search bar */}
      <div className="md:hidden border-b border-primary-foreground/10 px-3 py-2">
        <form onSubmit={handleSearch} className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-primary-foreground/50" />
          <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar produtos..."
            className="pl-8 h-8 text-sm bg-primary-foreground/10 border-primary-foreground/20 text-primary-foreground placeholder:text-primary-foreground/50 w-full" />
        </form>
      </div>
    </header>
  );
}
