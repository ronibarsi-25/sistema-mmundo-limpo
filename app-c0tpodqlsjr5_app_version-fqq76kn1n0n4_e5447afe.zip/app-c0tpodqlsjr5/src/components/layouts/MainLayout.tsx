import type { ReactNode } from 'react';
import { Header } from './Header';
import { Footer } from './Footer';
import { SubscriptionBanner } from '@/components/common/SubscriptionBanner';

interface MainLayoutProps { children: ReactNode; }

export function MainLayout({ children }: MainLayoutProps) {
  return (
    <div className="flex flex-col min-h-screen w-full">
      <SubscriptionBanner />
      <Header />
      <main className="flex-1 min-w-0">
        {children}
      </main>
      <Footer />
    </div>
  );
}
