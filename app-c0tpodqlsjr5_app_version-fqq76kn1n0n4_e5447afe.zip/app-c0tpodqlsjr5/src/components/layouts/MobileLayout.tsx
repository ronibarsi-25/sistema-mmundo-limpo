import { useLocation, useNavigate } from 'react-router-dom';
import { Package, Barcode, ClipboardList, Home, ChevronLeft } from 'lucide-react';

interface MobileLayoutProps {
  children: React.ReactNode;
  title?: string;
  showNav?: boolean;
  showBack?: boolean;
}

export function MobileLayout({ children, title, showNav = true, showBack = false }: MobileLayoutProps) {
  const location = useLocation();
  const navigate = useNavigate();

  const navItems = [
    { path: '/mobile', label: 'Início', icon: Home },
    { path: '/mobile/scanner', label: 'Scanner', icon: Barcode },
    { path: '/mobile/contagem', label: 'Contagem', icon: ClipboardList },
    { path: '/mobile/produtos', label: 'Produtos', icon: Package },
  ];

  return (
    <div className="flex flex-col h-[100dvh] bg-background">
      {/* Top bar */}
      <header className="shrink-0 flex items-center gap-2 px-3 py-3 bg-primary text-primary-foreground shadow-sm">
        {showBack && (
          <button onClick={() => navigate(-1)} className="p-1 rounded-full hover:bg-white/20 transition-colors">
            <ChevronLeft className="h-6 w-6" />
          </button>
        )}
        <h1 className="text-lg font-semibold flex-1 text-center pr-8">{title || 'Controle de Estoque'}</h1>
      </header>

      {/* Content */}
      <main className="flex-1 overflow-y-auto overscroll-y-auto">
        {children}
      </main>

      {/* Bottom nav */}
      {showNav && (
        <nav className="shrink-0 grid grid-cols-4 border-t bg-card safe-area-pb">
          {navItems.map((item) => {
            const active = location.pathname === item.path;
            return (
              <button
                key={item.path}
                onClick={() => navigate(item.path)}
                className={`flex flex-col items-center justify-center gap-0.5 py-2 transition-colors ${
                  active ? 'text-primary' : 'text-muted-foreground'
                }`}
              >
                <item.icon className="h-5 w-5" />
                <span className="text-[10px] font-medium">{item.label}</span>
              </button>
            );
          })}
        </nav>
      )}
    </div>
  );
}
