import { useState, useEffect, type ReactNode } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard, Package, Users, Truck, Warehouse, FileText,
  Tag, CreditCard, BarChart3, Settings, Settings2, LogOut, Menu, Droplets,
  ChevronRight, Receipt, Building2, UserCheck, Printer,
  Layers, Clock, DollarSign, RefreshCw, Star, Award,
  CalendarDays, GitBranch, TrendingUp, ShoppingCart,
  Search, Shield, Users2, ShoppingBag, Landmark, BookOpen,
  ShieldCheck, HeartHandshake, FileUp, Landmark as LandmarkIcon, ReceiptText, Lock, PieChart, Eye,
  Share2, Rss
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent } from '@/components/ui/sheet';
import { useAuth } from '@/contexts/AuthContext';
import { usePermissions } from '@/hooks/usePermissions';
import { cn } from '@/lib/utils';
import type { UserRole } from '@/types/types';

type NavItem = { label: string; icon: React.ElementType; path: string; roles?: UserRole[] };
type NavGroup = { label: string; items: NavItem[] };

function getNavGroups(role: UserRole): NavGroup[] {
  const r = role || 'user';
  const isStaff = ['admin', 'gestor', 'operador', 'vendedor'].includes(r);
  const isManager = ['admin', 'gestor'].includes(r);

  const groups: NavGroup[] = [
    {
      label: 'Principal',
      items: [
        { label: 'Dashboard', icon: LayoutDashboard, path: '/pdv', roles: ['admin', 'gestor', 'operador', 'vendedor'] },
        { label: 'Caixa', icon: CreditCard, path: '/pdv/caixa', roles: ['admin', 'gestor', 'operador', 'vendedor'] },
        { label: 'Vendas & Cancelamentos', icon: Receipt, path: '/pdv/vendas', roles: ['admin', 'gestor', 'operador', 'vendedor'] },
      ],
    },
    {
      label: 'Cadastros',
      items: [
        { label: 'Produtos', icon: Package, path: '/pdv/produtos', roles: ['admin', 'gestor', 'vendedor'] },
        { label: 'Importar Nota (IA)', icon: FileUp, path: '/pdv/importar-nota', roles: ['admin', 'gestor', 'vendedor'] },
        { label: 'Grades / Variações', icon: Layers, path: '/pdv/grades', roles: ['admin', 'gestor', 'vendedor'] },
        { label: 'Categorias', icon: Tag, path: '/pdv/categorias', roles: ['admin', 'gestor'] },
        { label: 'Clientes', icon: UserCheck, path: '/pdv/clientes', roles: ['admin', 'gestor', 'operador', 'vendedor'] },
        { label: 'Fornecedores', icon: Truck, path: '/pdv/fornecedores', roles: ['admin', 'gestor'] },
      ],
    },
    {
      label: 'Operações',
      items: [
        { label: 'Entrada Mercadorias', icon: Receipt, path: '/pdv/entrada-mercadorias', roles: ['admin', 'gestor'] },
        { label: 'Notas Fiscais', icon: FileText, path: '/pdv/notas-fiscais', roles: ['admin', 'gestor', 'operador', 'vendedor'] },
        { label: 'Cupom Fiscal', icon: ReceiptText, path: '/pdv/cupom-fiscal', roles: ['admin', 'gestor', 'operador'] },
        { label: 'Estoque', icon: Warehouse, path: '/pdv/estoque', roles: ['admin', 'gestor', 'operador', 'vendedor'] },
        { label: 'Lotes / Validade', icon: Clock, path: '/pdv/lotes', roles: ['admin', 'gestor', 'operador'] },
        { label: 'Rastreabilidade', icon: Search, path: '/pdv/rastreabilidade', roles: ['admin', 'gestor'] },
        { label: 'Etiquetas', icon: Printer, path: '/pdv/etiquetas', roles: ['admin', 'gestor', 'operador', 'vendedor'] },
        { label: 'Config. Etiquetas', icon: Settings2, path: '/pdv/configuracao-etiquetas', roles: ['admin', 'gestor'] },
      ],
    },
    {
      label: 'Vendas & Clientes',
      items: [
        { label: 'CRM Avançado', icon: HeartHandshake, path: '/pdv/crm', roles: ['admin', 'gestor', 'vendedor'] },
        { label: 'Pedidos Online', icon: ShoppingCart, path: '/pdv/pedidos-online', roles: ['admin', 'gestor', 'vendedor'] },
        { label: 'Devoluções / Trocas', icon: RefreshCw, path: '/pdv/devolucoes', roles: ['admin', 'gestor', 'operador', 'vendedor'] },
        { label: 'Entregas', icon: CalendarDays, path: '/pdv/entregas', roles: ['admin', 'gestor', 'vendedor'] },
        { label: 'Garantias', icon: Shield, path: '/pdv/garantias', roles: ['admin', 'gestor', 'operador', 'vendedor'] },
        { label: 'Fidelidade / Pontos', icon: Star, path: '/pdv/fidelidade', roles: ['admin', 'gestor', 'vendedor'] },
        { label: 'Indicações', icon: Users2, path: '/pdv/indicacoes', roles: ['admin', 'gestor', 'vendedor'] },
      ],
    },
    {
      label: 'Gestão Financeira',
      items: [
        { label: 'Relatórios', icon: PieChart, path: '/pdv/relatorios', roles: ['admin', 'gestor'] },
        { label: 'Financeiro', icon: BarChart3, path: '/pdv/financeiro', roles: ['admin', 'gestor'] },
        { label: 'Contas a Pagar/Receber', icon: DollarSign, path: '/pdv/contas', roles: ['admin', 'gestor'] },
        { label: 'Métodos de Pagamento', icon: CreditCard, path: '/pdv/metodos-pagamento', roles: ['admin', 'gestor'] },
        { label: 'Comissões', icon: Award, path: '/pdv/comissoes', roles: ['admin', 'gestor'] },
        { label: 'Conciliação Bancária', icon: Landmark, path: '/pdv/conciliacao', roles: ['admin', 'gestor'] },
        { label: 'Exportação Contábil', icon: BookOpen, path: '/pdv/contabilidade', roles: ['admin', 'gestor'] },
      ],
    },
    {
      label: 'Expansão',
      items: [
        { label: 'Filiais', icon: GitBranch, path: '/pdv/filiais', roles: ['admin', 'gestor'] },
        { label: 'Marketplaces', icon: ShoppingBag, path: '/pdv/marketplaces', roles: ['admin', 'gestor'] },
        { label: 'Análise Preditiva', icon: TrendingUp, path: '/pdv/analise-preditiva', roles: ['admin', 'gestor'] },
      ],
    },
    {
      label: 'Sistema',
      items: [
        { label: 'Fiscal & Certificado', icon: Lock, path: '/pdv/fiscal', roles: ['admin', 'gestor'] },
        { label: 'Meta Pixel & Marketing', icon: Share2, path: '/pdv/marketing', roles: ['admin', 'gestor'] },
        { label: 'Feed Meta & Instagram', icon: Rss, path: '/pdv/feed-meta', roles: ['admin', 'gestor', 'vendedor'] },
        { label: 'Usuários', icon: Users, path: '/pdv/usuarios', roles: ['admin', 'gestor'] },
        { label: 'Empresa', icon: Building2, path: '/pdv/empresa', roles: ['admin', 'gestor'] },
        { label: 'Auditoria', icon: Eye, path: '/pdv/auditoria', roles: ['admin', 'gestor'] },
        { label: 'Configurações', icon: Settings, path: '/pdv/configuracoes', roles: ['admin', 'gestor'] },
      ],
    },
  ];

  // Filter items by role
  return groups
    .map(g => ({
      ...g,
      items: g.items.filter(i => !i.roles || i.roles.includes(r)),
    }))
    .filter(g => g.items.length > 0);
}

function SidebarContent({ onItemClick }: { onItemClick?: () => void }) {
  const location = useLocation();
  const navigate = useNavigate();
  const { profile, signOut } = useAuth();
  const navGroups = getNavGroups((profile?.role ?? 'user') as UserRole);

  const handleSignOut = async () => {
    await signOut();
    navigate('/pdv/login');
  };

  return (
    <div className="flex flex-col h-full bg-sidebar">
      {/* Logo */}
      <div className="flex items-center gap-3 px-4 py-4 border-b border-sidebar-border shrink-0">
        <div className="h-9 w-9 rounded-lg bg-sidebar-primary flex items-center justify-center shrink-0">
          <Droplets className="h-5 w-5 text-sidebar-primary-foreground" />
        </div>
        <div className="min-w-0">
          <p className="font-bold text-sidebar-foreground text-sm truncate">Mundo Limpo</p>
          <p className="text-[11px] text-sidebar-foreground/50">Sistema PDV</p>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto px-3 py-3 space-y-4">
        {navGroups.map((group) => (
          <div key={group.label}>
            <p className="text-[10px] font-semibold uppercase tracking-widest text-sidebar-foreground/40 px-3 mb-1">{group.label}</p>
            <div className="space-y-0.5">
              {group.items.map((item) => {
                const active = location.pathname === item.path;
                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    onClick={onItemClick}
                    className={cn(
                      'flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors',
                      active
                        ? 'bg-sidebar-accent text-sidebar-primary font-semibold'
                        : 'text-sidebar-foreground/75 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
                    )}
                  >
                    <item.icon className="h-4 w-4 shrink-0" />
                    <span className="truncate">{item.label}</span>
                    {active && <ChevronRight className="h-3 w-3 ml-auto text-sidebar-primary shrink-0" />}
                  </Link>
                );
              })}
            </div>
          </div>
        ))}
      </nav>

      {/* Footer */}
      <div className="border-t border-sidebar-border px-3 py-3 shrink-0">
        <div className="flex items-center gap-2 px-3 py-2 mb-1">
          <div className="h-7 w-7 rounded-full bg-sidebar-accent flex items-center justify-center shrink-0">
            <span className="text-xs font-bold text-sidebar-accent-foreground">
              {(profile?.username || profile?.full_name || 'U').charAt(0).toUpperCase()}
            </span>
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-xs font-medium text-sidebar-foreground truncate">
              {profile?.full_name || profile?.username || 'Usuário'}
            </p>
            <p className="text-[10px] text-sidebar-foreground/50 capitalize">{profile?.role || 'operador'}</p>
          </div>
        </div>
        <button
          onClick={handleSignOut}
          className="w-full flex items-center gap-3 px-3 py-2 rounded-md text-sm text-destructive hover:bg-sidebar-accent transition-colors"
        >
          <LogOut className="h-4 w-4" />
          Sair
        </button>
        <Link
          to="/admin"
          onClick={onItemClick}
          className="w-full flex items-center gap-3 px-3 py-2 rounded-md text-sm font-semibold text-sidebar-primary hover:bg-sidebar-accent transition-colors"
        >
          <ShieldCheck className="h-4 w-4 shrink-0" />
          Painel Admin
        </Link>
      </div>
    </div>
  );
}

interface PdvLayoutProps {
  children: ReactNode;
  title?: string;
  actions?: ReactNode;
}

export function PdvLayout({ children, title, actions }: PdvLayoutProps) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const { profile, loading: authLoading } = useAuth();
  const permissions = usePermissions();

  // Route guard: redirect if user doesn't have permission for current path
  useEffect(() => {
    if (authLoading) return;
    const role = profile?.role ?? 'user';
    if (!permissions.isStaff) {
      navigate('/pdv/login');
      return;
    }
    const navGroups = getNavGroups(role);
    const allPaths = navGroups.flatMap(g => g.items.map(i => i.path));
    // Allow exact matches or child routes
    const allowed = allPaths.some(p => location.pathname === p || location.pathname.startsWith(p + '/'));
    if (!allowed) {
      // Redirect to first available page or dashboard
      const first = allPaths[0] || '/pdv';
      navigate(first, { replace: true });
    }
  }, [location.pathname, profile?.role, authLoading, permissions.isStaff, navigate]);

  return (
    <div className="flex min-h-screen w-full bg-background">
      {/* Desktop sidebar */}
      <aside className="hidden lg:flex flex-col w-56 shrink-0 border-r border-sidebar-border sticky top-0 h-screen">
        <SidebarContent />
      </aside>

      {/* Mobile sidebar */}
      <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
        <SheetContent side="left" className="p-0 w-56 bg-sidebar border-r border-sidebar-border">
          <SidebarContent onItemClick={() => setMobileOpen(false)} />
        </SheetContent>
      </Sheet>

      {/* Main content */}
      <div className="flex-1 min-w-0 flex flex-col">
        {/* Header */}
        <header className="sticky top-0 z-40 bg-background border-b border-border flex items-center gap-3 px-4 md:px-6 h-14 shrink-0">
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden shrink-0"
            onClick={() => setMobileOpen(true)}
          >
            <Menu className="h-5 w-5" />
          </Button>
          <h1 className="text-base font-semibold text-foreground truncate flex-1 min-w-0 text-balance">
            {title || 'PDV Mundo Limpo'}
          </h1>
          {actions && <div className="flex items-center gap-2 shrink-0">{actions}</div>}
        </header>

        {/* Page content */}
        <main className="flex-1 p-4 md:p-6 overflow-x-hidden">
          {children}
        </main>
      </div>
    </div>
  );
}
