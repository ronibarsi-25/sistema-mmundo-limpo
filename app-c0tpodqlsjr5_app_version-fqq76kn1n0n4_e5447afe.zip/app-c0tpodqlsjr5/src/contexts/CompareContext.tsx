import { createContext, useContext, useState, type ReactNode } from 'react';
import type { Product } from '@/types/types';
import { toast } from 'sonner';

const MAX_COMPARE = 4;

interface CompareContextType {
  compareItems: Product[];
  addToCompare: (product: Product) => void;
  removeFromCompare: (productId: string) => void;
  clearCompare: () => void;
  isInCompare: (productId: string) => boolean;
}

const CompareContext = createContext<CompareContextType | undefined>(undefined);

export function CompareProvider({ children }: { children: ReactNode }) {
  const [compareItems, setCompareItems] = useState<Product[]>([]);

  const addToCompare = (product: Product) => {
    if (compareItems.find(p => p.id === product.id)) {
      toast.info('Produto já está na comparação');
      return;
    }
    if (compareItems.length >= MAX_COMPARE) {
      toast.error(`Máximo de ${MAX_COMPARE} produtos para comparação`);
      return;
    }
    setCompareItems(prev => [...prev, product]);
    toast.success(`${product.name} adicionado à comparação`);
  };

  const removeFromCompare = (productId: string) => {
    setCompareItems(prev => prev.filter(p => p.id !== productId));
  };

  const clearCompare = () => setCompareItems([]);

  const isInCompare = (productId: string) => compareItems.some(p => p.id === productId);

  return (
    <CompareContext.Provider value={{ compareItems, addToCompare, removeFromCompare, clearCompare, isInCompare }}>
      {children}
    </CompareContext.Provider>
  );
}

export function useCompare() {
  const context = useContext(CompareContext);
  if (!context) throw new Error('useCompare deve ser usado dentro de CompareProvider');
  return context;
}
