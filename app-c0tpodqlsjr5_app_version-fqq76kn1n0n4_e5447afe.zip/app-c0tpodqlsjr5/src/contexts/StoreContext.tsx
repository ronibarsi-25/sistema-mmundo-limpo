import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import { supabase } from '@/db/supabase';
import type { StoreSettings, Subscription } from '@/types/types';
import { useTenant } from './TenantContext';

interface StoreContextType {
  settings: StoreSettings | null;
  subscription: Subscription | null;
  loading: boolean;
  refreshSettings: () => Promise<void>;
  reload: () => Promise<void>;
  isExpired: boolean;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

export function StoreProvider({ children }: { children: ReactNode }) {
  const { tenant } = useTenant();
  const [settings, setSettings] = useState<StoreSettings | null>(null);
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    setLoading(true);
    const tenantId = tenant?.id;
    const baseQuery = (q: any) => (tenantId ? q.eq('tenant_id', tenantId) : q);
    const [settingsRes, subRes] = await Promise.all([
      baseQuery(supabase.from('store_settings').select('*')).limit(1).maybeSingle(),
      baseQuery(supabase.from('subscriptions').select('*')).limit(1).maybeSingle()
    ]);

    setSettings(settingsRes.data);
    setSubscription(subRes.data);
    setLoading(false);
  };

  const refreshSettings = async () => { await fetchData(); };
  const reload = async () => { await fetchData(); };

  useEffect(() => { fetchData(); }, [tenant?.id]);

  useEffect(() => {
    const name = settings?.store_name?.trim() || 'Mundo Limpo';
    const desc = settings?.store_description || `Bem-vindo à ${name}`;

    // Título da aba
    document.title = name;

    // Helper para setar/criar meta tag
    const setMeta = (selector: string, attr: string, value: string) => {
      let el = document.querySelector<HTMLMetaElement>(selector);
      if (!el) {
        el = document.createElement('meta');
        el.setAttribute(selector.includes('property') ? 'property' : 'name',
          selector.replace(/.*["'](.+)["'].*/, '$1'));
        document.head.appendChild(el);
      }
      el.setAttribute(attr, value);
    };

    // Open Graph
    setMeta('meta[property="og:title"]', 'content', name);
    setMeta('meta[property="og:site_name"]', 'content', name);
    setMeta('meta[property="og:description"]', 'content', desc);
    setMeta('meta[property="og:type"]', 'content', 'website');

    // Meta description padrão
    setMeta('meta[name="description"]', 'content', desc);

    // Favicon dinâmico com inicial da loja
    const canvas = document.createElement('canvas');
    canvas.width = 64;
    canvas.height = 64;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      // Fundo cor primária (CSS var ou azul padrão)
      const primary = getComputedStyle(document.documentElement)
        .getPropertyValue('--primary').trim() || '222 47% 40%';
      ctx.fillStyle = `hsl(${primary})`;
      ctx.beginPath();
      ctx.roundRect(0, 0, 64, 64, 12);
      ctx.fill();
      // Letra inicial
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 36px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(name.charAt(0).toUpperCase(), 32, 34);
      // Injetar favicon
      let link = document.querySelector<HTMLLinkElement>("link[rel~='icon']");
      if (!link) {
        link = document.createElement('link');
        link.rel = 'icon';
        document.head.appendChild(link);
      }
      link.href = canvas.toDataURL('image/png');
    }
  }, [settings]);

  const isExpired = subscription ? (
    (subscription.status === 'expired') ||
    (subscription.status === 'trial' && new Date(subscription.trial_ends_at) < new Date()) ||
    (subscription.status === 'active' && new Date(subscription.expires_at) < new Date())
  ) : false;

  return (
    <StoreContext.Provider value={{ settings, subscription, loading, refreshSettings, reload, isExpired }}>
      {children}
    </StoreContext.Provider>
  );
}

export function useStore() {
  const context = useContext(StoreContext);
  if (!context) throw new Error('useStore deve ser usado dentro de StoreProvider');
  return context;
}
