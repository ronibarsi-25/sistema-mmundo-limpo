import { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from 'react';
import { supabase } from '@/db/supabase';
import { useAuth } from './AuthContext';
import type { Tenant } from '@/types/types';

interface TenantContextType {
  tenant: Tenant | null;
  loading: boolean;
  setTenant: (tenant: Tenant | null) => void;
  refreshTenant: () => Promise<void>;
}

const TenantContext = createContext<TenantContextType | undefined>(undefined);

export function TenantProvider({ children }: { children: ReactNode }) {
  const { profile } = useAuth();
  const [tenant, setTenant] = useState<Tenant | null>(null);
  const [loading, setLoading] = useState(true);

  const refreshTenant = useCallback(async () => {
    if (!profile?.tenant_id) {
      setTenant(null);
      setLoading(false);
      return;
    }
    const { data, error } = await supabase
      .from('tenants')
      .select('*')
      .eq('id', profile.tenant_id)
      .maybeSingle();
    if (error) {
      console.error('Erro ao carregar tenant:', error);
      setTenant(null);
    } else {
      setTenant(data as Tenant | null);
    }
    setLoading(false);
  }, [profile?.tenant_id]);

  useEffect(() => {
    refreshTenant();
  }, [refreshTenant]);

  return (
    <TenantContext.Provider value={{ tenant, loading, setTenant, refreshTenant }}>
      {children}
    </TenantContext.Provider>
  );
}

export function useTenant() {
  const ctx = useContext(TenantContext);
  if (!ctx) throw new Error('useTenant must be used within TenantProvider');
  return ctx;
}
