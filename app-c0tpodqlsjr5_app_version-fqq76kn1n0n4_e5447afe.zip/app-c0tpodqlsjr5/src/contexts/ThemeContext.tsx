import { createContext, useContext, useEffect, useState, useCallback, type ReactNode } from 'react';
import { supabase } from '@/db/supabase';
import { useTenant } from './TenantContext';
import type { ThemeSettings } from '@/types/types';

// Paletas vibrantes pré-definidas
export const THEME_PRESETS = [
  { name: 'azul-vibrante', label: 'Azul Vibrante', primary: '#2563EB', secondary: '#7C3AED', accent: '#F59E0B', bg: '#FAFAFA' },
  { name: 'verde-fresco', label: 'Verde Fresco', primary: '#059669', secondary: '#0891B2', accent: '#F59E0B', bg: '#F0FDF4' },
  { name: 'roxo-intenso', label: 'Roxo Intenso', primary: '#7C3AED', secondary: '#DB2777', accent: '#F59E0B', bg: '#FAF5FF' },
  { name: 'laranja-energetico', label: 'Laranja Enérgico', primary: '#EA580C', secondary: '#DC2626', accent: '#FBBF24', bg: '#FFF7ED' },
  { name: 'rosa-vibrante', label: 'Rosa Vibrante', primary: '#DB2777', secondary: '#9333EA', accent: '#06B6D4', bg: '#FDF2F8' },
  { name: 'teal-moderno', label: 'Teal Moderno', primary: '#0891B2', secondary: '#059669', accent: '#F59E0B', bg: '#F0FDFA' },
  { name: 'vermelho-bold', label: 'Vermelho Bold', primary: '#DC2626', secondary: '#EA580C', accent: '#FBBF24', bg: '#FFF1F2' },
  { name: 'escuro-elegante', label: 'Escuro Elegante', primary: '#1E293B', secondary: '#7C3AED', accent: '#F59E0B', bg: '#F8FAFC' },
];

export const FONT_OPTIONS = [
  { value: 'Inter', label: 'Inter (Padrão)' },
  { value: 'Roboto', label: 'Roboto' },
  { value: 'Poppins', label: 'Poppins' },
  { value: 'Montserrat', label: 'Montserrat' },
  { value: 'Open Sans', label: 'Open Sans' },
  { value: 'Lato', label: 'Lato' },
];

interface ThemeContextType {
  theme: ThemeSettings | null;
  loading: boolean;
  applyTheme: (settings: Partial<ThemeSettings>) => void;
  saveTheme: (settings: Partial<ThemeSettings>) => Promise<void>;
  reload: () => Promise<void>;
}

const ThemeContext = createContext<ThemeContextType>({
  theme: null,
  loading: true,
  applyTheme: () => {},
  saveTheme: async () => {},
  reload: async () => {},
});

// Converte hex (#2563EB) para HSL string usada pelo shadcn ("221 83% 53%")
function hexToHsl(hex: string): string {
  const clean = hex.replace('#', '');
  if (clean.length !== 6) return '221 83% 53%';
  const r = parseInt(clean.slice(0, 2), 16) / 255;
  const g = parseInt(clean.slice(2, 4), 16) / 255;
  const b = parseInt(clean.slice(4, 6), 16) / 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  let h = 0, s = 0;
  const l = (max + min) / 2;
  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r: h = ((g - b) / d + (g < b ? 6 : 0)) / 6; break;
      case g: h = ((b - r) / d + 2) / 6; break;
      case b: h = ((r - g) / d + 4) / 6; break;
    }
  }
  return `${Math.round(h * 360)} ${Math.round(s * 100)}% ${Math.round(l * 100)}%`;
}

// Determina se texto deve ser branco ou escuro sobre a cor dada
function foregroundHsl(hex: string): string {
  const clean = hex.replace('#', '');
  if (clean.length !== 6) return '0 0% 100%';
  const r = parseInt(clean.slice(0, 2), 16);
  const g = parseInt(clean.slice(2, 4), 16);
  const b = parseInt(clean.slice(4, 6), 16);
  const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  return luminance > 0.55 ? '0 0% 10%' : '0 0% 100%';
}

// Aplica TODOS os tokens CSS no :root
function applyThemeToDom(t: Partial<ThemeSettings>) {
  const root = document.documentElement;

  if (t.primary_color) {
    const hsl = hexToHsl(t.primary_color);
    const fg = foregroundHsl(t.primary_color);
    root.style.setProperty('--primary', hsl);
    root.style.setProperty('--primary-foreground', fg);
    root.style.setProperty('--ring', hsl);
    root.style.setProperty('--sidebar-primary', hsl);
    root.style.setProperty('--sidebar-primary-foreground', fg);
  }

  if (t.secondary_color) {
    const hsl = hexToHsl(t.secondary_color);
    const fg = foregroundHsl(t.secondary_color);
    root.style.setProperty('--secondary', hsl);
    root.style.setProperty('--secondary-foreground', fg);
  }

  if (t.accent_color) {
    const hsl = hexToHsl(t.accent_color);
    const fg = foregroundHsl(t.accent_color);
    root.style.setProperty('--accent', hsl);
    root.style.setProperty('--accent-foreground', fg);
  }

  if (t.background_color) {
    const hsl = hexToHsl(t.background_color);
    root.style.setProperty('--background', hsl);
    root.style.setProperty('--card', hsl);
  }

  if (t.font_family) {
    root.style.setProperty('--font-sans', `'${t.font_family}', system-ui, sans-serif`);
    document.body.style.fontFamily = `'${t.font_family}', system-ui, sans-serif`;
  }

  if (t.border_radius) {
    root.style.setProperty('--radius', `${t.border_radius}px`);
  }
}

export function ThemeProvider({ children }: { children: ReactNode }) {
  const { tenant } = useTenant();
  const [theme, setTheme] = useState<ThemeSettings | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchTheme = useCallback(async () => {
    try {
      const { data, error } = await supabase
        .from('theme_settings')
        .select('*')
        .order('created_at', { ascending: true })
        .limit(1)
        .maybeSingle();

      if (!error && data) {
        setTheme(data as ThemeSettings);
        applyThemeToDom(data);
      }
    } catch {
      // silencia erros de rede, mantém tema padrão
    } finally {
      setLoading(false);
    }
  }, []);

  // Aplica cores do tenant quando carregadas (white-label)
  useEffect(() => {
    if (tenant) {
      applyThemeToDom({
        primary_color: tenant.primary_color,
        secondary_color: tenant.secondary_color,
        accent_color: tenant.accent_color,
      });
    }
  }, [tenant?.primary_color, tenant?.secondary_color, tenant?.accent_color]);

  useEffect(() => { fetchTheme(); }, [fetchTheme]);

  const applyTheme = useCallback((settings: Partial<ThemeSettings>) => {
    applyThemeToDom(settings);
  }, []);

  const saveTheme = useCallback(async (settings: Partial<ThemeSettings>) => {
    // Aplica imediatamente no DOM
    applyThemeToDom(settings);

    const payload = { ...settings, updated_at: new Date().toISOString() };

    if (theme?.id) {
      await supabase.from('theme_settings').update(payload).eq('id', theme.id);
    } else {
      await supabase.from('theme_settings').insert(payload);
    }

    // Recarrega para sincronizar estado
    await fetchTheme();
  }, [theme, fetchTheme]);

  const reload = useCallback(async () => { await fetchTheme(); }, [fetchTheme]);

  return (
    <ThemeContext.Provider value={{ theme, loading, applyTheme, saveTheme, reload }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() { return useContext(ThemeContext); }
