// Hook de proteção contra brute-force no login.
// Armazena tentativas no localStorage para persistir entre recarregamentos.
// Após MAX_ATTEMPTS falhas consecutivas, bloqueia por LOCKOUT_MS.

import { useState, useEffect, useCallback, useRef } from 'react';

const MAX_ATTEMPTS = 5;
const LOCKOUT_MS = 5 * 60 * 1000; // 5 minutos
const PREFIX = 'login_limit_';

interface LimitEntry {
  attempts: number;
  lockedUntil: number | null; // timestamp em ms
}

function getEntry(key: string): LimitEntry {
  try {
    const raw = localStorage.getItem(PREFIX + key);
    if (raw) return JSON.parse(raw) as LimitEntry;
  } catch { /* ignora erros de parse */ }
  return { attempts: 0, lockedUntil: null };
}

function saveEntry(key: string, entry: LimitEntry) {
  try {
    localStorage.setItem(PREFIX + key, JSON.stringify(entry));
  } catch { /* ignora erros de storage */ }
}

function clearEntry(key: string) {
  try { localStorage.removeItem(PREFIX + key); } catch { /* noop */ }
}

export function useLoginRateLimit(identifier: string) {
  const [remainingSeconds, setRemainingSeconds] = useState(0);
  const [attempts, setAttempts] = useState(0);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Sincroniza state com a entrada atual do localStorage
  const syncState = useCallback(() => {
    const entry = getEntry(identifier);
    const now = Date.now();
    if (entry.lockedUntil && entry.lockedUntil > now) {
      setRemainingSeconds(Math.ceil((entry.lockedUntil - now) / 1000));
    } else {
      setRemainingSeconds(0);
    }
    setAttempts(entry.attempts);
  }, [identifier]);

  // Inicia countdown enquanto bloqueado
  useEffect(() => {
    syncState();
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = setInterval(() => {
      const entry = getEntry(identifier);
      const now = Date.now();
      if (entry.lockedUntil && entry.lockedUntil > now) {
        setRemainingSeconds(Math.ceil((entry.lockedUntil - now) / 1000));
      } else {
        setRemainingSeconds(0);
        setAttempts(entry.attempts);
      }
    }, 1000);
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [identifier, syncState]);

  const isLocked = remainingSeconds > 0;

  // Formata mm:ss
  const lockoutLabel = isLocked
    ? `${String(Math.floor(remainingSeconds / 60)).padStart(2, '0')}:${String(remainingSeconds % 60).padStart(2, '0')}`
    : '';

  const recordFailure = useCallback(() => {
    const entry = getEntry(identifier);
    const newAttempts = entry.attempts + 1;
    const lockedUntil = newAttempts >= MAX_ATTEMPTS ? Date.now() + LOCKOUT_MS : entry.lockedUntil;
    const updated: LimitEntry = { attempts: newAttempts, lockedUntil };
    saveEntry(identifier, updated);
    syncState();
    return newAttempts;
  }, [identifier, syncState]);

  const recordSuccess = useCallback(() => {
    clearEntry(identifier);
    setAttempts(0);
    setRemainingSeconds(0);
  }, [identifier]);

  return {
    isLocked,
    remainingSeconds,
    lockoutLabel,
    attempts,
    maxAttempts: MAX_ATTEMPTS,
    attemptsLeft: Math.max(0, MAX_ATTEMPTS - attempts),
    recordFailure,
    recordSuccess,
  };
}
