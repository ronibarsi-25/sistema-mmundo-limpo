import { useMemo } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import type { UserRole } from '@/types/types';

/* --- Permission matrix --- */
const ROLE_WEIGHT: Record<UserRole, number> = {
  user: 0,
  operador: 1,
  vendedor: 2,
  gestor: 3,
  admin: 4,
};

export function usePermissions() {
  const { profile } = useAuth();
  const role = profile?.role ?? 'user';
  const weight = ROLE_WEIGHT[role] ?? 0;

  return useMemo(() => ({
    role,
    weight,

    // Level checks
    isAdmin: role === 'admin',
    isGestor: role === 'gestor',
    isOperador: role === 'operador',
    isVendedor: role === 'vendedor',
    isCliente: role === 'user',

    // Group checks
    isStaff: ['admin', 'gestor', 'operador', 'vendedor'].includes(role),
    isManager: ['admin', 'gestor'].includes(role),

    // Feature permissions
    canAccessPdv: weight >= 1,
    canAccessCaixa: weight >= 1,
    canManageProducts: ['admin', 'gestor', 'vendedor'].includes(role),
    canManageCategories: ['admin', 'gestor'].includes(role),
    canManageClients: weight >= 1,
    canManageSuppliers: ['admin', 'gestor'].includes(role),
    canAccessEstoque: ['admin', 'gestor', 'operador', 'vendedor'].includes(role),
    canAccessFiscal: ['admin', 'gestor'].includes(role),
    canAccessFinanceiro: ['admin', 'gestor'].includes(role),
    canAccessRelatorios: ['admin', 'gestor'].includes(role),
    canManageUsers: ['admin', 'gestor'].includes(role),
    canAccessConfig: ['admin', 'gestor'].includes(role),
    canAccessEmpresa: ['admin', 'gestor'].includes(role),
    canImportNota: ['admin', 'gestor', 'vendedor'].includes(role),
    canAccessCupomFiscal: ['admin', 'gestor', 'operador'].includes(role),
    canAccessNotasFiscais: ['admin', 'gestor', 'operador', 'vendedor'].includes(role),
    canAccessDevolucoes: ['admin', 'gestor', 'operador', 'vendedor'].includes(role),
    canAccessCRM: ['admin', 'gestor', 'vendedor'].includes(role),
    canAccessPedidosOnline: ['admin', 'gestor', 'vendedor'].includes(role),
    canAccessFidelidade: ['admin', 'gestor', 'vendedor'].includes(role),
    canAccessComissoes: ['admin', 'gestor'].includes(role),
    canAccessMarketplaces: ['admin', 'gestor'].includes(role),
    canAccessAnalisePreditiva: ['admin', 'gestor'].includes(role),
    canAccessFiliais: ['admin', 'gestor'].includes(role),
    canAccessConciliacao: ['admin', 'gestor'].includes(role),
    canAccessContabilidade: ['admin', 'gestor'].includes(role),
    canAccessContas: ['admin', 'gestor'].includes(role),
    canAccessEntregas: ['admin', 'gestor', 'vendedor'].includes(role),
    canAccessGarantias: ['admin', 'gestor', 'operador', 'vendedor'].includes(role),
    canAccessIndicacoes: ['admin', 'gestor', 'vendedor'].includes(role),
    canAccessLotes: ['admin', 'gestor', 'operador'].includes(role),
    canAccessRastreabilidade: ['admin', 'gestor'].includes(role),
    canAccessEtiquetas: ['admin', 'gestor', 'operador', 'vendedor'].includes(role),
    canAccessGrades: ['admin', 'gestor', 'vendedor'].includes(role),
  }), [role, weight]);
}
