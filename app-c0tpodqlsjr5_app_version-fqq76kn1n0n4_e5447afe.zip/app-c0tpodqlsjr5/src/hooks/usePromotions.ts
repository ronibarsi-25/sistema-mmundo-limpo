import { useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/db/supabase';
import type { Promotion, Product } from '@/types/types';

// Cache global para promoções (module-level)
let promoCache: { data: Promotion[]; timestamp: number } | null = null;
const CACHE_TTL_MS = 120000; // 2 minutos

function getCachedPromotions(): Promotion[] | null {
  if (!promoCache) return null;
  if (Date.now() - promoCache.timestamp > CACHE_TTL_MS) {
    promoCache = null;
    return null;
  }
  return promoCache.data;
}

function setCachedPromotions(data: Promotion[]) {
  promoCache = { data, timestamp: Date.now() };
}

// Retorna as promoções ativas no momento atual (com cache)
export function useActivePromotions() {
  const [promotions, setPromotions] = useState<Promotion[]>(getCachedPromotions() || []);
  const [loading, setLoading] = useState(!promoCache);
  const fetchingRef = useRef(false);

  const fetchPromos = useCallback(async () => {
    const cached = getCachedPromotions();
    if (cached) {
      setPromotions(cached);
      setLoading(false);
      return;
    }
    if (fetchingRef.current) return; // evita race condition
    fetchingRef.current = true;
    const now = new Date().toISOString();
    const { data } = await supabase
      .from('promotions')
      .select('*')
      .eq('is_active', true)
      .lte('starts_at', now)
      .gte('ends_at', now)
      .order('discount_value', { ascending: false });
    const result = Array.isArray(data) ? data as Promotion[] : [];
    setCachedPromotions(result);
    setPromotions(result);
    setLoading(false);
    fetchingRef.current = false;
  }, []);

  useEffect(() => { fetchPromos(); }, [fetchPromos]);

  return { promotions, loading };
}

// Calcula o preço com desconto de um produto dado as promoções ativas
// Inclui promoções standard; progressivo/compre-X-leve-Y são calculados na quantidade
export function getPromotionalPrice(product: Product, promotions: Promotion[], quantity = 1): number | null {
  if (!promotions.length) return null;

  // Filtra promoções que se aplicam a este produto
  const applicable = promotions.filter(p => {
    if (p.scope === 'all') return true;
    if (p.scope === 'categories' && product.category_id) return p.scope_ids.includes(product.category_id);
    if (p.scope === 'products') return p.scope_ids.includes(product.id);
    return false;
  });

  if (!applicable.length) return null;

  let bestPrice = product.price;

  for (const p of applicable) {
    // Promoção padrão: percentual ou fixo
    if (p.promo_type === 'standard' || !p.promo_type) {
      const discounted = p.discount_type === 'percent'
        ? product.price * (1 - p.discount_value / 100)
        : product.price - p.discount_value;
      if (discounted < bestPrice) bestPrice = discounted;
    }

    // Desconto progressivo: aplica faixa conforme quantidade
    if (p.promo_type === 'progressive' && p.progressive_tiers?.length) {
      const tier = p.progressive_tiers
        .filter(t => quantity >= t.min_qty && (t.max_qty === null || quantity <= t.max_qty))
        .sort((a, b) => b.discount_percent - a.discount_percent)[0];
      if (tier) {
        const discounted = product.price * (1 - tier.discount_percent / 100);
        if (discounted < bestPrice) bestPrice = discounted;
      }
    }

    // Compre X Leve Y: preço efetivo por unidade = (X * price) / Y
    if (p.promo_type === 'buy_x_get_y' && p.buy_quantity && p.get_quantity && quantity >= p.buy_quantity) {
      const effectivePerUnit = (p.buy_quantity * product.price) / p.get_quantity;
      if (effectivePerUnit < bestPrice) bestPrice = effectivePerUnit;
    }
  }

  return bestPrice < product.price ? Math.max(0, bestPrice) : null;
}

// Retorna label de promoção para exibir no card/detalhe
export function getPromotionBadge(product: Product, promotions: Promotion[], quantity = 1): string | null {
  const applicable = promotions.filter(p => {
    if (p.scope === 'all') return true;
    if (p.scope === 'categories' && product.category_id) return p.scope_ids.includes(product.category_id);
    if (p.scope === 'products') return p.scope_ids.includes(product.id);
    return false;
  });
  if (!applicable.length) return null;

  // Prioriza buy_x_get_y > progressive > standard
  const bxgy = applicable.find(p => p.promo_type === 'buy_x_get_y');
  if (bxgy) return `Compre ${bxgy.buy_quantity} Leve ${bxgy.get_quantity}`;

  const progressive = applicable.find(p => p.promo_type === 'progressive' && p.progressive_tiers?.length);
  if (progressive) {
    const tier = progressive.progressive_tiers!
      .filter(t => quantity >= t.min_qty && (t.max_qty === null || quantity <= t.max_qty))
      .sort((a, b) => b.discount_percent - a.discount_percent)[0];
    if (tier) return `${tier.discount_percent}% OFF (${quantity}+ un.)`;
    return 'Desconto Progressivo';
  }

  // Melhor desconto padrão
  const best = applicable
    .filter(p => p.promo_type === 'standard' || !p.promo_type)
    .sort((a, b) => b.discount_value - a.discount_value)[0];
  if (best) {
    return best.discount_type === 'percent' ? `${best.discount_value}% OFF` : `R$ ${best.discount_value.toFixed(2)} OFF`;
  }
  return null;
}
