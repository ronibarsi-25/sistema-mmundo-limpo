import { useEffect, useState } from 'react';
import { toast } from 'sonner';
import { supabase } from '@/db/supabase';

const SESSION_KEY = 'pdv_venc_alert_shown';

export interface VencimentoItem {
  id: string;
  description: string;
  installment_number: number;
  amount: number;
  remaining_amount: number | null;
  due_date: string;
  type: 'pagar' | 'receber';
  days: number; // 0 = hoje, 1..3 = próximos dias, -N = vencido
}

export function useVencimentoAlert() {
  const [itens, setItens] = useState<VencimentoItem[]>([]);
  const [shown, setShown] = useState(false);

  useEffect(() => {
    const already = sessionStorage.getItem(SESSION_KEY);
    if (already) { setShown(true); return; }

    async function check() {
      const today  = new Date();
      today.setHours(0, 0, 0, 0);
      const limit  = new Date(today);
      limit.setDate(today.getDate() + 3);

      const from = today.toISOString().split('T')[0];
      const to   = limit.toISOString().split('T')[0];

      const { data } = await supabase
        .from('bill_installments')
        .select('id, bill_id, installment_number, amount, remaining_amount, due_date, status, bills(description, type)')
        .gte('due_date', from)
        .lte('due_date', to)
        .in('status', ['pendente', 'parcial', 'vencido'])
        .order('due_date');

      const rows: VencimentoItem[] = (data || []).map((i: any) => {
        const due  = new Date(i.due_date + 'T00:00:00');
        const diff = Math.round((due.getTime() - today.getTime()) / 86400000);
        return {
          id: i.id,
          description: i.bills?.description || 'Conta',
          installment_number: i.installment_number,
          amount: i.amount,
          remaining_amount: i.remaining_amount,
          due_date: i.due_date,
          type: i.bills?.type,
          days: diff,
        };
      });

      if (rows.length === 0) return;

      setItens(rows);
      sessionStorage.setItem(SESSION_KEY, '1');
      setShown(true);

      const vencendoHoje   = rows.filter(r => r.days === 0);
      const vencendoBreve  = rows.filter(r => r.days > 0 && r.days <= 3);

      if (vencendoHoje.length > 0) {
        toast.warning(
          `${vencendoHoje.length} parcela(s) vencem HOJE`,
          { description: vencendoHoje.map(r => `• ${r.description} (parc. ${r.installment_number})`).join('\n'), duration: 8000 }
        );
      }
      if (vencendoBreve.length > 0) {
        toast.info(
          `${vencendoBreve.length} parcela(s) vencem em até 3 dias`,
          { description: vencendoBreve.map(r => `• ${r.description} — ${new Date(r.due_date + 'T00:00:00').toLocaleDateString('pt-BR')}`).join('\n'), duration: 6000 }
        );
      }
    }
    check();
  }, []);

  return { itens, shown };
}
