import { createContext, useContext, useState, useCallback } from 'react';

export type Lang = 'pt' | 'en';

type Dict = Record<string, string | Record<string, string>>;

const pt: Dict = {
  'nav.home': 'Início',
  'nav.products': 'Produtos',
  'nav.cart': 'Carrinho',
  'nav.account': 'Minha Conta',
  'nav.login': 'Entrar',
  'nav.logout': 'Sair',
  'product.price': 'Preço',
  'product.stock': 'Estoque',
  'product.add_cart': 'Adicionar ao Carrinho',
  'product.buy_now': 'Comprar Agora',
  'product.out_of_stock': 'Fora de Estoque',
  'product.code': 'Código Interno',
  'product.barcode': 'Código de Barras',
  'product.unit': 'Unidade',
  'product.sku': 'SKU',
  'product.brand': 'Marca',
  'product.weight': 'Peso',
  'product.dimensions': 'Dimensões',
  'product.expiry': 'Validade',
  'product.specs': 'Especificações',
  'product.info': 'Informações do Produto',
  'search.placeholder': 'Buscar produtos...',
  'cart.empty': 'Seu carrinho está vazio',
  'cart.total': 'Total',
  'cart.checkout': 'Finalizar Compra',
  'admin.dashboard': 'Dashboard',
  'admin.products': 'Produtos',
  'admin.orders': 'Pedidos',
  'admin.stock': 'Estoque',
  'admin.export': 'Exportar Dados',
  'admin.import': 'Importar Produtos',
  'admin.movements': 'Movimentações',
  'admin.permissions': 'Permissões',
  'admin.labels': 'Etiquetas',
  'admin.settings': 'Configurações',
  'common.save': 'Salvar',
  'common.cancel': 'Cancelar',
  'common.edit': 'Editar',
  'common.delete': 'Excluir',
  'common.search': 'Buscar',
  'common.loading': 'Carregando...',
  'common.success': 'Sucesso',
  'common.error': 'Erro',
  'common.copy': 'Copiar',
};

const en: Dict = {
  'nav.home': 'Home',
  'nav.products': 'Products',
  'nav.cart': 'Cart',
  'nav.account': 'My Account',
  'nav.login': 'Login',
  'nav.logout': 'Logout',
  'product.price': 'Price',
  'product.stock': 'Stock',
  'product.add_cart': 'Add to Cart',
  'product.buy_now': 'Buy Now',
  'product.out_of_stock': 'Out of Stock',
  'product.code': 'Internal Code',
  'product.barcode': 'Barcode',
  'product.unit': 'Unit',
  'product.sku': 'SKU',
  'product.brand': 'Brand',
  'product.weight': 'Weight',
  'product.dimensions': 'Dimensions',
  'product.expiry': 'Expiry Date',
  'product.specs': 'Specifications',
  'product.info': 'Product Information',
  'search.placeholder': 'Search products...',
  'cart.empty': 'Your cart is empty',
  'cart.total': 'Total',
  'cart.checkout': 'Checkout',
  'admin.dashboard': 'Dashboard',
  'admin.products': 'Products',
  'admin.orders': 'Orders',
  'admin.stock': 'Stock',
  'admin.export': 'Export Data',
  'admin.import': 'Import Products',
  'admin.movements': 'Movements',
  'admin.permissions': 'Permissions',
  'admin.labels': 'Labels',
  'admin.settings': 'Settings',
  'common.save': 'Save',
  'common.cancel': 'Cancel',
  'common.edit': 'Edit',
  'common.delete': 'Delete',
  'common.search': 'Search',
  'common.loading': 'Loading...',
  'common.success': 'Success',
  'common.error': 'Error',
  'common.copy': 'Copy',
};

const DICTS: Record<Lang, Dict> = { pt, en };

interface I18nCtx {
  lang: Lang;
  setLang: (l: Lang) => void;
  t: (key: string) => string;
}

const I18nContext = createContext<I18nCtx>({
  lang: 'pt',
  setLang: () => {},
  t: (key: string) => key,
});

export function I18nProvider({ children }: { children: React.ReactNode }) {
  const [lang, setLangState] = useState<Lang>(() => {
    try {
      const saved = localStorage.getItem('app_lang') as Lang;
      return saved === 'en' ? 'en' : 'pt';
    } catch { return 'pt'; }
  });

  const setLang = useCallback((l: Lang) => {
    setLangState(l);
    try { localStorage.setItem('app_lang', l); } catch { /* noop */ }
  }, []);

  const t = useCallback((key: string) => {
    const dict = DICTS[lang];
    const val = dict[key];
    return typeof val === 'string' ? val : key;
  }, [lang]);

  return (
    <I18nContext.Provider value={{ lang, setLang, t }}>
      {children}
    </I18nContext.Provider>
  );
}

export function useI18n() {
  return useContext(I18nContext);
}
