import { useNavigate, Link } from 'react-router-dom';
import { ShoppingCart, Trash2, Plus, Minus, ArrowRight, ShoppingBag } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { MainLayout } from '@/components/layouts/MainLayout';
import { useCart } from '@/contexts/CartContext';

export default function CartPage() {
  const { items, removeItem, updateQuantity, subtotal, totalItems } = useCart();
  const navigate = useNavigate();

  return (
    <MainLayout>
      <div className="container py-6 md:py-10">
        <div className="flex items-center gap-3 mb-6">
          <ShoppingCart className="h-6 w-6" />
          <h1 className="text-2xl font-bold">Carrinho de Compras</h1>
          {totalItems > 0 && <span className="text-sm text-muted-foreground">({totalItems} {totalItems === 1 ? 'item' : 'itens'})</span>}
        </div>

        {items.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 gap-4 text-center">
            <div className="h-16 w-16 rounded-full bg-muted flex items-center justify-center">
              <ShoppingBag className="h-8 w-8 text-muted-foreground/40" />
            </div>
            <p className="text-lg font-medium">Seu carrinho está vazio</p>
            <p className="text-muted-foreground text-sm">Adicione produtos para continuar</p>
            <Button onClick={() => navigate('/produtos')} className="bg-accent text-accent-foreground hover:bg-accent/90 mt-2">
              Explorar Produtos <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        ) : (
          <div className="grid lg:grid-cols-3 gap-6">
            {/* Items */}
            <div className="lg:col-span-2 space-y-3">
              {items.map(({ product, quantity }) => {
                const imageUrl = product.images?.[0]?.url;
                return (
                  <div key={product.id} className="flex items-center gap-4 p-4 bg-card rounded-xl border border-border">
                    <Link to={`/produto/${product.slug}`} className="h-20 w-20 md:h-24 md:w-24 rounded-lg overflow-hidden bg-muted shrink-0">
                      {imageUrl ? <img src={imageUrl} alt={product.name} className="w-full h-full object-cover" />
                        : <div className="w-full h-full flex items-center justify-center"><ShoppingCart className="h-6 w-6 text-muted-foreground/30" /></div>}
                    </Link>
                    <div className="flex-1 min-w-0">
                      <Link to={`/produto/${product.slug}`}>
                        <p className="text-sm font-medium line-clamp-2 hover:text-accent transition-colors">{product.name}</p>
                      </Link>
                      <p className="text-xs text-muted-foreground mt-0.5">{product.categories?.name}</p>
                      <p className="text-sm font-bold mt-1">
                        {product.price.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                      </p>
                    </div>
                    <div className="flex flex-col items-end gap-3 shrink-0">
                      <button onClick={() => removeItem(product.id)} className="text-muted-foreground hover:text-destructive transition-colors">
                        <Trash2 className="h-4 w-4" />
                      </button>
                      <div className="flex items-center border border-border rounded-md">
                        <button onClick={() => updateQuantity(product.id, quantity - 1)} className="h-7 w-7 flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors">
                          <Minus className="h-3 w-3" />
                        </button>
                        <span className="h-7 w-7 flex items-center justify-center text-xs font-medium">{quantity}</span>
                        <button onClick={() => updateQuantity(product.id, quantity + 1)} className="h-7 w-7 flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors">
                          <Plus className="h-3 w-3" />
                        </button>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Subtotal: {(product.price * quantity).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Summary */}
            <div className="lg:col-span-1">
              <div className="sticky top-20 bg-card rounded-xl border border-border p-5 space-y-4">
                <h2 className="font-semibold text-base">Resumo do Pedido</h2>
                <div className="space-y-2">
                  {items.map(({ product, quantity }) => (
                    <div key={product.id} className="flex justify-between text-sm">
                      <span className="text-muted-foreground truncate mr-2">{product.name} × {quantity}</span>
                      <span className="shrink-0">{(product.price * quantity).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span>
                    </div>
                  ))}
                </div>
                <Separator />
                <div className="flex justify-between font-semibold">
                  <span>Subtotal</span>
                  <span>{subtotal.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span>
                </div>
                <p className="text-xs text-muted-foreground">Frete calculado no checkout</p>
                <Button className="w-full bg-accent text-accent-foreground hover:bg-accent/90 h-11"
                  onClick={() => navigate('/checkout')}>
                  Finalizar Compra <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
                <Button variant="outline" className="w-full" onClick={() => navigate('/produtos')}>
                  Continuar Comprando
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </MainLayout>
  );
}
