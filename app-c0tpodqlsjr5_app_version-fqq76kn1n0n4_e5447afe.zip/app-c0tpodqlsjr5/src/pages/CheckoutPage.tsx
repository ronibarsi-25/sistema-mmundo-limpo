import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import {
  Truck, Store, CreditCard, QrCode, Loader2, Copy, Check,
  Tag, X, CheckCircle2, AlertCircle, Landmark, Wallet, FileText,
  Building2, Smartphone, Package, Clock, Gift, MapPin
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { MainLayout } from '@/components/layouts/MainLayout';
import QRCodeDataUrl from '@/components/ui/qrcodedataurl';
import { useCart } from '@/contexts/CartContext';
import { useAuth } from '@/contexts/AuthContext';
import { useStore } from '@/contexts/StoreContext';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import type { DeliveryAddress, Coupon, PaymentGateway, ShippingOption } from '@/types/types';

const GATEWAY_ICONS: Record<string, React.ElementType> = {
  pix: QrCode,
  stripe: CreditCard,
  pagseguro: Landmark,
  mercadopago: Wallet,
  boleto: FileText,
  deposito: Building2,
  stone: CreditCard,
  cielo: CreditCard,
  rede: CreditCard,
  banricompras: Landmark,
  hipercard: CreditCard,
  amex: CreditCard,
  picpay: Smartphone,
  ame: Wallet,
  mercadocredito: Wallet,
};

interface CheckoutForm {
  name: string;
  phone: string;
  cep: string;
  street: string;
  number: string;
  complement: string;
  neighborhood: string;
  city: string;
  state: string;
}

export default function CheckoutPage() {
  const { items, subtotal, clearCart } = useCart();
  const { user, profile } = useAuth();
  const { settings } = useStore();
  const navigate = useNavigate();
  const [deliveryType, setDeliveryType] = useState<'delivery' | 'pickup'>('delivery');
  const [paymentMethod, setPaymentMethod] = useState<string>('pix');
  const [freightAmount, setFreightAmount] = useState(0);
  const [selectedShipping, setSelectedShipping] = useState<ShippingOption | null>(null);
  const [shippingOptions, setShippingOptions] = useState<ShippingOption[]>([]);
  const [shippingLoading, setShippingLoading] = useState(false);
  const [cepLoading, setCepLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [pixOrderId, setPixOrderId] = useState<string | null>(null);
  const [externalOrderId, setExternalOrderId] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [gateways, setGateways] = useState<PaymentGateway[]>([]);
  const [gatewaysLoading, setGatewaysLoading] = useState(true);

  // Estado do cupom
  const [couponCode, setCouponCode] = useState('');
  const [couponLoading, setCouponLoading] = useState(false);
  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);
  const [couponError, setCouponError] = useState('');

  const form = useForm<CheckoutForm>({
    defaultValues: {
      name: profile?.full_name || '',
      phone: profile?.phone || '',
      cep: '', street: '', number: '', complement: '', neighborhood: '', city: '', state: ''
    }
  });

  useEffect(() => {
    if (!user) { toast.error('Faça login para continuar'); navigate('/login'); return; }
    if (items.length === 0) { navigate('/carrinho'); }
  }, [user, items]);

  // Carrega gateways ativos do banco
  useEffect(() => {
    supabase
      .from('payment_gateways')
      .select('*')
      .eq('is_active', true)
      .order('sort_order', { ascending: true })
      .then(({ data }) => {
        const rows = (Array.isArray(data) ? data : []) as PaymentGateway[];
        setGateways(rows);
        if (rows.length > 0) setPaymentMethod(rows[0].id);
        setGatewaysLoading(false);
      });
  }, []);

  const lookupCep = async (cep: string) => {
    const clean = cep.replace(/\D/g, '');
    if (clean.length !== 8) return;
    setCepLoading(true);
    setShippingOptions([]);
    setSelectedShipping(null);
    setFreightAmount(0);
    try {
      const res = await fetch(`https://viacep.com.br/ws/${clean}/json/`);
      const data = await res.json();
      if (data.erro) { toast.error('CEP não encontrado'); return; }
      form.setValue('street', data.logradouro || '');
      form.setValue('neighborhood', data.bairro || '');
      form.setValue('city', data.localidade || '');
      form.setValue('state', data.uf || '');
      // Calcular frete após preencher endereço
      await calculateShipping(clean);
    } catch { toast.error('Erro ao buscar CEP'); }
    finally { setCepLoading(false); }
  };

  const calculateShipping = async (destCep: string) => {
    const cepOrigin = settings?.correios_cep_origin?.replace(/\D/g, '');
    setShippingLoading(true);
    const options: ShippingOption[] = [];

    // Frete grátis por valor mínimo
    const threshold = settings?.free_shipping_threshold;
    if (threshold && subtotal >= threshold) {
      options.push({ id: 'free_threshold', name: 'Frete Grátis', carrier: 'Promoção', price: 0, min_days: 7, max_days: 14, type: 'free' });
    }

    // Buscar métodos fixos/grátis do banco
    const { data: dbMethods } = await supabase
      .from('shipping_methods')
      .select('*')
      .eq('is_active', true)
      .in('type', ['fixed', 'free'])
      .order('sort_order');

    if (dbMethods) {
      for (const m of dbMethods) {
        options.push({ id: m.id, name: m.name, carrier: m.carrier, price: m.type === 'free' ? 0 : m.price, min_days: m.min_days, max_days: m.max_days, type: m.type });
      }
    }

    // Calcular Correios se CEP origem configurado
    if (cepOrigin && cepOrigin.length === 8 && destCep.length === 8) {
      try {
        const services: string[] = [];
        if (settings?.correios_pac_enabled !== false) services.push('04669');
        if (settings?.correios_sedex_enabled !== false) services.push('04162');

        if (services.length > 0) {
          const { data: calcData } = await supabase.functions.invoke('calculate-shipping', {
            body: {
              cep_origin: cepOrigin,
              cep_destiny: destCep,
              weight_kg: settings?.default_weight_kg || 0.5,
              length_cm: settings?.default_length_cm || 20,
              width_cm: settings?.default_width_cm || 15,
              height_cm: settings?.default_height_cm || 10,
              services,
            },
          });
          if (calcData?.options) {
            for (const o of calcData.options) {
              if (!o.error) {
                options.push({ id: `correios_${o.code}`, name: o.name, carrier: 'Correios', price: o.price, min_days: o.min_days, max_days: o.max_days, type: `correios_${o.code}` });
              }
            }
          }
        }
      } catch { /* falha silenciosa no cálculo Correios */ }
    }

    // Fallback: frete base da loja
    if (options.length === 0) {
      const basePrice = settings?.freight_base_value || 15;
      options.push({ id: 'base', name: 'Entrega Padrão', carrier: 'Loja', price: basePrice, min_days: 5, max_days: 10, type: 'fixed' });
    }

    setShippingOptions(options);
    // Pré-selecionar primeira opção
    const first = options[0];
    setSelectedShipping(first);
    setFreightAmount(first.price);
    setShippingLoading(false);
  };

  // Calcula desconto do cupom
  const couponDiscount = (() => {
    if (!appliedCoupon) return 0;
    const base = subtotal;
    if (appliedCoupon.discount_type === 'percent') return (base * appliedCoupon.discount_value) / 100;
    if (appliedCoupon.discount_type === 'fixed') return Math.min(appliedCoupon.discount_value, base);
    if (appliedCoupon.discount_type === 'free_shipping') return freightAmount;
    return 0;
  })();

  const effectiveFreight = appliedCoupon?.discount_type === 'free_shipping'
    ? 0
    : (deliveryType === 'delivery' ? freightAmount : 0);

  const total = subtotal + effectiveFreight - (appliedCoupon?.discount_type !== 'free_shipping' ? couponDiscount : 0);

  const applyCoupon = async () => {
    const code = couponCode.trim().toUpperCase();
    if (!code) return;
    setCouponLoading(true);
    setCouponError('');
    try {
      const { data, error } = await supabase
        .from('coupons')
        .select('*')
        .eq('code', code)
        .maybeSingle();

      if (error || !data) { setCouponError('Cupom não encontrado.'); setCouponLoading(false); return; }
      const coupon = data as Coupon;
      const now = new Date();

      if (!coupon.is_active) { setCouponError('Este cupom está inativo.'); setCouponLoading(false); return; }
      if (new Date(coupon.starts_at) > now) { setCouponError('Este cupom ainda não é válido.'); setCouponLoading(false); return; }
      if (coupon.ends_at && new Date(coupon.ends_at) < now) { setCouponError('Este cupom está expirado.'); setCouponLoading(false); return; }
      if (coupon.max_uses !== null && coupon.used_count >= coupon.max_uses) { setCouponError('Este cupom atingiu o limite de usos.'); setCouponLoading(false); return; }
      if (coupon.max_uses_per_user !== null && user) {
        const { count, error: countError } = await supabase
          .from('coupon_usages')
          .select('*', { count: 'exact', head: true })
          .eq('coupon_id', coupon.id)
          .eq('user_id', user.id);
        if (!countError && count !== null && count >= coupon.max_uses_per_user) {
          setCouponError(`Você já atingiu o limite de usos deste cupom.`);
          setCouponLoading(false); return;
        }
      }
      if (coupon.min_order_value > 0 && subtotal < coupon.min_order_value) {
        setCouponError(`Pedido mínimo de ${coupon.min_order_value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })} para este cupom.`);
        setCouponLoading(false); return;
      }

      setAppliedCoupon(coupon);
      setCouponError('');
      toast.success(`Cupom "${coupon.code}" aplicado!`);
    } catch { setCouponError('Erro ao validar cupom. Tente novamente.'); }
    finally { setCouponLoading(false); }
  };

  const removeCoupon = () => {
    setAppliedCoupon(null);
    setCouponCode('');
    setCouponError('');
  };

  // Cria pedido genérico (PIX, externo, boleto, etc.)
  const createOrder = async (formData: CheckoutForm, method: string) => {
    const deliveryAddress: DeliveryAddress = {
      name: formData.name, phone: formData.phone, cep: formData.cep,
      street: formData.street, number: formData.number,
      complement: formData.complement, neighborhood: formData.neighborhood,
      city: formData.city, state: formData.state
    };
    const orderItems = items.map(i => ({ id: i.product.id, name: i.product.name, price: i.product.price, quantity: i.quantity, image_url: i.product.images?.[0]?.url || '' }));
    const { data, error } = await supabase.from('orders').insert({
      user_id: user?.id || null,
      items: orderItems,
      subtotal,
      freight_amount: effectiveFreight,
      discount_amount: appliedCoupon ? couponDiscount : 0,
      total_amount: Math.max(0, total),
      status: 'pending',
      delivery_type: deliveryType,
      delivery_address: deliveryType === 'delivery' ? deliveryAddress : null,
      payment_method: method,
      customer_name: formData.name,
      customer_phone: formData.phone,
      customer_email: user?.email || null,
      coupon_id: appliedCoupon?.id || null,
    }).select().single();
    if (error) throw error;
    // Registrar uso do cupom
    if (appliedCoupon && data) {
      await supabase.from('coupon_usages').insert({
        coupon_id: appliedCoupon.id, order_id: data.id, user_id: user?.id || null,
        discount_applied: couponDiscount,
      });
      await supabase.from('coupons').update({ used_count: appliedCoupon.used_count + 1 }).eq('id', appliedCoupon.id);
    }
    return data;
  };

  const handlePixOrder = async (formData: CheckoutForm) => {
    setSubmitting(true);
    try {
      const data = await createOrder(formData, 'pix');
      setPixOrderId(data.id);
    } catch { toast.error('Erro ao criar pedido'); }
    finally { setSubmitting(false); }
  };

  const handleCardPayment = async (formData: CheckoutForm) => {
    setSubmitting(true);
    const deliveryAddress: DeliveryAddress = {
      name: formData.name, phone: formData.phone, cep: formData.cep,
      street: formData.street, number: formData.number,
      complement: formData.complement, neighborhood: formData.neighborhood,
      city: formData.city, state: formData.state
    };
    const orderItems = items.map(i => ({ id: i.product.id, quantity: i.quantity }));
    const { data, error } = await supabase.functions.invoke('create_stripe_checkout', {
      body: {
        items: orderItems,
        delivery_type: deliveryType,
        delivery_address: deliveryType === 'delivery' ? deliveryAddress : null,
        freight_amount: deliveryType === 'delivery' ? freightAmount : 0,
        customer_name: formData.name,
        customer_phone: formData.phone,
        coupon: appliedCoupon ? {
          id: appliedCoupon.id,
          code: appliedCoupon.code,
          discount_type: appliedCoupon.discount_type,
          discount_value: appliedCoupon.discount_value,
        } : null,
      }
    });
    if (error) {
      const msg = await error?.context?.text();
      toast.error(msg || 'Erro ao iniciar pagamento. Verifique a configuração do Stripe.');
      setSubmitting(false); return;
    }
    if (data?.data?.url) window.open(data.data.url, '_blank');
    setSubmitting(false);
  };

  // Gateways externos: cria pedido pendente e redireciona para URL de pagamento
  const handleExternalGateway = async (formData: CheckoutForm, gw: PaymentGateway) => {
    setSubmitting(true);
    try {
      const data = await createOrder(formData, gw.id);
      const checkoutUrl = gw.config?.checkout_url;
      if (checkoutUrl) {
        window.open(checkoutUrl, '_blank');
      }
      setExternalOrderId(data.id);
    } catch { toast.error('Erro ao criar pedido'); }
    finally { setSubmitting(false); }
  };

  // Gateways manuais (boleto/depósito): apenas cria pedido e exibe instruções
  const handleManualGateway = async (formData: CheckoutForm, gw: PaymentGateway) => {
    setSubmitting(true);
    try {
      const data = await createOrder(formData, gw.id);
      setExternalOrderId(data.id);
    } catch { toast.error('Erro ao criar pedido'); }
    finally { setSubmitting(false); }
  };

  const onSubmit = (formData: CheckoutForm) => {
    const gw = gateways.find(g => g.id === paymentMethod);
    if (!gw) return;
    if (paymentMethod === 'pix') return handlePixOrder(formData);
    if (paymentMethod === 'stripe') return handleCardPayment(formData);
    if (['pagseguro', 'mercadopago'].includes(paymentMethod)) return handleExternalGateway(formData, gw);
    // Qualquer outro gateway (stone, cielo, boleto, deposito, etc.) = manual
    return handleManualGateway(formData, gw);
  };

  const handlePixConfirm = () => {
    clearCart();
    navigate(`/minha-conta/pedidos`);
    toast.success('Pedido criado! Confirmaremos após o pagamento PIX.');
  };

  const handleExternalConfirm = () => {
    clearCart();
    navigate(`/minha-conta/pedidos`);
    toast.success('Pedido criado! Confirmaremos após o comprovante de pagamento.');
  };

  const copyPixKey = async () => {
    if (settings?.pix_key) {
      await navigator.clipboard.writeText(settings.pix_key);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
      toast.success('Chave PIX copiada!');
    }
  };

  // Tela PIX
  if (pixOrderId && settings?.pix_key) {
    return (
      <MainLayout>
        <div className="container py-10 max-w-lg">
          <div className="bg-card rounded-2xl border border-border p-8 text-center space-y-5">
            <div className="h-12 w-12 rounded-full bg-success/15 flex items-center justify-center mx-auto">
              <QrCode className="h-6 w-6 text-success" />
            </div>
            <h1 className="text-xl font-bold">Pague com PIX</h1>
            <p className="text-sm text-muted-foreground">Escaneie o QR Code ou copie a chave PIX abaixo:</p>
            <div className="flex justify-center p-4 bg-muted rounded-xl">
              <QRCodeDataUrl text={settings.pix_key} width={180} />
            </div>
            <div className="bg-muted rounded-lg p-3 flex items-center gap-2">
              <span className="flex-1 text-sm font-mono text-foreground truncate">{settings.pix_key}</span>
              <button onClick={copyPixKey} className="shrink-0 text-muted-foreground hover:text-foreground transition-colors">
                {copied ? <Check className="h-4 w-4 text-success" /> : <Copy className="h-4 w-4" />}
              </button>
            </div>
            <p className="text-xs text-muted-foreground">Tipo: {settings.pix_key_type?.toUpperCase()}</p>
            <div className="bg-muted/60 rounded-lg p-3 text-left text-sm space-y-1">
              <div className="flex justify-between"><span className="text-muted-foreground">Subtotal:</span><span>{subtotal.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span></div>
              {deliveryType === 'delivery' && <div className="flex justify-between"><span className="text-muted-foreground">Frete:</span><span>{effectiveFreight > 0 ? effectiveFreight.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }) : 'Grátis'}</span></div>}
              {couponDiscount > 0 && <div className="flex justify-between text-destructive"><span>Cupom ({appliedCoupon?.code}):</span><span>-{couponDiscount.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span></div>}
              <div className="flex justify-between font-bold"><span>Total:</span><span>{Math.max(0, total).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span></div>
            </div>
            <Button className="w-full bg-accent text-accent-foreground hover:bg-accent/90" onClick={handlePixConfirm}>
              Já realizei o pagamento
            </Button>
          </div>
        </div>
      </MainLayout>
    );
  }

  // Tela gateway externo / manual (PagSeguro, MP, boleto, depósito)
  if (externalOrderId) {
    const gw = gateways.find(g => g.id === paymentMethod);
    const Icon = gw ? (GATEWAY_ICONS[gw.id] || CreditCard) : CreditCard;
    const instructions = gw?.config?.instructions;
    const checkoutUrl = gw?.config?.checkout_url;
    return (
      <MainLayout>
        <div className="container py-10 max-w-lg">
          <div className="bg-card rounded-2xl border border-border p-8 text-center space-y-5">
            <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto">
              <Icon className="h-6 w-6 text-primary" />
            </div>
            <h1 className="text-xl font-bold">Pedido criado!</h1>
            <p className="text-sm text-muted-foreground">
              Seu pedido foi registrado. Complete o pagamento via <strong>{gw?.name}</strong> para confirmar.
            </p>
            {checkoutUrl && (
              <Button className="w-full" onClick={() => window.open(checkoutUrl, '_blank')}>
                Pagar via {gw?.name}
              </Button>
            )}
            {instructions && (
              <div className="bg-muted rounded-lg p-4 text-left text-sm text-muted-foreground whitespace-pre-line">
                {instructions}
              </div>
            )}
            {/* Configurações dinâmicas do gateway manual */}
            {gw?.config && Object.keys(gw.config).length > 0 && (
              <div className="bg-muted rounded-lg p-4 text-left text-sm space-y-1">
                {Object.entries(gw.config).filter(([k]) => k !== 'instructions' && k !== 'checkout_url').map(([k, v]) => (
                  <div key={k} className="flex justify-between">
                    <span className="text-muted-foreground capitalize">{k.replace(/_/g, ' ')}:</span>
                    <span className="font-medium">{String(v)}</span>
                  </div>
                ))}
              </div>
            )}
            <div className="bg-muted/60 rounded-lg p-3 text-left text-sm space-y-1">
              <div className="flex justify-between font-bold"><span>Total a pagar:</span><span>{Math.max(0, total).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span></div>
            </div>
            <Button variant="outline" className="w-full" onClick={handleExternalConfirm}>
              Ver meus pedidos
            </Button>
          </div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="container py-6 md:py-10">
        <h1 className="text-2xl font-bold mb-6">Checkout</h1>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            <div className="grid lg:grid-cols-3 gap-6">
              {/* Left: form */}
              <div className="lg:col-span-2 space-y-6">
                {/* Delivery type */}
                <div className="bg-card rounded-xl border border-border p-5">
                  <h2 className="font-semibold mb-4">Opção de Entrega</h2>
                  <RadioGroup value={deliveryType} onValueChange={(v) => { setDeliveryType(v as 'delivery' | 'pickup'); if (v === 'pickup') setFreightAmount(0); }}
                    className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <Label htmlFor="delivery" className={`flex items-center gap-3 p-4 rounded-lg border-2 cursor-pointer transition-colors ${deliveryType === 'delivery' ? 'border-accent bg-accent/5' : 'border-border hover:border-border/80'}`}>
                      <RadioGroupItem value="delivery" id="delivery" />
                      <Truck className="h-5 w-5 text-accent shrink-0" />
                      <div><p className="font-medium text-sm">Entrega</p><p className="text-xs text-muted-foreground">Receba em casa</p></div>
                    </Label>
                    <Label htmlFor="pickup" className={`flex items-center gap-3 p-4 rounded-lg border-2 cursor-pointer transition-colors ${deliveryType === 'pickup' ? 'border-accent bg-accent/5' : 'border-border hover:border-border/80'}`}>
                      <RadioGroupItem value="pickup" id="pickup" />
                      <Store className="h-5 w-5 text-accent shrink-0" />
                      <div><p className="font-medium text-sm">Retirada na Loja</p><p className="text-xs text-muted-foreground">Sem custo de frete</p></div>
                    </Label>
                  </RadioGroup>
                  {deliveryType === 'pickup' && settings?.store_address && (
                    <div className="mt-3 p-3 bg-muted rounded-lg text-sm">
                      <p className="font-medium">Endereço da loja:</p>
                      <p className="text-muted-foreground">{settings.store_address}{settings.store_city ? `, ${settings.store_city}` : ''}{settings.store_state ? ` - ${settings.store_state}` : ''}</p>
                    </div>
                  )}
                </div>

                {/* Delivery address */}
                {deliveryType === 'delivery' && (
                  <div className="bg-card rounded-xl border border-border p-5 space-y-4">
                    <h2 className="font-semibold">Endereço de Entrega</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField control={form.control} name="name" rules={{ required: 'Nome é obrigatório' }}
                        render={({ field }) => <FormItem className="md:col-span-2"><FormLabel>Nome completo</FormLabel><FormControl><Input {...field} placeholder="Seu nome" /></FormControl><FormMessage /></FormItem>} />
                      <FormField control={form.control} name="phone" rules={{ required: 'Telefone é obrigatório' }}
                        render={({ field }) => <FormItem><FormLabel>Telefone</FormLabel><FormControl><Input {...field} placeholder="(11) 99999-9999" /></FormControl><FormMessage /></FormItem>} />
                      <FormField control={form.control} name="cep" rules={{ required: 'CEP é obrigatório' }}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>CEP</FormLabel>
                            <div className="flex gap-2">
                              <FormControl>
                                <Input {...field} placeholder="00000-000" onChange={e => { field.onChange(e); if (e.target.value.replace(/\D/g, '').length === 8) lookupCep(e.target.value); }} />
                              </FormControl>
                              {cepLoading && <Loader2 className="h-4 w-4 animate-spin mt-3 shrink-0" />}
                            </div>
                            <FormMessage />
                          </FormItem>
                        )} />
                      <FormField control={form.control} name="street" rules={{ required: 'Rua é obrigatória' }}
                        render={({ field }) => <FormItem className="md:col-span-2"><FormLabel>Rua</FormLabel><FormControl><Input {...field} placeholder="Nome da rua" /></FormControl><FormMessage /></FormItem>} />
                      <FormField control={form.control} name="number" rules={{ required: 'Número é obrigatório' }}
                        render={({ field }) => <FormItem><FormLabel>Número</FormLabel><FormControl><Input {...field} placeholder="123" /></FormControl><FormMessage /></FormItem>} />
                      <FormField control={form.control} name="complement"
                        render={({ field }) => <FormItem><FormLabel>Complemento</FormLabel><FormControl><Input {...field} placeholder="Apto, bloco..." /></FormControl></FormItem>} />
                      <FormField control={form.control} name="neighborhood" rules={{ required: 'Bairro é obrigatório' }}
                        render={({ field }) => <FormItem><FormLabel>Bairro</FormLabel><FormControl><Input {...field} placeholder="Bairro" /></FormControl><FormMessage /></FormItem>} />
                      <FormField control={form.control} name="city" rules={{ required: 'Cidade é obrigatória' }}
                        render={({ field }) => <FormItem><FormLabel>Cidade</FormLabel><FormControl><Input {...field} placeholder="Cidade" /></FormControl><FormMessage /></FormItem>} />
                      <FormField control={form.control} name="state"
                        render={({ field }) => <FormItem><FormLabel>Estado</FormLabel><FormControl><Input {...field} placeholder="SP" maxLength={2} /></FormControl><FormMessage /></FormItem>} />
                    </div>

                    {/* Opções de frete calculadas */}
                    {shippingLoading && (
                      <div className="flex items-center gap-2 text-sm text-muted-foreground pt-2">
                        <Loader2 className="h-4 w-4 animate-spin" />
                        Calculando frete...
                      </div>
                    )}

                    {!shippingLoading && shippingOptions.length > 0 && (
                      <div className="space-y-2 pt-1">
                        <p className="text-sm font-medium flex items-center gap-1.5">
                          <MapPin className="h-4 w-4 text-primary" /> Opções de Entrega
                        </p>
                        <RadioGroup
                          value={selectedShipping?.id || ''}
                          onValueChange={(id) => {
                            const opt = shippingOptions.find(o => o.id === id);
                            if (opt) { setSelectedShipping(opt); setFreightAmount(opt.price); }
                          }}
                          className="space-y-2"
                        >
                          {shippingOptions.map(opt => (
                            <Label key={opt.id} htmlFor={`ship_${opt.id}`}
                              className={`flex items-center gap-3 p-3 rounded-lg border-2 cursor-pointer transition-colors ${selectedShipping?.id === opt.id ? 'border-accent bg-accent/5' : 'border-border hover:border-border/80'}`}>
                              <RadioGroupItem value={opt.id} id={`ship_${opt.id}`} />
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2">
                                  {opt.carrier === 'Correios' ? <Package className="h-4 w-4 text-primary shrink-0" /> : opt.price === 0 ? <Gift className="h-4 w-4 text-success shrink-0" /> : <Truck className="h-4 w-4 text-muted-foreground shrink-0" />}
                                  <p className="text-sm font-medium">{opt.name}</p>
                                  {opt.carrier && opt.carrier !== 'Loja' && <span className="text-xs text-muted-foreground">({opt.carrier})</span>}
                                </div>
                                <p className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5 ml-6">
                                  <Clock className="h-3 w-3" />{opt.min_days}–{opt.max_days} dias úteis
                                </p>
                              </div>
                              <p className="text-sm font-semibold shrink-0">
                                {opt.price === 0 ? <span className="text-success">Grátis</span> : opt.price.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                              </p>
                            </Label>
                          ))}
                        </RadioGroup>
                      </div>
                    )}
                  </div>
                )}

                {/* Contact for pickup */}
                {deliveryType === 'pickup' && (
                  <div className="bg-card rounded-xl border border-border p-5 space-y-4">
                    <h2 className="font-semibold">Dados de Contato</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField control={form.control} name="name" rules={{ required: 'Nome é obrigatório' }}
                        render={({ field }) => <FormItem><FormLabel>Nome completo</FormLabel><FormControl><Input {...field} placeholder="Seu nome" /></FormControl><FormMessage /></FormItem>} />
                      <FormField control={form.control} name="phone" rules={{ required: 'Telefone é obrigatório' }}
                        render={({ field }) => <FormItem><FormLabel>Telefone</FormLabel><FormControl><Input {...field} placeholder="(11) 99999-9999" /></FormControl><FormMessage /></FormItem>} />
                    </div>
                  </div>
                )}

                {/* Payment */}
                <div className="bg-card rounded-xl border border-border p-5 space-y-4">
                  <h2 className="font-semibold">Forma de Pagamento</h2>
                  {gatewaysLoading ? (
                    <div className="flex items-center gap-2 text-sm text-muted-foreground py-2">
                      <Loader2 className="h-4 w-4 animate-spin" /> Carregando opções...
                    </div>
                  ) : gateways.length === 0 ? (
                    <div className="p-3 bg-destructive/10 border border-destructive/20 rounded-lg text-sm text-destructive flex items-center gap-2">
                      <AlertCircle className="h-4 w-4 shrink-0" />
                      Nenhuma forma de pagamento disponível. Contate o suporte.
                    </div>
                  ) : (
                    <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod}
                      className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {gateways.map(gw => {
                        const Icon = GATEWAY_ICONS[gw.id] || GATEWAY_ICONS[gw.icon || ''] || CreditCard;
                        return (
                          <Label key={gw.id} htmlFor={gw.id}
                            className={`flex items-center gap-3 p-4 rounded-lg border-2 cursor-pointer transition-colors ${paymentMethod === gw.id ? 'border-accent bg-accent/5' : 'border-border hover:border-border/80'}`}>
                            <RadioGroupItem value={gw.id} id={gw.id} />
                            <Icon className="h-5 w-5 text-accent shrink-0" />
                            <div>
                              <p className="font-medium text-sm">{gw.name}</p>
                              <p className="text-xs text-muted-foreground">{gw.description || ''}</p>
                            </div>
                          </Label>
                        );
                      })}
                    </RadioGroup>
                  )}
                </div>
              </div>

              {/* Order summary */}
              <div className="lg:col-span-1">
                <div className="sticky top-20 bg-card rounded-xl border border-border p-5 space-y-4">
                  <h2 className="font-semibold">Resumo</h2>
                  <div className="space-y-2 max-h-48 overflow-y-auto">
                    {items.map(({ product, quantity }) => (
                      <div key={product.id} className="flex gap-2 text-sm">
                        <div className="h-10 w-10 rounded-md overflow-hidden bg-muted shrink-0">
                          {product.images?.[0]?.url ? <img src={product.images[0].url} alt={product.name} className="w-full h-full object-cover" /> : null}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-xs line-clamp-1 text-muted-foreground">{product.name} × {quantity}</p>
                          <p className="text-xs font-medium">{(product.price * quantity).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</p>
                        </div>
                      </div>
                    ))}
                  </div>

                  <Separator />

                  {/* Campo de cupom */}
                  {!appliedCoupon ? (
                    <div className="space-y-1.5">
                      <Label className="text-sm font-normal flex items-center gap-1.5">
                        <Tag className="h-3.5 w-3.5" /> Cupom de desconto
                      </Label>
                      <div className="flex gap-2">
                        <Input
                          value={couponCode}
                          onChange={e => { setCouponCode(e.target.value.toUpperCase()); setCouponError(''); }}
                          onKeyDown={e => e.key === 'Enter' && (e.preventDefault(), applyCoupon())}
                          placeholder="CÓDIGO"
                          className="h-9 text-sm font-mono uppercase flex-1"
                        />
                        <Button type="button" variant="outline" size="sm" onClick={applyCoupon}
                          disabled={couponLoading || !couponCode.trim()} className="h-9 shrink-0">
                          {couponLoading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : 'Aplicar'}
                        </Button>
                      </div>
                      {couponError && (
                        <p className="text-xs text-destructive flex items-center gap-1">
                          <AlertCircle className="h-3 w-3 shrink-0" />{couponError}
                        </p>
                      )}
                    </div>
                  ) : (
                    <div className="flex items-center justify-between bg-success/10 border border-success/20 rounded-lg px-3 py-2">
                      <div className="flex items-center gap-2 min-w-0">
                        <CheckCircle2 className="h-4 w-4 text-success shrink-0" />
                        <div className="min-w-0">
                          <p className="text-xs font-semibold font-mono text-success">{appliedCoupon.code}</p>
                          <p className="text-xs text-muted-foreground">
                            {appliedCoupon.discount_type === 'free_shipping' ? 'Frete grátis'
                              : appliedCoupon.discount_type === 'percent' ? `${appliedCoupon.discount_value}% de desconto`
                              : `R$ ${appliedCoupon.discount_value.toFixed(2)} de desconto`}
                          </p>
                        </div>
                      </div>
                      <button onClick={removeCoupon} className="shrink-0 text-muted-foreground hover:text-destructive transition-colors ml-2">
                        <X className="h-4 w-4" />
                      </button>
                    </div>
                  )}

                  <Separator />
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between"><span className="text-muted-foreground">Subtotal</span><span>{subtotal.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span></div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Frete</span>
                      <span>{deliveryType === 'pickup' ? 'Grátis' : appliedCoupon?.discount_type === 'free_shipping' ? 'Grátis (cupom)' : freightAmount > 0 ? freightAmount.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }) : 'A calcular'}</span>
                    </div>
                    {couponDiscount > 0 && appliedCoupon?.discount_type !== 'free_shipping' && (
                      <div className="flex justify-between text-destructive text-xs">
                        <span>Desconto ({appliedCoupon?.code})</span>
                        <span>-{couponDiscount.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span>
                      </div>
                    )}
                  </div>
                  <Separator />
                  <div className="flex justify-between font-bold">
                    <span>Total</span>
                    <span>{Math.max(0, total).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span>
                  </div>
                  <Button type="submit" className="w-full bg-accent text-accent-foreground hover:bg-accent/90 h-11"
                    disabled={submitting || gateways.length === 0}>
                    {submitting
                      ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Processando...</>
                      : paymentMethod === 'pix' ? 'Gerar Código PIX'
                      : paymentMethod === 'stripe' ? 'Pagar com Cartão'
                      : `Pagar com ${gateways.find(g => g.id === paymentMethod)?.name || 'Gateway'}`
                    }
                  </Button>
                </div>
              </div>
            </div>
          </form>
        </Form>
      </div>
    </MainLayout>
  );
}
