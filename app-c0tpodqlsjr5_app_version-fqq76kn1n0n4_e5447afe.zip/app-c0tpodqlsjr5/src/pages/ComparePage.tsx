import { useNavigate } from 'react-router-dom';
import { GitCompare, X, ShoppingCart, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { MainLayout } from '@/components/layouts/MainLayout';
import { useCompare } from '@/contexts/CompareContext';
import { useCart } from '@/contexts/CartContext';

export default function ComparePage() {
  const { compareItems, removeFromCompare, clearCompare } = useCompare();
  const { addItem } = useCart();
  const navigate = useNavigate();

  const allAttributeKeys = Array.from(
    new Set(compareItems.flatMap(p => Object.keys(p.attributes || {})))
  );

  const rows = [
    { label: 'Preço', key: 'price' },
    { label: 'Disponibilidade', key: 'availability' },
    { label: 'Categoria', key: 'category' },
    ...allAttributeKeys.map(k => ({ label: k.charAt(0).toUpperCase() + k.slice(1), key: `attr_${k}` })),
  ];

  const getValue = (product: typeof compareItems[0], key: string) => {
    if (key === 'price') return product.price.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
    if (key === 'availability') return product.is_available && product.stock_quantity > 0 ? 'Em estoque' : 'Indisponível';
    if (key === 'category') return product.categories?.name || '—';
    if (key.startsWith('attr_')) return product.attributes?.[key.replace('attr_', '')] || '—';
    return '—';
  };

  return (
    <MainLayout>
      <div className="container py-6 md:py-10">
        <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
          <div className="flex items-center gap-3">
            <GitCompare className="h-6 w-6 text-primary" />
            <h1 className="text-2xl font-bold">Comparação de Produtos</h1>
            <Badge variant="secondary">{compareItems.length}/4</Badge>
          </div>
          {compareItems.length > 0 && (
            <Button variant="outline" size="sm" onClick={clearCompare}>
              <X className="h-4 w-4 mr-1" /> Limpar
            </Button>
          )}
        </div>

        {compareItems.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 gap-4 text-center">
            <div className="h-16 w-16 rounded-full bg-muted flex items-center justify-center">
              <GitCompare className="h-8 w-8 text-muted-foreground/40" />
            </div>
            <p className="text-lg font-medium">Nenhum produto para comparar</p>
            <p className="text-muted-foreground text-sm">Adicione produtos usando o ícone de comparação nos cards</p>
            <Button onClick={() => navigate('/produtos')} className="bg-accent text-accent-foreground hover:bg-accent/90 mt-2">
              Explorar Produtos <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        ) : compareItems.length < 2 ? (
          <div className="rounded-xl border border-border bg-card p-8 text-center">
            <p className="text-muted-foreground">Adicione pelo menos 2 produtos para comparar.</p>
            <Button onClick={() => navigate('/produtos')} className="mt-4 bg-accent text-accent-foreground hover:bg-accent/90">
              Ver mais produtos
            </Button>
          </div>
        ) : (
          <div className="overflow-x-auto w-full">
            <table className="w-full min-w-max">
              <thead>
                <tr>
                  <th className="text-left p-4 bg-muted text-sm font-semibold text-muted-foreground w-40 rounded-tl-lg whitespace-nowrap">Produto</th>
                  {compareItems.map(p => (
                    <th key={p.id} className="p-4 bg-muted text-center min-w-48 whitespace-nowrap">
                      <div className="flex flex-col items-center gap-2">
                        <div className="relative">
                          <div className="h-24 w-24 rounded-lg overflow-hidden bg-background border border-border mx-auto">
                            {p.images?.[0]?.url ? (
                              <img src={p.images[0].url} alt={p.name} className="w-full h-full object-cover" />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center"><ShoppingCart className="h-8 w-8 text-muted-foreground/30" /></div>
                            )}
                          </div>
                          <button onClick={() => removeFromCompare(p.id)}
                            className="absolute -top-2 -right-2 h-5 w-5 rounded-full bg-destructive text-destructive-foreground flex items-center justify-center hover:bg-destructive/80 transition-colors">
                            <X className="h-3 w-3" />
                          </button>
                        </div>
                        <p className="text-sm font-medium text-card-foreground text-balance line-clamp-2">{p.name}</p>
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {rows.map((row, idx) => (
                  <tr key={row.key} className={idx % 2 === 0 ? 'bg-card' : 'bg-muted/40'}>
                    <td className="p-4 text-sm font-medium text-muted-foreground whitespace-nowrap">{row.label}</td>
                    {compareItems.map(p => (
                      <td key={p.id} className="p-4 text-sm text-center text-card-foreground whitespace-nowrap">
                        {row.key === 'price' ? <span className="font-bold text-base">{getValue(p, row.key)}</span>
                          : row.key === 'availability' ? (
                            <Badge className={p.is_available && p.stock_quantity > 0 ? 'bg-success text-success-foreground border-0' : ''} variant={p.is_available && p.stock_quantity > 0 ? 'default' : 'secondary'}>
                              {getValue(p, row.key)}
                            </Badge>
                          ) : getValue(p, row.key)}
                      </td>
                    ))}
                  </tr>
                ))}
                <tr className="bg-card border-t border-border">
                  <td className="p-4 text-sm font-medium text-muted-foreground rounded-bl-lg">Ação</td>
                  {compareItems.map(p => (
                    <td key={p.id} className="p-4 text-center">
                      <Button size="sm" className="bg-accent text-accent-foreground hover:bg-accent/90 h-8 text-xs"
                        onClick={() => addItem(p)} disabled={!p.is_available || p.stock_quantity === 0}>
                        <ShoppingCart className="h-3.5 w-3.5 mr-1" /> Adicionar
                      </Button>
                    </td>
                  ))}
                </tr>
              </tbody>
            </table>
          </div>
        )}
      </div>
    </MainLayout>
  );
}
