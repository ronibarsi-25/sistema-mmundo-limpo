import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Send, MessageCircle, Bot } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import { MainLayout } from '@/components/layouts/MainLayout';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/db/supabase';
import type { ChatMessage } from '@/types/types';
import { cn } from '@/lib/utils';

export default function CustomerChatPage() {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const conversationId = user?.id || 'guest';

  const scrollToBottom = () => messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });

  useEffect(() => {
    if (!user) { navigate('/login'); return; }
    supabase.from('chat_messages').select('*').eq('conversation_id', user.id)
      .order('created_at', { ascending: true })
      .then(({ data }) => { setMessages(Array.isArray(data) ? data : []); setLoading(false); setTimeout(scrollToBottom, 100); });

    const channel = supabase.channel(`chat-${user.id}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'chat_messages', filter: `conversation_id=eq.${user.id}` },
        payload => {
          setMessages(prev => [...prev, payload.new as ChatMessage]);
          setTimeout(scrollToBottom, 100);
          // Mark admin messages as read
          if ((payload.new as ChatMessage).sender_role === 'admin') {
            supabase.from('chat_messages').update({ is_read: true }).eq('id', (payload.new as ChatMessage).id);
          }
        })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [user]);

  useEffect(() => { scrollToBottom(); }, [messages]);

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim() || !user) return;
    setSending(true);
    await supabase.from('chat_messages').insert({
      conversation_id: user.id, user_id: user.id, sender_role: 'user', message: text.trim(), is_read: false
    });
    setText('');
    setSending(false);
  };

  return (
    <MainLayout>
      <div className="container py-6 md:py-10 max-w-2xl">
        <div className="flex items-center gap-3 mb-4">
          <MessageCircle className="h-6 w-6 text-accent" />
          <h1 className="text-2xl font-bold">Chat de Atendimento</h1>
        </div>
        <div className="bg-card rounded-2xl border border-border overflow-hidden flex flex-col" style={{ height: '60vh', minHeight: 400 }}>
          {/* Header */}
          <div className="flex items-center gap-3 px-5 py-3 border-b border-border bg-muted">
            <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center shrink-0">
              <Bot className="h-4 w-4 text-primary-foreground" />
            </div>
            <div>
              <p className="text-sm font-medium">Atendimento</p>
              <p className="text-xs text-muted-foreground">Equipe de suporte</p>
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {loading ? (
              <div className="space-y-3">{[...Array(4)].map((_, i) => <Skeleton key={i} className={`h-10 rounded-xl bg-muted ${i % 2 === 0 ? 'w-2/3' : 'w-1/2 ml-auto'}`} />)}</div>
            ) : messages.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full gap-3 text-center text-muted-foreground">
                <MessageCircle className="h-10 w-10 opacity-30" />
                <p className="text-sm">Inicie uma conversa com nossa equipe de atendimento</p>
              </div>
            ) : (
              messages.map(msg => {
                const isUser = msg.sender_role === 'user';
                return (
                  <div key={msg.id} className={cn('flex', isUser ? 'justify-end' : 'justify-start')}>
                    <div className={cn('max-w-[75%] rounded-2xl px-4 py-2.5 text-sm',
                      isUser ? 'bg-accent text-accent-foreground rounded-br-md' : 'bg-muted text-foreground rounded-bl-md')}>
                      <p className="text-pretty">{msg.message}</p>
                      <p className={cn('text-[10px] mt-1', isUser ? 'text-accent-foreground/70 text-right' : 'text-muted-foreground')}>
                        {new Date(msg.created_at).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                      </p>
                    </div>
                  </div>
                );
              })
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="border-t border-border p-3">
            <form onSubmit={sendMessage} className="flex gap-2">
              <Input value={text} onChange={e => setText(e.target.value)} placeholder="Digite sua mensagem..."
                className="flex-1" disabled={sending || !user} />
              <Button type="submit" size="icon" className="bg-accent text-accent-foreground hover:bg-accent/90 shrink-0" disabled={!text.trim() || sending}>
                <Send className="h-4 w-4" />
              </Button>
            </form>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
