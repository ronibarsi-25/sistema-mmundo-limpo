import { AlertTriangle, Lock } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function ExpiredStorePage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <div className="max-w-md w-full text-center space-y-6">
        <div className="flex justify-center">
          <div className="h-20 w-20 rounded-full bg-destructive/10 flex items-center justify-center">
            <Lock className="h-10 w-10 text-destructive" />
          </div>
        </div>
        <div className="space-y-2">
          <h1 className="text-2xl font-bold text-foreground">Loja Temporariamente Suspensa</h1>
          <p className="text-muted-foreground">
            A assinatura desta loja expirou ou o período de teste chegou ao fim.
            Se você é o proprietário, acesse o painel administrativo para renovar sua assinatura.
          </p>
        </div>
        <div className="p-4 bg-muted rounded-xl text-left flex gap-3">
          <AlertTriangle className="h-5 w-5 text-warning shrink-0 mt-0.5" />
          <p className="text-xs text-muted-foreground leading-relaxed">
            As vendas estão desabilitadas até que a assinatura seja regularizada. 
            Todos os seus dados e produtos continuam salvos com segurança.
          </p>
        </div>
        <Button variant="outline" className="w-full" onClick={() => window.location.href = '/admin'}>
          Acessar Painel Administrativo
        </Button>
      </div>
    </div>
  );
}
