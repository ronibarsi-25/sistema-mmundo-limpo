import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowRight, ShoppingBag, Truck, MessageCircle, ScanBarcode } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { MainLayout } from '@/components/layouts/MainLayout';
import { ProductCard } from '@/components/common/ProductCard';
import { BannerCarousel } from '@/components/common/BannerCarousel';
import { PromotionTopBar } from '@/components/common/PromotionTopBar';
import { BannerInauguracao } from '@/components/common/BannerInauguracao';
import { ICON_MAP } from '@/pages/admin/AdminSettings';
import { supabase } from '@/db/supabase';
import { useStore } from '@/contexts/StoreContext';
import { useActivePromotions } from '@/hooks/usePromotions';
import type { Product, Category, StoreFeature } from '@/types/types';

export default function HomePage() {
  const { settings } = useStore();
  const navigate = useNavigate();
  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const { promotions } = useActivePromotions();

  useEffect(() => {
    Promise.all([
      supabase.from('products').select('*, categories(*)').eq('is_featured', true).eq('is_available', true).order('created_at', { ascending: false }).limit(8),
      supabase.from('categories').select('*').eq('is_active', true).order('name').limit(12)
    ]).then(([products, cats]) => {
      setFeaturedProducts(Array.isArray(products.data) ? products.data : []);
      setCategories(Array.isArray(cats.data) ? cats.data : []);
      setLoading(false);
    });
  }, []);

  const storeName = settings?.store_name || 'MinhaLoja';

  const DEFAULT_FEATURES: StoreFeature[] = [
    { icon: 'Truck', title: 'Entrega Rápida', desc: 'Todo o Brasil' },
    { icon: 'Shield', title: 'Compra Segura', desc: 'Pagamento protegido' },
    { icon: 'RefreshCw', title: 'Troca Fácil', desc: 'Sem burocracia' },
    { icon: 'MessageCircle', title: 'Suporte 24h', desc: 'Sempre disponível' },
  ];
  const features = settings?.store_features?.length ? settings.store_features : DEFAULT_FEATURES;

  return (
    <MainLayout>
      {/* Banner de inauguração */}
      <BannerInauguracao />

      {/* Barra de promoção no topo */}
      <PromotionTopBar />

      {/* Carrossel de banners */}
      <section className="w-full px-3 md:px-6 pt-3 md:pt-5 pb-2">
        <div className="max-w-7xl mx-auto">
          <BannerCarousel />
        </div>
      </section>

      {/* Features bar — compacta em mobile */}
      <section className="border-y border-border bg-card w-full overflow-x-hidden">
        <div className="max-w-7xl mx-auto px-3 md:px-6 py-3 md:py-5">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 md:gap-6">
            {features.map(f => {
              const IconComp = ICON_MAP[f.icon] || Truck;
              return (
                <div key={f.title} className="flex items-center gap-2 md:gap-3 min-w-0">
                  <div className="h-8 w-8 md:h-9 md:w-9 rounded-lg bg-accent/10 flex items-center justify-center shrink-0">
                    <IconComp className="h-4 w-4 text-accent" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs md:text-sm font-semibold text-card-foreground leading-tight">{f.title}</p>
                    <p className="text-xs text-muted-foreground hidden md:block">{f.desc}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Quick tools — scanner */}
      <section className="w-full border-b border-border bg-card">
        <div className="max-w-7xl mx-auto px-3 md:px-6 py-3 md:py-4">
          <div className="grid grid-cols-1 gap-2 md:gap-4 max-w-xs mx-auto">
            <Button variant="outline" size="sm" className="h-auto flex flex-col items-center gap-1 py-2.5 px-1 text-xs md:text-sm" onClick={() => navigate('/mobile/scanner')}>
              <ScanBarcode className="h-5 w-5 text-accent" />
              <span>Scanner</span>
            </Button>
          </div>
        </div>
      </section>

      {/* Hero — compacto e responsivo */}
      <section className="bg-primary text-primary-foreground w-full overflow-x-hidden">
        <div className="max-w-7xl mx-auto px-4 md:px-6 py-8 md:py-16 flex flex-col md:flex-row items-center gap-6 md:gap-10">
          <div className="flex-1 space-y-4 text-center md:text-left min-w-0">
            <h1 className="text-xl md:text-4xl font-bold leading-tight text-balance">
              {storeName}
            </h1>
            <p className="text-sm md:text-base text-primary-foreground/80 text-pretty max-w-md mx-auto md:mx-0">
              Qualidade em cada detalhe. Os melhores produtos, entrega rápida e atendimento de excelência.
            </p>
            <div className="flex flex-row gap-2 justify-center md:justify-start flex-wrap">
              <Button size="sm" className="bg-accent text-accent-foreground hover:bg-accent/90 border-0 h-9 text-xs md:text-sm" onClick={() => navigate('/produtos')}>
                <ShoppingBag className="mr-1.5 h-3.5 w-3.5" /> Ver Produtos
              </Button>
              <Button size="sm" variant="ghost" className="border border-primary-foreground/40 text-primary-foreground hover:bg-primary-foreground/10 h-9 text-xs md:text-sm" onClick={() => navigate('/produtos')}>
                Categorias <ArrowRight className="ml-1 h-3.5 w-3.5" />
              </Button>
            </div>
          </div>
          {/* Decoração visível só em md+ */}
          <div className="hidden md:grid grid-cols-2 gap-3 max-w-xs w-full shrink-0">
            {[...Array(4)].map((_, i) => (
              <div key={i} className={`rounded-xl bg-primary-foreground/10 border border-primary-foreground/20 flex items-center justify-center p-6 ${i === 0 ? 'col-span-2' : ''}`}>
                <ShoppingBag className={`text-primary-foreground/40 ${i === 0 ? 'h-12 w-12' : 'h-8 w-8'}`} />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Categories */}
      {categories.length > 0 && (
        <section className="max-w-7xl mx-auto px-3 md:px-6 py-6 md:py-10 w-full">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-base md:text-xl font-bold text-balance">Categorias</h2>
              <p className="text-xs md:text-sm text-muted-foreground">Encontre o que você procura</p>
            </div>
            <Link to="/produtos">
              <Button variant="ghost" size="sm" className="text-xs h-8">
                <span className="hidden md:inline">Ver todas</span>
                <span className="md:hidden">Ver</span>
                <ArrowRight className="ml-1 h-3 w-3" />
              </Button>
            </Link>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-4">
            {categories.map(cat => (
              <Link
                key={cat.id}
                to={`/produtos?categoria=${cat.slug}`}
                className="group relative overflow-hidden rounded-xl border border-border aspect-[3/2] flex items-end bg-muted shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-200"
              >
                {/* Imagem de fundo */}
                {cat.image_url ? (
                  <img
                    src={cat.image_url}
                    alt={cat.name}
                    className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                ) : (
                  <div className="absolute inset-0 w-full h-full bg-primary/10 flex items-center justify-center">
                    <ShoppingBag className="h-8 w-8 md:h-10 md:w-10 text-primary/40" />
                  </div>
                )}
                {/* Gradiente overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
                {/* Nome da categoria */}
                <div className="relative z-10 w-full px-3 py-2.5 md:px-4 md:py-3">
                  <span className="block text-xs md:text-sm font-semibold text-white leading-tight text-balance drop-shadow">
                    {cat.name}
                  </span>
                  {cat.description && (
                    <span className="hidden md:block text-[11px] text-white/70 mt-0.5 line-clamp-1">{cat.description}</span>
                  )}
                </div>
              </Link>
            ))}
          </div>
        </section>
      )}

      {/* Featured Products */}
      <section className="max-w-7xl mx-auto px-3 md:px-6 py-6 md:py-10 w-full">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-base md:text-xl font-bold text-balance">Produtos em Destaque</h2>
            <p className="text-xs md:text-sm text-muted-foreground">Selecionados para você</p>
          </div>
          <Link to="/produtos">
            <Button variant="ghost" size="sm" className="text-xs h-8">
              <span className="hidden md:inline">Ver todos</span>
              <span className="md:hidden">Ver</span>
              <ArrowRight className="ml-1 h-3 w-3" />
            </Button>
          </Link>
        </div>
        {loading ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="rounded-lg border border-border overflow-hidden">
                <Skeleton className="aspect-[3/4] w-full bg-muted" />
                <div className="p-3 space-y-2">
                  <Skeleton className="h-3 w-16 bg-muted" />
                  <Skeleton className="h-4 w-full bg-muted" />
                  <Skeleton className="h-8 w-full bg-muted" />
                </div>
              </div>
            ))}
          </div>
        ) : featuredProducts.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-4">
            {featuredProducts.map(p => <ProductCard key={p.id} product={p} promotions={promotions} />)}
          </div>
        ) : (
          <div className="text-center py-12 text-sm text-muted-foreground">Nenhum produto em destaque no momento.</div>
        )}
      </section>

      {/* CTA banner */}
      <section className="max-w-7xl mx-auto px-3 md:px-6 pb-10 w-full">
        <div className="rounded-2xl bg-primary text-primary-foreground px-5 py-7 md:p-10 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="text-center md:text-left">
            <h2 className="text-lg md:text-2xl font-bold text-balance">Precisa de ajuda?</h2>
            <p className="text-primary-foreground/75 text-sm mt-1">Nossa equipe está pronta para atendê-lo.</p>
          </div>
          <Button size="default" className="bg-accent text-accent-foreground hover:bg-accent/90 border-0 shrink-0 h-10" onClick={() => navigate('/minha-conta/chat')}>
            <MessageCircle className="mr-2 h-4 w-4" /> Falar com Atendimento
          </Button>
        </div>
      </section>
    </MainLayout>
  );
}

