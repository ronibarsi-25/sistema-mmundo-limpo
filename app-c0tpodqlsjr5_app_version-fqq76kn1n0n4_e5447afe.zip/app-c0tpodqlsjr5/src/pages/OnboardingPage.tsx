import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { Building2, Store, Loader2, ArrowRight, CheckCircle2, Sparkles, Crown, Gem } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';

interface OnboardingForm {
  storeName: string;
  slug: string;
  phone: string;
  email: string;
  description: string;
  plan: 'free' | 'pro' | 'ouro';
}

const PLANS = [
  {
    id: 'free' as const,
    name: 'Free',
    icon: Sparkles,
    price: 'R$ 0/mês',
    features: ['30 produtos', '1 usuário', '50 pedidos/mês', 'Pagamento PIX'],
    highlighted: false,
  },
  {
    id: 'pro' as const,
    name: 'Pro',
    icon: Crown,
    price: 'R$ 49,90/mês',
    features: ['500 produtos', '5 usuários', '1.000 pedidos/mês', 'White Label', 'Relatórios avançados'],
    highlighted: true,
  },
  {
    id: 'ouro' as const,
    name: 'Ouro',
    icon: Gem,
    price: 'R$ 149,90/mês',
    features: ['Produtos ilimitados', '50 usuários', 'Pedidos ilimitados', 'White Label', 'Domínio customizado', 'API'],
    highlighted: false,
  },
];

export default function OnboardingPage() {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const [submitting, setSubmitting] = useState(false);
  const [step, setStep] = useState(1);
  const form = useForm<OnboardingForm>({
    defaultValues: {
      storeName: '',
      slug: '',
      phone: profile?.phone || '',
      email: user?.email || '',
      description: '',
      plan: 'free',
    },
  });

  const generateSlug = (name: string) => {
    return name
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '');
  };

  const onSubmit = async (data: OnboardingForm) => {
    if (!user?.id) { toast.error('Faça login primeiro'); return; }
    setSubmitting(true);
    try {
      const slug = data.slug || generateSlug(data.storeName);

      // Cria o tenant
      const { data: tenant, error: tenantError } = await supabase
        .from('tenants')
        .insert({
          name: data.storeName,
          slug,
          phone: data.phone,
          email: data.email,
          description: data.description,
          plan: data.plan,
          status: 'active',
        })
        .select()
        .single();

      if (tenantError || !tenant) {
        toast.error('Erro ao criar loja. O slug pode já estar em uso.');
        setSubmitting(false);
        return;
      }

      // Vincula o perfil ao tenant
      const { error: profileError } = await supabase
        .from('profiles')
        .update({ tenant_id: tenant.id })
        .eq('id', user.id);

      if (profileError) {
        toast.error('Erro ao vincular usuário à loja');
        setSubmitting(false);
        return;
      }

      // Cria store_settings padrão
      await supabase.from('store_settings').insert({
        tenant_id: tenant.id,
        store_name: data.storeName,
        store_phone: data.phone,
        store_email: data.email,
        store_description: data.description,
        pix_key_type: 'telefone',
        pix_key: data.phone?.replace(/\D/g, '') || '',
      });

      // Cria categorias padrão
      await supabase.from('categories').insert([
        { tenant_id: tenant.id, name: 'Geral', slug: 'geral', description: 'Categoria padrão' },
      ]);

      toast.success('Loja criada com sucesso!');
      setStep(2);
      setTimeout(() => navigate('/admin'), 1500);
    } catch {
      toast.error('Erro inesperado. Tente novamente.');
    } finally {
      setSubmitting(false);
    }
  };

  if (step === 2) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-4">
        <div className="max-w-md w-full text-center space-y-6">
          <CheckCircle2 className="h-16 w-16 text-success mx-auto" />
          <h1 className="text-2xl font-bold">Loja criada!</h1>
          <p className="text-muted-foreground">Redirecionando para o painel administrativo...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <div className="max-w-lg w-full space-y-8">
        <div className="text-center space-y-2">
          <div className="h-14 w-14 rounded-full bg-primary/10 flex items-center justify-center mx-auto">
            <Store className="h-7 w-7 text-primary" />
          </div>
          <h1 className="text-2xl font-bold text-balance">Crie sua loja</h1>
          <p className="text-sm text-muted-foreground text-balance">
            Configure sua loja em poucos passos e comece a vender online.
          </p>
        </div>

        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
          <div className="space-y-2">
            <Label htmlFor="storeName">Nome da Loja *</Label>
            <div className="relative">
              <Building2 className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                id="storeName"
                placeholder="Ex: Loja do João"
                className="pl-9"
                {...form.register('storeName', { required: 'Nome obrigatório' })}
              />
            </div>
            {form.formState.errors.storeName && (
              <p className="text-xs text-destructive">{form.formState.errors.storeName.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="slug">URL da Loja (slug)</Label>
            <Input
              id="slug"
              placeholder="loja-do-joao"
              {...form.register('slug')}
              onChange={(e) => {
                form.setValue('slug', e.target.value);
              }}
              onBlur={(e) => {
                if (!e.target.value && form.getValues('storeName')) {
                  form.setValue('slug', generateSlug(form.getValues('storeName')));
                }
              }}
            />
            <p className="text-xs text-muted-foreground">
              Será gerado automaticamente se deixado em branco.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="phone">Telefone *</Label>
              <Input
                id="phone"
                placeholder="(11) 99999-9999"
                {...form.register('phone', { required: 'Telefone obrigatório' })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">E-mail</Label>
              <Input
                id="email"
                type="email"
                placeholder="contato@loja.com"
                {...form.register('email')}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Descrição da Loja</Label>
            <Input
              id="description"
              placeholder="Breve descrição do que você vende"
              {...form.register('description')}
            />
          </div>

          {/* Plan Selection */}
          <div className="space-y-3">
            <Label>Escolha seu plano</Label>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {PLANS.map((p) => {
                const Icon = p.icon;
                const selected = form.watch('plan') === p.id;
                return (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => form.setValue('plan', p.id)}
                    className={`relative rounded-xl border p-4 text-left transition-all ${
                      selected
                        ? 'border-primary bg-primary/5 ring-1 ring-primary'
                        : 'border-border bg-card hover:border-muted-foreground/30'
                    } ${p.highlighted ? 'md:-mt-2 md:mb-2' : ''}`}
                  >
                    {p.highlighted && (
                      <span className="absolute -top-2 left-1/2 -translate-x-1/2 bg-accent text-accent-foreground text-[10px] font-semibold px-2 py-0.5 rounded-full">
                        Mais Popular
                      </span>
                    )}
                    <div className="flex items-center gap-2 mb-2">
                      <Icon className={`h-4 w-4 ${selected ? 'text-primary' : 'text-muted-foreground'}`} />
                      <span className="font-semibold text-sm">{p.name}</span>
                    </div>
                    <p className="text-lg font-bold mb-2">{p.price}</p>
                    <ul className="space-y-1">
                      {p.features.map((f, i) => (
                        <li key={i} className="text-xs text-muted-foreground flex items-start gap-1">
                          <CheckCircle2 className="h-3 w-3 shrink-0 mt-0.5 text-success" />
                          {f}
                        </li>
                      ))}
                    </ul>
                  </button>
                );
              })}
            </div>
          </div>

          <Button type="submit" className="w-full" disabled={submitting}>
            {submitting ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <>
                Criar Loja <ArrowRight className="ml-2 h-4 w-4" />
              </>
            )}
          </Button>
        </form>
      </div>
    </div>
  );
}
