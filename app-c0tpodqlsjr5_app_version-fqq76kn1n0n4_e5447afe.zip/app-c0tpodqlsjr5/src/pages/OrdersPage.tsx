import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Package, ChevronRight, RefreshCw } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { MainLayout } from '@/components/layouts/MainLayout';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/db/supabase';
import type { Order, OrderStatus } from '@/types/types';

const STATUS_CONFIG: Record<OrderStatus, { label: string; color: string }> = {
  pending: { label: 'Pendente', color: 'bg-warning/15 text-warning-foreground' },
  processing: { label: 'Em Processamento', color: 'bg-info/15 text-info-foreground' },
  shipped: { label: 'Enviado', color: 'bg-primary/15 text-primary' },
  delivered: { label: 'Entregue', color: 'bg-success/15 text-success' },
  cancelled: { label: 'Cancelado', color: 'bg-destructive/15 text-destructive' },
  completed: { label: 'Concluído', color: 'bg-success/15 text-success' },
};

export default function OrdersPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) { navigate('/login'); return; }
    supabase.from('orders').select('*').eq('user_id', user.id).order('created_at', { ascending: false })
      .then(({ data }) => { setOrders(Array.isArray(data) ? data : []); setLoading(false); });
  }, [user]);

  return (
    <MainLayout>
      <div className="container py-6 md:py-10 max-w-3xl">
        <div className="flex items-center gap-3 mb-6">
          <Package className="h-6 w-6" />
          <h1 className="text-2xl font-bold">Meus Pedidos</h1>
        </div>

        {loading ? (
          <div className="space-y-3">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-24 w-full bg-muted rounded-xl" />)}</div>
        ) : orders.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 gap-4 text-center">
            <div className="h-16 w-16 rounded-full bg-muted flex items-center justify-center"><Package className="h-8 w-8 text-muted-foreground/40" /></div>
            <p className="text-lg font-medium">Nenhum pedido encontrado</p>
            <p className="text-muted-foreground text-sm">Seus pedidos aparecerão aqui após a compra</p>
            <Button onClick={() => navigate('/produtos')} className="bg-accent text-accent-foreground hover:bg-accent/90 mt-2">Ver Produtos</Button>
          </div>
        ) : (
          <div className="space-y-3">
            {orders.map(order => {
              const status = STATUS_CONFIG[order.status] || { label: order.status, color: 'bg-muted' };
              return (
                <div key={order.id} className="bg-card rounded-xl border border-border p-5">
                  <div className="flex items-start justify-between gap-3 flex-wrap">
                    <div>
                      <p className="font-semibold text-sm">{order.order_number}</p>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {new Date(order.created_at).toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' })}
                      </p>
                    </div>
                    <Badge className={`${status.color} border-0 shrink-0`}>{status.label}</Badge>
                  </div>
                  <div className="mt-3 pt-3 border-t border-border flex items-center justify-between gap-3 flex-wrap">
                    <div className="text-sm">
                      <span className="text-muted-foreground">{order.items?.length || 0} produto(s) • </span>
                      <span className="font-medium">{order.total_amount?.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span>
                      <span className="text-muted-foreground ml-2">• {order.payment_method === 'pix' ? 'PIX' : 'Cartão'}</span>
                    </div>
                    <Link to={`/minha-conta/pedidos/${order.id}`}>
                      <Button variant="ghost" size="sm" className="h-7 text-xs">
                        Detalhes <ChevronRight className="h-3.5 w-3.5 ml-1" />
                      </Button>
                    </Link>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </MainLayout>
  );
}
