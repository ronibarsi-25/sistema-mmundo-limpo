import { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { CheckCircle, XCircle, Loader2, Package, Home } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { MainLayout } from '@/components/layouts/MainLayout';
import { useCart } from '@/contexts/CartContext';
import { supabase } from '@/db/supabase';
import type { Order } from '@/types/types';

export default function PaymentSuccessPage() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { clearCart } = useCart();
  const sessionId = searchParams.get('session_id');
  const [status, setStatus] = useState<'loading' | 'success' | 'error'>('loading');
  const [order, setOrder] = useState<Order | null>(null);

  useEffect(() => {
    if (!sessionId) { setStatus('error'); return; }
    supabase.functions.invoke('verify_stripe_payment', { body: { session_id: sessionId } })
      .then(({ data, error }) => {
        if (error || !data?.success) { setStatus('error'); return; }
        setOrder(data.order);
        setStatus('success');
        clearCart();
        // Notificar WhatsApp sobre novo pedido
        if (data.order?.id) {
          supabase.functions.invoke('whatsapp-notify', { body: { order_id: data.order.id } })
            .catch(() => {}); // Silencioso — não bloqueia o usuário
        }
      });
  }, [sessionId]);

  return (
    <MainLayout>
      <div className="container py-16 max-w-lg">
        {status === 'loading' && (
          <div className="flex flex-col items-center gap-4 text-center">
            <Loader2 className="h-12 w-12 animate-spin text-accent" />
            <p className="text-lg font-medium">Verificando pagamento...</p>
            <p className="text-muted-foreground text-sm">Por favor, aguarde</p>
          </div>
        )}
        {status === 'success' && (
          <div className="bg-card rounded-2xl border border-border p-8 text-center space-y-5">
            <div className="h-16 w-16 rounded-full bg-success/15 flex items-center justify-center mx-auto">
              <CheckCircle className="h-8 w-8 text-success" />
            </div>
            <h1 className="text-2xl font-bold">Pagamento Confirmado!</h1>
            <p className="text-muted-foreground">Seu pedido foi processado com sucesso.</p>
            {order && (
              <div className="bg-muted rounded-xl p-4 text-left space-y-2 text-sm">
                <div className="flex justify-between"><span className="text-muted-foreground">Pedido:</span><span className="font-mono font-medium">{order.order_number}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Total:</span><span className="font-bold">{order.total_amount?.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Status:</span><span className="text-success font-medium">Concluído</span></div>
              </div>
            )}
            <div className="flex flex-col gap-2">
              <Button onClick={() => navigate('/minha-conta/pedidos')} className="bg-accent text-accent-foreground hover:bg-accent/90 w-full">
                <Package className="h-4 w-4 mr-2" /> Ver Meus Pedidos
              </Button>
              <Button variant="outline" onClick={() => navigate('/')} className="w-full">
                <Home className="h-4 w-4 mr-2" /> Voltar à Loja
              </Button>
            </div>
          </div>
        )}
        {status === 'error' && (
          <div className="bg-card rounded-2xl border border-border p-8 text-center space-y-5">
            <div className="h-16 w-16 rounded-full bg-destructive/15 flex items-center justify-center mx-auto">
              <XCircle className="h-8 w-8 text-destructive" />
            </div>
            <h1 className="text-2xl font-bold">Erro no Pagamento</h1>
            <p className="text-muted-foreground">Não foi possível confirmar seu pagamento. Entre em contato com o suporte.</p>
            <div className="flex flex-col gap-2">
              <Button onClick={() => navigate('/carrinho')} className="bg-accent text-accent-foreground hover:bg-accent/90 w-full">
                Tentar Novamente
              </Button>
              <Button variant="outline" onClick={() => navigate('/')} className="w-full">
                <Home className="h-4 w-4 mr-2" /> Voltar à Loja
              </Button>
            </div>
          </div>
        )}
      </div>
    </MainLayout>
  );
}
