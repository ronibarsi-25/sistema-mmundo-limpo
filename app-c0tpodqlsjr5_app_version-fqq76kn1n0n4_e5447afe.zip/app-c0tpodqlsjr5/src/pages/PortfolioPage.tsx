import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Search, LayoutGrid, List, ImageOff, ArrowRight, Share2, Copy, Check, MessageCircle } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { MainLayout } from '@/components/layouts/MainLayout';
import { supabase } from '@/db/supabase';
import { useStore } from '@/contexts/StoreContext';
import { useActivePromotions, getPromotionalPrice } from '@/hooks/usePromotions';
import { toast } from 'sonner';
import type { Product, Category } from '@/types/types';

export default function PortfolioPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [showShareDialog, setShowShareDialog] = useState(false);
  const [copied, setCopied] = useState(false);
  const { promotions } = useActivePromotions();
  const { settings } = useStore();

  const storeName = settings?.store_name?.trim() || 'Mundo Limpo';
  const portfolioUrl = typeof window !== 'undefined' ? `${window.location.origin}/portfolio` : '/portfolio';
  const shareText = `Confira o catálogo de produtos da ${storeName}: ${portfolioUrl}`;

  const handleShareWhatsApp = () => {
    const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(shareText)}`;
    const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
    if (isMobile) {
      window.open(whatsappUrl, '_blank');
    } else {
      setShowShareDialog(true);
    }
  };

  const handleCopyMessage = async () => {
    try {
      await navigator.clipboard.writeText(shareText);
      setCopied(true);
      toast.success('Mensagem copiada para a área de transferência');
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error('Não foi possível copiar a mensagem');
    }
  };

  useEffect(() => {
    supabase.from('categories').select('*').eq('is_active', true).order('name').then(({ data }) => {
      setCategories(Array.isArray(data) ? data : []);
    });
  }, []);

  useEffect(() => {
    setLoading(true);
    let query = supabase.from('products').select('*, categories(*)').eq('is_available', true).order('created_at', { ascending: false });

    if (selectedCategory !== 'all') {
      query = query.eq('category_id', selectedCategory);
    }
    if (search.trim()) {
      query = query.or(`name.ilike.%${search.trim()}%,description.ilike.%${search.trim()}%`);
    }

    query.then(({ data }) => {
      setProducts(Array.isArray(data) ? data : []);
      setLoading(false);
    });
  }, [selectedCategory, search]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
  };

  return (
    <MainLayout>
      {/* Hero */}
      <section className="bg-muted/50 border-b border-border">
        <div className="container py-10 md:py-14 text-center">
          <h1 className="text-2xl md:text-4xl font-bold text-foreground mb-3 text-balance">
            Nosso Portfólio de Produtos
          </h1>
          <p className="text-sm md:text-base text-muted-foreground max-w-2xl mx-auto text-pretty mb-5">
            Conheça o catálogo completo da nossa loja. Qualidade e variedade para atender todas as suas necessidades.
          </p>
          <Button onClick={handleShareWhatsApp} className="gap-2 bg-success text-success-foreground hover:bg-success/90">
            <Share2 className="h-4 w-4" /> Compartilhar no WhatsApp
          </Button>
        </div>
      </section>

      <div className="container py-6 md:py-8">
        {/* Toolbar */}
        <div className="flex flex-col md:flex-row md:items-center gap-3 md:gap-4 mb-6 md:mb-8">
          <form onSubmit={handleSearch} className="relative flex-1 min-w-0">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Buscar produtos por nome..."
              className="pl-9 h-11"
            />
          </form>

          <div className="flex items-center gap-2 overflow-x-auto pb-1 md:pb-0">
            <Button
              variant={selectedCategory === 'all' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedCategory('all')}
              className="shrink-0"
            >
              Todas
            </Button>
            {categories.map((cat) => (
              <Button
                key={cat.id}
                variant={selectedCategory === cat.id ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedCategory(cat.id)}
                className="shrink-0"
              >
                {cat.name}
              </Button>
            ))}
          </div>

          <div className="hidden md:flex items-center border rounded-md p-1 shrink-0">
            <Button
              variant={viewMode === 'grid' ? 'secondary' : 'ghost'}
              size="icon"
              className="h-8 w-8"
              onClick={() => setViewMode('grid')}
            >
              <LayoutGrid className="h-4 w-4" />
            </Button>
            <Button
              variant={viewMode === 'list' ? 'secondary' : 'ghost'}
              size="icon"
              className="h-8 w-8"
              onClick={() => setViewMode('list')}
            >
              <List className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Results count */}
        <div className="flex items-center justify-between mb-4">
          <p className="text-sm text-muted-foreground">
            {loading ? 'Carregando produtos...' : `${products.length} produto${products.length !== 1 ? 's' : ''} encontrado${products.length !== 1 ? 's' : ''}`}
          </p>
        </div>

        {/* Loading */}
        {loading && (
          <div className={viewMode === 'grid' ? 'grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5' : 'space-y-4'}>
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="bg-card border border-border rounded-lg overflow-hidden">
                <Skeleton className="aspect-square w-full bg-muted" />
                <div className="p-4 space-y-2">
                  <Skeleton className="h-4 w-3/4 bg-muted" />
                  <Skeleton className="h-4 w-1/2 bg-muted" />
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Empty */}
        {!loading && products.length === 0 && (
          <div className="text-center py-16 md:py-24">
            <ImageOff className="h-12 w-12 mx-auto text-muted-foreground/40 mb-4" />
            <h2 className="text-lg font-semibold text-foreground mb-1">Nenhum produto encontrado</h2>
            <p className="text-sm text-muted-foreground">Tente ajustar os filtros ou a busca.</p>
          </div>
        )}

        {/* Grid view */}
        {!loading && viewMode === 'grid' && products.length > 0 && (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
            {products.map((product) => (
              <PortfolioCard key={product.id} product={product} promotions={promotions} />
            ))}
          </div>
        )}

        {/* List view */}
        {!loading && viewMode === 'list' && products.length > 0 && (
          <div className="space-y-4">
            {products.map((product) => (
              <PortfolioListItem key={product.id} product={product} promotions={promotions} />
            ))}
          </div>
        )}
      </div>

      {/* Share fallback dialog */}
      <Dialog open={showShareDialog} onOpenChange={setShowShareDialog}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-balance flex items-center gap-2">
              <MessageCircle className="h-5 w-5 text-success" /> Compartilhar no WhatsApp
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <p className="text-sm text-muted-foreground text-pretty">
              Copie a mensagem abaixo e envie pelo WhatsApp, ou clique para abrir o WhatsApp Web.
            </p>
            <div className="bg-muted rounded-lg p-3 text-sm text-foreground text-pretty border border-border">
              {shareText}
            </div>
          </div>
          <DialogFooter className="gap-2 flex-col md:flex-row">
            <Button variant="outline" onClick={handleCopyMessage} className="w-full md:w-auto gap-1.5">
              {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
              {copied ? 'Copiado' : 'Copiar Mensagem'}
            </Button>
            <Button
              className="w-full md:w-auto gap-1.5 bg-success text-success-foreground hover:bg-success/90"
              onClick={() => window.open(`https://wa.me/?text=${encodeURIComponent(shareText)}`, '_blank')}
            >
              <MessageCircle className="h-4 w-4" /> Abrir WhatsApp
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
}

function PortfolioCard({ product, promotions }: { product: Product; promotions: any[] }) {
  const imageUrl = product.images?.[0]?.url;
  const categoryName = product.categories?.name || 'Categoria';
  const promoPrice = getPromotionalPrice(product, promotions);
  const displayPrice = promoPrice ?? product.price;
  const originalPrice = promoPrice ? product.price : product.compare_at_price;

  return (
    <Link to={`/produto/${product.slug}`} className="group block bg-card border border-border rounded-lg overflow-hidden hover:shadow-lg transition-shadow">
      <div className="aspect-square w-full bg-muted overflow-hidden relative">
        {imageUrl ? (
          <img
            src={imageUrl}
            alt={product.name}
            loading="lazy"
            className="w-full h-full object-contain group-hover:scale-105 transition-transform duration-300"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-muted-foreground">
            <ImageOff className="h-10 w-10 opacity-40" />
          </div>
        )}
        {promoPrice && (
          <Badge className="absolute top-3 left-3 bg-accent text-accent-foreground">Promoção</Badge>
        )}
      </div>
      <div className="p-4">
        <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">{categoryName}</p>
        <h3 className="text-sm md:text-base font-semibold text-foreground mb-2 line-clamp-2 group-hover:text-primary transition-colors">{product.name}</h3>
        <div className="flex items-center gap-2">
          <span className="text-base font-bold text-primary">R$ {displayPrice.toFixed(2)}</span>
          {originalPrice && originalPrice > displayPrice && (
            <span className="text-xs text-muted-foreground line-through">R$ {originalPrice.toFixed(2)}</span>
          )}
        </div>
      </div>
    </Link>
  );
}

function PortfolioListItem({ product, promotions }: { product: Product; promotions: any[] }) {
  const imageUrl = product.images?.[0]?.url;
  const categoryName = product.categories?.name || 'Categoria';
  const promoPrice = getPromotionalPrice(product, promotions);
  const displayPrice = promoPrice ?? product.price;
  const originalPrice = promoPrice ? product.price : product.compare_at_price;

  return (
    <Link to={`/produto/${product.slug}`} className="group flex flex-col md:flex-row gap-4 bg-card border border-border rounded-lg overflow-hidden hover:shadow-lg transition-shadow p-3">
      <div className="aspect-square md:aspect-[4/3] md:w-48 w-full shrink-0 bg-muted rounded-md overflow-hidden relative">
        {imageUrl ? (
          <img
            src={imageUrl}
            alt={product.name}
            loading="lazy"
            className="w-full h-full object-contain group-hover:scale-105 transition-transform duration-300"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-muted-foreground">
            <ImageOff className="h-10 w-10 opacity-40" />
          </div>
        )}
      </div>
      <div className="flex-1 min-w-0 flex flex-col justify-center">
        <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">{categoryName}</p>
        <h3 className="text-base md:text-lg font-semibold text-foreground mb-2 line-clamp-2 group-hover:text-primary transition-colors">{product.name}</h3>
        {product.description && (
          <p className="text-sm text-muted-foreground line-clamp-2 mb-3 text-pretty">{product.description}</p>
        )}
        <div className="flex items-center gap-2 mb-3">
          <span className="text-lg font-bold text-primary">R$ {displayPrice.toFixed(2)}</span>
          {originalPrice && originalPrice > displayPrice && (
            <span className="text-sm text-muted-foreground line-through">R$ {originalPrice.toFixed(2)}</span>
          )}
          {promoPrice && <Badge className="bg-accent text-accent-foreground">Promoção</Badge>}
        </div>
        <div>
          <span className="inline-flex items-center gap-1 text-sm font-medium text-primary">
            Ver detalhes <ArrowRight className="h-3.5 w-3.5" />
          </span>
        </div>
      </div>
    </Link>
  );
}
