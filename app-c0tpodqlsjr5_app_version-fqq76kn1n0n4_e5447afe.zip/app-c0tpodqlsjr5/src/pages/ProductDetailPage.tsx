import { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import {
  ShoppingCart, Heart, GitCompare, Share2, ChevronLeft, Check,
  Truck, Shield, Facebook, Twitter, MessageCircle, Play,
  ZoomIn, X, ChevronLeft as PrevIcon, ChevronRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Skeleton } from '@/components/ui/skeleton';
import { MainLayout } from '@/components/layouts/MainLayout';
import { ProductCard } from '@/components/common/ProductCard';
import { useCart } from '@/contexts/CartContext';
import { useAuth } from '@/contexts/AuthContext';
import { useCompare } from '@/contexts/CompareContext';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import type { Product } from '@/types/types';
import { useActivePromotions, getPromotionalPrice, getPromotionBadge } from '@/hooks/usePromotions';
import { metaPixel } from '@/utils/metaPixel';

function getYoutubeId(url: string): string | null {
  if (!url) return null;
  const reg = /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/|youtube\.com\/v\/|youtube\.com\/shorts\/)([a-zA-Z0-9_-]{11})/;
  const match = url.match(reg);
  return match ? match[1] : null;
}

type VideoType = 'youtube' | 'vimeo' | 'tiktok' | 'instagram' | null;

function detectVideoType(url: string): VideoType {
  if (!url) return null;
  if (/youtube\.com|youtu\.be/.test(url)) return 'youtube';
  if (/vimeo\.com/.test(url)) return 'vimeo';
  if (/tiktok\.com/.test(url)) return 'tiktok';
  if (/instagram\.com/.test(url)) return 'instagram';
  return null;
}

function getVimeoId(url: string): string | null {
  const match = url.match(/vimeo\.com\/(?:video\/)?(\d+)/);
  return match ? match[1] : null;
}

function getTikTokEmbedUrl(url: string): string | null {
  // TikTok embed: https://www.tiktok.com/embed/v2/{video_id}
  const match = url.match(/tiktok\.com\/@[^/]+\/video\/(\d+)/);
  return match ? `https://www.tiktok.com/embed/v2/${match[1]}` : null;
}

export default function ProductDetailPage() {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const { addItem } = useCart();
  const { user } = useAuth();
  const { addToCompare, isInCompare, removeFromCompare } = useCompare();
  const [product, setProduct] = useState<Product | null>(null);
  const [related, setRelated] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [qty, setQty] = useState(1);
  const [selectedImage, setSelectedImage] = useState(0);
  const [inWishlist, setInWishlist] = useState(false);
  const [added, setAdded] = useState(false);
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const { promotions } = useActivePromotions();

  const handleLightboxKey = useCallback((e: KeyboardEvent) => {
    if (!lightboxOpen || !product) return;
    if (e.key === 'Escape') setLightboxOpen(false);
    if (e.key === 'ArrowRight') setSelectedImage(i => Math.min(i + 1, (product.images?.length ?? 1) - 1));
    if (e.key === 'ArrowLeft') setSelectedImage(i => Math.max(i - 1, 0));
  }, [lightboxOpen, product]);

  useEffect(() => {
    document.addEventListener('keydown', handleLightboxKey);
    return () => document.removeEventListener('keydown', handleLightboxKey);
  }, [handleLightboxKey]);

  useEffect(() => {
    if (!slug) return;
    supabase.from('products').select('*, categories(*)').eq('slug', slug).maybeSingle()
      .then(({ data }) => {
        setProduct(data);
        setLoading(false);
        
        // SEO: Atualizar meta tags e título
        if (data) {
          metaPixel.trackViewContent({
            id: data.id,
            name: data.name,
            price: Number(data.price) || 0,
            category: (data as any).categories?.name,
          });
          document.title = `${data.name} | Loja`;
          const metaDesc = document.querySelector('meta[name="description"]');
          if (metaDesc) {
            metaDesc.setAttribute('content', data.description || `Compre ${data.name} na nossa loja pelo melhor preço.`);
          }
        }

        if (data?.category_id) {
          supabase.from('products').select('*, categories(*)').eq('category_id', data.category_id).eq('is_available', true).neq('id', data.id).limit(4)
            .then(({ data: rel }) => setRelated(Array.isArray(rel) ? rel : []));
        }
        if (user && data) {
          supabase.from('wishlist').select('id').eq('user_id', user.id).eq('product_id', data.id).maybeSingle()
            .then(({ data: w }) => setInWishlist(!!w));
        }
      });
  }, [slug, user]);

  const handleAddToCart = () => {
    if (!product) return;
    for (let i = 0; i < qty; i++) addItem(product);
    metaPixel.trackAddToCart({
      id: product.id,
      name: product.name,
      price: Number(product.price) || 0,
      quantity: qty,
      category: (product as any).categories?.name,
    });
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  const handleWishlist = async () => {
    if (!user) { toast.error('Faça login para usar a lista de desejos'); return; }
    if (!product) return;
    if (inWishlist) {
      await supabase.from('wishlist').delete().eq('user_id', user.id).eq('product_id', product.id);
      setInWishlist(false);
      toast.success('Removido da lista de desejos');
    } else {
      await supabase.from('wishlist').insert({ user_id: user.id, product_id: product.id });
      setInWishlist(true);
      toast.success('Adicionado à lista de desejos');
    }
  };

  const handleShare = async (platform?: string) => {
    const url = window.location.href;
    if (platform === 'facebook') window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`, '_blank');
    else if (platform === 'twitter') window.open(`https://twitter.com/intent/tweet?url=${encodeURIComponent(url)}&text=${encodeURIComponent(product?.name || '')}`, '_blank');
    else if (platform === 'whatsapp') window.open(`https://wa.me/?text=${encodeURIComponent(product?.name + ' ' + url)}`, '_blank');
    else {
      await navigator.clipboard.writeText(url);
      toast.success('Link copiado!');
    }
  };

  if (loading) return (
    <MainLayout>
      <div className="container py-8">
        <div className="grid md:grid-cols-2 gap-8">
          <Skeleton className="aspect-square rounded-xl bg-muted" />
          <div className="space-y-4"><Skeleton className="h-8 w-3/4 bg-muted" /><Skeleton className="h-6 w-1/3 bg-muted" /><Skeleton className="h-20 bg-muted" /><Skeleton className="h-12 bg-muted" /></div>
        </div>
      </div>
    </MainLayout>
  );

  if (!product) return (
    <MainLayout>
      <div className="container py-16 text-center">
        <p className="text-muted-foreground">Produto não encontrado</p>
        <Button className="mt-4" onClick={() => navigate('/produtos')}>Ver produtos</Button>
      </div>
    </MainLayout>
  );

  const promoPrice = product ? getPromotionalPrice(product, promotions, qty) : null;
  const displayPrice = promoPrice ?? product?.price ?? 0;
  const originalPrice = promoPrice ? product?.price : product?.compare_at_price;
  const discount = promoPrice && product
    ? Math.round((1 - promoPrice / product.price) * 100)
    : product?.compare_at_price
      ? Math.round((1 - product.price / product.compare_at_price) * 100)
      : null;
  const promoBadge = product ? getPromotionBadge(product, promotions, qty) : null;

  return (
    <MainLayout>
      <div className="container py-6 md:py-8">
        {/* Breadcrumb */}
        <nav className="flex items-center gap-1 text-sm text-muted-foreground mb-6">
          <Link to="/" className="hover:text-foreground">Início</Link>
          <span>/</span>
          <Link to="/produtos" className="hover:text-foreground">Produtos</Link>
          {product.categories && <><span>/</span><Link to={`/produtos?categoria=${product.categories.slug}`} className="hover:text-foreground">{product.categories.name}</Link></>}
          <span>/</span>
          <span className="text-foreground truncate">{product.name}</span>
        </nav>

        <Button variant="ghost" size="sm" className="mb-4 -ml-1" onClick={() => navigate(-1)}>
          <ChevronLeft className="h-4 w-4 mr-1" /> Voltar
        </Button>

        <div className="grid md:grid-cols-2 gap-8 lg:gap-12">
          {/* Images */}
          <div className="space-y-3">
            {/* Main image */}
            <div
              className="relative aspect-square rounded-xl overflow-hidden bg-muted border border-border cursor-zoom-in"
              onClick={() => setLightboxOpen(true)}
            >
              {product.images?.[selectedImage]?.url ? (
                <>
                  <img
                    src={product.images[selectedImage].url}
                    alt={product.images[selectedImage].alt || product.name}
                    loading="eager"
                    decoding="async"
                    className="w-full h-full object-contain p-4 transition-transform duration-500 hover:scale-110"
                  />
                  <div className="absolute bottom-3 right-3 flex items-center gap-1.5 bg-background/80 backdrop-blur-sm rounded-full px-2.5 py-1 text-xs text-muted-foreground border border-border shadow-sm pointer-events-none">
                    <ZoomIn className="h-3.5 w-3.5" /> Clique para ampliar
                  </div>
                </>
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <ShoppingCart className="h-16 w-16 text-muted-foreground/30" />
                </div>
              )}
            </div>

            {/* Thumbnails */}
            {product.images?.length > 1 && (
              <div className="flex gap-2 overflow-x-auto pb-1">
                {product.images.map((img, i) => (
                  <button key={i} onClick={() => setSelectedImage(i)}
                    className={`relative h-20 w-20 rounded-lg overflow-hidden border-2 transition-all shrink-0 bg-muted ${selectedImage === i ? 'border-accent shadow-md scale-105' : 'border-border hover:border-accent/60 hover:scale-105'}`}>
                    <img src={img.url} alt={img.alt} loading="lazy" className="w-full h-full object-contain p-1" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Info */}
          <div className="space-y-5">
            {product.categories && <Badge variant="secondary">{product.categories.name}</Badge>}
            <h1 className="text-2xl md:text-3xl font-bold text-balance">{product.name}</h1>

            <div className="flex items-baseline gap-3 flex-wrap">
              <span className={`text-2xl md:text-3xl font-bold ${promoPrice ? 'text-destructive' : 'text-foreground'}`}>
                {displayPrice.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
              </span>
              {originalPrice && (
                <span className="text-base text-muted-foreground line-through">
                  {originalPrice.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                </span>
              )}
              {discount && <Badge className="bg-destructive text-destructive-foreground border-0">-{discount}%</Badge>}
              {promoBadge && <Badge className="bg-destructive/10 text-destructive border-0 text-xs">{promoBadge}</Badge>}
            </div>

            {/* Banner de promoção ativa */}
            {promotions.filter(p => p.promo_type === 'buy_x_get_y' || p.promo_type === 'progressive').filter(p => {
              if (p.scope === 'all') return true;
              if (p.scope === 'categories' && product.category_id) return p.scope_ids.includes(product.category_id);
              if (p.scope === 'products') return p.scope_ids.includes(product.id);
              return false;
            }).slice(0, 1).map(p => (
              <div key={p.id} className="rounded-xl border p-3 text-sm space-y-1"
                style={{ backgroundColor: p.banner_color + '12', borderColor: p.banner_color + '40' }}>
                <p className="font-semibold text-sm" style={{ color: p.banner_color }}>
                  {p.promo_type === 'buy_x_get_y' ? `Compre ${p.buy_quantity} Leve ${p.get_quantity}` : 'Desconto Progressivo'}
                </p>
                {p.promo_type === 'buy_x_get_y' && (
                  <p className="text-xs text-muted-foreground">
                    Adicione {p.get_quantity} unidades ao carrinho e pague apenas {p.buy_quantity}!
                  </p>
                )}
                {p.promo_type === 'progressive' && p.progressive_tiers && (
                  <div className="flex flex-wrap gap-2 mt-1">
                    {p.progressive_tiers.map((t, i) => (
                      <span key={i} className="text-xs font-medium px-2 py-0.5 rounded-full"
                        style={{ backgroundColor: p.banner_color + '22', color: p.banner_color }}>
                        {t.max_qty ? `${t.min_qty}-${t.max_qty} un: ${t.discount_percent}%` : `${t.min_qty}+ un: ${t.discount_percent}%`}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            ))}

            <p className="text-sm text-pretty text-muted-foreground">{product.description}</p>

            {/* Vídeo do Produto — multi-plataforma */}
            {product.video_url && (() => {
              const vtype = detectVideoType(product.video_url);
              const ytId = vtype === 'youtube' ? getYoutubeId(product.video_url) : null;
              const vmId = vtype === 'vimeo' ? getVimeoId(product.video_url) : null;
              const ttUrl = vtype === 'tiktok' ? getTikTokEmbedUrl(product.video_url) : null;

              if (vtype === 'youtube' && ytId) return (
                <div className="space-y-2">
                  <h3 className="text-sm font-semibold flex items-center gap-2">
                    <Play className="h-4 w-4 text-destructive" /> Vídeo do Produto
                    <Badge variant="secondary" className="text-[10px] px-1.5 py-0">YouTube</Badge>
                  </h3>
                  <div className="aspect-video w-full rounded-xl overflow-hidden bg-black">
                    <iframe src={`https://www.youtube.com/embed/${ytId}`}
                      title={`Vídeo de ${product.name}`}
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen className="w-full h-full" />
                  </div>
                </div>
              );

              if (vtype === 'vimeo' && vmId) return (
                <div className="space-y-2">
                  <h3 className="text-sm font-semibold flex items-center gap-2">
                    <Play className="h-4 w-4 text-blue-500" /> Vídeo do Produto
                    <Badge variant="secondary" className="text-[10px] px-1.5 py-0">Vimeo</Badge>
                  </h3>
                  <div className="aspect-video w-full rounded-xl overflow-hidden bg-black">
                    <iframe src={`https://player.vimeo.com/video/${vmId}?badge=0&autopause=0&player_id=0`}
                      title={`Vídeo de ${product.name}`}
                      allow="autoplay; fullscreen; picture-in-picture"
                      allowFullScreen className="w-full h-full" />
                  </div>
                </div>
              );

              if (vtype === 'tiktok' && ttUrl) return (
                <div className="space-y-2">
                  <h3 className="text-sm font-semibold flex items-center gap-2">
                    <Play className="h-4 w-4" /> Vídeo do Produto
                    <Badge variant="secondary" className="text-[10px] px-1.5 py-0">TikTok</Badge>
                  </h3>
                  <div className="w-full max-w-xs mx-auto rounded-xl overflow-hidden bg-black" style={{ aspectRatio: '9/16' }}>
                    <iframe src={ttUrl}
                      title={`Vídeo TikTok de ${product.name}`}
                      allow="autoplay; clipboard-write; encrypted-media; picture-in-picture"
                      allowFullScreen className="w-full h-full" />
                  </div>
                </div>
              );

              if (vtype === 'instagram') return (
                <div className="space-y-2">
                  <h3 className="text-sm font-semibold flex items-center gap-2">
                    <Play className="h-4 w-4 text-pink-500" /> Vídeo do Produto
                    <Badge variant="secondary" className="text-[10px] px-1.5 py-0">Instagram</Badge>
                  </h3>
                  <a href={product.video_url} target="_blank" rel="noopener noreferrer"
                    className="flex items-center gap-3 p-4 rounded-xl border border-border bg-muted hover:bg-muted/80 transition-colors group">
                    <div className="h-12 w-12 rounded-full bg-gradient-to-tr from-yellow-400 via-pink-500 to-purple-600 flex items-center justify-center shrink-0">
                      <Play className="h-5 w-5 text-white" fill="currentColor" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium group-hover:text-primary transition-colors">Ver vídeo no Instagram</p>
                      <p className="text-xs text-muted-foreground truncate">{product.video_url}</p>
                    </div>
                    <Share2 className="h-4 w-4 text-muted-foreground shrink-0" />
                  </a>
                </div>
              );

              return null;
            })()}

            {/* Informações adicionais do produto */}
            <div className="space-y-2">
              <h3 className="text-sm font-semibold">Informações do Produto</h3>
              <div className="grid grid-cols-2 gap-2">
                {product.code && (
                  <div className="bg-muted rounded-md px-3 py-2">
                    <p className="text-xs text-muted-foreground">Código Interno</p>
                    <p className="text-sm font-medium">{product.code}</p>
                  </div>
                )}
                {product.barcode && (
                  <div className="bg-muted rounded-md px-3 py-2">
                    <p className="text-xs text-muted-foreground">Código de Barras</p>
                    <p className="text-sm font-medium">{product.barcode}</p>
                  </div>
                )}
                {product.unit && (
                  <div className="bg-muted rounded-md px-3 py-2">
                    <p className="text-xs text-muted-foreground">Unidade</p>
                    <p className="text-sm font-medium">{product.unit}</p>
                  </div>
                )}
                {product.sku && (
                  <div className="bg-muted rounded-md px-3 py-2">
                    <p className="text-xs text-muted-foreground">SKU</p>
                    <p className="text-sm font-medium">{product.sku}</p>
                  </div>
                )}
                {product.brand && (
                  <div className="bg-muted rounded-md px-3 py-2">
                    <p className="text-xs text-muted-foreground">Marca</p>
                    <p className="text-sm font-medium">{product.brand}</p>
                  </div>
                )}
                {product.weight && (
                  <div className="bg-muted rounded-md px-3 py-2">
                    <p className="text-xs text-muted-foreground">Peso</p>
                    <p className="text-sm font-medium">{product.weight} kg</p>
                  </div>
                )}
                {product.dimensions && (
                  <div className="bg-muted rounded-md px-3 py-2">
                    <p className="text-xs text-muted-foreground">Dimensões</p>
                    <p className="text-sm font-medium">{product.dimensions}</p>
                  </div>
                )}
                {product.expiry_date && (
                  <div className="bg-muted rounded-md px-3 py-2">
                    <p className="text-xs text-muted-foreground">Validade</p>
                    <p className="text-sm font-medium">{new Date(product.expiry_date).toLocaleDateString('pt-BR')}</p>
                  </div>
                )}
              </div>
            </div>

            {/* Attributes */}
            {Object.keys(product.attributes || {}).length > 0 && (
              <div className="space-y-2">
                <h3 className="text-sm font-semibold">Especificações</h3>
                <div className="grid grid-cols-2 gap-2">
                  {Object.entries(product.attributes).map(([key, val]) => (
                    <div key={key} className="bg-muted rounded-md px-3 py-2">
                      <p className="text-xs text-muted-foreground capitalize">{key}</p>
                      <p className="text-sm font-medium">{val}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <Separator />

            {/* Stock */}
            <div className="flex items-center gap-2">
              {product.is_available && product.stock_quantity > 0 ? (
                <><Badge className="bg-success text-success-foreground border-0">Em estoque</Badge>
                  {product.stock_quantity <= 5 && <span className="text-xs text-warning-foreground font-medium">Últimas {product.stock_quantity} unidades</span>}
                </>
              ) : <Badge variant="secondary">Indisponível</Badge>}
            </div>

            {/* Quantity + Add to cart */}
            {product.is_available && product.stock_quantity > 0 && (
              <div className="flex items-center gap-3">
                <div className="flex items-center border border-border rounded-md">
                  <button onClick={() => setQty(q => Math.max(1, q - 1))} className="h-10 w-10 flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors">-</button>
                  <span className="h-10 w-10 flex items-center justify-center text-sm font-medium">{qty}</span>
                  <button onClick={() => setQty(q => Math.min(product.stock_quantity, q + 1))} className="h-10 w-10 flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors">+</button>
                </div>
                <Button onClick={handleAddToCart} className="flex-1 bg-accent text-accent-foreground hover:bg-accent/90 h-10" disabled={added}>
                  {added ? <><Check className="h-4 w-4 mr-2" /> Adicionado</> : <><ShoppingCart className="h-4 w-4 mr-2" /> Adicionar ao Carrinho</>}
                </Button>
              </div>
            )}

            {/* Actions */}
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={handleWishlist} className={inWishlist ? 'text-destructive border-destructive/40' : ''}>
                <Heart className="h-4 w-4 mr-2" fill={inWishlist ? 'currentColor' : 'none'} />
                {inWishlist ? 'Na lista' : 'Lista de Desejos'}
              </Button>
              <Button variant="outline" size="sm" onClick={() => isInCompare(product.id) ? removeFromCompare(product.id) : addToCompare(product)}
                className={isInCompare(product.id) ? 'text-primary border-primary/40' : ''}>
                <GitCompare className="h-4 w-4 mr-2" />
                {isInCompare(product.id) ? 'Comparando' : 'Comparar'}
              </Button>
            </div>

            {/* Share */}
            <div className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground">Compartilhar:</span>
              <button onClick={() => handleShare('facebook')} className="h-7 w-7 rounded-md bg-muted flex items-center justify-center hover:bg-muted/80 transition-colors">
                <Facebook className="h-3.5 w-3.5" />
              </button>
              <button onClick={() => handleShare('twitter')} className="h-7 w-7 rounded-md bg-muted flex items-center justify-center hover:bg-muted/80 transition-colors">
                <Twitter className="h-3.5 w-3.5" />
              </button>
              <button onClick={() => handleShare('whatsapp')} className="h-7 w-7 rounded-md bg-muted flex items-center justify-center hover:bg-muted/80 transition-colors">
                <MessageCircle className="h-3.5 w-3.5" />
              </button>
              <button onClick={() => handleShare()} className="h-7 w-7 rounded-md bg-muted flex items-center justify-center hover:bg-muted/80 transition-colors">
                <Share2 className="h-3.5 w-3.5" />
              </button>
            </div>

            {/* Trust indicators */}
            <div className="bg-muted rounded-lg p-4 grid grid-cols-2 gap-3">
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <Truck className="h-4 w-4 shrink-0 text-accent" /> Entrega para todo Brasil
              </div>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <Shield className="h-4 w-4 shrink-0 text-accent" /> Compra 100% segura
              </div>
            </div>
          </div>
        </div>

        {/* Related products */}
        {related.length > 0 && (
          <div className="mt-12">
            <h2 className="text-lg font-bold mb-5">Produtos Relacionados</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {related.map(p => <ProductCard key={p.id} product={p} promotions={promotions} />)}
            </div>
          </div>
        )}
      </div>

      {/* Lightbox */}
      {lightboxOpen && product.images?.length > 0 && (
        <div
          className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center"
          onClick={() => setLightboxOpen(false)}
        >
          {/* Close */}
          <button
            className="absolute top-4 right-4 h-10 w-10 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors z-10"
            onClick={() => setLightboxOpen(false)}
          >
            <X className="h-5 w-5" />
          </button>

          {/* Prev */}
          {selectedImage > 0 && (
            <button
              className="absolute left-4 h-10 w-10 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors z-10"
              onClick={e => { e.stopPropagation(); setSelectedImage(i => i - 1); }}
            >
              <PrevIcon className="h-5 w-5" />
            </button>
          )}

          {/* Image */}
          <div className="max-w-3xl max-h-[85vh] w-full px-16" onClick={e => e.stopPropagation()}>
            <img
              src={product.images[selectedImage].url}
              alt={product.images[selectedImage].alt || product.name}
              className="w-full h-full object-contain max-h-[80vh] rounded-lg select-none"
              draggable={false}
            />
            {product.images.length > 1 && (
              <p className="text-center text-white/60 text-sm mt-3">
                {selectedImage + 1} / {product.images.length}
              </p>
            )}
          </div>

          {/* Next */}
          {selectedImage < product.images.length - 1 && (
            <button
              className="absolute right-4 h-10 w-10 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors z-10"
              onClick={e => { e.stopPropagation(); setSelectedImage(i => i + 1); }}
            >
              <ChevronRight className="h-5 w-5" />
            </button>
          )}

          {/* Thumbnail strip */}
          {product.images.length > 1 && (
            <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-2">
              {product.images.map((img, i) => (
                <button
                  key={i}
                  onClick={e => { e.stopPropagation(); setSelectedImage(i); }}
                  className={`h-14 w-14 rounded-md overflow-hidden border-2 transition-all shrink-0 ${selectedImage === i ? 'border-white scale-110' : 'border-white/30 hover:border-white/60'}`}
                >
                  <img src={img.url} alt={img.alt} className="w-full h-full object-contain bg-white/5" />
                </button>
              ))}
            </div>
          )}
        </div>
      )}
    </MainLayout>
  );
}
