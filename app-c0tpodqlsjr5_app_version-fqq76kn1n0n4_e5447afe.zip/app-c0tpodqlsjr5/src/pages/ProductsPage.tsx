import { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Search, SlidersHorizontal, X } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { MainLayout } from '@/components/layouts/MainLayout';
import { ProductCard } from '@/components/common/ProductCard';
import { supabase } from '@/db/supabase';
import { useActivePromotions } from '@/hooks/usePromotions';
import type { Product, Category } from '@/types/types';

export default function ProductsPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState(searchParams.get('busca') || '');
  const [sort, setSort] = useState('newest');
  const [showFilters, setShowFilters] = useState(false);
  const { promotions } = useActivePromotions();

  const categorySlug = searchParams.get('categoria');
  const searchQuery = searchParams.get('busca') || '';

  useEffect(() => {
    supabase.from('categories').select('*').eq('is_active', true).order('name').then(({ data }) => {
      setCategories(Array.isArray(data) ? data : []);
    });
  }, []);

  useEffect(() => {
    setLoading(true);
    let query = supabase.from('products').select('*, categories(*)').eq('is_available', true);

    if (categorySlug) {
      query = query.eq('categories.slug', categorySlug);
    }
    if (searchQuery) {
      query = query.or(`name.ilike.%${searchQuery}%,description.ilike.%${searchQuery}%`);
    }

    switch (sort) {
      case 'price_asc': query = query.order('price', { ascending: true }); break;
      case 'price_desc': query = query.order('price', { ascending: false }); break;
      case 'newest': query = query.order('created_at', { ascending: false }); break;
    }

    query.then(({ data }) => {
      let filtered = Array.isArray(data) ? data : [];
      if (categorySlug) {
        filtered = filtered.filter((p: Product) => p.categories?.slug === categorySlug);
      }
      setProducts(filtered);
      setLoading(false);
    });
  }, [categorySlug, searchQuery, sort]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const params = new URLSearchParams(searchParams);
    if (search.trim()) params.set('busca', search.trim());
    else params.delete('busca');
    setSearchParams(params);
  };

  const clearFilter = (type: 'categoria' | 'busca') => {
    const params = new URLSearchParams(searchParams);
    params.delete(type);
    setSearchParams(params);
    if (type === 'busca') setSearch('');
  };

  const activeCategory = categories.find(c => c.slug === categorySlug);

  return (
    <MainLayout>
      <div className="container py-6 md:py-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
          <div>
            <h1 className="text-xl md:text-2xl font-bold text-balance">
              {activeCategory ? activeCategory.name : searchQuery ? `Busca: "${searchQuery}"` : 'Todos os Produtos'}
            </h1>
            <p className="text-sm text-muted-foreground">{loading ? '...' : `${products.length} produto(s) encontrado(s)`}</p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => setShowFilters(!showFilters)} className="md:hidden">
              <SlidersHorizontal className="h-4 w-4 mr-2" /> Filtros
            </Button>
            <Select value={sort} onValueChange={setSort}>
              <SelectTrigger className="w-44 h-9"><SelectValue placeholder="Ordenar por" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="newest">Mais recentes</SelectItem>
                <SelectItem value="price_asc">Menor preço</SelectItem>
                <SelectItem value="price_desc">Maior preço</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Active filters */}
        <div className="flex flex-wrap gap-2 mb-4">
          {activeCategory && (
            <Badge variant="secondary" className="gap-1">
              Categoria: {activeCategory.name}
              <button onClick={() => clearFilter('categoria')}><X className="h-3 w-3" /></button>
            </Badge>
          )}
          {searchQuery && (
            <Badge variant="secondary" className="gap-1">
              Busca: {searchQuery}
              <button onClick={() => clearFilter('busca')}><X className="h-3 w-3" /></button>
            </Badge>
          )}
        </div>

        <div className="flex gap-6">
          {/* Sidebar filters */}
          <aside className={`w-56 shrink-0 ${showFilters ? 'block' : 'hidden'} md:block`}>
            <div className="sticky top-20 space-y-5">
              <form onSubmit={handleSearch}>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar..." className="pl-9 h-9" />
                </div>
              </form>
              <div>
                <h3 className="text-sm font-semibold mb-2">Categorias</h3>
                <div className="space-y-0.5">
                  <button onClick={() => { const p = new URLSearchParams(searchParams); p.delete('categoria'); setSearchParams(p); }}
                    className={`w-full text-left px-2 py-1.5 rounded-md text-sm transition-colors ${!categorySlug ? 'bg-accent/10 text-accent font-medium' : 'text-muted-foreground hover:bg-muted hover:text-foreground'}`}>
                    Todas
                  </button>
                  {categories.map(cat => (
                    <button key={cat.id} onClick={() => { const p = new URLSearchParams(searchParams); p.set('categoria', cat.slug); setSearchParams(p); }}
                      className={`w-full text-left px-2 py-1.5 rounded-md text-sm transition-colors ${categorySlug === cat.slug ? 'bg-accent/10 text-accent font-medium' : 'text-muted-foreground hover:bg-muted hover:text-foreground'}`}>
                      {cat.name}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </aside>

          {/* Products grid */}
          <div className="flex-1 min-w-0">
            {loading ? (
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {[...Array(9)].map((_, i) => (
                  <div key={i} className="rounded-lg border overflow-hidden">
                    <Skeleton className="aspect-[3/4] bg-muted" />
                    <div className="p-3 space-y-2"><Skeleton className="h-3 w-16 bg-muted" /><Skeleton className="h-4 w-full bg-muted" /><Skeleton className="h-8 bg-muted" /></div>
                  </div>
                ))}
              </div>
            ) : products.length > 0 ? (
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {products.map(p => <ProductCard key={p.id} product={p} promotions={promotions} />)}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-16 text-center gap-3">
                <Search className="h-12 w-12 text-muted-foreground/30" />
                <p className="text-base font-medium">Nenhum produto encontrado</p>
                <p className="text-sm text-muted-foreground">Tente outros termos ou remova os filtros</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
