import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { User, Save, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { MainLayout } from '@/components/layouts/MainLayout';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import { useForm } from 'react-hook-form';

interface ProfileForm { full_name: string; phone: string; }

export default function ProfilePage() {
  const { user, profile, refreshProfile } = useAuth();
  const navigate = useNavigate();
  const [saving, setSaving] = useState(false);

  const form = useForm<ProfileForm>({
    defaultValues: { full_name: '', phone: '' }
  });

  useEffect(() => {
    if (!user) { navigate('/login'); return; }
    if (profile) {
      form.reset({ full_name: profile.full_name || '', phone: profile.phone || '' });
    }
  }, [user, profile]);

  const onSubmit = async (data: ProfileForm) => {
    if (!user) return;
    setSaving(true);
    const { error } = await supabase.from('profiles').update({
      full_name: data.full_name || null,
      phone: data.phone || null,
      updated_at: new Date().toISOString()
    }).eq('id', user.id);
    if (error) { toast.error('Erro ao salvar perfil'); setSaving(false); return; }
    await refreshProfile();
    toast.success('Perfil atualizado!');
    setSaving(false);
  };

  return (
    <MainLayout>
      <div className="container py-6 md:py-10 max-w-lg">
        <div className="flex items-center gap-3 mb-6">
          <User className="h-6 w-6" />
          <h1 className="text-2xl font-bold">Meu Perfil</h1>
        </div>
        <div className="bg-card rounded-xl border border-border p-6">
          <div className="flex items-center gap-4 mb-6 pb-6 border-b border-border">
            <div className="h-14 w-14 rounded-full bg-primary/10 flex items-center justify-center">
              <User className="h-7 w-7 text-primary" />
            </div>
            <div>
              <p className="font-semibold">{profile?.full_name || 'Usuário'}</p>
              <p className="text-sm text-muted-foreground">{user?.email}</p>
            </div>
          </div>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField control={form.control} name="full_name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Nome completo</FormLabel>
                    <FormControl><Input {...field} placeholder="Seu nome" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              <div className="space-y-1">
                <label className="text-sm font-normal">E-mail</label>
                <Input value={user?.email || ''} disabled className="bg-muted" />
                <p className="text-xs text-muted-foreground">O e-mail não pode ser alterado</p>
              </div>
              <FormField control={form.control} name="phone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Telefone</FormLabel>
                    <FormControl><Input {...field} placeholder="(11) 99999-9999" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              <Button type="submit" className="w-full bg-accent text-accent-foreground hover:bg-accent/90 h-10" disabled={saving}>
                {saving ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Save className="h-4 w-4 mr-2" />}
                Salvar Alterações
              </Button>
            </form>
          </Form>
        </div>
      </div>
    </MainLayout>
  );
}
