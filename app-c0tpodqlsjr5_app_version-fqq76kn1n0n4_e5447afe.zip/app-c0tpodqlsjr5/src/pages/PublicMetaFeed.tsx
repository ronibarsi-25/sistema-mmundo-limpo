import { useEffect, useState } from 'react';
import { useSearchParams, useLocation, Link } from 'react-router-dom';
import { supabase } from '@/db/supabase';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Download, Copy, ArrowLeft, Check, Rss, ExternalLink, ShieldCheck } from 'lucide-react';
import { toast } from 'sonner';
import {
  generateMetaXml,
  generateMetaCsv,
  downloadFile,
  sanitizeMetaImageUrl,
  type MetaProductItem,
} from '@/utils/metaFeedGenerator';

export default function PublicMetaFeed() {
  const location = useLocation();
  const [searchParams] = useSearchParams();

  // Detecta formato seja por query (?format=csv) ou pelo caminho (/feed/meta/format=csv, /feed/meta.csv, /feed/meta/csv)
  const queryFormat = (searchParams.get('format') || '').toLowerCase();
  const path = location.pathname.toLowerCase();
  const format = queryFormat === 'csv' || path.includes('csv') ? 'csv' : 'xml';

  const [loading, setLoading] = useState(true);
  const [content, setContent] = useState('');
  const [copied, setCopied] = useState(false);
  const [productsCount, setProductsCount] = useState(0);
  const [showRaw, setShowRaw] = useState(searchParams.get('raw') === 'true');

  useEffect(() => {
    loadFeed();
  }, [format, location.pathname]);

  const loadFeed = async () => {
    setLoading(true);
    try {
      // 1. Buscar produtos do catálogo online
      const { data: onlineProducts } = await supabase
        .from('products')
        .select('id, name, slug, description, price, stock_quantity, is_available, images, barcode, category_id, categories(name)')
        .eq('is_available', true);

      // 2. Buscar pdv_products para enriquecer com código de barras/EAN
      const { data: pdvList } = await supabase
        .from('pdv_products')
        .select('name, code, barcode, site_product_id');

      const barcodeBySiteId = new Map<string, string>();
      const barcodeByName = new Map<string, string>();
      pdvList?.forEach(p => {
        if (p.barcode?.trim()) {
          if (p.site_product_id) barcodeBySiteId.set(p.site_product_id, p.barcode.trim());
          barcodeByName.set(p.name.trim().toLowerCase(), p.barcode.trim());
        }
      });

      const origin = window.location.origin;
      const metaItems: MetaProductItem[] = (onlineProducts || []).map(p => {
        const barcode = p.barcode?.trim() || barcodeBySiteId.get(p.id) || barcodeByName.get(p.name.trim().toLowerCase()) || '';
        const rawImgUrl = p.images?.[0]?.url;
        const imgUrl = sanitizeMetaImageUrl(rawImgUrl, origin, p.slug || p.id);
        const productLink = `${origin}/produto/${p.slug || p.id}`;
        const priceFormatted = `${Number(p.price || 0).toFixed(2)} BRL`;

        return {
          id: p.id,
          title: p.name,
          description: p.description || p.name,
          availability: (p.stock_quantity || 0) > 0 ? 'in stock' : 'out of stock',
          condition: 'new',
          price: priceFormatted,
          link: productLink,
          image_link: imgUrl,
          brand: 'Mundo Limpo',
          gtin: barcode,
          fb_product_category: 'Health & Beauty > Personal Care'
        };
      });

      setProductsCount(metaItems.length);

      const storeInfo = {
        storeName: 'Mundo Limpo',
        storeUrl: origin,
        storeDescription: 'Feed oficial de produtos Mundo Limpo para Facebook Shop e Instagram Shopping',
      };

      if (format === 'csv') {
        setContent(generateMetaCsv(metaItems));
      } else {
        setContent(generateMetaXml(metaItems, storeInfo));
      }
    } catch (err: any) {
      console.error(err);
      toast.error('Erro ao gerar feed: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(content);
    setCopied(true);
    toast.success('Conteúdo do feed copiado para a área de transferência!');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    if (format === 'csv') {
      downloadFile(content, 'catalogo_meta_facebook_instagram.csv', 'text/csv;charset=utf-8;');
    } else {
      downloadFile(content, 'catalogo_meta_facebook_instagram.xml', 'application/xml;charset=utf-8;');
    }
    toast.success(`Download do feed ${format.toUpperCase()} iniciado!`);
  };

  if (showRaw) {
    return (
      <div className="min-h-screen bg-background text-foreground font-mono text-xs p-4 select-all">
        <div className="fixed top-2 right-2 flex gap-2 z-50">
          <Button size="sm" variant="outline" onClick={() => setShowRaw(false)} className="h-7 text-xs bg-background/90">
            Sair do Modo Puro
          </Button>
          <Button size="sm" onClick={handleDownload} className="h-7 text-xs">
            Baixar {format.toUpperCase()}
          </Button>
        </div>
        <pre className="whitespace-pre-wrap break-all leading-relaxed">
          {content}
        </pre>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-muted/20 p-4 md:p-8 font-sans">
      <div className="max-w-5xl mx-auto space-y-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-border pb-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Link to="/pdv/marketing" className="text-muted-foreground hover:text-foreground text-xs flex items-center gap-1 transition-colors">
                <ArrowLeft className="h-3.5 w-3.5" /> Voltar ao Painel
              </Link>
              <Badge variant="outline" className="bg-primary/10 text-primary border-primary/30 text-xs">
                Meta Commerce Manager
              </Badge>
            </div>
            <h1 className="text-xl md:text-2xl font-bold tracking-tight text-foreground flex items-center gap-2">
              <Rss className="h-5 w-5 text-primary" />
              Feed Dinâmico de Produtos (Facebook & Instagram Shopping)
            </h1>
            <p className="text-xs md:text-sm text-muted-foreground">
              URL oficial do feed nos formatos oficiais XML RSS e CSV para sincronização automática no Catálogo da Meta.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <Button
              variant={showRaw ? 'default' : 'outline'}
              size="sm"
              onClick={() => setShowRaw(true)}
              className="text-xs"
            >
              Exibir XML/CSV Puro
            </Button>
            <Button
              variant={format === 'xml' ? 'default' : 'outline'}
              size="sm"
              asChild
            >
              <Link to="/feed/meta?format=xml">Formato XML (Oficial)</Link>
            </Button>
            <Button
              variant={format === 'csv' ? 'default' : 'outline'}
              size="sm"
              asChild
            >
              <Link to="/feed/meta?format=csv">Formato CSV</Link>
            </Button>
          </div>
        </div>

        {/* Stats card */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <Card>
            <CardHeader className="py-3 px-4">
              <CardTitle className="text-xs text-muted-foreground font-medium">Produtos no Feed</CardTitle>
              <p className="text-2xl font-bold text-foreground">{loading ? '...' : productsCount}</p>
            </CardHeader>
          </Card>
          <Card>
            <CardHeader className="py-3 px-4">
              <CardTitle className="text-xs text-muted-foreground font-medium">Status de Sincronização</CardTitle>
              <p className="text-sm font-semibold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                <ShieldCheck className="h-4 w-4" /> Ativo & Dinâmico
              </p>
            </CardHeader>
          </Card>
          <Card>
            <CardHeader className="py-3 px-4">
              <CardTitle className="text-xs text-muted-foreground font-medium">Compatibilidade</CardTitle>
              <p className="text-xs font-semibold text-foreground">
                Instagram Shopping, Facebook Shop & Google Merchant
              </p>
            </CardHeader>
          </Card>
        </div>

        {/* Action bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 bg-card p-3 rounded-lg border border-border">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <span className="font-semibold text-foreground">URL deste Feed:</span>
            <code className="bg-muted px-2 py-0.5 rounded text-[11px] font-mono break-all">
              {window.location.href}
            </code>
          </div>
          <div className="flex items-center gap-2">
            <Button size="sm" variant="outline" onClick={handleCopy} className="gap-1.5 h-8 text-xs">
              {copied ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
              {copied ? 'Copiado!' : 'Copiar Conteúdo'}
            </Button>
            <Button size="sm" onClick={handleDownload} className="gap-1.5 h-8 text-xs bg-primary text-primary-foreground">
              <Download className="h-3.5 w-3.5" />
              Baixar Arquivo {format.toUpperCase()}
            </Button>
          </div>
        </div>

        {/* Code preview */}
        <Card>
          <CardHeader className="py-3 px-4 flex flex-row items-center justify-between border-b border-border">
            <CardTitle className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Pré-visualização do Arquivo ({format.toUpperCase()})
            </CardTitle>
            <span className="text-[11px] text-muted-foreground">
              {loading ? 'Carregando dados...' : `${content.length} caracteres`}
            </span>
          </CardHeader>
          <CardContent className="p-0">
            {loading ? (
              <div className="p-8 text-center text-xs text-muted-foreground">Gerando catálogo em tempo real...</div>
            ) : (
              <pre className="p-4 bg-muted/40 text-[11px] font-mono overflow-x-auto max-h-[500px] leading-relaxed text-foreground/90 whitespace-pre">
                {content}
              </pre>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
