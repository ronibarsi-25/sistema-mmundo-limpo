import { useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Heart, ShoppingCart, Trash2, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { MainLayout } from '@/components/layouts/MainLayout';
import { useAuth } from '@/contexts/AuthContext';
import { useCart } from '@/contexts/CartContext';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import type { WishlistItem } from '@/types/types';
import { useState } from 'react';

export default function WishlistPage() {
  const { user } = useAuth();
  const { addItem } = useCart();
  const navigate = useNavigate();
  const [items, setItems] = useState<WishlistItem[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchWishlist = async () => {
    if (!user) return;
    const { data } = await supabase
      .from('wishlist')
      .select('*, products(*, categories(*))')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });
    setItems(Array.isArray(data) ? data : []);
    setLoading(false);
  };

  useEffect(() => {
    if (!user) { navigate('/login'); return; }
    fetchWishlist();
  }, [user]);

  const removeFromWishlist = async (itemId: string, productName: string) => {
    await supabase.from('wishlist').delete().eq('id', itemId);
    setItems(prev => prev.filter(i => i.id !== itemId));
    toast.success(`${productName} removido da lista de desejos`);
  };

  const moveToCart = async (item: WishlistItem) => {
    if (!item.products) return;
    addItem(item.products as any);
    await supabase.from('wishlist').delete().eq('id', item.id);
    setItems(prev => prev.filter(i => i.id !== item.id));
  };

  if (!user) return null;

  return (
    <MainLayout>
      <div className="container py-6 md:py-10 max-w-4xl">
        <div className="flex items-center gap-3 mb-6">
          <Heart className="h-6 w-6 text-destructive" fill="currentColor" />
          <h1 className="text-2xl font-bold">Lista de Desejos</h1>
          {items.length > 0 && <Badge variant="secondary">{items.length} {items.length === 1 ? 'item' : 'itens'}</Badge>}
        </div>

        {loading ? (
          <div className="space-y-3">
            {[...Array(3)].map((_, i) => <Skeleton key={i} className="h-28 w-full bg-muted rounded-xl" />)}
          </div>
        ) : items.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 gap-4 text-center">
            <div className="h-16 w-16 rounded-full bg-muted flex items-center justify-center">
              <Heart className="h-8 w-8 text-muted-foreground/40" />
            </div>
            <p className="text-lg font-medium">Sua lista de desejos está vazia</p>
            <p className="text-muted-foreground text-sm">Adicione produtos que você gostaria de comprar futuramente</p>
            <Button onClick={() => navigate('/produtos')} className="bg-accent text-accent-foreground hover:bg-accent/90 mt-2">
              Explorar Produtos <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        ) : (
          <div className="space-y-3">
            {items.map(item => {
              const product = item.products as any;
              if (!product) return null;
              const imageUrl = product.images?.[0]?.url;
              return (
                <div key={item.id} className="flex items-center gap-4 p-4 bg-card rounded-xl border border-border">
                  <Link to={`/produto/${product.slug}`} className="h-20 w-20 rounded-lg overflow-hidden bg-muted shrink-0">
                    {imageUrl ? (
                      <img src={imageUrl} alt={product.name} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center"><ShoppingCart className="h-8 w-8 text-muted-foreground/30" /></div>
                    )}
                  </Link>
                  <div className="flex-1 min-w-0">
                    <Link to={`/produto/${product.slug}`}>
                      <p className="text-sm font-medium text-card-foreground line-clamp-2 hover:text-accent transition-colors">{product.name}</p>
                    </Link>
                    <p className="text-xs text-muted-foreground mt-0.5">{product.categories?.name}</p>
                    <p className="text-base font-bold text-card-foreground mt-1">
                      {product.price.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                    </p>
                  </div>
                  <div className="flex flex-col gap-2 shrink-0">
                    <Button size="sm" className="bg-accent text-accent-foreground hover:bg-accent/90 h-8 text-xs"
                      onClick={() => moveToCart(item)} disabled={!product.is_available}>
                      <ShoppingCart className="h-3.5 w-3.5 mr-1" />
                      {product.is_available ? 'Mover ao Carrinho' : 'Indisponível'}
                    </Button>
                    <Button size="sm" variant="outline" className="h-8 text-xs text-destructive border-destructive/30 hover:bg-destructive/5"
                      onClick={() => removeFromWishlist(item.id, product.name)}>
                      <Trash2 className="h-3.5 w-3.5 mr-1" /> Remover
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </MainLayout>
  );
}
