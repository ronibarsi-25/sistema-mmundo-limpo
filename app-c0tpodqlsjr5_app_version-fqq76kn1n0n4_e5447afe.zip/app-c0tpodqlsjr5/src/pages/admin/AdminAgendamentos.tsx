import { useEffect, useState } from 'react';
import { Plus, Pencil, Trash2, Search, Calendar, ChevronLeft, ChevronRight, Loader2, Settings } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { AdminLayout } from '@/components/layouts/AdminLayout';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';

interface BookableResource { id: string; name: string; description: string | null; color: string; is_active: boolean; }
interface Appointment {
  id: string; resource_id: string | null; customer_name: string; customer_phone: string | null;
  customer_email: string | null; title: string; description: string | null;
  starts_at: string; ends_at: string; status: 'pending' | 'confirmed' | 'cancelled' | 'completed'; notes: string | null;
  bookable_resources?: { name: string; color: string } | null;
}

const STATUS_MAP: Record<string, { label: string; cls: string }> = {
  pending: { label: 'Pendente', cls: 'bg-warning/15 text-warning border-0' },
  confirmed: { label: 'Confirmado', cls: 'bg-success/15 text-success border-0' },
  cancelled: { label: 'Cancelado', cls: 'bg-destructive/15 text-destructive border-0' },
  completed: { label: 'Concluído', cls: 'bg-primary/15 text-primary border-0' },
};

type ApptStatus = 'pending' | 'confirmed' | 'cancelled' | 'completed';

const emptyAppt = {
  resource_id: 'none', customer_name: '', customer_phone: '', customer_email: '',
  title: '', description: '', starts_at: '', ends_at: '', status: 'pending' as ApptStatus, notes: '',
};

const emptyResource = { name: '', description: '', color: '#0A5C5A', is_active: true };

const WEEK_DAYS = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];

function getWeekDates(base: Date): Date[] {
  const start = new Date(base);
  start.setDate(base.getDate() - base.getDay());
  return Array.from({ length: 7 }, (_, i) => { const d = new Date(start); d.setDate(start.getDate() + i); return d; });
}

export default function AdminAgendamentos() {
  const [resources, setResources] = useState<BookableResource[]>([]);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [tab, setTab] = useState('list');

  // Appointment dialog
  const [showApptDialog, setShowApptDialog] = useState(false);
  const [editingAppt, setEditingAppt] = useState<Appointment | null>(null);
  const [apptForm, setApptForm] = useState(emptyAppt);
  const [submitting, setSubmitting] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  // Resource dialog
  const [showResDialog, setShowResDialog] = useState(false);
  const [editingRes, setEditingRes] = useState<BookableResource | null>(null);
  const [resForm, setResForm] = useState(emptyResource);

  // Calendar
  const [weekBase, setWeekBase] = useState(new Date());
  const weekDates = getWeekDates(weekBase);

  useEffect(() => { loadAll(); }, []);

  const loadAll = async () => {
    setLoading(true);
    const [apptRes, resRes] = await Promise.all([
      supabase.from('appointments').select('*, bookable_resources(name,color)').order('starts_at', { ascending: false }).limit(200),
      supabase.from('bookable_resources').select('*').order('name'),
    ]);
    setAppointments((apptRes.data as Appointment[]) || []);
    setResources((resRes.data as BookableResource[]) || []);
    setLoading(false);
  };

  const af = (key: string, val: unknown) => setApptForm(p => ({ ...p, [key]: val }));
  const rf = (key: string, val: unknown) => setResForm(p => ({ ...p, [key]: val }));

  const openCreateAppt = () => {
    setEditingAppt(null);
    const now = new Date();
    const start = new Date(now.getTime() + 60 * 60000);
    const end = new Date(start.getTime() + 60 * 60000);
    setApptForm({ ...emptyAppt, starts_at: toLocal(start), ends_at: toLocal(end) });
    setShowApptDialog(true);
  };
  const openEditAppt = (a: Appointment) => {
    setEditingAppt(a);
    setApptForm({
      resource_id: a.resource_id || 'none', customer_name: a.customer_name, customer_phone: a.customer_phone || '',
      customer_email: a.customer_email || '', title: a.title, description: a.description || '',
      starts_at: toLocal(new Date(a.starts_at)), ends_at: toLocal(new Date(a.ends_at)),
      status: a.status, notes: a.notes || '',
    });
    setShowApptDialog(true);
  };

  const toLocal = (d: Date) => {
    const pad = (n: number) => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
  };

  const handleSaveAppt = async () => {
    if (!apptForm.customer_name.trim() || !apptForm.title.trim() || !apptForm.starts_at || !apptForm.ends_at) {
      toast.error('Preencha cliente, título, início e fim'); return;
    }
    if (new Date(apptForm.ends_at) <= new Date(apptForm.starts_at)) {
      toast.error('Horário de fim deve ser após o início'); return;
    }
    setSubmitting(true);
    const payload = {
      resource_id: apptForm.resource_id === 'none' ? null : apptForm.resource_id,
      customer_name: apptForm.customer_name.trim(), customer_phone: apptForm.customer_phone || null,
      customer_email: apptForm.customer_email || null, title: apptForm.title.trim(),
      description: apptForm.description || null,
      starts_at: new Date(apptForm.starts_at).toISOString(), ends_at: new Date(apptForm.ends_at).toISOString(),
      status: apptForm.status, notes: apptForm.notes || null,
    };
    const q = editingAppt
      ? supabase.from('appointments').update({ ...payload, updated_at: new Date().toISOString() }).eq('id', editingAppt.id)
      : supabase.from('appointments').insert(payload);
    const { error } = await q;
    setSubmitting(false);
    if (error) { toast.error('Erro ao salvar: ' + error.message); return; }
    toast.success(editingAppt ? 'Agendamento atualizado!' : 'Agendamento criado!');
    setShowApptDialog(false);
    loadAll();
  };

  const handleDeleteAppt = async () => {
    if (!deleteId) return;
    const { error } = await supabase.from('appointments').delete().eq('id', deleteId);
    if (error) toast.error('Erro ao excluir');
    else { toast.success('Agendamento excluído'); loadAll(); }
    setDeleteId(null);
  };

  const handleSaveRes = async () => {
    if (!resForm.name.trim()) { toast.error('Informe o nome do recurso'); return; }
    const payload = { name: resForm.name.trim(), description: resForm.description || null, color: resForm.color, is_active: resForm.is_active };
    const q = editingRes
      ? supabase.from('bookable_resources').update({ ...payload, updated_at: new Date().toISOString() }).eq('id', editingRes.id)
      : supabase.from('bookable_resources').insert(payload);
    const { error } = await q;
    if (error) { toast.error('Erro: ' + error.message); return; }
    toast.success(editingRes ? 'Recurso atualizado!' : 'Recurso criado!');
    setShowResDialog(false);
    loadAll();
  };

  const filtered = appointments.filter(a => {
    const q = search.toLowerCase();
    return (statusFilter === 'all' || a.status === statusFilter) &&
      (!q || a.customer_name.toLowerCase().includes(q) || a.title.toLowerCase().includes(q));
  });

  // Calendar: appointments in the current week
  const calAppts = (day: Date) => {
    const dayStr = day.toISOString().split('T')[0];
    return appointments.filter(a => a.starts_at.startsWith(dayStr) && a.status !== 'cancelled');
  };
  const isToday = (d: Date) => d.toISOString().split('T')[0] === new Date().toISOString().split('T')[0];

  return (
    <AdminLayout title="Reservas e Agendamentos" subtitle="Gestão de recursos e agenda"
      breadcrumbs={[{ label: 'Admin', path: '/admin' }, { label: 'Agendamentos' }]}>

      <Tabs value={tab} onValueChange={setTab}>
        <div className="flex flex-col md:flex-row md:items-center gap-3 mb-5">
          <TabsList>
            <TabsTrigger value="list">Lista</TabsTrigger>
            <TabsTrigger value="calendar">Calendário</TabsTrigger>
            <TabsTrigger value="resources">Recursos</TabsTrigger>
          </TabsList>
          <div className="flex-1" />
          <Button size="sm" onClick={openCreateAppt}>
            <Plus className="h-4 w-4 mr-1.5" /> Novo Agendamento
          </Button>
        </div>

        {/* LIST */}
        <TabsContent value="list">
          <div className="flex flex-col md:flex-row gap-3 mb-4">
            <div className="relative flex-1 min-w-0">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Buscar por cliente ou título..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full md:w-40 shrink-0"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos</SelectItem>
                {Object.entries(STATUS_MAP).map(([v, { label }]) => <SelectItem key={v} value={v}>{label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="bg-card border border-border rounded-xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm min-w-max">
                <thead>
                  <tr className="border-b border-border bg-muted/40">
                    {['Título / Cliente', 'Recurso', 'Início', 'Fim', 'Status', 'Ações'].map(h => (
                      <th key={h} className="text-left px-4 py-3 font-semibold text-muted-foreground uppercase text-[11px] tracking-wide whitespace-nowrap">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {loading ? Array.from({ length: 5 }).map((_, i) => (
                    <tr key={i}><td colSpan={6} className="px-4 py-3"><Skeleton className="h-5 w-full bg-muted" /></td></tr>
                  )) : filtered.length === 0 ? (
                    <tr><td colSpan={6} className="text-center py-12 text-muted-foreground">
                      <Calendar className="h-8 w-8 mx-auto mb-2 opacity-30" />
                      <p>Nenhum agendamento encontrado</p>
                    </td></tr>
                  ) : filtered.map(a => {
                    const s = STATUS_MAP[a.status] || STATUS_MAP.pending;
                    return (
                      <tr key={a.id} className="hover:bg-muted/30 transition-colors">
                        <td className="px-4 py-3 whitespace-nowrap">
                          <p className="font-medium">{a.title}</p>
                          <p className="text-xs text-muted-foreground">{a.customer_name}</p>
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          {a.bookable_resources ? (
                            <span className="inline-flex items-center gap-1.5 text-xs font-medium px-2 py-0.5 rounded-full border"
                              style={{ borderColor: a.bookable_resources.color + '40', color: a.bookable_resources.color, background: a.bookable_resources.color + '18' }}>
                              <span className="h-1.5 w-1.5 rounded-full" style={{ background: a.bookable_resources.color }} />
                              {a.bookable_resources.name}
                            </span>
                          ) : <span className="text-muted-foreground">—</span>}
                        </td>
                        <td className="px-4 py-3 text-xs font-mono whitespace-nowrap">{new Date(a.starts_at).toLocaleString('pt-BR')}</td>
                        <td className="px-4 py-3 text-xs font-mono whitespace-nowrap">{new Date(a.ends_at).toLocaleString('pt-BR')}</td>
                        <td className="px-4 py-3 whitespace-nowrap"><Badge className={s.cls}>{s.label}</Badge></td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <div className="flex items-center gap-1.5 justify-end">
                            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEditAppt(a)}>
                              <Pencil className="h-3.5 w-3.5" />
                            </Button>
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive" onClick={() => setDeleteId(a.id)}>
                              <Trash2 className="h-3.5 w-3.5" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </TabsContent>

        {/* CALENDAR */}
        <TabsContent value="calendar">
          <div className="flex items-center justify-between mb-4">
            <Button variant="outline" size="icon" onClick={() => { const d = new Date(weekBase); d.setDate(d.getDate()-7); setWeekBase(d); }}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <p className="text-sm font-semibold">
              {weekDates[0].toLocaleDateString('pt-BR', { day:'2-digit', month:'short' })} — {weekDates[6].toLocaleDateString('pt-BR', { day:'2-digit', month:'short', year:'numeric' })}
            </p>
            <Button variant="outline" size="icon" onClick={() => { const d = new Date(weekBase); d.setDate(d.getDate()+7); setWeekBase(d); }}>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
          <div className="grid grid-cols-7 gap-2">
            {weekDates.map((day, i) => {
              const dayAppts = calAppts(day);
              return (
                <div key={i} className={`bg-card border rounded-xl p-2 min-h-[120px] ${isToday(day) ? 'border-primary' : 'border-border'}`}>
                  <p className={`text-[11px] font-bold uppercase mb-2 ${isToday(day) ? 'text-primary' : 'text-muted-foreground'}`}>
                    {WEEK_DAYS[i]}<br />
                    <span className={`text-base ${isToday(day) ? 'text-primary' : 'text-foreground'}`}>{day.getDate()}</span>
                  </p>
                  <div className="space-y-1">
                    {dayAppts.slice(0, 3).map(a => (
                      <div key={a.id} onClick={() => openEditAppt(a)} className="cursor-pointer rounded px-1.5 py-1 text-[10px] font-medium truncate"
                        style={{ background: (a.bookable_resources?.color || '#0A5C5A') + '22', color: a.bookable_resources?.color || '#0A5C5A', border: `1px solid ${(a.bookable_resources?.color || '#0A5C5A')}40` }}>
                        {new Date(a.starts_at).toLocaleTimeString('pt-BR', { hour:'2-digit', minute:'2-digit' })} {a.title}
                      </div>
                    ))}
                    {dayAppts.length > 3 && <p className="text-[10px] text-muted-foreground">+{dayAppts.length - 3} mais</p>}
                  </div>
                </div>
              );
            })}
          </div>
        </TabsContent>

        {/* RESOURCES */}
        <TabsContent value="resources">
          <div className="flex justify-end mb-4">
            <Button size="sm" onClick={() => { setEditingRes(null); setResForm(emptyResource); setShowResDialog(true); }}>
              <Plus className="h-4 w-4 mr-1.5" /> Novo Recurso
            </Button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {loading ? Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-24 bg-muted rounded-xl" />) :
              resources.length === 0 ? (
                <div className="col-span-3 text-center py-12 text-muted-foreground">
                  <Settings className="h-8 w-8 mx-auto mb-2 opacity-30" />
                  <p>Nenhum recurso cadastrado</p>
                </div>
              ) : resources.map(r => (
                <div key={r.id} className="bg-card border border-border rounded-xl p-4 flex items-start gap-3">
                  <div className="h-10 w-10 rounded-lg shrink-0 mt-0.5" style={{ background: r.color + '25', border: `2px solid ${r.color}50` }}>
                    <span className="flex h-full items-center justify-center text-[10px] font-black" style={{ color: r.color }}>{r.name.slice(0,2).toUpperCase()}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-sm truncate">{r.name}</p>
                    {r.description && <p className="text-xs text-muted-foreground truncate">{r.description}</p>}
                    <Badge variant={r.is_active ? 'default' : 'secondary'} className="mt-1 text-[10px]">{r.is_active ? 'Ativo' : 'Inativo'}</Badge>
                  </div>
                  <Button variant="ghost" size="icon" className="h-8 w-8 shrink-0" onClick={() => { setEditingRes(r); setResForm({ name: r.name, description: r.description || '', color: r.color, is_active: r.is_active }); setShowResDialog(true); }}>
                    <Pencil className="h-3.5 w-3.5" />
                  </Button>
                </div>
              ))
            }
          </div>
        </TabsContent>
      </Tabs>

      {/* Appointment Dialog */}
      <Dialog open={showApptDialog} onOpenChange={setShowApptDialog}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl max-h-[90dvh] overflow-y-auto">
          <DialogHeader><DialogTitle>{editingAppt ? 'Editar Agendamento' : 'Novo Agendamento'}</DialogTitle></DialogHeader>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-2">
            <div className="space-y-1.5 md:col-span-2">
              <Label className="text-sm font-normal">Título *</Label>
              <Input value={apptForm.title} onChange={e => af('title', e.target.value)} placeholder="Ex: Consulta, Reunião, Manutenção..." />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Cliente *</Label>
              <Input value={apptForm.customer_name} onChange={e => af('customer_name', e.target.value)} placeholder="Nome do cliente" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Telefone</Label>
              <Input value={apptForm.customer_phone} onChange={e => af('customer_phone', e.target.value)} placeholder="(00) 00000-0000" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">E-mail</Label>
              <Input type="email" value={apptForm.customer_email} onChange={e => af('customer_email', e.target.value)} placeholder="cliente@email.com" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Recurso</Label>
              <Select value={apptForm.resource_id} onValueChange={v => af('resource_id', v)}>
                <SelectTrigger><SelectValue placeholder="Selecionar" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Sem recurso específico</SelectItem>
                  {resources.filter(r => r.is_active).map(r => <SelectItem key={r.id} value={r.id}>{r.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Início *</Label>
              <Input type="datetime-local" value={apptForm.starts_at} onChange={e => af('starts_at', e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Fim *</Label>
              <Input type="datetime-local" value={apptForm.ends_at} onChange={e => af('ends_at', e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Status</Label>
              <Select value={apptForm.status} onValueChange={v => af('status', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{Object.entries(STATUS_MAP).map(([v, { label }]) => <SelectItem key={v} value={v}>{label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5 md:col-span-2">
              <Label className="text-sm font-normal">Observações</Label>
              <Input value={apptForm.notes} onChange={e => af('notes', e.target.value)} placeholder="Notas adicionais" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowApptDialog(false)}>Cancelar</Button>
            <Button onClick={handleSaveAppt} disabled={submitting}>
              {submitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              {editingAppt ? 'Salvar' : 'Criar Agendamento'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Resource Dialog */}
      <Dialog open={showResDialog} onOpenChange={setShowResDialog}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <DialogHeader><DialogTitle>{editingRes ? 'Editar Recurso' : 'Novo Recurso'}</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Nome *</Label>
              <Input value={resForm.name} onChange={e => rf('name', e.target.value)} placeholder="Ex: Sala A, Equipamento 1, Dr. João..." />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Descrição</Label>
              <Input value={resForm.description} onChange={e => rf('description', e.target.value)} placeholder="Descrição opcional" />
            </div>
            <div className="flex items-center gap-4">
              <div className="space-y-1.5 flex-1">
                <Label className="text-sm font-normal">Cor</Label>
                <Input type="color" value={resForm.color} onChange={e => rf('color', e.target.value)} className="h-9 cursor-pointer" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">Status</Label>
                <Select value={resForm.is_active ? 'active' : 'inactive'} onValueChange={v => rf('is_active', v === 'active')}>
                  <SelectTrigger className="w-28"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Ativo</SelectItem>
                    <SelectItem value="inactive">Inativo</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowResDialog(false)}>Cancelar</Button>
            <Button onClick={handleSaveRes}>{editingRes ? 'Salvar' : 'Criar Recurso'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete confirm */}
      <AlertDialog open={!!deleteId} onOpenChange={o => !o && setDeleteId(null)}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir Agendamento</AlertDialogTitle>
            <AlertDialogDescription>Esta ação não pode ser desfeita.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteAppt} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">Excluir</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AdminLayout>
  );
}
