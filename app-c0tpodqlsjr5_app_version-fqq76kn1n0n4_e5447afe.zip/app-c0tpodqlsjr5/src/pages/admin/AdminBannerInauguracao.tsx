import { useState, useEffect } from 'react';
import { Save, PartyPopper, Eye, EyeOff, Loader2, MessageCircle, Copy, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { AdminLayout } from '@/components/layouts/AdminLayout';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';

interface BannerForm {
  is_active: boolean;
  store_name: string;
  headline: string;
  subtitle: string;
  coupon_code: string;
  discount_text: string;
  whatsapp_message: string;
  expires_at: string;
}

const DEFAULT: BannerForm = {
  is_active: true,
  store_name: 'Mundo Limpo',
  headline: '🎉 Grande Inauguração Mundo Limpo!',
  subtitle: 'Aproveite nossos preços especiais de lançamento. Produtos de limpeza com qualidade e preço justo!',
  coupon_code: 'INAUGURA15',
  discount_text: '15% OFF em toda a loja',
  whatsapp_message: 'Olá! 🎉 A Mundo Limpo está inaugurando e tem um presente especial para você!\n\nUse o cupom *{coupon}* e ganhe {discount} na sua primeira compra!\n\n✅ Válido até {expiry}\n🛒 Acesse: {url}\n\nNão perca essa oportunidade! 🧹✨',
  expires_at: '',
};

export default function AdminBannerInauguracao() {
  const [form, setForm] = useState<BannerForm>(DEFAULT);
  const [bannerId, setBannerId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [preview, setPreview] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    supabase.from('inauguration_banner').select('*').limit(1).maybeSingle().then(({ data }) => {
      if (data) {
        setBannerId(data.id);
        setForm({
          is_active: data.is_active,
          store_name: data.store_name || '',
          headline: data.headline || '',
          subtitle: data.subtitle || '',
          coupon_code: data.coupon_code || '',
          discount_text: data.discount_text || '',
          whatsapp_message: data.whatsapp_message || '',
          expires_at: data.expires_at
            ? new Date(data.expires_at).toISOString().split('T')[0]
            : '',
        });
      }
      setLoading(false);
    });
  }, []);

  const set = (field: keyof BannerForm, value: string | boolean) =>
    setForm(f => ({ ...f, [field]: value }));

  const handleSave = async () => {
    if (!form.coupon_code.trim()) { toast.error('Informe o código do cupom'); return; }
    if (!form.discount_text.trim()) { toast.error('Informe o valor do desconto'); return; }
    setSaving(true);

    const payload = {
      is_active: form.is_active,
      store_name: form.store_name.trim(),
      headline: form.headline.trim(),
      subtitle: form.subtitle.trim(),
      coupon_code: form.coupon_code.trim().toUpperCase(),
      discount_text: form.discount_text.trim(),
      whatsapp_message: form.whatsapp_message.trim(),
      expires_at: form.expires_at ? new Date(form.expires_at + 'T23:59:59').toISOString() : null,
      updated_at: new Date().toISOString(),
    };

    let error;
    if (bannerId) {
      ({ error } = await supabase.from('inauguration_banner').update(payload).eq('id', bannerId));
    } else {
      const { data, error: err } = await supabase.from('inauguration_banner').insert(payload).select().maybeSingle();
      error = err;
      if (data) setBannerId(data.id);
    }

    setSaving(false);
    if (error) { toast.error('Erro ao salvar: ' + error.message); return; }
    toast.success('Banner salvo com sucesso!');
    set('coupon_code', form.coupon_code.trim().toUpperCase());
  };

  const handleCopyPreview = async () => {
    const expiryStr = form.expires_at
      ? new Date(form.expires_at).toLocaleDateString('pt-BR')
      : 'em breve';
    const msg = form.whatsapp_message
      .replace('{coupon}', form.coupon_code)
      .replace('{discount}', form.discount_text)
      .replace('{expiry}', expiryStr)
      .replace('{url}', window.location.origin);
    await navigator.clipboard.writeText(msg);
    setCopied(true);
    toast.success('Mensagem copiada!');
    setTimeout(() => setCopied(false), 3000);
  };

  const whatsappPreview = () => {
    const expiryStr = form.expires_at
      ? new Date(form.expires_at).toLocaleDateString('pt-BR')
      : 'em breve';
    return form.whatsapp_message
      .replace('{coupon}', form.coupon_code || 'CUPOM')
      .replace('{discount}', form.discount_text || 'desconto')
      .replace('{expiry}', expiryStr)
      .replace('{url}', window.location.origin);
  };

  if (loading) {
    return (
      <AdminLayout title="Banner de Inauguração">
        <div className="flex items-center justify-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout title="Banner de Inauguração">
      <div className="max-w-4xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center">
              <PartyPopper className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-foreground text-balance">Banner de Inauguração</h1>
              <p className="text-sm text-muted-foreground">Configure o banner com cupom de desconto para o site e WhatsApp</p>
            </div>
          </div>
          <div className="flex items-center gap-3 shrink-0">
            <div className="flex items-center gap-2">
              <Switch
                checked={form.is_active}
                onCheckedChange={v => set('is_active', v)}
                id="is_active"
              />
              <Label htmlFor="is_active" className="text-sm cursor-pointer">
                {form.is_active
                  ? <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200 dark:bg-emerald-900/30 dark:text-emerald-400">Ativo</Badge>
                  : <Badge variant="secondary">Inativo</Badge>}
              </Label>
            </div>
            <Button onClick={handleSave} disabled={saving} className="gap-2 h-9">
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              Salvar
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Conteúdo do Banner */}
          <Card className="h-full">
            <CardHeader className="pb-3">
              <CardTitle className="text-base text-balance">Conteúdo do Banner</CardTitle>
              <CardDescription>Textos exibidos no banner do site</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">Nome da Loja</Label>
                <Input value={form.store_name} onChange={e => set('store_name', e.target.value)} placeholder="Mundo Limpo" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">Título Principal</Label>
                <Input value={form.headline} onChange={e => set('headline', e.target.value)} placeholder="🎉 Grande Inauguração!" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">Subtítulo</Label>
                <Textarea
                  value={form.subtitle}
                  onChange={e => set('subtitle', e.target.value)}
                  placeholder="Aproveite nossos preços especiais de lançamento!"
                  rows={3}
                  className="resize-none"
                />
              </div>
            </CardContent>
          </Card>

          {/* Cupom de Desconto */}
          <Card className="h-full">
            <CardHeader className="pb-3">
              <CardTitle className="text-base text-balance">Cupom de Desconto</CardTitle>
              <CardDescription>Código e validade do cupom</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">Código do Cupom</Label>
                <Input
                  value={form.coupon_code}
                  onChange={e => set('coupon_code', e.target.value.toUpperCase())}
                  placeholder="INAUGURA15"
                  className="font-mono font-bold tracking-wider"
                  maxLength={20}
                />
                <p className="text-xs text-muted-foreground">Letras maiúsculas e números. Será usado no checkout.</p>
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">Texto do Desconto</Label>
                <Input
                  value={form.discount_text}
                  onChange={e => set('discount_text', e.target.value)}
                  placeholder="15% OFF em toda a loja"
                />
                <p className="text-xs text-muted-foreground">Ex: 10% OFF, R$ 20 OFF, Frete Grátis</p>
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">Validade do Cupom</Label>
                <Input
                  type="date"
                  value={form.expires_at}
                  onChange={e => set('expires_at', e.target.value)}
                  min={new Date().toISOString().split('T')[0]}
                />
                <p className="text-xs text-muted-foreground">O banner some automaticamente após essa data</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Mensagem WhatsApp */}
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between gap-4">
              <div>
                <CardTitle className="text-base flex items-center gap-2 text-balance">
                  <MessageCircle className="h-4 w-4 text-[#25D366]" />
                  Mensagem para WhatsApp
                </CardTitle>
                <CardDescription>Texto enviado ao clicar em "Compartilhar no WhatsApp"</CardDescription>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setPreview(v => !v)}
                className="shrink-0 gap-1.5 h-8 text-xs"
              >
                {preview ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                {preview ? 'Editar' : 'Visualizar'}
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {preview ? (
              <div className="space-y-3">
                <div className="bg-[#e7fbe6] dark:bg-[#1a3320] border border-[#25D366]/30 rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-3">
                    <div className="h-8 w-8 rounded-full bg-[#25D366] flex items-center justify-center">
                      <MessageCircle className="h-4 w-4 text-white" />
                    </div>
                    <div>
                      <p className="text-xs font-semibold text-foreground">{form.store_name || 'Mundo Limpo'}</p>
                      <p className="text-[10px] text-muted-foreground">Prévia da mensagem</p>
                    </div>
                  </div>
                  <p className="text-sm text-foreground whitespace-pre-line leading-relaxed">
                    {whatsappPreview()}
                  </p>
                </div>
                <Button variant="outline" size="sm" onClick={handleCopyPreview} className="gap-1.5 h-8 text-xs">
                  {copied ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
                  {copied ? 'Copiado!' : 'Copiar Mensagem'}
                </Button>
              </div>
            ) : (
              <div className="space-y-2">
                <Textarea
                  value={form.whatsapp_message}
                  onChange={e => set('whatsapp_message', e.target.value)}
                  rows={6}
                  className="resize-none font-mono text-sm"
                  placeholder="Olá! Use o cupom {coupon} e ganhe {discount}. Válido até {expiry}. Acesse: {url}"
                />
                <div className="flex flex-wrap gap-2">
                  {['{coupon}', '{discount}', '{expiry}', '{url}'].map(v => (
                    <Badge
                      key={v}
                      variant="secondary"
                      className="text-xs cursor-pointer hover:bg-muted font-mono"
                      onClick={() => set('whatsapp_message', form.whatsapp_message + v)}
                    >
                      {v}
                    </Badge>
                  ))}
                </div>
                <p className="text-xs text-muted-foreground">
                  Use as variáveis acima para inserir dados dinâmicos na mensagem
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Preview do Banner */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base text-balance">Pré-visualização do Banner</CardTitle>
            <CardDescription>Como o banner aparece no site para os clientes</CardDescription>
          </CardHeader>
          <CardContent className="p-0 overflow-hidden rounded-b-lg">
            <div className="bg-gradient-to-br from-emerald-600 via-green-700 to-teal-800 text-white p-5">
              <div className="flex flex-col md:flex-row items-center gap-4 md:gap-6">
                <div className="hidden md:flex h-16 w-16 rounded-2xl bg-white/15 items-center justify-center shrink-0">
                  <PartyPopper className="h-8 w-8 text-yellow-300" />
                </div>
                <div className="flex-1 min-w-0 text-center md:text-left">
                  <div className="flex items-center justify-center md:justify-start gap-2">
                    <PartyPopper className="h-4 w-4 text-yellow-300 md:hidden" />
                    <h3 className="text-base md:text-lg font-bold text-white text-balance">
                      {form.headline || '🎉 Grande Inauguração!'}
                    </h3>
                  </div>
                  {form.subtitle && (
                    <p className="text-xs md:text-sm text-white/80 mt-1 text-pretty">{form.subtitle}</p>
                  )}
                  {form.expires_at && (
                    <p className="text-[10px] text-white/60 mt-1">
                      ⏰ Válido até {new Date(form.expires_at).toLocaleDateString('pt-BR')}
                    </p>
                  )}
                </div>
                <div className="shrink-0 w-full md:w-auto">
                  <div className="bg-white/15 border border-dashed border-white/40 rounded-xl p-3 space-y-2 md:min-w-[220px]">
                    <p className="text-xs font-bold text-yellow-300 text-center">{form.discount_text || 'Desconto Especial'}</p>
                    <div className="bg-white/10 border-2 border-dashed border-white/50 rounded-lg px-3 py-2 text-center">
                      <span className="text-lg font-black tracking-widest text-white font-mono">
                        {form.coupon_code || 'CUPOM'}
                      </span>
                    </div>
                    <div className="flex gap-2">
                      <div className="flex-1 bg-white rounded-lg py-1.5 flex items-center justify-center gap-1">
                        <Copy className="h-3 w-3 text-emerald-700" />
                        <span className="text-[10px] font-semibold text-emerald-700">Copiar</span>
                      </div>
                      <div className="flex-1 bg-[#25D366] rounded-lg py-1.5 flex items-center justify-center gap-1">
                        <MessageCircle className="h-3 w-3 text-white" />
                        <span className="text-[10px] font-semibold text-white">WhatsApp</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Separator />

        <div className="flex justify-end">
          <Button onClick={handleSave} disabled={saving} size="lg" className="gap-2 min-w-[140px]">
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
            Salvar Alterações
          </Button>
        </div>
      </div>
    </AdminLayout>
  );
}
