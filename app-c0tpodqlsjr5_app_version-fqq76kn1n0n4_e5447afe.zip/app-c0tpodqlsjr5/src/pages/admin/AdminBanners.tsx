import { useState, useEffect, useCallback } from 'react';
import {
  Plus, Pencil, Trash2, Eye, EyeOff, Loader2,
  Image as ImageIcon, ExternalLink, ChevronUp, ChevronDown,
  AlertCircle, ArrowUpCircle, GripVertical
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter
} from '@/components/ui/dialog';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel,
  AlertDialogContent, AlertDialogDescription, AlertDialogFooter,
  AlertDialogHeader, AlertDialogTitle
} from '@/components/ui/alert-dialog';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { AdminLayout } from '@/components/layouts/AdminLayout';
import { ImageUploader } from '@/components/admin/ImageUploader';
import { useStore } from '@/contexts/StoreContext';
import { PLAN_LIMITS } from '@/types/types';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import { useForm } from 'react-hook-form';
import type { Banner } from '@/types/types';

interface BannerForm {
  title: string;
  subtitle: string;
  image_url: string;
  cta_text: string;
  cta_link: string;
  is_active: boolean;
}

export default function AdminBanners() {
  const [banners, setBanners] = useState<Banner[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [editingBanner, setEditingBanner] = useState<Banner | null>(null);
  const [saving, setSaving] = useState(false);
  const { subscription } = useStore();
  const maxBanners = PLAN_LIMITS[subscription?.plan_level || 'prata'].maxBanners;

  const form = useForm<BannerForm>({
    defaultValues: { title: '', subtitle: '', image_url: '', cta_text: 'Ver mais', cta_link: '/', is_active: true }
  });

  const fetchBanners = useCallback(async () => {
    const { data } = await supabase.from('banners').select('*').order('sort_order', { ascending: true });
    setBanners(Array.isArray(data) ? data as Banner[] : []);
    setLoading(false);
  }, []);

  useEffect(() => { fetchBanners(); }, [fetchBanners]);

  const openCreate = () => {
    if (banners.length >= maxBanners) {
      toast.error(`Limite de ${maxBanners} banners atingido no plano atual. Faça upgrade para adicionar mais.`);
      return;
    }
    setEditingBanner(null);
    form.reset({ title: '', subtitle: '', image_url: '', cta_text: 'Ver mais', cta_link: '/', is_active: true });
    setDialogOpen(true);
  };

  const openEdit = (banner: Banner) => {
    setEditingBanner(banner);
    form.reset({
      title: banner.title, subtitle: banner.subtitle || '', image_url: banner.image_url,
      cta_text: banner.cta_text, cta_link: banner.cta_link, is_active: banner.is_active
    });
    setDialogOpen(true);
  };

  const onSubmit = async (data: BannerForm) => {
    setSaving(true);
    const payload = { ...data, updated_at: new Date().toISOString() };
    let error;
    if (editingBanner) {
      ({ error } = await supabase.from('banners').update(payload).eq('id', editingBanner.id));
    } else {
      const maxOrder = banners.length ? Math.max(...banners.map(b => b.sort_order)) + 1 : 0;
      ({ error } = await supabase.from('banners').insert({ ...payload, sort_order: maxOrder }));
    }
    if (error) { toast.error('Erro ao salvar banner'); setSaving(false); return; }
    toast.success(editingBanner ? 'Banner atualizado!' : 'Banner criado!');
    setDialogOpen(false);
    setSaving(false);
    fetchBanners();
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    const { error } = await supabase.from('banners').delete().eq('id', deleteId);
    if (error) { toast.error('Erro ao excluir banner'); }
    else { toast.success('Banner excluído!'); fetchBanners(); }
    setDeleteId(null);
  };

  const toggleActive = async (banner: Banner) => {
    await supabase.from('banners').update({ is_active: !banner.is_active }).eq('id', banner.id);
    fetchBanners();
  };

  const moveOrder = async (banner: Banner, direction: 'up' | 'down') => {
    const sorted = [...banners].sort((a, b) => a.sort_order - b.sort_order);
    const idx = sorted.findIndex(b => b.id === banner.id);
    const swapIdx = direction === 'up' ? idx - 1 : idx + 1;
    if (swapIdx < 0 || swapIdx >= sorted.length) return;
    const swapBanner = sorted[swapIdx];
    await Promise.all([
      supabase.from('banners').update({ sort_order: swapBanner.sort_order }).eq('id', banner.id),
      supabase.from('banners').update({ sort_order: banner.sort_order }).eq('id', swapBanner.id),
    ]);
    fetchBanners();
  };



  return (
    <AdminLayout title="Banners">
      <div className="space-y-5">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <p className="text-sm text-muted-foreground">Gerencie os banners exibidos no carrossel da página inicial.</p>
            <p className="text-xs text-muted-foreground mt-0.5">
              {banners.length} / {maxBanners} banners usados no seu plano
            </p>
          </div>
          <div className="flex items-center gap-2">
            {banners.length >= maxBanners && (
              <div className="flex items-center gap-1.5 text-xs text-amber-600 bg-amber-50 border border-amber-200 rounded-md px-2.5 py-1.5">
                <ArrowUpCircle className="h-3.5 w-3.5 shrink-0" />
                <span>Limite atingido — faça upgrade do plano</span>
              </div>
            )}
            <Button onClick={openCreate} disabled={banners.length >= maxBanners}
              className="bg-primary text-primary-foreground hover:bg-primary/90 h-9 shrink-0">
              <Plus className="h-4 w-4 mr-2" /> Novo Banner
            </Button>
          </div>
        </div>

        {/* Alerta de limite */}
        {banners.length >= maxBanners && (
          <div className="flex items-start gap-3 p-3 bg-amber-50 border border-amber-200 rounded-lg">
            <AlertCircle className="h-4 w-4 text-amber-600 shrink-0 mt-0.5" />
            <div className="text-sm text-amber-800">
              <p className="font-semibold">Limite de banners atingido ({banners.length}/{maxBanners})</p>
              <p className="text-xs mt-0.5">Seu plano atual permite até {maxBanners} banner{maxBanners > 1 ? 's' : ''}. Vá em <strong>Assinatura</strong> para mudar de plano e adicionar mais.</p>
            </div>
          </div>
        )}

        {/* Lista */}
        {loading ? (
          <div className="flex items-center justify-center py-16"><Loader2 className="h-7 w-7 animate-spin text-muted-foreground" /></div>
        ) : banners.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 gap-3 text-center border border-dashed rounded-xl">
            <ImageIcon className="h-10 w-10 text-muted-foreground/40" />
            <p className="text-sm text-muted-foreground">Nenhum banner cadastrado. Crie o primeiro!</p>
          </div>
        ) : (
          <div className="space-y-3">
            {[...banners].sort((a, b) => a.sort_order - b.sort_order).map((banner, idx, arr) => (
              <div key={banner.id} className="bg-card border border-border rounded-xl overflow-hidden">
                <div className="flex items-center gap-3 p-3">
                  {/* Ordem */}
                  <div className="flex flex-col gap-0.5 shrink-0">
                    <button onClick={() => moveOrder(banner, 'up')} disabled={idx === 0}
                      className="p-0.5 text-muted-foreground hover:text-foreground disabled:opacity-30">
                      <ChevronUp className="h-4 w-4" />
                    </button>
                    <GripVertical className="h-4 w-4 text-muted-foreground/40 mx-auto" />
                    <button onClick={() => moveOrder(banner, 'down')} disabled={idx === arr.length - 1}
                      className="p-0.5 text-muted-foreground hover:text-foreground disabled:opacity-30">
                      <ChevronDown className="h-4 w-4" />
                    </button>
                  </div>

                  {/* Imagem */}
                  <div className="w-24 h-14 rounded-lg overflow-hidden shrink-0 bg-muted">
                    <img src={banner.image_url} alt={banner.title} className="w-full h-full object-cover" />
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-sm text-foreground truncate">{banner.title}</p>
                    {banner.subtitle && <p className="text-xs text-muted-foreground truncate">{banner.subtitle}</p>}
                    <div className="flex items-center gap-2 mt-1">
                      <Badge variant="outline" className="text-xs h-5">{banner.cta_text}</Badge>
                      <a href={banner.cta_link} target="_blank" rel="noreferrer"
                        className="text-xs text-muted-foreground hover:text-primary flex items-center gap-0.5 truncate max-w-[120px]">
                        <ExternalLink className="h-3 w-3 shrink-0" /> {banner.cta_link}
                      </a>
                    </div>
                  </div>

                  {/* Ações */}
                  <div className="flex items-center gap-2 shrink-0">
                    <Switch checked={banner.is_active} onCheckedChange={() => toggleActive(banner)} />
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(banner)}>
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive"
                      onClick={() => setDeleteId(banner.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Dialog criar/editar */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingBanner ? 'Editar Banner' : 'Novo Banner'}</DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField control={form.control} name="image_url" rules={{ required: 'Imagem é obrigatória' }}
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <ImageUploader
                        value={field.value}
                        onChange={field.onChange}
                        label="Imagem do Banner"
                        aspectRatio="banner"
                        folder="banners"
                      />
                    </FormControl>
                    <FormMessage />
                    <p className="text-xs text-muted-foreground">Recomendado: 1200×400px ou proporção 3:1.</p>
                  </FormItem>
                )} />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField control={form.control} name="title" rules={{ required: 'Título é obrigatório' }}
                  render={({ field }) => (
                    <FormItem className="md:col-span-2">
                      <FormLabel>Título</FormLabel>
                      <FormControl><Input {...field} placeholder="Ex: Promoção de Verão" className="h-10" /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />

                <FormField control={form.control} name="subtitle"
                  render={({ field }) => (
                    <FormItem className="md:col-span-2">
                      <FormLabel>Subtítulo (opcional)</FormLabel>
                      <FormControl><Input {...field} placeholder="Ex: Até 50% de desconto" className="h-10" /></FormControl>
                    </FormItem>
                  )} />

                <FormField control={form.control} name="cta_text"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Texto do Botão</FormLabel>
                      <FormControl><Input {...field} placeholder="Ver mais" className="h-10" /></FormControl>
                    </FormItem>
                  )} />

                <FormField control={form.control} name="cta_link"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Link de Destino</FormLabel>
                      <FormControl><Input {...field} placeholder="/produtos" className="h-10" /></FormControl>
                    </FormItem>
                  )} />
              </div>

              <FormField control={form.control} name="is_active"
                render={({ field }) => (
                  <div className="flex items-center gap-3">
                    <Switch checked={field.value} onCheckedChange={field.onChange} id="is_active" />
                    <Label htmlFor="is_active" className="text-sm">Banner ativo (visível na loja)</Label>
                  </div>
                )} />

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setDialogOpen(false)} className="h-9">Cancelar</Button>
                <Button type="submit" className="bg-primary text-primary-foreground hover:bg-primary/90 h-9" disabled={saving}>
                  {saving && <Loader2 className="h-4 w-4 animate-spin mr-2" />}
                  {editingBanner ? 'Salvar' : 'Criar Banner'}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Confirmar exclusão */}
      <AlertDialog open={!!deleteId} onOpenChange={v => !v && setDeleteId(null)}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir Banner?</AlertDialogTitle>
            <AlertDialogDescription>Esta ação não pode ser desfeita.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground">Excluir</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AdminLayout>
  );
}
