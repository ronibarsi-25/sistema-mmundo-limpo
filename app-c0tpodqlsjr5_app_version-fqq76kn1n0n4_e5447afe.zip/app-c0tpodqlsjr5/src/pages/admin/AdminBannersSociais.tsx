import { useState, useEffect, useRef, useCallback } from 'react';
import html2canvas from 'html2canvas';
import { supabase } from '@/db/supabase';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Download, Search, ImageIcon, Instagram, MessageCircle,
  Palette, LayoutGrid, RefreshCw, Star, Tag, Package, Sparkles,
} from 'lucide-react';
import { toast } from 'sonner';
import type { Product } from '@/types/types';

function getFirstImageUrl(p: Product | undefined): string | null {
  if (!p) return null;
  const img = p.images?.[0];
  return img ? (img.url || null) : null;
}

// ─── Tipos ──────────────────────────────────────────────────────────────────

type BannerFormat = 'square' | 'story' | 'whatsapp' | 'feed2';
type BannerTheme = 'verde' | 'azul' | 'laranja' | 'roxo' | 'vermelho' | 'escuro';
type BannerTemplate = 'destaque' | 'promocao' | 'novo' | 'simples';

interface ThemeConfig {
  bg: string; text: string; accent: string; badge: string; badgeText: string; overlay: string;
}

const THEMES: Record<BannerTheme, ThemeConfig> = {
  verde:    { bg: 'linear-gradient(135deg,#0f5132 0%,#198754 100%)',  text: '#fff',    accent: '#adffca', badge: '#adffca', badgeText: '#0f5132', overlay: 'rgba(0,0,0,0.25)' },
  azul:     { bg: 'linear-gradient(135deg,#0a1f44 0%,#1565c0 100%)', text: '#fff',    accent: '#90caf9', badge: '#90caf9', badgeText: '#0a1f44', overlay: 'rgba(0,0,0,0.25)' },
  laranja:  { bg: 'linear-gradient(135deg,#7b2d00 0%,#f57c00 100%)', text: '#fff',    accent: '#ffcc80', badge: '#ffcc80', badgeText: '#7b2d00', overlay: 'rgba(0,0,0,0.25)' },
  roxo:     { bg: 'linear-gradient(135deg,#2d004b 0%,#7b1fa2 100%)', text: '#fff',    accent: '#e1bee7', badge: '#e1bee7', badgeText: '#2d004b', overlay: 'rgba(0,0,0,0.25)' },
  vermelho: { bg: 'linear-gradient(135deg,#5c0a00 0%,#c62828 100%)', text: '#fff',    accent: '#ffcdd2', badge: '#ffcdd2', badgeText: '#5c0a00', overlay: 'rgba(0,0,0,0.25)' },
  escuro:   { bg: 'linear-gradient(135deg,#1a1a2e 0%,#16213e 100%)', text: '#f0f0f0', accent: '#e94560', badge: '#e94560', badgeText: '#fff',    overlay: 'rgba(0,0,0,0.35)' },
};

const FORMAT_SIZES: Record<BannerFormat, { w: number; h: number; label: string }> = {
  square:   { w: 400, h: 400, label: '1:1 Instagram' },
  story:    { w: 270, h: 480, label: '9:16 Story' },
  whatsapp: { w: 480, h: 270, label: 'WhatsApp' },
  feed2:    { w: 480, h: 240, label: '2 Produtos' },
};

// ─── Componente de preview do banner ────────────────────────────────────────

interface BannerPreviewProps {
  products: Product[];
  selected: Product[];
  format: BannerFormat;
  theme: BannerTheme;
  template: BannerTemplate;
  storeName: string;
  tagline: string;
  showPrice: boolean;
  discount: number;
  previewRef: React.RefObject<HTMLDivElement>;
}

function BannerPreview({ products: _products, selected, format, theme, template, storeName, tagline, showPrice, discount, previewRef }: BannerPreviewProps) {
  const { w, h } = FORMAT_SIZES[format];
  const th = THEMES[theme];
  const p1 = selected[0];
  const p2 = selected[1];

  const discountedPrice = (price: number) =>
    discount > 0 ? price * (1 - discount / 100) : price;

  // Template: feed2 — dois produtos lado a lado
  if (format === 'feed2') {
    return (
      <div ref={previewRef} style={{ width: w, height: h, background: th.bg, position: 'relative', overflow: 'hidden', fontFamily: "'Segoe UI',sans-serif", display: 'flex', flexDirection: 'column' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 16px', background: 'rgba(0,0,0,0.3)' }}>
          <span style={{ color: th.text, fontWeight: 700, fontSize: 15 }}>{storeName}</span>
          {tagline && <span style={{ color: th.accent, fontSize: 11 }}>{tagline}</span>}
        </div>
        <div style={{ flex: 1, display: 'flex', gap: 2 }}>
          {[p1, p2].map((p, i) => !p ? (
            <div key={i} style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'rgba(255,255,255,0.3)', fontSize: 12 }}>Produto {i + 1}</div>
          ) : (
            <div key={p.id} style={{ flex: 1, display: 'flex', flexDirection: 'column', position: 'relative' }}>
              {getFirstImageUrl(p) && <img src={getFirstImageUrl(p)!} alt={p.name} style={{ width: '100%', height: '100%', objectFit: 'cover', position: 'absolute', inset: 0 }} />}
              <div style={{ position: 'absolute', inset: 0, background: th.overlay }} />
              <div style={{ position: 'relative', marginTop: 'auto', padding: '8px 10px' }}>
                <div style={{ color: th.text, fontWeight: 600, fontSize: 12, textShadow: '0 1px 3px rgba(0,0,0,0.5)' }}>{p.name}</div>
                {showPrice && <div style={{ color: th.accent, fontWeight: 700, fontSize: 14 }}>R$ {discountedPrice(p.price).toFixed(2)}</div>}
                {discount > 0 && <div style={{ background: th.badge, color: th.badgeText, fontSize: 10, fontWeight: 700, borderRadius: 4, padding: '1px 5px', display: 'inline-block' }}>{discount}% OFF</div>}
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // Templates padrão (square / story / whatsapp)
  const imgSize = format === 'story' ? '55%' : format === 'whatsapp' ? '50%' : '52%';

  return (
    <div ref={previewRef} style={{ width: w, height: h, background: th.bg, position: 'relative', overflow: 'hidden', fontFamily: "'Segoe UI',sans-serif", display: 'flex', flexDirection: 'column' }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: format === 'story' ? '14px 16px' : '10px 16px', background: 'rgba(0,0,0,0.25)', flexShrink: 0 }}>
        <span style={{ color: th.text, fontWeight: 800, fontSize: format === 'story' ? 16 : 14, letterSpacing: '0.5px' }}>{storeName}</span>
        {template === 'promocao' && <span style={{ background: th.badge, color: th.badgeText, fontSize: 11, fontWeight: 700, borderRadius: 20, padding: '2px 10px' }}>🔥 PROMOÇÃO</span>}
        {template === 'novo' && <span style={{ background: th.badge, color: th.badgeText, fontSize: 11, fontWeight: 700, borderRadius: 20, padding: '2px 10px' }}>✨ NOVO</span>}
        {template === 'destaque' && <span style={{ background: th.badge, color: th.badgeText, fontSize: 11, fontWeight: 700, borderRadius: 20, padding: '2px 10px' }}>⭐ DESTAQUE</span>}
      </div>

      {/* Imagem do produto */}
      <div style={{ flex: 1, position: 'relative', overflow: 'hidden', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        {getFirstImageUrl(p1) ? (
          <>
            <img src={getFirstImageUrl(p1)!} alt={p1.name} crossOrigin="anonymous" style={{ width: imgSize, height: imgSize, objectFit: 'contain', position: 'relative', zIndex: 1, filter: 'drop-shadow(0 4px 16px rgba(0,0,0,0.4))' }} />
            <img src={getFirstImageUrl(p1)!} alt="" aria-hidden crossOrigin="anonymous" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover', filter: 'blur(20px) brightness(0.4) saturate(1.5)', transform: 'scale(1.1)' }} />
          </>
        ) : (
          <div style={{ color: 'rgba(255,255,255,0.3)', fontSize: 13, zIndex: 1 }}>Selecione um produto</div>
        )}
        {discount > 0 && (
          <div style={{ position: 'absolute', top: 10, right: 10, background: th.badge, color: th.badgeText, fontWeight: 800, fontSize: format === 'story' ? 22 : 18, width: format === 'story' ? 60 : 52, height: format === 'story' ? 60 : 52, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 2, boxShadow: '0 2px 10px rgba(0,0,0,0.3)' }}>
            -{discount}%
          </div>
        )}
      </div>

      {/* Info do produto */}
      {p1 && (
        <div style={{ background: 'rgba(0,0,0,0.45)', padding: format === 'story' ? '14px 16px' : '10px 16px', flexShrink: 0 }}>
          <div style={{ color: th.text, fontWeight: 700, fontSize: format === 'story' ? 15 : 13, marginBottom: 3, textShadow: '0 1px 3px rgba(0,0,0,0.5)' }}>{p1.name}</div>
          {tagline && <div style={{ color: th.accent, fontSize: format === 'story' ? 12 : 11, marginBottom: 4 }}>{tagline}</div>}
          {showPrice && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              {discount > 0 && <span style={{ color: 'rgba(255,255,255,0.5)', textDecoration: 'line-through', fontSize: format === 'story' ? 13 : 11 }}>R$ {p1.price.toFixed(2)}</span>}
              <span style={{ color: th.accent, fontWeight: 800, fontSize: format === 'story' ? 22 : 18 }}>R$ {discountedPrice(p1.price).toFixed(2)}</span>
            </div>
          )}
        </div>
      )}

      {/* Footer */}
      <div style={{ background: 'rgba(0,0,0,0.5)', padding: '6px 16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexShrink: 0 }}>
        <span style={{ color: 'rgba(255,255,255,0.6)', fontSize: 10 }}>Peça pelo WhatsApp ou acesse o site</span>
        <span style={{ color: th.accent, fontSize: 10, fontWeight: 600 }}>🛒 Compre já!</span>
      </div>
    </div>
  );
}

// ─── Página principal ────────────────────────────────────────────────────────

export default function AdminBannersSociais() {
  const [products, setProducts] = useState<Product[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<Product[]>([]);
  const [format, setFormat] = useState<BannerFormat>('square');
  const [theme, setTheme] = useState<BannerTheme>('verde');
  const [template, setTemplate] = useState<BannerTemplate>('destaque');
  const [storeName, setStoreName] = useState('Mundo Limpo');
  const [tagline, setTagline] = useState('Produtos para limpeza');
  const [showPrice, setShowPrice] = useState(true);
  const [discount, setDiscount] = useState(0);
  const [exporting, setExporting] = useState(false);
  const previewRef = useRef<HTMLDivElement>(null!);

  useEffect(() => {
    loadProducts();
    loadStoreName();
  }, []);

  const loadStoreName = async () => {
    const { data } = await supabase.from('company').select('nome_fantasia,razao_social').limit(1).maybeSingle();
    if (data) setStoreName(data.nome_fantasia || data.razao_social || 'Minha Loja');
  };

  const loadProducts = async () => {
    setLoading(true);
    const { data } = await supabase.from('products').select('id,name,price,images,category_id,is_available,stock_quantity,code,brand').eq('is_available', true).order('name').limit(200);
    setProducts(Array.isArray(data) ? (data as unknown as Product[]) : []);
    setLoading(false);
  };

  const filtered = products.filter(p =>
    !search || p.name.toLowerCase().includes(search.toLowerCase()) || (p.code && p.code.toLowerCase().includes(search.toLowerCase()))
  );

  const toggleSelect = useCallback((p: Product) => {
    const max = format === 'feed2' ? 2 : 1;
    setSelected(prev => {
      const has = prev.find(x => x.id === p.id);
      if (has) return prev.filter(x => x.id !== p.id);
      if (prev.length >= max) return [...prev.slice(1), p];
      return [...prev, p];
    });
  }, [format]);

  const handleExport = async () => {
    if (!previewRef.current) return;
    setExporting(true);
    try {
      const canvas = await html2canvas(previewRef.current, {
        scale: 2.5,
        useCORS: true,
        allowTaint: true,
        logging: false,
      });
      const url = canvas.toDataURL('image/png');
      const a = document.createElement('a');
      const productName = selected[0]?.name?.replace(/\s+/g, '-').toLowerCase() || 'banner';
      a.href = url;
      a.download = `banner-${productName}-${format}.png`;
      a.click();
      toast.success('Banner exportado com sucesso!');
    } catch {
      toast.error('Erro ao exportar banner');
    } finally {
      setExporting(false);
    }
  };

  const themeOptions: { value: BannerTheme; label: string; color: string }[] = [
    { value: 'verde',    label: 'Verde',    color: 'bg-emerald-600' },
    { value: 'azul',     label: 'Azul',     color: 'bg-blue-600' },
    { value: 'laranja',  label: 'Laranja',  color: 'bg-orange-500' },
    { value: 'roxo',     label: 'Roxo',     color: 'bg-purple-600' },
    { value: 'vermelho', label: 'Vermelho', color: 'bg-red-600' },
    { value: 'escuro',   label: 'Escuro',   color: 'bg-slate-800' },
  ];

  return (
    <div className="p-4 md:p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-foreground text-balance flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-primary" /> Banners para Redes Sociais
          </h1>
          <p className="text-sm text-muted-foreground text-pretty">
            Crie banners com seus produtos para postar no WhatsApp e Instagram — baixe como imagem PNG
          </p>
        </div>
        <div className="flex gap-2">
          <Badge variant="outline" className="gap-1.5 text-xs"><Instagram className="h-3.5 w-3.5" /> Instagram</Badge>
          <Badge variant="outline" className="gap-1.5 text-xs"><MessageCircle className="h-3.5 w-3.5 text-green-600" /> WhatsApp</Badge>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_auto] gap-6">
        {/* Painel esquerdo — configurações */}
        <div className="space-y-4">
          <Tabs defaultValue="formato">
            <TabsList className="grid grid-cols-3 w-full">
              <TabsTrigger value="formato" className="text-xs sm:text-sm"><LayoutGrid className="h-3.5 w-3.5 mr-1.5" />Formato</TabsTrigger>
              <TabsTrigger value="design" className="text-xs sm:text-sm"><Palette className="h-3.5 w-3.5 mr-1.5" />Design</TabsTrigger>
              <TabsTrigger value="produto" className="text-xs sm:text-sm"><Package className="h-3.5 w-3.5 mr-1.5" />Produto</TabsTrigger>
            </TabsList>

            {/* Aba Formato */}
            <TabsContent value="formato" className="space-y-4 mt-4">
              <Card>
                <CardHeader className="pb-3"><CardTitle className="text-sm font-semibold">Formato do Banner</CardTitle></CardHeader>
                <CardContent className="grid grid-cols-2 gap-2">
                  {(Object.entries(FORMAT_SIZES) as [BannerFormat, { w: number; h: number; label: string }][]).map(([key, val]) => (
                    <button
                      key={key}
                      onClick={() => setFormat(key)}
                      className={`rounded-lg border p-3 text-left transition-all ${format === key ? 'border-primary bg-primary/10' : 'border-border hover:bg-muted/60'}`}
                    >
                      <div className="text-sm font-semibold capitalize">{key === 'feed2' ? 'Duplo' : key === 'square' ? 'Quadrado' : key === 'story' ? 'Story' : 'WhatsApp'}</div>
                      <div className="text-xs text-muted-foreground">{val.label}</div>
                      <div className="text-[10px] text-muted-foreground">{val.w}×{val.h}px</div>
                    </button>
                  ))}
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3"><CardTitle className="text-sm font-semibold">Template</CardTitle></CardHeader>
                <CardContent className="grid grid-cols-2 gap-2">
                  {[
                    { value: 'destaque',  icon: Star,     label: 'Destaque' },
                    { value: 'promocao',  icon: Tag,      label: 'Promoção' },
                    { value: 'novo',      icon: Sparkles, label: 'Novidade' },
                    { value: 'simples',   icon: ImageIcon, label: 'Simples' },
                  ].map(t => (
                    <button
                      key={t.value}
                      onClick={() => setTemplate(t.value as BannerTemplate)}
                      className={`rounded-lg border p-3 text-left flex items-center gap-2.5 transition-all ${template === t.value ? 'border-primary bg-primary/10' : 'border-border hover:bg-muted/60'}`}
                    >
                      <t.icon className={`h-4 w-4 shrink-0 ${template === t.value ? 'text-primary' : 'text-muted-foreground'}`} />
                      <span className="text-sm font-medium">{t.label}</span>
                    </button>
                  ))}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Aba Design */}
            <TabsContent value="design" className="space-y-4 mt-4">
              <Card>
                <CardHeader className="pb-3"><CardTitle className="text-sm font-semibold">Tema de Cores</CardTitle></CardHeader>
                <CardContent className="grid grid-cols-3 gap-2">
                  {themeOptions.map(t => (
                    <button
                      key={t.value}
                      onClick={() => setTheme(t.value)}
                      className={`rounded-lg border p-2.5 flex flex-col items-center gap-1.5 transition-all ${theme === t.value ? 'border-primary ring-2 ring-primary/30' : 'border-border hover:bg-muted/60'}`}
                    >
                      <span className={`h-7 w-7 rounded-full ${t.color}`} />
                      <span className="text-xs font-medium">{t.label}</span>
                    </button>
                  ))}
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3"><CardTitle className="text-sm font-semibold">Textos</CardTitle></CardHeader>
                <CardContent className="space-y-3">
                  <div className="space-y-1.5">
                    <Label className="text-sm font-normal">Nome da Loja</Label>
                    <Input value={storeName} onChange={e => setStoreName(e.target.value)} placeholder="Minha Loja" className="h-9" />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-sm font-normal">Slogan / Tagline</Label>
                    <Input value={tagline} onChange={e => setTagline(e.target.value)} placeholder="Qualidade para você!" className="h-9" />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label className="text-sm font-normal">Mostrar Preço</Label>
                    <button
                      onClick={() => setShowPrice(!showPrice)}
                      className={`h-6 w-11 rounded-full transition-colors relative ${showPrice ? 'bg-primary' : 'bg-muted'}`}
                    >
                      <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform ${showPrice ? 'translate-x-5' : 'translate-x-0.5'}`} />
                    </button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-sm font-semibold">Desconto</CardTitle>
                    {discount > 0 && <Badge className="h-5 text-[10px] bg-destructive">{discount}% OFF</Badge>}
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Slider min={0} max={80} step={5} value={[discount]} onValueChange={([v]) => setDiscount(v)} className="mt-1" />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>Sem desconto</span><span>Desconto: {discount}%</span>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Aba Produto */}
            <TabsContent value="produto" className="space-y-4 mt-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
                <Input
                  placeholder="Buscar produto..."
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  className="pl-9 h-10"
                />
              </div>
              <p className="text-xs text-muted-foreground">
                {format === 'feed2' ? 'Selecione até 2 produtos' : 'Selecione 1 produto'} — {selected.length} selecionado(s)
              </p>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-[380px] overflow-y-auto">
                {loading ? (
                  Array.from({ length: 6 }).map((_, i) => (
                    <div key={i} className="aspect-square rounded-lg bg-muted animate-pulse" />
                  ))
                ) : filtered.length === 0 ? (
                  <div className="col-span-3 text-center text-sm text-muted-foreground py-8">Nenhum produto encontrado</div>
                ) : (
                  filtered.map(p => {
                    const isSel = selected.some(x => x.id === p.id);
                    return (
                      <button
                        key={p.id}
                        onClick={() => toggleSelect(p)}
                        className={`rounded-lg border overflow-hidden text-left transition-all ${isSel ? 'border-primary ring-2 ring-primary/40' : 'border-border hover:border-muted-foreground/40'}`}
                      >
                        <div className="aspect-square bg-muted relative overflow-hidden">
                          {getFirstImageUrl(p)
                            ? <img src={getFirstImageUrl(p)!} alt={p.name} className="w-full h-full object-cover" />
                            : <div className="w-full h-full flex items-center justify-center"><Package className="h-8 w-8 text-muted-foreground/40" /></div>
                          }
                          {isSel && (
                            <div className="absolute inset-0 bg-primary/30 flex items-center justify-center">
                              <div className="h-7 w-7 rounded-full bg-primary flex items-center justify-center text-primary-foreground text-sm font-bold">
                                {selected.findIndex(x => x.id === p.id) + 1}
                              </div>
                            </div>
                          )}
                        </div>
                        <div className="p-2">
                          <p className="text-xs font-semibold text-foreground line-clamp-2 text-balance">{p.name}</p>
                          <p className="text-xs text-primary font-bold mt-0.5">R$ {p.price.toFixed(2)}</p>
                        </div>
                      </button>
                    );
                  })
                )}
              </div>
            </TabsContent>
          </Tabs>
        </div>

        {/* Painel direito — preview + download */}
        <div className="flex flex-col items-center gap-4 lg:sticky lg:top-4">
          <div className="flex items-center justify-between w-full">
            <span className="text-sm font-semibold text-foreground">Preview</span>
            <div className="flex items-center gap-2">
              <Select value={format} onValueChange={v => setFormat(v as BannerFormat)}>
                <SelectTrigger className="h-8 text-xs w-36">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {(Object.entries(FORMAT_SIZES) as [BannerFormat, { label: string }][]).map(([k, v]) => (
                    <SelectItem key={k} value={k}>{v.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button size="icon" variant="outline" className="h-8 w-8" onClick={loadProducts}>
                <RefreshCw className="h-3.5 w-3.5" />
              </Button>
            </div>
          </div>

          {/* Preview box — scale down para caber na tela */}
          <div className="overflow-hidden rounded-xl shadow-2xl border border-border/50" style={{ maxWidth: '100%' }}>
            <div style={{
              transform: `scale(${Math.min(1, 480 / FORMAT_SIZES[format].w)})`,
              transformOrigin: 'top left',
              width: FORMAT_SIZES[format].w,
              height: FORMAT_SIZES[format].h,
            }}>
              <BannerPreview
                products={products}
                selected={selected}
                format={format}
                theme={theme}
                template={template}
                storeName={storeName}
                tagline={tagline}
                showPrice={showPrice}
                discount={discount}
                previewRef={previewRef}
              />
            </div>
          </div>

          <div className="text-xs text-muted-foreground text-center">
            {FORMAT_SIZES[format].w} × {FORMAT_SIZES[format].h} px · exportado em 2.5× ({Math.round(FORMAT_SIZES[format].w * 2.5)} × {Math.round(FORMAT_SIZES[format].h * 2.5)} px)
          </div>

          <Button
            className="w-full gap-2"
            onClick={handleExport}
            disabled={exporting}
          >
            {exporting ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Download className="h-4 w-4" />}
            {exporting ? 'Exportando...' : 'Baixar Banner (PNG)'}
          </Button>

          <p className="text-[11px] text-muted-foreground text-center text-pretty max-w-xs">
            A imagem é salva em alta resolução, pronta para publicar no WhatsApp, Instagram Stories, Feed e Reels.
          </p>
        </div>
      </div>
    </div>
  );
}
