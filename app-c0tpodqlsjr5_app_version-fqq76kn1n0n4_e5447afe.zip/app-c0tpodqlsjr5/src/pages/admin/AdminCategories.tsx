import { useState, useEffect } from 'react';
import { Plus, Pencil, Trash2, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Skeleton } from '@/components/ui/skeleton';
import { AdminLayout } from '@/components/layouts/AdminLayout';
import { ImageUploader } from '@/components/admin/ImageUploader';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import { useForm } from 'react-hook-form';
import type { Category } from '@/types/types';

interface CategoryForm { name: string; description: string; image_url: string; is_active: boolean; }

export default function AdminCategories() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [editing, setEditing] = useState<Category | null>(null);
  const [saving, setSaving] = useState(false);
  const [productCounts, setProductCounts] = useState<Record<string, number>>({});

  const form = useForm<CategoryForm>({ defaultValues: { name: '', description: '', image_url: '', is_active: true } });

  const load = async () => {
    const [cRes, pRes] = await Promise.all([
      supabase.from('categories').select('*').order('name'),
      supabase.from('products').select('category_id')
    ]);
    const cats = Array.isArray(cRes.data) ? cRes.data : [];
    setCategories(cats);
    const counts: Record<string, number> = {};
    (pRes.data || []).forEach((p: any) => { if (p.category_id) counts[p.category_id] = (counts[p.category_id] || 0) + 1; });
    setProductCounts(counts);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const openCreate = () => {
    setEditing(null);
    form.reset({ name: '', description: '', image_url: '', is_active: true });
    setDialogOpen(true);
  };

  const openEdit = (cat: Category) => {
    setEditing(cat);
    form.reset({ name: cat.name, description: cat.description || '', image_url: cat.image_url || '', is_active: cat.is_active });
    setDialogOpen(true);
  };

  const onSubmit = async (data: CategoryForm) => {
    setSaving(true);
    const slug = data.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
    const payload = { name: data.name, slug: editing?.slug || slug, description: data.description || null, image_url: data.image_url || null, is_active: data.is_active, updated_at: new Date().toISOString() };
    if (editing) {
      const { error } = await supabase.from('categories').update(payload).eq('id', editing.id);
      if (error) { toast.error('Erro ao atualizar categoria'); setSaving(false); return; }
      toast.success('Categoria atualizada!');
    } else {
      const { error } = await supabase.from('categories').insert(payload);
      if (error) { toast.error('Erro ao criar categoria'); setSaving(false); return; }
      toast.success('Categoria criada!');
    }
    setDialogOpen(false); setSaving(false); load();
  };

  const deleteCategory = async (id: string) => {
    if (productCounts[id] > 0) { toast.error('Esta categoria possui produtos e não pode ser excluída'); setDeleteId(null); return; }
    const { error } = await supabase.from('categories').delete().eq('id', id);
    if (error) { toast.error('Erro ao excluir categoria'); return; }
    toast.success('Categoria excluída'); setDeleteId(null); load();
  };

  return (
    <AdminLayout title="Categorias">
      <div className="space-y-4">
        <div className="flex justify-end">
          <Button onClick={openCreate} className="bg-accent text-accent-foreground hover:bg-accent/90 h-9">
            <Plus className="h-4 w-4 mr-2" /> Nova Categoria
          </Button>
        </div>
        <div className="bg-card rounded-xl border border-border overflow-hidden">
          {loading ? (
            <div className="p-5 space-y-3">{[...Array(4)].map((_, i) => <Skeleton key={i} className="h-12 bg-muted" />)}</div>
          ) : categories.length === 0 ? (
            <div className="p-10 text-center text-muted-foreground text-sm">Nenhuma categoria cadastrada</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-max">
                <thead><tr className="border-b border-border bg-muted/40">
                  {['Nome', 'Slug', 'Produtos', 'Status', 'Ações'].map(h => <th key={h} className="text-left px-5 py-3 text-xs font-semibold text-muted-foreground whitespace-nowrap">{h}</th>)}
                </tr></thead>
                <tbody>
                  {categories.map(cat => (
                    <tr key={cat.id} className="border-b border-border last:border-0 hover:bg-muted/20 transition-colors">
                      <td className="px-5 py-3">
                        <div className="flex items-center gap-3">
                          {cat.image_url ? <img src={cat.image_url} alt={cat.name} className="h-8 w-8 rounded-md object-cover shrink-0" /> : <div className="h-8 w-8 rounded-md bg-muted shrink-0" />}
                          <span className="text-sm font-medium whitespace-nowrap">{cat.name}</span>
                        </div>
                      </td>
                      <td className="px-5 py-3 text-sm text-muted-foreground font-mono whitespace-nowrap">{cat.slug}</td>
                      <td className="px-5 py-3 whitespace-nowrap"><Badge variant="secondary" className="text-xs">{productCounts[cat.id] || 0}</Badge></td>
                      <td className="px-5 py-3 whitespace-nowrap"><Badge className={`border-0 text-xs ${cat.is_active ? 'bg-success/15 text-success' : 'bg-muted text-muted-foreground'}`}>{cat.is_active ? 'Ativa' : 'Inativa'}</Badge></td>
                      <td className="px-5 py-3 whitespace-nowrap">
                        <div className="flex items-center gap-1">
                          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(cat)}><Pencil className="h-3.5 w-3.5" /></Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive" onClick={() => setDeleteId(cat.id)}><Trash2 className="h-3.5 w-3.5" /></Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <DialogHeader><DialogTitle>{editing ? 'Editar Categoria' : 'Nova Categoria'}</DialogTitle></DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField control={form.control} name="name" rules={{ required: 'Nome é obrigatório' }}
                render={({ field }) => <FormItem><FormLabel>Nome</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>} />
              <FormField control={form.control} name="description"
                render={({ field }) => <FormItem><FormLabel>Descrição</FormLabel><FormControl><Textarea {...field} rows={2} /></FormControl></FormItem>} />
              <FormField control={form.control} name="image_url"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <ImageUploader
                        value={field.value}
                        onChange={field.onChange}
                        label="Imagem da Categoria"
                        aspectRatio="square"
                        folder="categorias"
                      />
                    </FormControl>
                  </FormItem>
                )} />
              <FormField control={form.control} name="is_active"
                render={({ field }) => <FormItem className="flex items-center gap-3"><FormLabel className="mb-0">Ativa</FormLabel><FormControl><Switch checked={field.value} onCheckedChange={field.onChange} /></FormControl></FormItem>} />
              <div className="flex justify-end gap-2 pt-2">
                <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>Cancelar</Button>
                <Button type="submit" className="bg-accent text-accent-foreground hover:bg-accent/90" disabled={saving}>
                  {saving ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}{editing ? 'Salvar' : 'Criar'}
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={open => !open && setDeleteId(null)}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir categoria</AlertDialogTitle>
            <AlertDialogDescription>Esta categoria será excluída permanentemente. Categorias com produtos não podem ser excluídas.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={() => deleteId && deleteCategory(deleteId)}>Excluir</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AdminLayout>
  );
}
