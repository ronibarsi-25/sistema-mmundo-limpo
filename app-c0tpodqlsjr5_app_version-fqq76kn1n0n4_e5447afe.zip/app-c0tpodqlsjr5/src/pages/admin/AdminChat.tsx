import { useState, useEffect, useRef } from 'react';
import { Send, MessageCircle, User, Bell } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { AdminLayout } from '@/components/layouts/AdminLayout';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/db/supabase';
import type { ChatMessage } from '@/types/types';
import { cn } from '@/lib/utils';

interface Conversation {
  conversation_id: string;
  user_id: string | null;
  last_message: string;
  last_at: string;
  unread: number;
  user_name?: string;
}

export default function AdminChat() {
  const { user } = useAuth();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [selectedConv, setSelectedConv] = useState<string | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });

  const loadConversations = async () => {
    const { data } = await supabase.from('chat_messages').select('conversation_id, user_id, message, created_at, is_read, sender_role').order('created_at', { ascending: false });
    if (!data) return;
    const convMap: Record<string, Conversation> = {};
    data.forEach((m: any) => {
      if (!convMap[m.conversation_id]) {
        convMap[m.conversation_id] = { conversation_id: m.conversation_id, user_id: m.user_id, last_message: m.message, last_at: m.created_at, unread: 0 };
      }
      if (!m.is_read && m.sender_role === 'user') convMap[m.conversation_id].unread++;
    });
    setConversations(Object.values(convMap).sort((a, b) => new Date(b.last_at).getTime() - new Date(a.last_at).getTime()));
    setLoading(false);
  };

  const loadMessages = async (convId: string) => {
    const { data } = await supabase.from('chat_messages').select('*').eq('conversation_id', convId).order('created_at', { ascending: true });
    setMessages(Array.isArray(data) ? data : []);
    setTimeout(scrollToBottom, 100);
    // mark as read
    await supabase.from('chat_messages').update({ is_read: true }).eq('conversation_id', convId).eq('sender_role', 'user');
    setConversations(prev => prev.map(c => c.conversation_id === convId ? { ...c, unread: 0 } : c));
  };

  useEffect(() => {
    loadConversations();
    const channel = supabase.channel('admin-chat')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'chat_messages' },
        async payload => {
          const msg = payload.new as ChatMessage;
          if (msg.conversation_id === selectedConv) {
            setMessages(prev => [...prev, msg]);
            setTimeout(scrollToBottom, 100);
            await supabase.from('chat_messages').update({ is_read: true }).eq('id', msg.id);
          } else {
            loadConversations();
          }
        })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [selectedConv]);

  const selectConv = (convId: string) => { setSelectedConv(convId); loadMessages(convId); };

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim() || !selectedConv || !user) return;
    setSending(true);
    const conv = conversations.find(c => c.conversation_id === selectedConv);
    await supabase.from('chat_messages').insert({
      conversation_id: selectedConv, user_id: conv?.user_id || null,
      sender_role: 'admin', message: text.trim(), is_read: false
    });
    setText('');
    setSending(false);
    loadConversations();
  };

  const totalUnread = conversations.reduce((s, c) => s + c.unread, 0);

  return (
    <AdminLayout title="Chat de Atendimento">
      <div className="flex gap-4 h-[calc(100vh-10rem)] min-h-[400px]">
        {/* Conversations list */}
        <div className="w-64 shrink-0 bg-card rounded-xl border border-border overflow-hidden flex flex-col">
          <div className="flex items-center gap-2 px-4 py-3 border-b border-border">
            <MessageCircle className="h-4 w-4 text-accent shrink-0" />
            <span className="text-sm font-semibold flex-1">Conversas</span>
            {totalUnread > 0 && <Badge className="bg-destructive text-destructive-foreground border-0 text-xs">{totalUnread}</Badge>}
          </div>
          <div className="flex-1 overflow-y-auto">
            {loading ? (
              <div className="p-3 space-y-2">{[...Array(4)].map((_, i) => <Skeleton key={i} className="h-14 bg-muted rounded-lg" />)}</div>
            ) : conversations.length === 0 ? (
              <div className="p-6 text-center text-muted-foreground text-sm">Sem conversas ainda</div>
            ) : conversations.map(conv => (
              <button key={conv.conversation_id} onClick={() => selectConv(conv.conversation_id)}
                className={cn('w-full text-left px-4 py-3 flex items-start gap-3 border-b border-border transition-colors',
                  selectedConv === conv.conversation_id ? 'bg-accent/10' : 'hover:bg-muted/50')}>
                <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                  <User className="h-4 w-4 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-1">
                    <span className="text-xs font-medium truncate">{conv.conversation_id.slice(0, 8)}...</span>
                    {conv.unread > 0 && <Badge className="bg-destructive text-destructive-foreground border-0 text-[10px] h-4 min-w-4 px-1 shrink-0">{conv.unread}</Badge>}
                  </div>
                  <p className="text-xs text-muted-foreground truncate">{conv.last_message}</p>
                  <p className="text-[10px] text-muted-foreground/60">{new Date(conv.last_at).toLocaleDateString('pt-BR')}</p>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Chat area */}
        <div className="flex-1 min-w-0 bg-card rounded-xl border border-border flex flex-col overflow-hidden">
          {!selectedConv ? (
            <div className="flex-1 flex flex-col items-center justify-center gap-3 text-center p-6">
              <Bell className="h-10 w-10 text-muted-foreground/30" />
              <p className="text-muted-foreground text-sm">Selecione uma conversa para responder</p>
            </div>
          ) : (
            <>
              <div className="px-5 py-3 border-b border-border flex items-center gap-2">
                <div className="h-7 w-7 rounded-full bg-primary/10 flex items-center justify-center shrink-0"><User className="h-3.5 w-3.5 text-primary" /></div>
                <span className="text-sm font-medium">Cliente {selectedConv.slice(0, 8)}...</span>
              </div>
              <div className="flex-1 overflow-y-auto p-4 space-y-3">
                {messages.map(msg => {
                  const isAdmin = msg.sender_role === 'admin';
                  return (
                    <div key={msg.id} className={cn('flex', isAdmin ? 'justify-end' : 'justify-start')}>
                      <div className={cn('max-w-[75%] rounded-2xl px-4 py-2.5 text-sm',
                        isAdmin ? 'bg-primary text-primary-foreground rounded-br-md' : 'bg-muted text-foreground rounded-bl-md')}>
                        <p className="text-pretty">{msg.message}</p>
                        <p className={cn('text-[10px] mt-1', isAdmin ? 'text-primary-foreground/70 text-right' : 'text-muted-foreground')}>
                          {new Date(msg.created_at).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                        </p>
                      </div>
                    </div>
                  );
                })}
                <div ref={messagesEndRef} />
              </div>
              <div className="border-t border-border p-3">
                <form onSubmit={sendMessage} className="flex gap-2">
                  <Input value={text} onChange={e => setText(e.target.value)} placeholder="Responder..." className="flex-1" />
                  <Button type="submit" size="icon" className="bg-accent text-accent-foreground hover:bg-accent/90 shrink-0" disabled={!text.trim() || sending}>
                    <Send className="h-4 w-4" />
                  </Button>
                </form>
              </div>
            </>
          )}
        </div>
      </div>
    </AdminLayout>
  );
}
