import { useState, useEffect } from 'react';
import { Save, Loader2, Ticket, Eye, EyeOff, Clock, Percent, Copy, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Slider } from '@/components/ui/slider';
import { AdminLayout } from '@/components/layouts/AdminLayout';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';

interface CouponConfig {
  id: string;
  show_banner: boolean;
  code: string;
  discount_percentage: number;
  min_order_value: number;
  expires_at: string | null;
  banner_headline: string;
  banner_subtitle: string;
  bg_color: string;
  text_color: string;
  button_text: string;
}

export default function AdminCouponConfig() {
  const [config, setConfig] = useState<CouponConfig | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    supabase.from('site_coupon_config').select('*').limit(1).maybeSingle().then(({ data }) => {
      if (data) setConfig(data as CouponConfig);
      setLoading(false);
    });
  }, []);

  const setField = (field: keyof CouponConfig, value: string | number | boolean) =>
    setConfig(c => c ? { ...c, [field]: value } : null);

  const handleSave = async () => {
    if (!config) return;
    setSaving(true);
    const { error } = await supabase.from('site_coupon_config').update({
      show_banner: config.show_banner,
      code: config.code,
      discount_percentage: config.discount_percentage,
      min_order_value: config.min_order_value,
      expires_at: config.expires_at || null,
      banner_headline: config.banner_headline,
      banner_subtitle: config.banner_subtitle,
      bg_color: config.bg_color,
      text_color: config.text_color,
      button_text: config.button_text,
      updated_at: new Date().toISOString(),
    }).eq('id', config.id);
    setSaving(false);
    if (error) { toast.error('Erro ao salvar: ' + error.message); return; }
    toast.success('Configuração salva!');
  };

  const copyCode = () => {
    if (!config) return;
    navigator.clipboard.writeText(config.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (loading) {
    return (
      <AdminLayout title="Cupom de Desconto">
        <div className="flex items-center justify-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      </AdminLayout>
    );
  }

  if (!config) {
    return (
      <AdminLayout title="Cupom de Desconto">
        <div className="p-8 text-center text-muted-foreground">Configuração não encontrada</div>
      </AdminLayout>
    );
  }

  const previewHeadline = config.banner_headline
    .replace(/{code}/g, config.code)
    .replace(/{discount}/g, String(config.discount_percentage));

  const isExpired = config.expires_at ? new Date() > new Date(config.expires_at) : false;

  return (
    <AdminLayout title="Cupom de Desconto" subtitle="Configure o cupom promocional do site">
      <div className="max-w-3xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-primary/10 flex items-center justify-center">
              <Ticket className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-foreground text-balance">Cupom de Desconto</h1>
              <p className="text-sm text-muted-foreground">Gerencie o cupom exibido no site</p>
            </div>
          </div>
          <div className="flex items-center gap-3 shrink-0">
            <div className="flex items-center gap-2">
              <Switch
                checked={config.show_banner}
                onCheckedChange={v => setField('show_banner', v)}
                id="show_banner"
              />
              <Label htmlFor="show_banner" className="text-sm cursor-pointer">
                {config.show_banner
                  ? <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200 dark:bg-emerald-900/30 dark:text-emerald-400 flex items-center gap-1"><Eye className="h-3 w-3" /> Visível</Badge>
                  : <Badge variant="secondary" className="flex items-center gap-1"><EyeOff className="h-3 w-3" /> Oculto</Badge>}
              </Label>
            </div>
            <Button onClick={handleSave} disabled={saving} className="gap-2 h-9">
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              Salvar
            </Button>
          </div>
        </div>

        {/* Configurações do Cupom */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Percent className="h-4 w-4 text-primary" />
              Dados do Cupom
            </CardTitle>
            <CardDescription>Código, percentual de desconto e regras</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">Código do Cupom</Label>
                <div className="flex gap-2">
                  <Input value={config.code} onChange={e => setField('code', e.target.value.toUpperCase())} placeholder="EX: BEMVINDO20" />
                  <Button variant="outline" size="icon" onClick={copyCode} className="shrink-0">
                    {copied ? <Check className="h-4 w-4 text-success" /> : <Copy className="h-4 w-4" />}
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">Código que o cliente digita no checkout</p>
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">Desconto (%)</Label>
                <div className="flex items-center gap-3">
                  <Slider value={[config.discount_percentage]} onValueChange={v => setField('discount_percentage', v[0])} max={50} step={1} className="flex-1" />
                  <span className="text-sm font-semibold w-10 text-right">{config.discount_percentage}%</span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">Pedido Mínimo (R$)</Label>
                <Input type="number" min={0} value={config.min_order_value} onChange={e => setField('min_order_value', Number(e.target.value))} />
                <p className="text-xs text-muted-foreground">0 = sem valor mínimo</p>
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-normal flex items-center gap-1.5">
                  <Clock className="h-3.5 w-3.5 text-muted-foreground" />
                  Expira em
                </Label>
                <Input
                  type="datetime-local"
                  value={config.expires_at ? config.expires_at.slice(0, 16) : ''}
                  onChange={e => setField('expires_at', e.target.value ? new Date(e.target.value).toISOString() : '')}
                />
                {isExpired && <p className="text-xs text-destructive">Este cupom já expirou</p>}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Banner */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Banner Promocional</CardTitle>
            <CardDescription>Configure o texto e as cores do banner exibido no site</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Título do Banner</Label>
              <Input value={config.banner_headline} onChange={e => setField('banner_headline', e.target.value)} placeholder="Use o cupom {code} e ganhe {discount}% de desconto!" />
              <p className="text-xs text-muted-foreground">Variáveis: {`{code}`}, {`{discount}`}</p>
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Subtítulo</Label>
              <Input value={config.banner_subtitle} onChange={e => setField('banner_subtitle', e.target.value)} placeholder="Válido por tempo limitado. Aproveite!" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Texto do Botão</Label>
              <Input value={config.button_text} onChange={e => setField('button_text', e.target.value)} placeholder="Copiar Cupom" />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">Cor de Fundo</Label>
                <div className="flex gap-2">
                  <Input value={config.bg_color} onChange={e => setField('bg_color', e.target.value)} placeholder="#10b981" />
                  <div className="h-9 w-9 rounded-md border border-border shrink-0" style={{ backgroundColor: config.bg_color }} />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">Cor do Texto</Label>
                <div className="flex gap-2">
                  <Input value={config.text_color} onChange={e => setField('text_color', e.target.value)} placeholder="#ffffff" />
                  <div className="h-9 w-9 rounded-md border border-border shrink-0" style={{ backgroundColor: config.text_color }} />
                </div>
              </div>
            </div>

            <Separator />

            {/* Preview */}
            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Prévia do Banner</p>
              <div className="rounded-xl p-5 text-center space-y-2 transition-colors" style={{ backgroundColor: config.bg_color, color: config.text_color }}>
                <p className="text-lg font-bold text-balance">{previewHeadline}</p>
                <p className="text-sm opacity-90 text-pretty">{config.banner_subtitle}</p>
                <button type="button" className="mt-2 inline-flex items-center justify-center rounded-md text-sm font-medium h-8 px-3 bg-white/20 text-white border border-white/40 hover:bg-white/30 backdrop-blur-sm transition-colors">
                  <Copy className="h-3.5 w-3.5 mr-1.5" /> {config.button_text}
                </button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}
