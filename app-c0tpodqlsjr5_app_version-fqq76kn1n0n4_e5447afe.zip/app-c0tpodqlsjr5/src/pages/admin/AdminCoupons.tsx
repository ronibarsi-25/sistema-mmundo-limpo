import { useState, useEffect, useCallback } from 'react';
import { Plus, Pencil, Trash2, Loader2, Tag, ToggleLeft, ToggleRight, Search, X, Eye } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { AdminLayout } from '@/components/layouts/AdminLayout';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import type { Coupon, CouponDiscountType } from '@/types/types';

const EMPTY_FORM = {
  code: '',
  discount_type: 'percent' as CouponDiscountType,
  discount_value: 10,
  min_order_value: 0,
  max_uses: '' as string | number,
  max_uses_per_user: '' as string | number,
  starts_at: new Date().toISOString().slice(0, 16),
  ends_at: '',
  is_active: true,
};

export default function AdminCoupons() {
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [editing, setEditing] = useState<Coupon | null>(null);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ ...EMPTY_FORM });
  const [ordersDialogCoupon, setOrdersDialogCoupon] = useState<Coupon | null>(null);
  const [couponUsages, setCouponUsages] = useState<any[]>([]);
  const [ordersLoading, setOrdersLoading] = useState(false);

  const fetchCoupons = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase.from('coupons').select('*').order('created_at', { ascending: false });
    setCoupons(Array.isArray(data) ? data : []);
    setLoading(false);
  }, []);

  useEffect(() => { fetchCoupons(); }, [fetchCoupons]);

  const openCreate = () => {
    setEditing(null);
    setForm({ ...EMPTY_FORM });
    setDialogOpen(true);
  };

  const openEdit = (c: Coupon) => {
    setEditing(c);
    setForm({
      code: c.code,
      discount_type: c.discount_type,
      discount_value: c.discount_value,
      min_order_value: c.min_order_value,
      max_uses: c.max_uses ?? '',
      max_uses_per_user: c.max_uses_per_user ?? '',
      starts_at: c.starts_at.slice(0, 16),
      ends_at: c.ends_at ? c.ends_at.slice(0, 16) : '',
      is_active: c.is_active,
    });
    setDialogOpen(true);
  };

  const handleSave = async () => {
    if (!form.code.trim()) { toast.error('Informe o código do cupom.'); return; }
    if (form.discount_type !== 'free_shipping' && (form.discount_value <= 0)) {
      toast.error('O valor do desconto deve ser maior que 0.'); return;
    }
    setSaving(true);
    const payload = {
      code: form.code.trim().toUpperCase(),
      discount_type: form.discount_type,
      discount_value: form.discount_type === 'free_shipping' ? 0 : Number(form.discount_value),
      min_order_value: Number(form.min_order_value) || 0,
      max_uses: form.max_uses === '' ? null : Number(form.max_uses),
      max_uses_per_user: form.max_uses_per_user === '' ? null : Number(form.max_uses_per_user),
      starts_at: form.starts_at ? new Date(form.starts_at).toISOString() : new Date().toISOString(),
      ends_at: form.ends_at ? new Date(form.ends_at).toISOString() : null,
      is_active: form.is_active,
      updated_at: new Date().toISOString(),
    };
    let err;
    if (editing) {
      ({ error: err } = await supabase.from('coupons').update(payload).eq('id', editing.id));
    } else {
      ({ error: err } = await supabase.from('coupons').insert(payload));
    }
    if (err) {
      if (err.code === '23505') toast.error('Já existe um cupom com esse código.');
      else toast.error('Erro ao salvar cupom.');
    } else {
      toast.success(editing ? 'Cupom atualizado!' : 'Cupom criado!');
      setDialogOpen(false);
      fetchCoupons();
    }
    setSaving(false);
  };

  const handleToggle = async (c: Coupon) => {
    await supabase.from('coupons').update({ is_active: !c.is_active, updated_at: new Date().toISOString() }).eq('id', c.id);
    toast.success(c.is_active ? 'Cupom desativado' : 'Cupom ativado');
    fetchCoupons();
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    await supabase.from('coupons').delete().eq('id', deleteId);
    toast.success('Cupom excluído.');
    setDeleteId(null);
    fetchCoupons();
  };

  const discountLabel = (c: Coupon) => {
    if (c.discount_type === 'free_shipping') return 'Frete Grátis';
    if (c.discount_type === 'percent') return `-${c.discount_value}%`;
    return `-R$ ${c.discount_value.toFixed(2)}`;
  };

  const isExpired = (c: Coupon) => c.ends_at ? new Date(c.ends_at) < new Date() : false;

  const openOrdersDialog = async (c: Coupon) => {
    setOrdersDialogCoupon(c);
    setOrdersLoading(true);
    const { data } = await supabase
      .from('coupon_usages')
      .select('*, orders(order_number, customer_name, total_amount, status, created_at)')
      .eq('coupon_id', c.id)
      .order('used_at', { ascending: false });
    setCouponUsages(Array.isArray(data) ? data : []);
    setOrdersLoading(false);
  };

  const filtered = coupons.filter(c =>
    c.code.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <AdminLayout title="Cupons de Desconto">
      <div className="space-y-4">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center gap-3">
          <div className="relative flex-1 max-w-xs">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Buscar código..." value={search} onChange={e => setSearch(e.target.value)}
              className="pl-9 h-9 text-sm" />
            {search && <button onClick={() => setSearch('')} className="absolute right-2 top-1/2 -translate-y-1/2"><X className="h-3.5 w-3.5 text-muted-foreground" /></button>}
          </div>
          <Button onClick={openCreate} className="h-9 bg-primary text-primary-foreground hover:bg-primary/90 shrink-0">
            <Plus className="h-4 w-4 mr-2" /> Novo Cupom
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-card border border-border rounded-xl p-4 text-center">
            <p className="text-2xl font-bold text-foreground">{coupons.length}</p>
            <p className="text-xs text-muted-foreground">Total</p>
          </div>
          <div className="bg-card border border-border rounded-xl p-4 text-center">
            <p className="text-2xl font-bold text-foreground">{coupons.filter(c => c.is_active && !isExpired(c)).length}</p>
            <p className="text-xs text-muted-foreground">Ativos</p>
          </div>
          <div className="bg-card border border-border rounded-xl p-4 text-center">
            <p className="text-2xl font-bold text-foreground">{coupons.reduce((s, c) => s + c.used_count, 0)}</p>
            <p className="text-xs text-muted-foreground">Usos Total</p>
          </div>
        </div>

        {/* Table */}
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          {loading ? (
            <div className="flex items-center justify-center py-16"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-16">
              <Tag className="h-10 w-10 text-muted-foreground/30 mx-auto mb-3" />
              <p className="text-sm text-muted-foreground">{search ? 'Nenhum cupom encontrado.' : 'Nenhum cupom cadastrado ainda.'}</p>
              {!search && <Button variant="ghost" size="sm" className="mt-2" onClick={openCreate}><Plus className="h-3.5 w-3.5 mr-1" />Criar cupom</Button>}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border bg-muted/40">
                    <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground whitespace-nowrap">Código</th>
                    <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground whitespace-nowrap">Desconto</th>
                    <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground whitespace-nowrap hidden md:table-cell">Mín. Pedido</th>
                    <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground whitespace-nowrap hidden md:table-cell">Usos</th>
                    <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground whitespace-nowrap hidden md:table-cell">Validade</th>
                    <th className="text-left py-3 px-4 text-xs font-semibold text-muted-foreground whitespace-nowrap">Status</th>
                    <th className="py-3 px-4 w-24" />
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {filtered.map(c => (
                    <tr key={c.id} className="hover:bg-muted/20 transition-colors">
                      <td className="py-3 px-4 whitespace-nowrap">
                        <span className="font-mono text-sm font-semibold bg-muted px-2 py-0.5 rounded">{c.code}</span>
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        <Badge className="text-xs font-semibold bg-destructive/10 text-destructive border-0">{discountLabel(c)}</Badge>
                      </td>
                      <td className="py-3 px-4 text-sm text-muted-foreground whitespace-nowrap hidden md:table-cell">
                        {c.min_order_value > 0 ? `R$ ${c.min_order_value.toFixed(2)}` : '—'}
                      </td>
                      <td className="py-3 px-4 text-sm text-muted-foreground whitespace-nowrap hidden md:table-cell">
                        {c.used_count}{c.max_uses ? `/${c.max_uses}` : ''}
                      </td>
                      <td className="py-3 px-4 text-xs text-muted-foreground whitespace-nowrap hidden md:table-cell">
                        {c.ends_at ? (
                          <span className={isExpired(c) ? 'text-destructive' : ''}>
                            {isExpired(c) ? '⚠ ' : ''}{new Date(c.ends_at).toLocaleDateString('pt-BR')}
                          </span>
                        ) : 'Sem limite'}
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        <button onClick={() => handleToggle(c)} className="text-muted-foreground hover:text-foreground transition-colors">
                          {c.is_active && !isExpired(c) ? (
                            <ToggleRight className="h-5 w-5 text-primary" />
                          ) : (
                            <ToggleLeft className="h-5 w-5" />
                          )}
                        </button>
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        <div className="flex items-center gap-1 justify-end">
                          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openOrdersDialog(c)} title="Ver pedidos">
                            <Eye className="h-3.5 w-3.5" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openEdit(c)}>
                            <Pencil className="h-3.5 w-3.5" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive hover:text-destructive" onClick={() => setDeleteId(c.id)}>
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Dialog criar/editar */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader>
            <DialogTitle>{editing ? 'Editar Cupom' : 'Novo Cupom'}</DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-1">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5 col-span-2 md:col-span-1">
                <Label className="text-sm font-normal">Código do Cupom *</Label>
                <Input value={form.code} onChange={e => setForm(f => ({ ...f, code: e.target.value.toUpperCase() }))}
                  placeholder="Ex: PROMO10" className="h-9 font-mono uppercase" />
              </div>
              <div className="space-y-1.5 col-span-2 md:col-span-1">
                <Label className="text-sm font-normal">Tipo de Desconto *</Label>
                <Select value={form.discount_type} onValueChange={v => setForm(f => ({ ...f, discount_type: v as CouponDiscountType }))}>
                  <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="percent">Percentual (%)</SelectItem>
                    <SelectItem value="fixed">Valor Fixo (R$)</SelectItem>
                    <SelectItem value="free_shipping">Frete Grátis</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {form.discount_type !== 'free_shipping' && (
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">
                  {form.discount_type === 'percent' ? 'Desconto (%)' : 'Desconto (R$)'} *
                </Label>
                <Input type="number" min={0} max={form.discount_type === 'percent' ? 100 : undefined}
                  value={form.discount_value} onChange={e => setForm(f => ({ ...f, discount_value: Number(e.target.value) }))}
                  className="h-9" />
              </div>
            )}

            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">Valor Mínimo (R$)</Label>
                <Input type="number" min={0} value={form.min_order_value}
                  onChange={e => setForm(f => ({ ...f, min_order_value: Number(e.target.value) }))}
                  placeholder="0 = sem mínimo" className="h-9" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">Limite Total</Label>
                <Input type="number" min={1} value={form.max_uses}
                  onChange={e => setForm(f => ({ ...f, max_uses: e.target.value }))}
                  placeholder="Vazio = ilimitado" className="h-9" />
              </div>
              <div className="space-y-1.5 col-span-2 md:col-span-1">
                <Label className="text-sm font-normal">Limite por Cliente</Label>
                <Input type="number" min={1} value={form.max_uses_per_user}
                  onChange={e => setForm(f => ({ ...f, max_uses_per_user: e.target.value }))}
                  placeholder="Vazio = sem limite" className="h-9" />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">Início *</Label>
                <Input type="datetime-local" value={form.starts_at}
                  onChange={e => setForm(f => ({ ...f, starts_at: e.target.value }))} className="h-9 text-sm" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">Validade</Label>
                <Input type="datetime-local" value={form.ends_at}
                  onChange={e => setForm(f => ({ ...f, ends_at: e.target.value }))} className="h-9 text-sm" />
              </div>
            </div>

            <div className="flex items-center gap-3 pt-1">
              <Switch id="coupon-active" checked={form.is_active} onCheckedChange={v => setForm(f => ({ ...f, is_active: v }))} />
              <Label htmlFor="coupon-active" className="text-sm font-normal cursor-pointer">Cupom ativo</Label>
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setDialogOpen(false)} className="h-9">Cancelar</Button>
            <Button onClick={handleSave} disabled={saving} className="h-9 bg-primary text-primary-foreground hover:bg-primary/90">
              {saving ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
              {editing ? 'Salvar' : 'Criar Cupom'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Confirmação exclusão */}
      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir cupom?</AlertDialogTitle>
            <AlertDialogDescription>Esta ação não pode ser desfeita.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Pedidos vinculados */}
      <Dialog open={!!ordersDialogCoupon} onOpenChange={() => setOrdersDialogCoupon(null)}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl">
          <DialogHeader>
            <DialogTitle>Pedidos com {ordersDialogCoupon?.code}</DialogTitle>
          </DialogHeader>
          {ordersLoading ? (
            <div className="flex items-center justify-center py-10"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
          ) : couponUsages.length === 0 ? (
            <div className="py-10 text-center text-sm text-muted-foreground">Nenhum pedido utilizou este cupom ainda.</div>
          ) : (
            <div className="overflow-x-auto -mx-6 px-6">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="whitespace-nowrap">Pedido</TableHead>
                    <TableHead className="whitespace-nowrap">Cliente</TableHead>
                    <TableHead className="whitespace-nowrap">Total</TableHead>
                    <TableHead className="whitespace-nowrap">Desconto</TableHead>
                    <TableHead className="whitespace-nowrap">Data</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {couponUsages.map((usage) => (
                    <TableRow key={usage.id}>
                      <TableCell className="whitespace-nowrap font-mono text-sm">{usage.orders?.order_number || '—'}</TableCell>
                      <TableCell className="whitespace-nowrap">{usage.orders?.customer_name || '—'}</TableCell>
                      <TableCell className="whitespace-nowrap">
                        {usage.orders?.total_amount?.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }) || '—'}
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-destructive">
                        -{usage.discount_applied?.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }) || '—'}
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground text-xs">
                        {usage.used_at ? new Date(usage.used_at).toLocaleDateString('pt-BR') : '—'}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
}
