import { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import {
  ShoppingCart, Package, Tag, TrendingUp, AlertTriangle, ChevronRight, Clock,
  MonitorSmartphone, Zap, PackageOpen, Receipt, Users, Percent, Megaphone,
  Wallet, Truck, BarChart3, Image as ImageIcon, Settings, Palette, FileText,
  Ticket, Image, CalendarDays, Store, CreditCard, PartyPopper, Download,
  FileSpreadsheet, Bell, BellRing
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Progress } from '@/components/ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AdminLayout } from '@/components/layouts/AdminLayout';
import { StatCard } from '@/components/admin/StatCard';
import { SparklineChart } from '@/components/admin/SparklineChart';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import type { Order, OrderStatus } from '@/types/types';

/* Recharts imports */
import {
  BarChart as ReBarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as ReTooltip,
  ResponsiveContainer, PieChart, Pie, Cell, Legend
} from 'recharts';

const STATUS_CONFIG: Record<OrderStatus, { label: string; variant: string }> = {
  pending: { label: 'Pendente', variant: 'status-badge-warning' },
  processing: { label: 'Processando', variant: 'status-badge-info' },
  shipped: { label: 'Enviado', variant: 'status-badge-success' },
  delivered: { label: 'Entregue', variant: 'status-badge-success' },
  cancelled: { label: 'Cancelado', variant: 'status-badge-destructive' },
  completed: { label: 'Concluído', variant: 'status-badge-success' },
};

/* ─── Quick Actions ─── */
const QUICK_ACTIONS = [
  { label: 'Novo Pedido', icon: Receipt, path: '/pdv', color: 'bg-primary text-primary-foreground' },
  { label: 'Adicionar Produto', icon: PackageOpen, path: '/admin/produtos', color: 'bg-accent text-accent-foreground' },
  { label: 'Criar Cupom', icon: Percent, path: '/admin/cupons', color: 'bg-info text-info-foreground' },
  { label: 'Ver Relatórios', icon: BarChart3, path: '/admin/relatorios', color: 'bg-success text-success-foreground' },
  { label: 'Configurar Entrega', icon: Truck, path: '/admin/entregas', color: 'bg-warning text-warning-foreground' },
  { label: 'Ver Loja', icon: MonitorSmartphone, path: '/', color: 'bg-secondary text-secondary-foreground' },
];

const PERIOD_OPTIONS = [
  { value: '7', label: 'Últimos 7 dias' },
  { value: '30', label: 'Últimos 30 dias' },
  { value: '90', label: 'Últimos 90 dias' },
];

const CHART_COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#06b6d4'];

export default function AdminDashboard() {
  const [stats, setStats] = useState({
    orders: 0, products: 0, categories: 0, revenue: 0, pendingOrders: 0,
    newOrdersToday: 0, revenueToday: 0, customers: 0, coupons: 0,
    outOfStock: 0, totalStockValue: 0
  });
  const [recentOrders, setRecentOrders] = useState<Order[]>([]);
  const [lowStockProducts, setLowStockProducts] = useState<{ id: string; name: string; stock_quantity: number }[]>([]);
  const [salesData, setSalesData] = useState<number[]>([]);
  const [salesLabels, setSalesLabels] = useState<string[]>([]);
  const [categoryData, setCategoryData] = useState<{ name: string; value: number; color: string }[]>([]);
  const [periodDays, setPeriodDays] = useState('7');
  const [loading, setLoading] = useState(true);
  const [exporting, setExporting] = useState(false);
  const [orderStatusCounts, setOrderStatusCounts] = useState<Record<string, number>>({});
  const [toastNotified, setToastNotified] = useState(false);

  /* ─── Data Fetching ─── */
  useEffect(() => {
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);

    Promise.all([
      supabase.from('orders').select('id, status, total_amount, order_number, created_at, customer_name, items').order('created_at', { ascending: false }).limit(300),
      supabase.from('products').select('id, name, stock_quantity, cost_price, is_available, category_id, categories(name)').eq('is_available', true).limit(500),
      supabase.from('categories').select('id, name').eq('is_active', true),
      supabase.from('customers').select('id').limit(1000),
      supabase.from('coupons').select('id').eq('is_active', true),
    ]).then(([ordersRes, productsRes, catsRes, customersRes, couponsRes]) => {
      const orders = Array.isArray(ordersRes.data) ? ordersRes.data : [];
      const products = Array.isArray(productsRes.data) ? productsRes.data : [];
      const cats = Array.isArray(catsRes.data) ? catsRes.data : [];
      const customers = Array.isArray(customersRes.data) ? customersRes.data : [];
      const coupons = Array.isArray(couponsRes.data) ? couponsRes.data : [];

      // Revenue (completed/delivered)
      const revenue = orders.filter((o: any) => o.status === 'completed' || o.status === 'delivered').reduce((s: number, o: any) => s + (o.total_amount || 0), 0);
      const pending = orders.filter((o: any) => o.status === 'pending').length;

      // Today's orders & revenue
      const newOrdersToday = orders.filter((o: any) => new Date(o.created_at) >= todayStart).length;
      const revenueToday = orders.filter((o: any) => new Date(o.created_at) >= todayStart && (o.status === 'completed' || o.status === 'delivered')).reduce((s: number, o: any) => s + (o.total_amount || 0), 0);

      // Low stock
      const lowStock = products.filter((p: any) => p.stock_quantity <= 5 && p.stock_quantity > 0);
      const outOfStock = products.filter((p: any) => p.stock_quantity <= 0).length;
      const totalStockValue = products.reduce((s: number, p: any) => s + ((p.cost_price || 0) * (p.stock_quantity || 0)), 0);

      // Order status distribution
      const statusCounts: Record<string, number> = {};
      orders.forEach((o: any) => { statusCounts[o.status] = (statusCounts[o.status] || 0) + 1; });

      // Category sales: map product name → category name
      const catMap: Record<string, string> = {};
      products.forEach((p: any) => {
        const catName = p.categories?.name || 'Sem categoria';
        catMap[p.name] = catName;
      });
      const catSales: Record<string, number> = {};
      orders.forEach((o: any) => {
        if (o.status === 'cancelled') return;
        (o.items || []).forEach((item: any) => {
          const cat = catMap[item.name] || 'Outros';
          catSales[cat] = (catSales[cat] || 0) + (item.quantity || 1);
        });
      });
      const topCats = Object.entries(catSales)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 6)
        .map(([name, value], i) => ({ name, value, color: CHART_COLORS[i % CHART_COLORS.length] }));

      setStats({
        orders: orders.length, products: products.length, categories: cats.length, revenue,
        pendingOrders: pending, newOrdersToday, revenueToday,
        customers: customers.length, coupons: coupons.length, outOfStock, totalStockValue
      });
      setRecentOrders(orders.slice(0, 7) as Order[]);
      setLowStockProducts(lowStock.slice(0, 5) as { id: string; name: string; stock_quantity: number }[]);
      setCategoryData(topCats);
      setOrderStatusCounts(statusCounts);
      setLoading(false);
    });
  }, []);

  /* ─── Sales by Period ─── */
  useEffect(() => {
    if (loading) return;
    const days = parseInt(periodDays, 10);
    supabase.from('orders').select('created_at, total_amount, status').gte('created_at', new Date(Date.now() - days * 86400000).toISOString()).limit(500)
      .then(({ data }) => {
        const orders = Array.isArray(data) ? data : [];
        const validOrders = orders.filter((o: any) => o.status === 'completed' || o.status === 'delivered');
        const dailySales: number[] = [];
        const labels: string[] = [];
        for (let i = days - 1; i >= 0; i--) {
          const d = new Date();
          d.setDate(d.getDate() - i);
          d.setHours(0, 0, 0, 0);
          const nextDay = new Date(d);
          nextDay.setDate(nextDay.getDate() + 1);
          const sum = validOrders
            .filter((o: any) => {
              const cd = new Date(o.created_at);
              return cd >= d && cd < nextDay;
            })
            .reduce((s: number, o: any) => s + (o.total_amount || 0), 0);
          dailySales.push(sum);
          labels.push(d.toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' }));
        }
        setSalesData(dailySales);
        setSalesLabels(labels);
      });
  }, [periodDays, loading]);

  /* ─── Toast notifications ─── */
  useEffect(() => {
    if (loading || toastNotified) return;
    if (stats.pendingOrders > 0) {
      toast.warning(
        `${stats.pendingOrders} pedido(s) pendente(s) aguardando processamento`,
        { icon: <BellRing className="h-4 w-4" />, duration: 6000 }
      );
    }
    setToastNotified(true);
  }, [loading, stats.pendingOrders, lowStockProducts.length, toastNotified]);

  /* ─── Export CSV ─── */
  const handleExportCSV = () => {
    setExporting(true);
    const rows = [
      ['Dashboard Mundo Limpo - Exportação', new Date().toLocaleString('pt-BR')],
      [],
      ['KPI', 'Valor'],
      ['Total Pedidos', String(stats.orders)],
      ['Produtos Ativos', String(stats.products)],
      ['Categorias', String(stats.categories)],
      ['Receita Total', stats.revenue.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })],
      ['Clientes', String(stats.customers)],
      ['Cupons Ativos', String(stats.coupons)],
      ['Pedidos Pendentes', String(stats.pendingOrders)],
      [],
      ['Pedido', 'Cliente', 'Total', 'Status', 'Data'],
      ...recentOrders.map(o => [
        o.order_number,
        o.customer_name || '',
        String(o.total_amount || 0),
        o.status,
        new Date(o.created_at).toLocaleDateString('pt-BR')
      ]),
    ];
    const csvContent = rows.map(r => r.map(c => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\n');
    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `dashboard-mundo-limpo-${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    setExporting(false);
    toast.success('Dados exportados em CSV');
  };

  const sparkData = salesData.length > 0 ? salesData : [0];

  const totalOrders = stats.orders || 1;
  const statusPercent = (status: string) =>
    orderStatusCounts[status] ? Math.round((orderStatusCounts[status] / totalOrders) * 100) : 0;

  /* ─── Módulos Principais ─── */
  const MODULE_CARDS = [
    { label: 'Pedidos', icon: ShoppingCart, path: '/admin/pedidos', color: 'bg-primary/10 text-primary hover:bg-primary/20', desc: 'Gestão de vendas' },
    { label: 'Produtos', icon: Package, path: '/admin/produtos', color: 'bg-accent/10 text-accent hover:bg-accent/20', desc: 'Catálogo e estoque' },
    { label: 'Relatórios', icon: BarChart3, path: '/admin/relatorios', color: 'bg-success/10 text-success hover:bg-success/20', desc: 'Análise e métricas' },
    { label: 'Cupons', icon: Ticket, path: '/admin/cupons', color: 'bg-info/10 text-info hover:bg-info/20', desc: 'Promoções e descontos' },
    { label: 'Banners', icon: ImageIcon, path: '/admin/banners', color: 'bg-warning/10 text-warning hover:bg-warning/20', desc: 'Marketing visual' },
    { label: 'Inauguração', icon: PartyPopper, path: '/admin/banner-inauguracao', color: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400 hover:bg-emerald-200/50', desc: 'Banner de lançamento' },
    { label: 'Entregas', icon: Truck, path: '/admin/entregas', color: 'bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-400 hover:bg-rose-200/50', desc: 'Frete e logística' },
    { label: 'Configurações', icon: Settings, path: '/admin/configuracoes', color: 'bg-muted text-muted-foreground hover:bg-muted/80', desc: 'Geral e integrações' },
  ];

  const rechartsBarData = useMemo(() =>
    salesLabels.map((label, i) => ({ name: label, vendas: salesData[i] || 0 })),
    [salesLabels, salesData]
  );

  return (
    <AdminLayout title="Dashboard" subtitle="Visão geral da sua loja">
      <div className="space-y-6">

        {/* Export Button */}
        <div className="flex justify-end">
          <Button variant="outline" size="sm" onClick={handleExportCSV} disabled={exporting || loading} className="gap-1.5 h-8 text-xs">
            {exporting ? <Zap className="h-3.5 w-3.5 animate-spin" /> : <Download className="h-3.5 w-3.5" />}
            Exportar CSV
          </Button>
        </div>

        {/* KPI Cards - Row 1 */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <Link to="/admin/pedidos">
            <StatCard title="Total Pedidos" value={stats.orders} icon={ShoppingCart} color="primary" loading={loading}
              trend={stats.newOrdersToday > 0 ? `${stats.newOrdersToday} hoje` : undefined} trendUp={true} />
          </Link>
          <Link to="/admin/produtos">
            <StatCard title="Produtos Ativos" value={stats.products} icon={Package} color="accent" loading={loading} />
          </Link>
          <Link to="/admin/relatorios">
            <StatCard title="Receita Total" value={stats.revenue.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })} icon={TrendingUp} color="success" loading={loading}
              trend={stats.revenueToday > 0 ? `${stats.revenueToday.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })} hoje` : undefined} trendUp={true} />
          </Link>
          <Link to="/admin/categorias">
            <StatCard title="Categorias" value={stats.categories} icon={Tag} color="info" loading={loading} />
          </Link>
        </div>

        {/* KPI Cards - Row 2 */}
        <div className="grid grid-cols-2 gap-4">
          <Link to="/admin/pedidos">
            <StatCard title="Clientes" value={stats.customers} icon={Users} color="info" loading={loading}
              trend={stats.customers > 0 ? 'cadastrados' : undefined} trendUp={false} />
          </Link>
          <Link to="/admin/cupons">
            <StatCard title="Cupons Ativos" value={stats.coupons} icon={Percent} color="warning" loading={loading} />
          </Link>
        </div>

        {/* Charts Row: Sales Period + Category + Status */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          {/* Sales by Period Chart */}
          <Card className="lg:col-span-2 card-hover">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-base flex items-center gap-2">
                    <TrendingUp className="h-4 w-4 text-primary" />
                    Vendas por Período
                  </CardTitle>
                  <CardDescription>Total: {salesData.reduce((a, b) => a + b, 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</CardDescription>
                </div>
                <Select value={periodDays} onValueChange={setPeriodDays}>
                  <SelectTrigger className="w-[150px] h-8 text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {PERIOD_OPTIONS.map(o => <SelectItem key={o.value} value={o.value} className="text-xs">{o.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="h-52 flex items-center justify-center">
                  <Skeleton className="h-44 w-full bg-muted" />
                </div>
              ) : salesData.every(v => v === 0) ? (
                <div className="h-52 flex items-center justify-center text-sm text-muted-foreground">Nenhuma venda no período</div>
              ) : (
                <div className="w-full min-w-0 overflow-hidden">
                  <ResponsiveContainer width="100%" height={220}>
                    <ReBarChart data={rechartsBarData} margin={{ top: 8, right: 8, left: -15, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                      <XAxis dataKey="name" tick={{ fontSize: 10 }} axisLine={false} tickLine={false} />
                      <YAxis tick={{ fontSize: 10 }} axisLine={false} tickLine={false} tickFormatter={v => `R${(v / 1000).toFixed(0)}k`} />
                      <ReTooltip
                        formatter={(value: number) => [value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }), 'Vendas']}
                        contentStyle={{ fontSize: 12, borderRadius: 8, border: '1px solid hsl(var(--border))' }}
                      />
                      <Bar dataKey="vendas" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                    </ReBarChart>
                  </ResponsiveContainer>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Status de Pedidos */}
          <Card className="card-hover">
            <CardHeader className="pb-2">
              <CardTitle className="text-base flex items-center gap-2">
                <BarChart3 className="h-4 w-4 text-info" />
                Status dos Pedidos
              </CardTitle>
              <CardDescription>Distribuição dos pedidos por status</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {loading ? (
                <div className="space-y-2">{[...Array(5)].map((_, i) => <Skeleton key={i} className="h-6 bg-muted" />)}</div>
              ) : stats.orders === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-4">Nenhum pedido registrado</p>
              ) : (
                <>
                  {(['pending', 'processing', 'shipped', 'completed', 'cancelled'] as OrderStatus[]).map(status => {
                    const count = orderStatusCounts[status] || 0;
                    if (count === 0) return null;
                    const s = STATUS_CONFIG[status];
                    const pct = statusPercent(status);
                    return (
                      <div key={status} className="space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-medium">{s.label}</span>
                          <span className="text-xs text-muted-foreground">{count} ({pct}%)</span>
                        </div>
                        <Progress value={pct} className="h-1.5" />
                      </div>
                    );
                  })}
                </>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Category Sales Chart */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          <Card className="card-hover">
            <CardHeader className="pb-2">
              <CardTitle className="text-base flex items-center gap-2">
                <PieChart className="h-4 w-4 text-accent" />
                Vendas por Categoria
              </CardTitle>
              <CardDescription>Quantidade de itens vendidos por categoria</CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="h-48 flex items-center justify-center">
                  <Skeleton className="h-40 w-40 rounded-full bg-muted" />
                </div>
              ) : categoryData.length === 0 ? (
                <div className="h-48 flex items-center justify-center text-sm text-muted-foreground">Nenhuma venda por categoria</div>
              ) : (
                <div className="w-full min-w-0 overflow-hidden flex flex-col md:flex-row items-center gap-4">
                  <div className="w-full md:w-1/2 h-52">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={categoryData}
                          cx="50%" cy="50%"
                          innerRadius={50} outerRadius={80}
                          paddingAngle={3}
                          dataKey="value"
                        >
                          {categoryData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <ReTooltip formatter={(value: number) => [`${value} itens`, 'Qtd']} />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="w-full md:w-1/2 space-y-2">
                    {categoryData.map(cat => (
                      <div key={cat.name} className="flex items-center gap-2">
                        <div className="h-3 w-3 rounded-full shrink-0" style={{ backgroundColor: cat.color }} />
                        <span className="text-xs text-muted-foreground flex-1 min-w-0 truncate">{cat.name}</span>
                        <span className="text-xs font-semibold">{cat.value}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Sparkline Fallback / Mini Chart */}
          <Card className="card-hover">
            <CardHeader className="pb-2">
              <CardTitle className="text-base flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-primary" />
                Tendência de Vendas
              </CardTitle>
              <CardDescription>Evolução diária no período selecionado</CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="h-48 flex items-center justify-center">
                  <Skeleton className="h-32 w-full bg-muted" />
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="flex justify-center">
                    <SparklineChart data={sparkData} width={300} height={70} />
                  </div>
                  <div className="grid grid-cols-7 gap-1 text-center">
                    {salesLabels.slice(-7).map((label, i) => {
                      const idx = salesData.length - 7 + i;
                      const val = idx >= 0 ? salesData[idx] : 0;
                      return (
                        <div key={i} className="min-w-0">
                          <p className="text-[10px] text-muted-foreground truncate">{label.split(' ')[0]}</p>
                          <p className="text-[11px] font-semibold text-foreground">
                            {val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', minimumFractionDigits: 0 })}
                          </p>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Ações Rápidas */}
        <Card className="card-hover">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Ações Rápidas</CardTitle>
            <CardDescription>Atalhos para tarefas do dia a dia</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-2">
              {QUICK_ACTIONS.map(action => (
                <Link key={action.path} to={action.path} className="group">
                  <div className={`flex flex-col items-center justify-center gap-1.5 p-3 rounded-xl ${action.color} bg-opacity-10 hover:bg-opacity-20 transition-all text-center`}>
                    <action.icon className="h-5 w-5" />
                    <span className="text-[11px] font-medium leading-tight">{action.label}</span>
                  </div>
                </Link>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Módulos Principais */}
        <Card className="card-hover">
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Store className="h-4 w-4 text-primary" />
              Módulos da Loja
            </CardTitle>
            <CardDescription>Acesse rapidamente cada área do sistema</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {MODULE_CARDS.map(mod => (
                <Link key={mod.path} to={mod.path} className="group">
                  <div className={`flex items-center gap-3 p-3 rounded-xl ${mod.color} transition-all border border-transparent`}>
                    <div className="h-9 w-9 rounded-lg bg-white/60 dark:bg-white/10 flex items-center justify-center shrink-0">
                      <mod.icon className="h-4.5 w-4.5" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm font-semibold leading-tight">{mod.label}</p>
                      <p className="text-[11px] opacity-70">{mod.desc}</p>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Bottom Row: Recent Orders + Alerts + Low Stock */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          {/* Recent Orders */}
          <Card className="lg:col-span-2 card-hover">
            <CardHeader className="pb-3 flex flex-row items-center justify-between">
              <CardTitle className="text-base flex items-center gap-2">
                <Receipt className="h-4 w-4 text-primary" />
                Pedidos Recentes
              </CardTitle>
              <Link to="/admin/pedidos">
                <Button variant="ghost" size="sm" className="h-8 text-xs">
                  Ver todos <ChevronRight className="h-3.5 w-3.5 ml-1" />
                </Button>
              </Link>
            </CardHeader>
            <CardContent className="p-0">
              {loading ? (
                <div className="p-5 space-y-3">{[...Array(5)].map((_, i) => <Skeleton key={i} className="h-10 bg-muted" />)}</div>
              ) : recentOrders.length === 0 ? (
                <div className="p-8 text-center text-muted-foreground text-sm">Nenhum pedido ainda</div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full min-w-max">
                    <thead>
                      <tr className="border-b border-border bg-muted/40">
                        {['Pedido', 'Cliente', 'Total', 'Status', 'Data'].map(h => (
                          <th key={h} className="text-left px-4 py-3 text-[11px] font-semibold text-muted-foreground uppercase tracking-wide whitespace-nowrap">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {recentOrders.map(order => {
                        const s = STATUS_CONFIG[order.status] || { label: order.status, variant: 'status-badge-muted' };
                        return (
                          <tr key={order.id} className="border-b border-border last:border-0 hover:bg-muted/30 transition-colors">
                            <td className="px-4 py-3 text-sm font-mono whitespace-nowrap">{order.order_number}</td>
                            <td className="px-4 py-3 text-sm text-muted-foreground whitespace-nowrap">{order.customer_name || '—'}</td>
                            <td className="px-4 py-3 text-sm font-medium whitespace-nowrap">{order.total_amount?.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</td>
                            <td className="px-4 py-3 whitespace-nowrap"><span className={s.variant}>{s.label}</span></td>
                            <td className="px-4 py-3 text-xs text-muted-foreground whitespace-nowrap">{new Date(order.created_at).toLocaleDateString('pt-BR')}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Right Column: Alerts + Low Stock */}
          <div className="space-y-5">
            {/* Status Summary */}
            <Card className="card-hover">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4 text-warning" />
                  Status da Loja
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {stats.pendingOrders > 0 ? (
                  <Link to="/admin/pedidos">
                    <div className="flex items-center gap-3 p-3 rounded-lg bg-warning/8 border border-warning/20 hover:bg-warning/12 transition-colors">
                      <div className="h-9 w-9 rounded-lg bg-warning/15 flex items-center justify-center shrink-0">
                        <Clock className="h-4 w-4 text-warning" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-foreground">{stats.pendingOrders} pedido(s) pendente(s)</p>
                        <p className="text-xs text-muted-foreground">Precisam de atenção</p>
                      </div>
                      <ChevronRight className="h-4 w-4 text-muted-foreground shrink-0" />
                    </div>
                  </Link>
                ) : (
                  <div className="flex items-center gap-3 p-3 rounded-lg bg-success/8 border border-success/20">
                    <div className="h-9 w-9 rounded-lg bg-success/15 flex items-center justify-center shrink-0">
                      <TrendingUp className="h-4 w-4 text-success" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-foreground">Tudo em ordem</p>
                      <p className="text-xs text-muted-foreground">Sem pendências no momento</p>
                    </div>
                  </div>
                )}


              </CardContent>
            </Card>

            {/* Open PDV */}
            <Link to="/pdv">
              <Card className="bg-primary hover:bg-primary/90 transition-colors cursor-pointer border-0 shadow-lg shadow-primary/20">
                <CardContent className="p-4">
                  <div className="flex items-center gap-4">
                    <div className="h-10 w-10 rounded-xl bg-primary-foreground/20 flex items-center justify-center shrink-0">
                      <MonitorSmartphone className="h-5 w-5 text-primary-foreground" />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-primary-foreground">Abrir PDV</p>
                      <p className="text-xs text-primary-foreground/80">Acesso rápido ao ponto de venda</p>
                    </div>
                    <Zap className="h-5 w-5 text-primary-foreground/60 ml-auto shrink-0" />
                  </div>
                </CardContent>
              </Card>
            </Link>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}
