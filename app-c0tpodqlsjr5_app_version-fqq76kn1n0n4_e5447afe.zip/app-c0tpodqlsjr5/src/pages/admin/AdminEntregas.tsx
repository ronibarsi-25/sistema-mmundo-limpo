import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import {
  Truck, Plus, Pencil, Trash2, Save, Loader2, Package, MapPin,
  ToggleLeft, ToggleRight, AlertCircle, CheckCircle2, Gift, Clock
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AdminLayout } from '@/components/layouts/AdminLayout';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import type { StoreSettings, ShippingMethod } from '@/types/types';

interface MethodForm {
  name: string;
  type: 'fixed' | 'free' | 'correios_pac' | 'correios_sedex';
  price: number;
  min_days: number;
  max_days: number;
}

const TYPE_LABELS: Record<string, { label: string; color: string }> = {
  fixed:          { label: 'Fixo',          color: 'bg-info/15 text-info-foreground' },
  free:           { label: 'Grátis',        color: 'bg-success/15 text-success' },
  correios_pac:   { label: 'PAC (Correios)',   color: 'bg-primary/15 text-primary' },
  correios_sedex: { label: 'SEDEX (Correios)', color: 'bg-accent/15 text-accent-foreground' },
};

export default function AdminEntregas() {
  const [settings, setSettings] = useState<StoreSettings | null>(null);
  const [methods, setMethods] = useState<ShippingMethod[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingMethod, setEditingMethod] = useState<ShippingMethod | null>(null);
  const [testCep, setTestCep] = useState('');
  const [testLoading, setTestLoading] = useState(false);
  const [testResult, setTestResult] = useState<{ name: string; price: number; min_days: number; max_days: number; error?: string }[]>([]);

  const settingsForm = useForm<Partial<StoreSettings>>();
  const methodForm = useForm<MethodForm>({ defaultValues: { type: 'fixed', price: 0, min_days: 1, max_days: 7 } });

  useEffect(() => {
    Promise.all([
      supabase.from('store_settings').select('*').limit(1).maybeSingle(),
      supabase.from('shipping_methods').select('*').order('sort_order'),
    ]).then(([sRes, mRes]) => {
      if (sRes.data) {
        setSettings(sRes.data as StoreSettings);
        settingsForm.reset(sRes.data as Partial<StoreSettings>);
      }
      if (mRes.data) setMethods(mRes.data as ShippingMethod[]);
      setLoading(false);
    });
  }, []);

  const saveSettings = async (data: Partial<StoreSettings>) => {
    setSaving(true);
    const { error } = await supabase
      .from('store_settings')
      .update({
        correios_cep_origin: data.correios_cep_origin,
        correios_contract: data.correios_contract,
        correios_password: data.correios_password,
        correios_pac_enabled: data.correios_pac_enabled,
        correios_sedex_enabled: data.correios_sedex_enabled,
        free_shipping_threshold: data.free_shipping_threshold || null,
        default_weight_kg: data.default_weight_kg || 0.5,
        default_length_cm: data.default_length_cm || 20,
        default_width_cm: data.default_width_cm || 15,
        default_height_cm: data.default_height_cm || 10,
      })
      .eq('id', settings?.id || 1);

    if (error) { toast.error('Erro ao salvar configurações'); }
    else { toast.success('Configurações de entrega salvas!'); }
    setSaving(false);
  };

  const openNew = () => {
    setEditingMethod(null);
    methodForm.reset({ type: 'fixed', price: 0, min_days: 1, max_days: 7 });
    setDialogOpen(true);
  };

  const openEdit = (m: ShippingMethod) => {
    setEditingMethod(m);
    methodForm.reset({ name: m.name, type: m.type as MethodForm['type'], price: m.price, min_days: m.min_days, max_days: m.max_days });
    setDialogOpen(true);
  };

  const saveMethod = async (data: MethodForm) => {
    const isCorreios = data.type.startsWith('correios');
    const payload = {
      name: data.name,
      carrier: isCorreios ? 'correios' : 'custom',
      code: data.type === 'correios_pac' ? '04669' : data.type === 'correios_sedex' ? '04162' : null,
      type: data.type,
      price: isCorreios ? 0 : data.price,
      min_days: data.min_days,
      max_days: data.max_days,
    };

    if (editingMethod) {
      const { error } = await supabase.from('shipping_methods').update(payload).eq('id', editingMethod.id);
      if (error) { toast.error('Erro ao salvar método'); return; }
      setMethods(prev => prev.map(m => m.id === editingMethod.id ? { ...m, ...payload } : m));
    } else {
      const { data: created, error } = await supabase.from('shipping_methods').insert({ ...payload, sort_order: methods.length }).select().single();
      if (error || !created) { toast.error('Erro ao criar método'); return; }
      setMethods(prev => [...prev, created as ShippingMethod]);
    }
    toast.success(editingMethod ? 'Método atualizado!' : 'Método criado!');
    setDialogOpen(false);
  };

  const toggleMethod = async (m: ShippingMethod) => {
    const { error } = await supabase.from('shipping_methods').update({ is_active: !m.is_active }).eq('id', m.id);
    if (error) { toast.error('Erro'); return; }
    setMethods(prev => prev.map(x => x.id === m.id ? { ...x, is_active: !x.is_active } : x));
  };

  const deleteMethod = async (id: string) => {
    const { error } = await supabase.from('shipping_methods').delete().eq('id', id);
    if (error) { toast.error('Erro ao excluir'); return; }
    setMethods(prev => prev.filter(m => m.id !== id));
    toast.success('Método excluído');
  };

  const testShipping = async () => {
    const cep = testCep.replace(/\D/g, '');
    if (cep.length !== 8) { toast.error('CEP inválido'); return; }
    const origin = settingsForm.getValues('correios_cep_origin')?.replace(/\D/g, '');
    if (!origin || origin.length !== 8) { toast.error('Configure o CEP de origem primeiro'); return; }

    setTestLoading(true);
    setTestResult([]);
    try {
      const { data, error } = await supabase.functions.invoke('calculate-shipping', {
        body: {
          cep_origin: origin,
          cep_destiny: cep,
          weight_kg: settingsForm.getValues('default_weight_kg') || 0.5,
          length_cm: settingsForm.getValues('default_length_cm') || 20,
          width_cm: settingsForm.getValues('default_width_cm') || 15,
          height_cm: settingsForm.getValues('default_height_cm') || 10,
        },
      });
      if (error) throw error;
      setTestResult(data?.options || []);
    } catch {
      toast.error('Erro ao calcular frete. Verifique o CEP e tente novamente.');
    } finally {
      setTestLoading(false);
    }
  };

  const watchType = methodForm.watch('type');

  if (loading) {
    return (
      <AdminLayout title="Entregas">
        <div className="flex items-center justify-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout title="Entregas & Frete">
      <div className="space-y-6">

        {/* Configurações Correios */}
        <form onSubmit={settingsForm.handleSubmit(saveSettings)}>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Package className="h-5 w-5 text-primary" />
                Configurações dos Correios
              </CardTitle>
              <CardDescription>
                Configure o CEP de origem e as credenciais para calcular PAC e SEDEX automaticamente.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-5">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>CEP de Origem *</Label>
                  <Input
                    placeholder="00000-000"
                    {...settingsForm.register('correios_cep_origin')}
                  />
                  <p className="text-xs text-muted-foreground">CEP do local de despacho dos produtos</p>
                </div>
                <div className="space-y-2">
                  <Label>Frete Grátis acima de (R$)</Label>
                  <Input
                    type="number"
                    step="0.01"
                    min="0"
                    placeholder="Ex: 150.00"
                    {...settingsForm.register('free_shipping_threshold', { valueAsNumber: true })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Código do Contrato (opcional)</Label>
                  <Input placeholder="Contrato Correios" {...settingsForm.register('correios_contract')} />
                </div>
                <div className="space-y-2">
                  <Label>Senha do Contrato (opcional)</Label>
                  <Input type="password" placeholder="••••••••" {...settingsForm.register('correios_password')} />
                </div>
              </div>

              <Separator />
              <p className="text-sm font-medium">Dimensões e peso padrão do pacote</p>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="space-y-2">
                  <Label>Peso (kg)</Label>
                  <Input type="number" step="0.001" min="0.1" {...settingsForm.register('default_weight_kg', { valueAsNumber: true })} />
                </div>
                <div className="space-y-2">
                  <Label>Comprimento (cm)</Label>
                  <Input type="number" min="1" {...settingsForm.register('default_length_cm', { valueAsNumber: true })} />
                </div>
                <div className="space-y-2">
                  <Label>Largura (cm)</Label>
                  <Input type="number" min="1" {...settingsForm.register('default_width_cm', { valueAsNumber: true })} />
                </div>
                <div className="space-y-2">
                  <Label>Altura (cm)</Label>
                  <Input type="number" min="1" {...settingsForm.register('default_height_cm', { valueAsNumber: true })} />
                </div>
              </div>

              <Separator />
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex items-center justify-between sm:gap-4 p-3 border border-border rounded-lg flex-1">
                  <div>
                    <p className="text-sm font-medium">PAC ativo</p>
                    <p className="text-xs text-muted-foreground">Econômico, entrega em 5–10 dias</p>
                  </div>
                  <Switch {...settingsForm.register('correios_pac_enabled')} defaultChecked={settings?.correios_pac_enabled ?? true} />
                </div>
                <div className="flex items-center justify-between sm:gap-4 p-3 border border-border rounded-lg flex-1">
                  <div>
                    <p className="text-sm font-medium">SEDEX ativo</p>
                    <p className="text-xs text-muted-foreground">Expresso, entrega em 1–3 dias</p>
                  </div>
                  <Switch {...settingsForm.register('correios_sedex_enabled')} defaultChecked={settings?.correios_sedex_enabled ?? true} />
                </div>
              </div>

              <div className="flex justify-end">
                <Button type="submit" disabled={saving}>
                  {saving ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Save className="h-4 w-4 mr-2" />}
                  Salvar Configurações
                </Button>
              </div>
            </CardContent>
          </Card>
        </form>

        {/* Teste de frete */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <MapPin className="h-4 w-4 text-primary" />
              Testar Cálculo de Frete
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-3">
              <Input
                placeholder="CEP de destino para teste"
                value={testCep}
                onChange={e => setTestCep(e.target.value)}
                className="max-w-xs"
              />
              <Button type="button" onClick={testShipping} disabled={testLoading}>
                {testLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Calcular'}
              </Button>
            </div>
            {testResult.length > 0 && (
              <div className="mt-4 space-y-2">
                {testResult.map(r => (
                  <div key={r.name} className={`flex items-center justify-between p-3 rounded-lg border ${r.error ? 'border-destructive/30 bg-destructive/5' : 'border-border bg-muted/40'}`}>
                    <div className="flex items-center gap-2">
                      {r.error ? <AlertCircle className="h-4 w-4 text-destructive" /> : <CheckCircle2 className="h-4 w-4 text-success" />}
                      <div>
                        <p className="text-sm font-medium">{r.name}</p>
                        {r.error ? <p className="text-xs text-destructive">{r.error}</p>
                          : <p className="text-xs text-muted-foreground">{r.min_days}–{r.max_days} dias úteis</p>}
                      </div>
                    </div>
                    {!r.error && <p className="font-semibold text-sm">{r.price.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</p>}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Métodos personalizados */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Truck className="h-5 w-5 text-primary" />
                Métodos de Entrega
              </CardTitle>
              <CardDescription>Adicione fretes fixos, grátis ou personalizados</CardDescription>
            </div>
            <Button size="sm" onClick={openNew}>
              <Plus className="h-4 w-4 mr-1" /> Novo
            </Button>
          </CardHeader>
          <CardContent>
            {methods.length === 0 ? (
              <div className="text-center py-10 text-muted-foreground text-sm">
                Nenhum método cadastrado além dos Correios automáticos.
              </div>
            ) : (
              <div className="space-y-2">
                {methods.map(m => {
                  const info = TYPE_LABELS[m.type] || { label: m.type, color: 'bg-muted text-muted-foreground' };
                  return (
                    <div key={m.id} className={`flex items-center gap-3 p-3 rounded-lg border border-border transition-opacity ${m.is_active ? '' : 'opacity-50'}`}>
                      <button onClick={() => toggleMethod(m)} className="shrink-0 text-muted-foreground hover:text-foreground transition-colors">
                        {m.is_active ? <ToggleRight className="h-5 w-5 text-success" /> : <ToggleLeft className="h-5 w-5" />}
                      </button>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <p className="text-sm font-medium">{m.name}</p>
                          <Badge className={`text-[10px] ${info.color}`}>{info.label}</Badge>
                        </div>
                        <p className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
                          <Clock className="h-3 w-3" /> {m.min_days}–{m.max_days} dias
                        </p>
                      </div>
                      <div className="shrink-0 text-right">
                        {m.type === 'free' || m.type === 'correios_pac' || m.type === 'correios_sedex'
                          ? <span className="text-sm font-semibold text-success flex items-center gap-1"><Gift className="h-3.5 w-3.5" /> Calculado</span>
                          : <p className="text-sm font-semibold">{m.price.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</p>
                        }
                      </div>
                      <Button size="icon" variant="ghost" className="shrink-0 h-8 w-8" onClick={() => openEdit(m)}>
                        <Pencil className="h-3.5 w-3.5" />
                      </Button>
                      <Button size="icon" variant="ghost" className="shrink-0 h-8 w-8 text-destructive hover:text-destructive" onClick={() => deleteMethod(m.id)}>
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Dialog novo/editar método */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingMethod ? 'Editar Método' : 'Novo Método de Entrega'}</DialogTitle>
          </DialogHeader>
          <form onSubmit={methodForm.handleSubmit(saveMethod)} className="space-y-4 py-2">
            <div className="space-y-2">
              <Label>Nome</Label>
              <Input placeholder="Ex: Motoboy SP" {...methodForm.register('name', { required: true })} />
            </div>
            <div className="space-y-2">
              <Label>Tipo</Label>
              <Select
                value={watchType}
                onValueChange={v => methodForm.setValue('type', v as MethodForm['type'])}
              >
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="fixed">Frete Fixo</SelectItem>
                  <SelectItem value="free">Grátis</SelectItem>
                  <SelectItem value="correios_pac">PAC (Correios calculado)</SelectItem>
                  <SelectItem value="correios_sedex">SEDEX (Correios calculado)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {watchType === 'fixed' && (
              <div className="space-y-2">
                <Label>Preço (R$)</Label>
                <Input type="number" step="0.01" min="0" {...methodForm.register('price', { valueAsNumber: true })} />
              </div>
            )}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Prazo mínimo (dias)</Label>
                <Input type="number" min="1" {...methodForm.register('min_days', { valueAsNumber: true })} />
              </div>
              <div className="space-y-2">
                <Label>Prazo máximo (dias)</Label>
                <Input type="number" min="1" {...methodForm.register('max_days', { valueAsNumber: true })} />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>Cancelar</Button>
              <Button type="submit">Salvar</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
}
