import { useState } from 'react';
import { Download, Loader2, FileSpreadsheet } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { AdminLayout } from '@/components/layouts/AdminLayout';
import { supabase } from '@/db/supabase';
import { exportToCsv } from '@/lib/export';
import { toast } from 'sonner';

const EXPORT_OPTIONS = [
  { key: 'products', label: 'Produtos', desc: 'Exporta todos os produtos do site' },
  { key: 'orders', label: 'Vendas', desc: 'Exporta todos os pedidos' },
  { key: 'stock', label: 'Estoque', desc: 'Exporta produtos com quantidade em estoque' },
  { key: 'movements', label: 'Movimentações', desc: 'Exporta histórico de movimentações' },
  { key: 'customers', label: 'Clientes', desc: 'Exporta perfis de clientes' },
];

export default function AdminExportData() {
  const [loading, setLoading] = useState<string | null>(null);

  const handleExport = async (key: string) => {
    setLoading(key);
    try {
      let rows: Record<string, unknown>[] = [];
      switch (key) {
        case 'products': {
          const { data } = await supabase.from('products').select('id, code, name, slug, price, cost_price, stock_quantity, is_available, barcode, unit, brand, sku, created_at').limit(5000);
          rows = (data || []).map(p => ({
            ID: p.id,
            Codigo: p.code,
            Nome: p.name,
            Slug: p.slug,
            Preco_Venda: p.price,
            Preco_Custo: p.cost_price,
            Estoque: p.stock_quantity,
            Ativo: p.is_available ? 'Sim' : 'Nao',
            Codigo_Barras: p.barcode,
            Unidade: p.unit,
            Marca: p.brand,
            SKU: p.sku,
            Criado_Em: p.created_at,
          }));
          break;
        }
        case 'orders': {
          const { data } = await supabase.from('orders').select('id, status, total_amount, customer_name, customer_email, created_at').limit(5000);
          rows = (data || []).map(o => ({
            ID: o.id,
            Status: o.status,
            Total: o.total_amount,
            Cliente: o.customer_name,
            Email: o.customer_email,
            Data: o.created_at,
          }));
          break;
        }
        case 'stock': {
          const { data } = await supabase.from('products').select('id, code, name, stock_quantity, cost_price, price, is_available').limit(5000);
          rows = (data || []).map(p => ({
            ID: p.id,
            Codigo: p.code,
            Nome: p.name,
            Estoque: p.stock_quantity,
            Custo: p.cost_price,
            Preco: p.price,
            Valor_Total: (p.cost_price || 0) * (p.stock_quantity || 0),
            Ativo: p.is_available ? 'Sim' : 'Nao',
          }));
          break;
        }
        case 'movements': {
          const { data } = await supabase.from('stock_movements').select('id, product_id, type, quantity, notes, created_at').limit(5000);
          rows = (data || []).map(m => ({
            ID: m.id,
            Produto_ID: m.product_id,
            Tipo: m.type,
            Quantidade: m.quantity,
            Observacao: m.notes,
            Data: m.created_at,
          }));
          break;
        }
        case 'customers': {
          const { data } = await supabase.from('profiles').select('id, full_name, email, phone, role, created_at').limit(5000);
          rows = (data || []).map(c => ({
            ID: c.id,
            Nome: c.full_name,
            Email: c.email,
            Telefone: c.phone,
            Perfil: c.role,
            Cadastro: c.created_at,
          }));
          break;
        }
      }
      if (!rows.length) {
        toast.info('Nenhum dado encontrado para exportar');
      } else {
        exportToCsv(`export_${key}`, rows);
        toast.success(`${rows.length} registros exportados`);
      }
    } catch (err) {
      toast.error('Erro ao exportar: ' + (err as Error).message);
    }
    setLoading(null);
  };

  return (
    <AdminLayout title="Exportar Dados" subtitle="Baixe relatórios em CSV">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-xl bg-accent/10 flex items-center justify-center">
            <FileSpreadsheet className="h-5 w-5 text-accent" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-foreground text-balance">Exportar Dados</h1>
            <p className="text-sm text-muted-foreground">Selecione o tipo de dados para exportar</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {EXPORT_OPTIONS.map(opt => (
            <Card key={opt.key} className="h-full flex flex-col">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">{opt.label}</CardTitle>
                <CardDescription>{opt.desc}</CardDescription>
              </CardHeader>
              <CardContent className="mt-auto pt-0">
                <Button
                  onClick={() => handleExport(opt.key)}
                  disabled={loading === opt.key}
                  className="w-full gap-2 h-9"
                  size="sm"
                >
                  {loading === opt.key ? <Loader2 className="h-4 w-4 animate-spin" /> : <Download className="h-4 w-4" />}
                  Exportar CSV
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </AdminLayout>
  );
}
