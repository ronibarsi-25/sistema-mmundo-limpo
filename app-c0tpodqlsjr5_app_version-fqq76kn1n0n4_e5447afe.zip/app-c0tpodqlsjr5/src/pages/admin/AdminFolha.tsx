import { useEffect, useState } from 'react';
import { Plus, FileDown, Wallet, Loader2, ChevronDown, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Separator } from '@/components/ui/separator';
import { AdminLayout } from '@/components/layouts/AdminLayout';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';

interface Employee { id: string; name: string; role: string; department: string; base_salary: number; status: string; }
interface PayrollEntry {
  id: string; employee_id: string; competence_month: number; competence_year: number;
  base_salary: number; overtime_hours: number; overtime_value: number;
  advance: number; transport_voucher: number;
  inss_discount: number; irrf_discount: number; other_discounts: number;
  gross_salary: number; net_salary: number; notes: string | null;
  employees?: { name: string; role: string; department: string } | null;
}

const MONTHS = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
const currentYear = new Date().getFullYear();
const YEARS = Array.from({ length: 5 }, (_, i) => currentYear - i);

// INSS table 2024
function calcINSS(gross: number): number {
  if (gross <= 1412.00) return gross * 0.075;
  if (gross <= 2666.68) return gross * 0.09;
  if (gross <= 4000.03) return gross * 0.12;
  if (gross <= 7786.02) return gross * 0.14;
  return 908.85;
}

// IRRF simplified (2024 table after INSS deduction)
function calcIRRF(base: number): number {
  if (base <= 2259.20) return 0;
  if (base <= 2826.65) return base * 0.075 - 169.44;
  if (base <= 3751.05) return base * 0.15 - 381.44;
  if (base <= 4664.68) return base * 0.225 - 662.77;
  return base * 0.275 - 896.00;
}

const emptyForm = {
  employee_id: '', competence_month: new Date().getMonth() + 1, competence_year: currentYear,
  overtime_hours: '0', overtime_value: '0',
  advance: '0', transport_voucher: '0', other_discounts: '0', notes: '',
};

export default function AdminFolha() {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [entries, setEntries] = useState<PayrollEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [showDialog, setShowDialog] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [submitting, setSubmitting] = useState(false);
  const [filterMonth, setFilterMonth] = useState(new Date().getMonth() + 1);
  const [filterYear, setFilterYear] = useState(currentYear);
  const [preview, setPreview] = useState<{ inss: number; irrf: number; gross: number; net: number } | null>(null);

  useEffect(() => { loadAll(); }, []);
  useEffect(() => { loadEntries(); }, [filterMonth, filterYear]);

  const loadAll = async () => {
    const { data } = await supabase.from('employees').select('id,name,role,department,base_salary,status').eq('status','active').order('name');
    setEmployees((data as Employee[]) || []);
    loadEntries();
  };

  const loadEntries = async () => {
    setLoading(true);
    const { data } = await supabase.from('payroll_entries')
      .select('*, employees(name,role,department)')
      .eq('competence_month', filterMonth)
      .eq('competence_year', filterYear)
      .order('created_at', { ascending: false });
    setEntries((data as PayrollEntry[]) || []);
    setLoading(false);
  };

  const f = (key: string, val: unknown) => {
    setForm(p => {
      const next = { ...p, [key]: val };
      // recalculate preview
      const emp = employees.find(e => e.id === next.employee_id);
      if (emp) {
        const gross = emp.base_salary + (parseFloat(String(next.overtime_value)) || 0);
        const inss = calcINSS(gross);
        const irrf = Math.max(0, calcIRRF(gross - inss));
        const net = gross - inss - irrf - (parseFloat(String(next.advance)) || 0)
          - (parseFloat(String(next.transport_voucher)) || 0) - (parseFloat(String(next.other_discounts)) || 0);
        setPreview({ inss, irrf, gross, net });
      } else { setPreview(null); }
      return next;
    });
  };

  const openDialog = () => { setForm(emptyForm); setPreview(null); setShowDialog(true); };

  const handleGenerate = async () => {
    if (!form.employee_id) { toast.error('Selecione um funcionário'); return; }
    const emp = employees.find(e => e.id === form.employee_id);
    if (!emp) return;
    setSubmitting(true);
    const gross = emp.base_salary + (parseFloat(form.overtime_value) || 0);
    const inss = calcINSS(gross);
    const irrf = Math.max(0, calcIRRF(gross - inss));
    const advance = parseFloat(form.advance) || 0;
    const vt = parseFloat(form.transport_voucher) || 0;
    const other = parseFloat(form.other_discounts) || 0;
    const net = gross - inss - irrf - advance - vt - other;
    const { error } = await supabase.from('payroll_entries').upsert({
      employee_id: form.employee_id,
      competence_month: form.competence_month, competence_year: form.competence_year,
      base_salary: emp.base_salary,
      overtime_hours: parseFloat(form.overtime_hours) || 0, overtime_value: parseFloat(form.overtime_value) || 0,
      advance, transport_voucher: vt, inss_discount: inss, irrf_discount: irrf, other_discounts: other,
      gross_salary: gross, net_salary: net, notes: form.notes || null,
    }, { onConflict: 'tenant_id,employee_id,competence_month,competence_year' });
    setSubmitting(false);
    if (error) { toast.error('Erro ao gerar folha: ' + error.message); return; }
    toast.success('Folha gerada com sucesso!');
    setShowDialog(false);
    loadEntries();
  };

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from('payroll_entries').delete().eq('id', id);
    if (error) toast.error('Erro ao remover entrada');
    else { toast.success('Entrada removida'); loadEntries(); }
  };

  // Generate full payroll for all active employees
  const handleGenerateAll = async () => {
    if (employees.length === 0) { toast.error('Sem funcionários ativos'); return; }
    setSubmitting(true);
    const rows = employees.map(emp => {
      const gross = emp.base_salary;
      const inss = calcINSS(gross);
      const irrf = Math.max(0, calcIRRF(gross - inss));
      return { employee_id: emp.id, competence_month: filterMonth, competence_year: filterYear,
        base_salary: emp.base_salary, overtime_hours: 0, overtime_value: 0,
        advance: 0, transport_voucher: 0, inss_discount: inss, irrf_discount: irrf, other_discounts: 0,
        gross_salary: gross, net_salary: gross - inss - irrf, notes: null };
    });
    const { error } = await supabase.from('payroll_entries').upsert(rows, { onConflict: 'tenant_id,employee_id,competence_month,competence_year' });
    setSubmitting(false);
    if (error) { toast.error('Erro ao gerar folha: ' + error.message); return; }
    toast.success(`Folha gerada para ${employees.length} funcionário(s)!`);
    loadEntries();
  };

  const totalGross = entries.reduce((s, e) => s + e.gross_salary, 0);
  const totalNet = entries.reduce((s, e) => s + e.net_salary, 0);
  const totalDiscounts = entries.reduce((s, e) => s + e.inss_discount + e.irrf_discount + e.other_discounts + e.advance + e.transport_voucher, 0);

  return (
    <AdminLayout title="Folha de Pagamento" subtitle="Geração e histórico de folhas mensais"
      breadcrumbs={[{ label: 'Admin', path: '/admin' }, { label: 'Folha de Pagamento' }]}>

      {/* Filters */}
      <div className="flex flex-col md:flex-row gap-3 mb-5">
        <Select value={String(filterMonth)} onValueChange={v => setFilterMonth(Number(v))}>
          <SelectTrigger className="w-full md:w-40 shrink-0"><SelectValue /></SelectTrigger>
          <SelectContent>{MONTHS.map((m, i) => <SelectItem key={i+1} value={String(i+1)}>{m}</SelectItem>)}</SelectContent>
        </Select>
        <Select value={String(filterYear)} onValueChange={v => setFilterYear(Number(v))}>
          <SelectTrigger className="w-full md:w-28 shrink-0"><SelectValue /></SelectTrigger>
          <SelectContent>{YEARS.map(y => <SelectItem key={y} value={String(y)}>{y}</SelectItem>)}</SelectContent>
        </Select>
        <div className="flex-1" />
        <Button variant="outline" size="sm" onClick={handleGenerateAll} disabled={submitting} className="shrink-0">
          {submitting ? <Loader2 className="h-4 w-4 mr-1.5 animate-spin" /> : <RefreshCwIcon />}
          Gerar Todos
        </Button>
        <Button size="sm" onClick={openDialog} className="shrink-0">
          <Plus className="h-4 w-4 mr-1.5" /> Individual
        </Button>
      </div>

      {/* Summary Cards */}
      {entries.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-5">
          <Card><CardContent className="p-4">
            <p className="text-xs text-muted-foreground uppercase font-semibold tracking-wide">Total Bruto</p>
            <p className="text-xl font-bold mt-1">{totalGross.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</p>
          </CardContent></Card>
          <Card><CardContent className="p-4">
            <p className="text-xs text-muted-foreground uppercase font-semibold tracking-wide">Descontos</p>
            <p className="text-xl font-bold mt-1 text-destructive">{totalDiscounts.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</p>
          </CardContent></Card>
          <Card><CardContent className="p-4">
            <p className="text-xs text-muted-foreground uppercase font-semibold tracking-wide">Total Líquido</p>
            <p className="text-xl font-bold mt-1 text-success">{totalNet.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</p>
          </CardContent></Card>
        </div>
      )}

      {/* Table */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm min-w-max">
            <thead>
              <tr className="border-b border-border bg-muted/40">
                {['Funcionário', 'Cargo', 'Salário Bruto', 'INSS', 'IRRF', 'VT', 'Adiant.', 'Outros', 'Salário Líquido', ''].map(h => (
                  <th key={h} className="text-left px-4 py-3 font-semibold text-muted-foreground uppercase text-[11px] tracking-wide whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {loading ? Array.from({ length: 4 }).map((_, i) => (
                <tr key={i}><td colSpan={10} className="px-4 py-3"><Skeleton className="h-5 w-full bg-muted" /></td></tr>
              )) : entries.length === 0 ? (
                <tr><td colSpan={10} className="text-center py-12 text-muted-foreground">
                  <Wallet className="h-8 w-8 mx-auto mb-2 opacity-30" />
                  <p>Nenhuma folha gerada para {MONTHS[filterMonth - 1]}/{filterYear}</p>
                </td></tr>
              ) : entries.map(e => (
                <tr key={e.id} className="hover:bg-muted/30 transition-colors">
                  <td className="px-4 py-3 font-medium whitespace-nowrap">{e.employees?.name || '—'}</td>
                  <td className="px-4 py-3 text-muted-foreground whitespace-nowrap text-xs">{e.employees?.role}</td>
                  <td className="px-4 py-3 font-semibold whitespace-nowrap">{e.gross_salary.toLocaleString('pt-BR',{style:'currency',currency:'BRL'})}</td>
                  <td className="px-4 py-3 text-destructive whitespace-nowrap">-{e.inss_discount.toLocaleString('pt-BR',{style:'currency',currency:'BRL'})}</td>
                  <td className="px-4 py-3 text-destructive whitespace-nowrap">-{e.irrf_discount.toLocaleString('pt-BR',{style:'currency',currency:'BRL'})}</td>
                  <td className="px-4 py-3 text-muted-foreground whitespace-nowrap">-{e.transport_voucher.toLocaleString('pt-BR',{style:'currency',currency:'BRL'})}</td>
                  <td className="px-4 py-3 text-muted-foreground whitespace-nowrap">-{e.advance.toLocaleString('pt-BR',{style:'currency',currency:'BRL'})}</td>
                  <td className="px-4 py-3 text-muted-foreground whitespace-nowrap">-{e.other_discounts.toLocaleString('pt-BR',{style:'currency',currency:'BRL'})}</td>
                  <td className="px-4 py-3 font-bold text-success whitespace-nowrap">{e.net_salary.toLocaleString('pt-BR',{style:'currency',currency:'BRL'})}</td>
                  <td className="px-4 py-3 whitespace-nowrap">
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive" onClick={() => handleDelete(e.id)}>
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg max-h-[90dvh] overflow-y-auto">
          <DialogHeader><DialogTitle>Gerar Folha Individual</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Funcionário *</Label>
              <Select value={form.employee_id} onValueChange={v => f('employee_id', v)}>
                <SelectTrigger><SelectValue placeholder="Selecionar funcionário" /></SelectTrigger>
                <SelectContent>{employees.map(e => <SelectItem key={e.id} value={e.id}>{e.name} — {e.role}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">Mês</Label>
                <Select value={String(form.competence_month)} onValueChange={v => f('competence_month', Number(v))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{MONTHS.map((m,i) => <SelectItem key={i+1} value={String(i+1)}>{m}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">Ano</Label>
                <Select value={String(form.competence_year)} onValueChange={v => f('competence_year', Number(v))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{YEARS.map(y => <SelectItem key={y} value={String(y)}>{y}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <Separator />
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">H. Extras</Label>
                <Input type="number" min="0" step="0.5" value={form.overtime_hours} onChange={e => f('overtime_hours', e.target.value)} placeholder="0" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">Valor H. Extras (R$)</Label>
                <Input type="number" min="0" step="0.01" value={form.overtime_value} onChange={e => f('overtime_value', e.target.value)} placeholder="0,00" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">Adiantamento (R$)</Label>
                <Input type="number" min="0" step="0.01" value={form.advance} onChange={e => f('advance', e.target.value)} placeholder="0,00" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">Vale Transporte (R$)</Label>
                <Input type="number" min="0" step="0.01" value={form.transport_voucher} onChange={e => f('transport_voucher', e.target.value)} placeholder="0,00" />
              </div>
              <div className="space-y-1.5 col-span-2">
                <Label className="text-sm font-normal">Outros Descontos (R$)</Label>
                <Input type="number" min="0" step="0.01" value={form.other_discounts} onChange={e => f('other_discounts', e.target.value)} placeholder="0,00" />
              </div>
            </div>
            {preview && (
              <>
                <Separator />
                <div className="bg-muted/40 rounded-lg p-4 space-y-2 text-sm">
                  <p className="font-semibold text-xs uppercase text-muted-foreground tracking-wide mb-3">Prévia do Cálculo</p>
                  <div className="flex justify-between"><span>Salário Bruto</span><span className="font-semibold">{preview.gross.toLocaleString('pt-BR',{style:'currency',currency:'BRL'})}</span></div>
                  <div className="flex justify-between text-destructive"><span>(-) INSS</span><span>{preview.inss.toLocaleString('pt-BR',{style:'currency',currency:'BRL'})}</span></div>
                  <div className="flex justify-between text-destructive"><span>(-) IRRF</span><span>{preview.irrf.toLocaleString('pt-BR',{style:'currency',currency:'BRL'})}</span></div>
                  <Separator />
                  <div className="flex justify-between text-success font-bold"><span>Salário Líquido</span><span>{preview.net.toLocaleString('pt-BR',{style:'currency',currency:'BRL'})}</span></div>
                </div>
              </>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDialog(false)}>Cancelar</Button>
            <Button onClick={handleGenerate} disabled={submitting}>
              {submitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />} Gerar Folha
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
}

function RefreshCwIcon() {
  return <svg className="h-4 w-4 mr-1.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/></svg>;
}
