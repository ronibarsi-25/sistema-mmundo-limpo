import { useState, useRef } from 'react';
import * as XLSX from 'xlsx';
import Papa from 'papaparse';
import {
  Upload, Download, CheckCircle2, XCircle, Loader2,
  FileSpreadsheet, AlertCircle, RefreshCw
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { AdminLayout } from '@/components/layouts/AdminLayout';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';

// ─── Tipos ──────────────────────────────────────────────────────────────────

interface RawProduct {
  nome: string;
  descricao?: string;
  preco: string;
  preco_original?: string;
  categoria?: string;
  estoque?: string;
  disponivel?: string;
  destaque?: string;
  imagem_url?: string;
}

interface RawCategory {
  nome: string;
  descricao?: string;
  imagem_url?: string;
  ativa?: string;
}

interface ImportRow<T> {
  data: T;
  status: 'pendente' | 'ok' | 'erro';
  mensagem?: string;
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

const toSlug = (str: string) =>
  str.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') + '-' + Date.now();

const toBool = (v?: string) => {
  if (!v) return true;
  return !['nao', 'não', 'false', '0', 'no'].includes(v.toLowerCase().trim());
};

const PRODUCT_HEADERS = ['nome', 'descricao', 'preco', 'preco_original', 'categoria', 'estoque', 'disponivel', 'destaque', 'imagem_url'];
const CATEGORY_HEADERS = ['nome', 'descricao', 'imagem_url', 'ativa'];

const downloadTemplate = (headers: string[], filename: string) => {
  const ws = XLSX.utils.aoa_to_sheet([headers]);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Modelo');
  XLSX.writeFile(wb, filename);
};

const parseFile = (file: File): Promise<Record<string, string>[]> => {
  return new Promise((resolve, reject) => {
    const ext = file.name.split('.').pop()?.toLowerCase();
    if (ext === 'csv') {
      Papa.parse(file, {
        header: true,
        skipEmptyLines: true,
        complete: (r) => resolve(r.data as Record<string, string>[]),
        error: reject
      });
    } else {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const wb = XLSX.read(e.target?.result, { type: 'binary' });
          const ws = wb.Sheets[wb.SheetNames[0]];
          resolve(XLSX.utils.sheet_to_json(ws, { defval: '' }) as Record<string, string>[]);
        } catch (err) { reject(err); }
      };
      reader.readAsBinaryString(file);
    }
  });
};

// ─── Componente de Upload ─────────────────────────────────────────────────────

interface DropZoneProps {
  onFile: (f: File) => void;
  disabled?: boolean;
}

function DropZone({ onFile, disabled }: DropZoneProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);

  const handle = (f: File | null | undefined) => {
    if (!f) return;
    const ext = f.name.split('.').pop()?.toLowerCase();
    if (!['csv', 'xlsx', 'xls'].includes(ext || '')) {
      toast.error('Formato inválido. Use CSV, XLSX ou XLS.');
      return;
    }
    onFile(f);
  };

  return (
    <div
      className={`border-2 border-dashed rounded-xl p-8 flex flex-col items-center gap-3 transition-colors cursor-pointer
        ${dragging ? 'border-primary bg-primary/5' : 'border-border bg-muted/30 hover:bg-muted/50'}
        ${disabled ? 'opacity-50 pointer-events-none' : ''}`}
      onDragOver={e => { e.preventDefault(); setDragging(true); }}
      onDragLeave={() => setDragging(false)}
      onDrop={e => { e.preventDefault(); setDragging(false); handle(e.dataTransfer.files[0]); }}
      onClick={() => inputRef.current?.click()}
    >
      <FileSpreadsheet className="h-10 w-10 text-muted-foreground" />
      <div className="text-center">
        <p className="text-sm font-medium text-foreground">Arraste o arquivo ou clique para selecionar</p>
        <p className="text-xs text-muted-foreground mt-1">Formatos aceitos: CSV, XLSX, XLS</p>
      </div>
      <input ref={inputRef} type="file" accept=".csv,.xlsx,.xls" className="hidden"
        onChange={e => handle(e.target.files?.[0])} />
    </div>
  );
}

// ─── Aba de Produtos ──────────────────────────────────────────────────────────

function ImportProducts() {
  const [rows, setRows] = useState<ImportRow<RawProduct>[]>([]);
  const [importing, setImporting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [done, setDone] = useState(false);

  const handleFile = async (file: File) => {
    setDone(false);
    setRows([]);
    try {
      const data = await parseFile(file);
      const parsed: ImportRow<RawProduct>[] = data.map((row) => {
        const nome = row['nome'] || row['Nome'] || row['name'] || '';
        const preco = row['preco'] || row['Preço'] || row['preco'] || row['price'] || '';
        if (!nome || !preco) return { data: row as unknown as RawProduct, status: 'erro', mensagem: 'Nome ou preço ausente' };
        if (isNaN(parseFloat(preco))) return { data: row as unknown as RawProduct, status: 'erro', mensagem: 'Preço inválido' };
        return {
          data: {
            nome,
            descricao: row['descricao'] || row['Descricao'] || row['description'] || '',
            preco,
            preco_original: row['preco_original'] || row['Preco Original'] || '',
            categoria: row['categoria'] || row['Categoria'] || row['category'] || '',
            estoque: row['estoque'] || row['Estoque'] || row['stock'] || '0',
            disponivel: row['disponivel'] || row['Disponivel'] || row['available'] || 'sim',
            destaque: row['destaque'] || row['Destaque'] || row['featured'] || 'nao',
            imagem_url: row['imagem_url'] || row['Imagem'] || row['image_url'] || '',
          },
          status: 'pendente'
        };
      });
      setRows(parsed);
    } catch {
      toast.error('Erro ao ler o arquivo. Verifique o formato.');
    }
  };

  const runImport = async () => {
    setImporting(true);
    setProgress(0);
    const updated = [...rows];

    // Buscar categorias existentes
    const { data: cats } = await supabase.from('categories').select('id,name');
    const catMap: Record<string, string> = {};
    (cats || []).forEach((c: any) => { catMap[c.name.toLowerCase()] = c.id; });

    let done = 0;
    for (let i = 0; i < updated.length; i++) {
      if (updated[i].status === 'erro') { done++; setProgress(Math.round((done / updated.length) * 100)); continue; }
      const r = updated[i].data;
      const catName = r.categoria?.toLowerCase().trim() || '';
      let catId: string | null = catMap[catName] || null;

      // Criar categoria automaticamente se não existir
      if (catName && !catId) {
        const slug = catName.replace(/[^a-z0-9]+/g, '-');
        const { data: newCat } = await supabase.from('categories').insert({ name: r.categoria, slug, is_active: true }).select('id').maybeSingle();
        if (newCat) { catId = newCat.id; catMap[catName] = catId!; }
      }

      const slug = toSlug(r.nome);
      const images = r.imagem_url ? [{ url: r.imagem_url, alt: r.nome }] : [];
      const { error } = await supabase.from('products').insert({
        name: r.nome,
        slug,
        description: r.descricao || null,
        price: parseFloat(r.preco),
        compare_at_price: r.preco_original ? parseFloat(r.preco_original) : null,
        category_id: catId,
        stock_quantity: parseInt(r.estoque || '0') || 0,
        is_available: toBool(r.disponivel),
        is_featured: !toBool(r.destaque) ? false : toBool(r.destaque),
        images,
        attributes: {}
      });

      updated[i] = error
        ? { ...updated[i], status: 'erro', mensagem: error.message }
        : { ...updated[i], status: 'ok' };
      done++;
      setProgress(Math.round((done / updated.length) * 100));
      setRows([...updated]);
    }

    const ok = updated.filter(r => r.status === 'ok').length;
    const errs = updated.filter(r => r.status === 'erro').length;
    toast.success(`Importação concluída: ${ok} produtos criados${errs ? `, ${errs} erros` : ''}`);
    setImporting(false);
    setDone(true);
  };

  const pendentes = rows.filter(r => r.status === 'pendente').length;
  const erros = rows.filter(r => r.status === 'erro').length;
  const ok = rows.filter(r => r.status === 'ok').length;

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center gap-3">
        <div className="flex-1 min-w-0">
          <h2 className="text-sm font-semibold text-foreground">Importar Produtos</h2>
          <p className="text-xs text-muted-foreground mt-0.5">Envie um arquivo CSV ou Excel com os produtos. Categorias novas serão criadas automaticamente.</p>
        </div>
        <Button variant="outline" size="sm" className="h-8 shrink-0"
          onClick={() => downloadTemplate(PRODUCT_HEADERS, 'modelo_produtos.xlsx')}>
          <Download className="h-3.5 w-3.5 mr-1.5" /> Baixar Modelo
        </Button>
      </div>

      <Alert className="border-border bg-muted/30">
        <AlertCircle className="h-4 w-4 text-muted-foreground" />
        <AlertDescription className="text-xs text-muted-foreground">
          Colunas esperadas: <span className="font-mono font-medium text-foreground">{PRODUCT_HEADERS.join(', ')}</span>
        </AlertDescription>
      </Alert>

      {rows.length === 0 ? (
        <DropZone onFile={handleFile} disabled={importing} />
      ) : (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2 flex-1 min-w-0">
              <Badge variant="secondary" className="text-xs">{rows.length} linhas</Badge>
              {pendentes > 0 && <Badge className="text-xs bg-primary/15 text-primary border-0">{pendentes} pendentes</Badge>}
              {ok > 0 && <Badge className="text-xs bg-success/15 text-success border-0">{ok} importados</Badge>}
              {erros > 0 && <Badge className="text-xs bg-destructive/15 text-destructive border-0">{erros} erros</Badge>}
            </div>
            <div className="flex gap-2 shrink-0">
              <Button variant="outline" size="sm" className="h-8" onClick={() => { setRows([]); setDone(false); }}>
                <RefreshCw className="h-3.5 w-3.5 mr-1.5" /> Novo arquivo
              </Button>
              {!done && pendentes > 0 && (
                <Button size="sm" className="h-8 bg-accent text-accent-foreground hover:bg-accent/90"
                  onClick={runImport} disabled={importing}>
                  {importing ? <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" /> : <Upload className="h-3.5 w-3.5 mr-1.5" />}
                  {importing ? 'Importando...' : `Importar ${pendentes} produtos`}
                </Button>
              )}
            </div>
          </div>

          {importing && (
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>Progresso</span><span>{progress}%</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>
          )}

          <div className="rounded-xl border border-border overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full min-w-max text-xs">
                <thead>
                  <tr className="bg-muted/40 border-b border-border">
                    <th className="text-left px-3 py-2.5 font-semibold text-muted-foreground whitespace-nowrap">Status</th>
                    <th className="text-left px-3 py-2.5 font-semibold text-muted-foreground whitespace-nowrap">Nome</th>
                    <th className="text-left px-3 py-2.5 font-semibold text-muted-foreground whitespace-nowrap">Preço</th>
                    <th className="text-left px-3 py-2.5 font-semibold text-muted-foreground whitespace-nowrap">Categoria</th>
                    <th className="text-left px-3 py-2.5 font-semibold text-muted-foreground whitespace-nowrap">Estoque</th>
                    <th className="text-left px-3 py-2.5 font-semibold text-muted-foreground whitespace-nowrap">Observação</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((row, i) => (
                    <tr key={i} className="border-b border-border last:border-0 hover:bg-muted/20">
                      <td className="px-3 py-2 whitespace-nowrap">
                        {row.status === 'pendente' && <Badge variant="secondary" className="text-[10px] border-0">Pendente</Badge>}
                        {row.status === 'ok' && <CheckCircle2 className="h-4 w-4 text-success" />}
                        {row.status === 'erro' && <XCircle className="h-4 w-4 text-destructive" />}
                      </td>
                      <td className="px-3 py-2 whitespace-nowrap font-medium max-w-48 truncate">{row.data.nome || '—'}</td>
                      <td className="px-3 py-2 whitespace-nowrap">{row.data.preco ? `R$ ${parseFloat(row.data.preco).toFixed(2)}` : '—'}</td>
                      <td className="px-3 py-2 whitespace-nowrap text-muted-foreground">{row.data.categoria || '—'}</td>
                      <td className="px-3 py-2 whitespace-nowrap text-muted-foreground">{row.data.estoque || '0'}</td>
                      <td className="px-3 py-2 whitespace-nowrap text-destructive text-[10px]">{row.mensagem || ''}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Aba de Categorias ────────────────────────────────────────────────────────

function ImportCategories() {
  const [rows, setRows] = useState<ImportRow<RawCategory>[]>([]);
  const [importing, setImporting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [done, setDone] = useState(false);

  const handleFile = async (file: File) => {
    setDone(false);
    setRows([]);
    try {
      const data = await parseFile(file);
      const parsed: ImportRow<RawCategory>[] = data.map((row) => {
        const nome = row['nome'] || row['Nome'] || row['name'] || '';
        if (!nome) return { data: row as unknown as RawCategory, status: 'erro', mensagem: 'Nome ausente' };
        return {
          data: {
            nome,
            descricao: row['descricao'] || row['Descricao'] || row['description'] || '',
            imagem_url: row['imagem_url'] || row['Imagem'] || row['image_url'] || '',
            ativa: row['ativa'] || row['Ativa'] || row['active'] || 'sim',
          },
          status: 'pendente'
        };
      });
      setRows(parsed);
    } catch {
      toast.error('Erro ao ler o arquivo.');
    }
  };

  const runImport = async () => {
    setImporting(true);
    setProgress(0);
    const updated = [...rows];
    let done = 0;

    for (let i = 0; i < updated.length; i++) {
      if (updated[i].status === 'erro') { done++; setProgress(Math.round((done / updated.length) * 100)); continue; }
      const r = updated[i].data;
      const slug = r.nome.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
      const { error } = await supabase.from('categories').insert({
        name: r.nome,
        slug,
        description: r.descricao || null,
        image_url: r.imagem_url || null,
        is_active: toBool(r.ativa),
        updated_at: new Date().toISOString()
      });
      updated[i] = error
        ? { ...updated[i], status: 'erro', mensagem: error.message }
        : { ...updated[i], status: 'ok' };
      done++;
      setProgress(Math.round((done / updated.length) * 100));
      setRows([...updated]);
    }

    const ok = updated.filter(r => r.status === 'ok').length;
    const errs = updated.filter(r => r.status === 'erro').length;
    toast.success(`Importação concluída: ${ok} categorias criadas${errs ? `, ${errs} erros` : ''}`);
    setImporting(false);
    setDone(true);
  };

  const pendentes = rows.filter(r => r.status === 'pendente').length;
  const erros = rows.filter(r => r.status === 'erro').length;
  const ok = rows.filter(r => r.status === 'ok').length;

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center gap-3">
        <div className="flex-1 min-w-0">
          <h2 className="text-sm font-semibold text-foreground">Importar Categorias</h2>
          <p className="text-xs text-muted-foreground mt-0.5">Envie um arquivo CSV ou Excel com as categorias.</p>
        </div>
        <Button variant="outline" size="sm" className="h-8 shrink-0"
          onClick={() => downloadTemplate(CATEGORY_HEADERS, 'modelo_categorias.xlsx')}>
          <Download className="h-3.5 w-3.5 mr-1.5" /> Baixar Modelo
        </Button>
      </div>

      <Alert className="border-border bg-muted/30">
        <AlertCircle className="h-4 w-4 text-muted-foreground" />
        <AlertDescription className="text-xs text-muted-foreground">
          Colunas esperadas: <span className="font-mono font-medium text-foreground">{CATEGORY_HEADERS.join(', ')}</span>
        </AlertDescription>
      </Alert>

      {rows.length === 0 ? (
        <DropZone onFile={handleFile} disabled={importing} />
      ) : (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2 flex-1 min-w-0">
              <Badge variant="secondary" className="text-xs">{rows.length} linhas</Badge>
              {pendentes > 0 && <Badge className="text-xs bg-primary/15 text-primary border-0">{pendentes} pendentes</Badge>}
              {ok > 0 && <Badge className="text-xs bg-success/15 text-success border-0">{ok} importadas</Badge>}
              {erros > 0 && <Badge className="text-xs bg-destructive/15 text-destructive border-0">{erros} erros</Badge>}
            </div>
            <div className="flex gap-2 shrink-0">
              <Button variant="outline" size="sm" className="h-8" onClick={() => { setRows([]); setDone(false); }}>
                <RefreshCw className="h-3.5 w-3.5 mr-1.5" /> Novo arquivo
              </Button>
              {!done && pendentes > 0 && (
                <Button size="sm" className="h-8 bg-accent text-accent-foreground hover:bg-accent/90"
                  onClick={runImport} disabled={importing}>
                  {importing ? <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" /> : <Upload className="h-3.5 w-3.5 mr-1.5" />}
                  {importing ? 'Importando...' : `Importar ${pendentes} categorias`}
                </Button>
              )}
            </div>
          </div>

          {importing && (
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>Progresso</span><span>{progress}%</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>
          )}

          <div className="rounded-xl border border-border overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full min-w-max text-xs">
                <thead>
                  <tr className="bg-muted/40 border-b border-border">
                    <th className="text-left px-3 py-2.5 font-semibold text-muted-foreground whitespace-nowrap">Status</th>
                    <th className="text-left px-3 py-2.5 font-semibold text-muted-foreground whitespace-nowrap">Nome</th>
                    <th className="text-left px-3 py-2.5 font-semibold text-muted-foreground whitespace-nowrap">Descrição</th>
                    <th className="text-left px-3 py-2.5 font-semibold text-muted-foreground whitespace-nowrap">Ativa</th>
                    <th className="text-left px-3 py-2.5 font-semibold text-muted-foreground whitespace-nowrap">Observação</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((row, i) => (
                    <tr key={i} className="border-b border-border last:border-0 hover:bg-muted/20">
                      <td className="px-3 py-2 whitespace-nowrap">
                        {row.status === 'pendente' && <Badge variant="secondary" className="text-[10px] border-0">Pendente</Badge>}
                        {row.status === 'ok' && <CheckCircle2 className="h-4 w-4 text-success" />}
                        {row.status === 'erro' && <XCircle className="h-4 w-4 text-destructive" />}
                      </td>
                      <td className="px-3 py-2 whitespace-nowrap font-medium">{row.data.nome || '—'}</td>
                      <td className="px-3 py-2 max-w-48 truncate text-muted-foreground whitespace-nowrap">{row.data.descricao || '—'}</td>
                      <td className="px-3 py-2 whitespace-nowrap">
                        <Badge className={`text-[10px] border-0 ${toBool(row.data.ativa) ? 'bg-success/15 text-success' : 'bg-muted text-muted-foreground'}`}>
                          {toBool(row.data.ativa) ? 'Sim' : 'Não'}
                        </Badge>
                      </td>
                      <td className="px-3 py-2 whitespace-nowrap text-destructive text-[10px]">{row.mensagem || ''}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Página Principal ─────────────────────────────────────────────────────────

export default function AdminImport() {
  return (
    <AdminLayout title="Importar Dados">
      <div className="max-w-5xl space-y-6">
        <div>
          <h1 className="text-lg font-bold text-foreground text-balance">Importação em Massa</h1>
          <p className="text-sm text-muted-foreground mt-1 text-pretty">
            Importe produtos e categorias a partir de arquivos CSV ou Excel.
            Baixe o modelo, preencha e envie.
          </p>
        </div>

        <Tabs defaultValue="produtos">
          <TabsList className="h-9">
            <TabsTrigger value="produtos" className="text-sm">Produtos</TabsTrigger>
            <TabsTrigger value="categorias" className="text-sm">Categorias</TabsTrigger>
          </TabsList>

          <TabsContent value="produtos" className="mt-5">
            <div className="bg-card border border-border rounded-xl p-5 md:p-6">
              <ImportProducts />
            </div>
          </TabsContent>

          <TabsContent value="categorias" className="mt-5">
            <div className="bg-card border border-border rounded-xl p-5 md:p-6">
              <ImportCategories />
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </AdminLayout>
  );
}
