import { useState, useCallback } from 'react';
import { Upload, FileSpreadsheet, AlertTriangle, CheckCircle, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { AdminLayout } from '@/components/layouts/AdminLayout';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';

interface ImportRow {
  name: string;
  barcode?: string;
  code?: string;
  description?: string;
  price?: string;
  cost_price?: string;
  stock_quantity?: string;
  unit?: string;
  brand?: string;
  sku?: string;
  weight?: string;
  dimensions?: string;
  _valid: boolean;
  _error?: string;
}

function parseCsv(text: string): Record<string, string>[] {
  const lines = text.split(/\r?\n/).filter(l => l.trim());
  if (lines.length < 2) return [];
  const headers = lines[0].split(';').map(h => h.trim().replace(/^"|"$/g, ''));
  return lines.slice(1).map(line => {
    const values = line.split(';').map(v => v.trim().replace(/^"|"$/g, ''));
    const obj: Record<string, string> = {};
    headers.forEach((h, i) => { obj[h] = values[i] || ''; });
    return obj;
  });
}

function generateSlug(name: string): string {
  return name
    .toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9\s-]/g, '')
    .trim()
    .replace(/\s+/g, '-')
    .slice(0, 100);
}

export default function AdminImportProducts() {
  const [preview, setPreview] = useState<ImportRow[]>([]);
  const [importing, setImporting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [result, setResult] = useState<{ success: number; failed: number } | null>(null);

  const handleFile = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
      const text = String(ev.target?.result || '');
      const raw = parseCsv(text);
      const mapped: ImportRow[] = raw.map(row => {
        const name = row['nome'] || row['name'] || row['Nome'] || row['NOME'] || '';
        const barcode = row['codigo_barras'] || row['barcode'] || row['Codigo_Barras'] || '';
        if (!name) return { name: '', _valid: false, _error: 'Nome obrigatório' };
        return {
          name,
          barcode,
          code: row['codigo'] || row['code'] || row['Codigo'] || '',
          description: row['descricao'] || row['description'] || '',
          price: row['preco'] || row['price'] || row['Preco_Venda'] || '',
          cost_price: row['custo'] || row['cost_price'] || row['Preco_Custo'] || '',
          stock_quantity: row['estoque'] || row['stock'] || row['Estoque'] || '',
          unit: row['unidade'] || row['unit'] || 'un',
          brand: row['marca'] || row['brand'] || '',
          sku: row['sku'] || row['SKU'] || '',
          weight: row['peso'] || row['weight'] || '',
          dimensions: row['dimensoes'] || row['dimensions'] || '',
          _valid: true,
        };
      });
      setPreview(mapped);
      setResult(null);
    };
    reader.readAsText(file);
  }, []);

  const handleImport = async () => {
    const validRows = preview.filter(r => r._valid);
    if (!validRows.length) { toast.error('Nenhum produto válido para importar'); return; }
    setImporting(true);
    setProgress(0);
    setResult(null);

    let success = 0, failed = 0;
    for (let i = 0; i < validRows.length; i++) {
      const r = validRows[i];
      const price = parseFloat(r.price?.replace(',', '.') || '0') || 0;
      const cost = parseFloat(r.cost_price?.replace(',', '.') || '0') || 0;
      const stock = parseInt(r.stock_quantity || '0', 10) || 0;
      const weight = parseFloat(r.weight?.replace(',', '.') || '') || null;

      const { error } = await supabase.from('products').insert({
        name: r.name,
        slug: generateSlug(r.name),
        code: r.code || null,
        barcode: r.barcode || null,
        description: r.description || '',
        price,
        cost_price: cost,
        stock_quantity: stock,
        is_available: true,
        is_featured: false,
        unit: r.unit || 'un',
        brand: r.brand || null,
        sku: r.sku || null,
        weight,
        dimensions: r.dimensions || null,
        images: [],
        attributes: {},
        created_at: new Date().toISOString(),
      });

      if (!error) {
        success++;
        if (stock > 0) {
          await supabase.from('stock_movements').insert({
            product_id: null,
            type: 'importacao',
            quantity: stock,
            notes: `Importação em lote: ${r.name}`,
            created_at: new Date().toISOString(),
          });
        }
      } else {
        failed++;
      }
      setProgress(Math.round(((i + 1) / validRows.length) * 100));
    }

    setResult({ success, failed });
    setImporting(false);
    toast.success(`${success} produtos importados, ${failed} falhas`);
  };

  const validCount = preview.filter(r => r._valid).length;
  const invalidCount = preview.filter(r => !r._valid).length;

  return (
    <AdminLayout title="Importar Produtos" subtitle="Importe produtos em lote via CSV">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-xl bg-accent/10 flex items-center justify-center">
            <Upload className="h-5 w-5 text-accent" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-foreground text-balance">Importar Produtos</h1>
            <p className="text-sm text-muted-foreground">Upload de arquivo CSV com colunas: nome, codigo_barras, preco, estoque, etc.</p>
          </div>
        </div>

        <Card>
          <CardContent className="p-6">
            <label className="flex flex-col items-center justify-center border-2 border-dashed border-border rounded-xl p-8 cursor-pointer hover:bg-muted/40 transition-colors">
              <FileSpreadsheet className="h-10 w-10 text-muted-foreground mb-3" />
              <p className="text-sm font-medium">Clique para selecionar arquivo CSV</p>
              <p className="text-xs text-muted-foreground mt-1">Separado por ponto e vírgula (;)</p>
              <input type="file" accept=".csv,.txt" className="hidden" onChange={handleFile} />
            </label>
          </CardContent>
        </Card>

        {preview.length > 0 && (
          <Card>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-base">Preview ({preview.length} linhas)</CardTitle>
                  <CardDescription>{validCount} válidos / {invalidCount} inválidos</CardDescription>
                </div>
                <div className="flex gap-2">
                  {invalidCount > 0 && <Badge variant="destructive">{invalidCount} erros</Badge>}
                  {validCount > 0 && <Badge className="bg-success text-success-foreground">{validCount} OK</Badge>}
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-2 px-2">Nome</th>
                      <th className="text-left py-2 px-2">Código Barras</th>
                      <th className="text-left py-2 px-2">Preço</th>
                      <th className="text-left py-2 px-2">Estoque</th>
                      <th className="text-left py-2 px-2">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {preview.slice(0, 20).map((row, i) => (
                      <tr key={i} className="border-b border-border/50">
                        <td className="py-2 px-2">{row.name}</td>
                        <td className="py-2 px-2">{row.barcode}</td>
                        <td className="py-2 px-2">{row.price}</td>
                        <td className="py-2 px-2">{row.stock_quantity}</td>
                        <td className="py-2 px-2">
                          {row._valid
                            ? <span className="text-success text-xs font-medium">OK</span>
                            : <span className="text-destructive text-xs font-medium">{row._error}</span>}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {preview.length > 20 && <p className="text-xs text-muted-foreground text-center py-2">... e mais {preview.length - 20} linhas</p>}
              </div>

              {validCount > 0 && (
                <Button onClick={handleImport} disabled={importing} className="w-full gap-2">
                  {importing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
                  Importar {validCount} Produtos
                </Button>
              )}

              {importing && (
                <div className="space-y-2">
                  <Progress value={progress} className="h-2" />
                  <p className="text-xs text-muted-foreground text-center">{progress}% processado</p>
                </div>
              )}

              {result && (
                <Alert className={result.failed > 0 ? 'bg-warning/5 border-warning/20' : 'bg-success/5 border-success/20'}>
                  {result.failed > 0 ? <AlertTriangle className="h-4 w-4 text-warning" /> : <CheckCircle className="h-4 w-4 text-success" />}
                  <AlertDescription>
                    {result.success} importados com sucesso. {result.failed > 0 ? `${result.failed} falhas.` : ''}
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </AdminLayout>
  );
}
