import { useState, useEffect, useRef } from 'react';
import { Printer, Check, Loader2, QrCode, Barcode } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AdminLayout } from '@/components/layouts/AdminLayout';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';

interface ProductItem {
  id: string;
  name: string;
  code: string | null;
  barcode: string | null;
  price: number;
  selected: boolean;
  copies: number;
}

type LabelSize = 'P' | 'M' | 'G';

export default function AdminLabelPrint() {
  const [products, setProducts] = useState<ProductItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [size, setSize] = useState<LabelSize>('M');
  const [search, setSearch] = useState('');
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    supabase.from('products').select('id, name, code, barcode, price').eq('is_available', true).order('name').limit(500)
      .then(({ data }) => {
        setProducts((Array.isArray(data) ? data : []).map(p => ({ ...p, selected: false, copies: 1 })));
        setLoading(false);
      });
  }, []);

  const toggleSelect = (id: string) => {
    setProducts(prev => prev.map(p => p.id === id ? { ...p, selected: !p.selected } : p));
  };

  const setCopies = (id: string, copies: number) => {
    setProducts(prev => prev.map(p => p.id === id ? { ...p, copies: Math.max(1, copies) } : p));
  };

  const selected = products.filter(p => p.selected);

  const generateBarcode = (code: string) => {
    // Gerar Code128 simples via canvas
    const canvas = canvasRef.current;
    if (!canvas) return '';
    const ctx = canvas.getContext('2d');
    if (!ctx) return '';
    canvas.width = 300;
    canvas.height = 80;
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#000';
    // Render texto como "barcode" visual simples (barras verticais alternadas)
    const barWidth = 2;
    let x = 20;
    for (let i = 0; i < code.length; i++) {
      const charCode = code.charCodeAt(i);
      for (let b = 0; b < 8; b++) {
        if ((charCode >> b) & 1) {
          ctx.fillRect(x, 10, barWidth, 50);
        }
        x += barWidth + 1;
      }
      x += 2;
    }
    ctx.font = '12px monospace';
    ctx.textAlign = 'center';
    ctx.fillText(code, canvas.width / 2, 72);
    return canvas.toDataURL('image/png');
  };

  const handlePrint = () => {
    if (!selected.length) { toast.error('Selecione pelo menos um produto'); return; }
    const printWindow = window.open('', '_blank');
    if (!printWindow) { toast.error('Permita popups para imprimir'); return; }

    const sizeStyles = {
      P: { width: '40mm', height: '30mm' },
      M: { width: '60mm', height: '40mm' },
      G: { width: '80mm', height: '60mm' },
    };

    const html = `
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Etiquetas</title>
<style>
@page { size: auto; margin: 5mm; }
body { font-family: Arial, sans-serif; margin: 0; padding: 0; }
.label { border: 1px solid #ccc; padding: 4mm; box-sizing: border-box; page-break-inside: avoid; display: flex; flex-direction: column; align-items: center; justify-content: center; }
.name { font-size: 10px; font-weight: bold; text-align: center; margin-bottom: 2px; }
.code { font-size: 9px; color: #666; margin-bottom: 2px; }
.price { font-size: 12px; font-weight: bold; color: #000; }
</style>
</head>
<body>
<div style="display:grid; grid-template-columns: repeat(auto-fill, minmax(${sizeStyles[size].width}, 1fr)); gap: 2mm;">
${selected.map(p => {
  const barcodeUrl = generateBarcode(p.barcode || p.code || p.id.slice(0, 10));
  return Array.from({ length: p.copies }).map(() => `
<div class="label" style="width:${sizeStyles[size].width};height:${sizeStyles[size].height};">
  <div class="name">${p.name.slice(0, 25)}</div>
  <div class="code">${p.code || p.barcode || ''}</div>
  <img src="${barcodeUrl}" style="height:30px;max-width:90%;" />
  <div class="price">R$ ${p.price.toFixed(2).replace('.', ',')}</div>
</div>
  `).join('');
}).join('')}
</div>
<script>window.onload = () => { setTimeout(() => window.print(), 300); };</script>
</body>
</html>`;
    printWindow.document.write(html);
    printWindow.document.close();
    toast.success('Janela de impressão aberta');
  };

  const filtered = products.filter(p => p.name.toLowerCase().includes(search.toLowerCase()) || (p.code || '').toLowerCase().includes(search.toLowerCase()));

  return (
    <AdminLayout title="Impressão de Etiquetas" subtitle="Gere etiquetas com código de barras">
      <div className="max-w-5xl mx-auto space-y-6">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-xl bg-accent/10 flex items-center justify-center">
            <Printer className="h-5 w-5 text-accent" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-foreground text-balance">Etiquetas</h1>
            <p className="text-sm text-muted-foreground">Selecione produtos e configure o tamanho</p>
          </div>
        </div>

        <div className="flex flex-col md:flex-row gap-3">
          <Input placeholder="Buscar produto..." value={search} onChange={e => setSearch(e.target.value)} className="h-9 flex-1" />
          <Select value={size} onValueChange={(v) => setSize(v as LabelSize)}>
            <SelectTrigger className="w-32 h-9"><SelectValue placeholder="Tamanho" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="P">P (40×30)</SelectItem>
              <SelectItem value="M">M (60×40)</SelectItem>
              <SelectItem value="G">G (80×60)</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={handlePrint} disabled={selected.length === 0} className="gap-2 h-9 shrink-0">
            <Printer className="h-4 w-4" /> Imprimir {selected.length > 0 ? `(${selected.length})` : ''}
          </Button>
        </div>

        <canvas ref={canvasRef} style={{ display: 'none' }} />

        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-muted/40">
                    <th className="text-left py-3 px-4 w-10"><input type="checkbox" onChange={e => setProducts(prev => prev.map(p => ({ ...p, selected: e.target.checked })))} /></th>
                    <th className="text-left py-3 px-4">Produto</th>
                    <th className="text-left py-3 px-4">Código</th>
                    <th className="text-right py-3 px-4">Preço</th>
                    <th className="text-center py-3 px-4">Cópias</th>
                  </tr>
                </thead>
                <tbody>
                  {loading ? (
                    <tr><td colSpan={5} className="py-8 text-center text-muted-foreground"><Loader2 className="h-5 w-5 animate-spin mx-auto" /></td></tr>
                  ) : filtered.length === 0 ? (
                    <tr><td colSpan={5} className="py-8 text-center text-muted-foreground">Nenhum produto encontrado</td></tr>
                  ) : (
                    filtered.map(p => (
                      <tr key={p.id} className="border-b border-border/50 hover:bg-muted/20">
                        <td className="py-3 px-4">
                          <input type="checkbox" checked={p.selected} onChange={() => toggleSelect(p.id)} />
                        </td>
                        <td className="py-3 px-4 font-medium">{p.name}</td>
                        <td className="py-3 px-4"><Badge variant="secondary" className="text-[10px]">{p.code || p.barcode || '-'}</Badge></td>
                        <td className="py-3 px-4 text-right">{p.price.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</td>
                        <td className="py-3 px-4 text-center">
                          <Input type="number" min={1} value={p.copies} onChange={e => setCopies(p.id, parseInt(e.target.value, 10) || 1)} className="w-16 h-7 mx-auto text-center" />
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}
