import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Eye, EyeOff, Lock, Mail, ShieldCheck, AlertCircle, Loader2, Store, ShieldAlert, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import { useAuth } from '@/contexts/AuthContext';
import { useStore } from '@/contexts/StoreContext';
import { useLoginRateLimit } from '@/hooks/useLoginRateLimit';
import { supabase } from '@/db/supabase';

export default function AdminLoginPage() {
  const { signInWithEmail, signUpWithEmail, user, profile } = useAuth();
  const { settings } = useStore();
  const navigate = useNavigate();

  const [mode, setMode] = useState<'login' | 'register' | 'request'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const storeName = settings?.store_name || 'R&D Informatica';

  const {
    isLocked, lockoutLabel, attemptsLeft, maxAttempts,
    recordFailure, recordSuccess,
  } = useLoginRateLimit(email.trim() || 'admin');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isLocked) return;
    setError('');
    setLoading(true);
    const { error: err } = await signInWithEmail(email, password);
    if (err) {
      const left = recordFailure();
      if (left >= maxAttempts) {
        setError('Muitas tentativas incorretas. Acesso bloqueado por 5 minutos.');
      } else {
        setError(`E-mail ou senha incorretos. ${maxAttempts - left} tentativa(s) restante(s).`);
      }
      setLoading(false);
      return;
    }
    // Verifica role admin
    const { data: profileData } = await supabase
      .from('profiles').select('role').eq('id', (await supabase.auth.getUser()).data.user?.id ?? '').maybeSingle();
    if (profileData?.role !== 'admin') {
      setError('Sua conta não tem permissão de administrador.');
      await supabase.auth.signOut();
      setLoading(false);
      return;
    }
    recordSuccess();
    navigate('/admin');
  };

  const handleRegisterFirstAdmin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    // Impede criação se já existir um admin
    const { data: existingAdmins } = await supabase.from('profiles').select('id').eq('role', 'admin').limit(1);
    if (existingAdmins && existingAdmins.length > 0) {
      setError('Já existe um administrador cadastrado. Use a opção de login.');
      setLoading(false);
      return;
    }
    // Cria conta
    const { error: err } = await signUpWithEmail(email, password, name);
    if (err) {
      setError('Erro ao criar conta: ' + err.message);
      setLoading(false);
      return;
    }
    // Faz login imediato
    const { error: loginErr } = await signInWithEmail(email, password);
    if (loginErr) {
      setSuccess('Conta criada! Confirme seu e-mail e faça login.');
      setLoading(false);
      return;
    }
    // Promove para admin via RPC SECURITY DEFINER (contorna RLS)
    const { data: rpcData, error: rpcErr } = await supabase.rpc('set_first_admin_role');
    if (rpcErr || !rpcData?.success) {
      setError(rpcData?.message || 'Não foi possível conceder permissão admin. Tente a aba "Solicitar".');
      await supabase.auth.signOut();
      setLoading(false);
      return;
    }
    navigate('/admin');
  };

  const handleRequestAdmin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    const { data, error: rpcErr } = await supabase.rpc('request_admin_access', { user_email: email });
    if (rpcErr || !data?.success) {
      setError(data?.message || 'Não foi possível conceder acesso admin.');
      setLoading(false);
      return;
    }
    setSuccess(data.message + ' Faça login agora.');
    setMode('login');
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-muted/30 flex flex-col items-center justify-center px-4 py-10">
      {/* Header */}
      <div className="mb-8 flex flex-col items-center gap-2 text-center">
        <div className="h-14 w-14 rounded-2xl bg-primary flex items-center justify-center shadow-md mb-1">
          <Store className="h-7 w-7 text-primary-foreground" />
        </div>
        <h1 className="text-xl font-bold text-foreground">{storeName}</h1>
        <div className="flex items-center gap-1.5 text-muted-foreground text-sm">
          <ShieldCheck className="h-4 w-4 text-accent" />
          <span>Área Restrita — Painel Administrativo</span>
        </div>
      </div>

      <div className="w-full max-w-sm bg-card rounded-2xl border border-border shadow-md p-6 space-y-5">
        {/* Mode tabs */}
        <div className="flex rounded-lg bg-muted p-1 gap-1">
          <button
            onClick={() => { setMode('login'); setError(''); setSuccess(''); }}
            className={`flex-1 text-xs font-medium py-1.5 rounded-md transition-colors ${mode === 'login' ? 'bg-background text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}>
            Entrar
          </button>
          <button
            onClick={() => { setMode('register'); setError(''); setSuccess(''); }}
            className={`flex-1 text-xs font-medium py-1.5 rounded-md transition-colors ${mode === 'register' ? 'bg-background text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}>
            1º Acesso
          </button>
          <button
            onClick={() => { setMode('request'); setError(''); setSuccess(''); }}
            className={`flex-1 text-xs font-medium py-1.5 rounded-md transition-colors ${mode === 'request' ? 'bg-background text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}>
            Solicitar
          </button>
        </div>

        {/* Alerts */}
        {error && (
          <Alert variant="destructive" className="py-3">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription className="text-xs">{error}</AlertDescription>
          </Alert>
        )}
        {success && (
          <Alert className="py-3 border-success/30 bg-success/10">
            <ShieldCheck className="h-4 w-4 text-success" />
            <AlertDescription className="text-xs text-success">{success}</AlertDescription>
          </Alert>
        )}

        {/* Alerta de bloqueio (apenas no modo login) */}
        {mode === 'login' && isLocked && (
          <Alert variant="destructive" className="py-3">
            <ShieldAlert className="h-4 w-4" />
            <AlertDescription className="text-xs">
              Acesso bloqueado. Tente novamente em <strong>{lockoutLabel}</strong>.
            </AlertDescription>
          </Alert>
        )}
        {mode === 'login' && !isLocked && attemptsLeft < maxAttempts && attemptsLeft > 0 && (
          <Alert className="py-3 border-warning/40 bg-warning/10">
            <AlertTriangle className="h-4 w-4 text-warning" />
            <AlertDescription className="text-xs text-warning">
              {attemptsLeft} tentativa(s) restante(s) antes do bloqueio.
            </AlertDescription>
          </Alert>
        )}

        {/* LOGIN form */}
        {mode === 'login' && (
          <form onSubmit={handleLogin} className="space-y-4">
            <p className="text-xs text-muted-foreground text-balance">
              Acesse com suas credenciais de administrador.
            </p>
            <div className="space-y-1.5">
              <Label htmlFor="email" className="text-sm font-normal">E-mail</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input id="email" type="email" value={email} onChange={e => setEmail(e.target.value)}
                  placeholder="admin@loja.com" className="pl-9 h-10" required disabled={isLocked} />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="password" className="text-sm font-normal">Senha</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input id="password" type={showPass ? 'text' : 'password'} value={password}
                  onChange={e => setPassword(e.target.value)} placeholder="••••••••" className="pl-9 pr-10 h-10"
                  required disabled={isLocked} />
                <button type="button" onClick={() => setShowPass(v => !v)} disabled={isLocked}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                  {showPass ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>
            <Button type="submit" className="w-full h-10 bg-primary text-primary-foreground hover:bg-primary/90"
              disabled={loading || isLocked}>
              {loading
                ? <Loader2 className="h-4 w-4 animate-spin mr-2" />
                : isLocked
                  ? <ShieldAlert className="h-4 w-4 mr-2" />
                  : <ShieldCheck className="h-4 w-4 mr-2" />}
              {isLocked ? `Bloqueado por ${lockoutLabel}` : 'Entrar no Painel'}
            </Button>
          </form>
        )}

        {/* REGISTER FIRST ADMIN form */}
        {mode === 'register' && (
          <form onSubmit={handleRegisterFirstAdmin} className="space-y-4">
            <p className="text-xs text-muted-foreground text-balance">
              Crie o primeiro acesso de administrador. Só é possível se ainda não houver nenhum admin cadastrado.
            </p>
            <div className="space-y-1.5">
              <Label htmlFor="name" className="text-sm font-normal">Nome completo</Label>
              <Input id="name" value={name} onChange={e => setName(e.target.value)}
                placeholder="Seu nome" className="h-10" required />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="email2" className="text-sm font-normal">E-mail</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input id="email2" type="email" value={email} onChange={e => setEmail(e.target.value)}
                  placeholder="admin@loja.com" className="pl-9 h-10" required />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="password2" className="text-sm font-normal">Senha (mín. 6 caracteres)</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input id="password2" type={showPass ? 'text' : 'password'} value={password}
                  onChange={e => setPassword(e.target.value)} placeholder="••••••••" className="pl-9 pr-10 h-10"
                  required minLength={6} />
                <button type="button" onClick={() => setShowPass(v => !v)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                  {showPass ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>
            <Button type="submit" className="w-full h-10 bg-primary text-primary-foreground hover:bg-primary/90" disabled={loading}>
              {loading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <ShieldCheck className="h-4 w-4 mr-2" />}
              Criar Primeiro Admin
            </Button>
          </form>
        )}

        {/* REQUEST ADMIN form */}
        {mode === 'request' && (
          <form onSubmit={handleRequestAdmin} className="space-y-4">
            <p className="text-xs text-muted-foreground text-balance">
              Se você já tem uma conta cadastrada e nenhum admin existe, insira seu e-mail para receber acesso administrativo.
            </p>
            <div className="space-y-1.5">
              <Label htmlFor="email3" className="text-sm font-normal">E-mail da conta</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input id="email3" type="email" value={email} onChange={e => setEmail(e.target.value)}
                  placeholder="seuemail@loja.com" className="pl-9 h-10" required />
              </div>
            </div>
            <Button type="submit" className="w-full h-10 bg-primary text-primary-foreground hover:bg-primary/90" disabled={loading}>
              {loading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <ShieldCheck className="h-4 w-4 mr-2" />}
              Solicitar Acesso Admin
            </Button>
          </form>
        )}

        <Separator />
        <div className="flex justify-center">
          <Link to="/" className="text-xs text-muted-foreground hover:text-foreground transition-colors">
            ← Voltar para a loja
          </Link>
        </div>
      </div>

      <p className="mt-6 text-xs text-muted-foreground text-center">
        Acesso restrito a administradores autorizados.
      </p>
    </div>
  );
}
