import { useState, useEffect } from 'react';
import { Save, MessageCircle, Bell, Loader2, Check, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AdminLayout } from '@/components/layouts/AdminLayout';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';

interface NotificationConfig {
  id: string;
  whatsapp_enabled: boolean;
  whatsapp_number: string;
  whatsapp_provider: string;
  whatsapp_api_key: string;
  whatsapp_webhook_url: string;
  message_template: string;
}

export default function AdminNotifications() {
  const [config, setConfig] = useState<NotificationConfig | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [testSending, setTestSending] = useState(false);

  useEffect(() => {
    supabase.from('notification_settings').select('*').limit(1).maybeSingle().then(({ data }) => {
      if (data) setConfig(data as NotificationConfig);
      setLoading(false);
    });
  }, []);

  const setField = (field: keyof NotificationConfig, value: string | boolean) =>
    setConfig(c => c ? { ...c, [field]: value } : null);

  const handleSave = async () => {
    if (!config) return;
    setSaving(true);
    const { error } = await supabase.from('notification_settings').update({
      whatsapp_enabled: config.whatsapp_enabled,
      whatsapp_number: config.whatsapp_number,
      whatsapp_provider: config.whatsapp_provider,
      whatsapp_api_key: config.whatsapp_api_key,
      whatsapp_webhook_url: config.whatsapp_webhook_url,
      message_template: config.message_template,
      updated_at: new Date().toISOString(),
    }).eq('id', config.id);
    setSaving(false);
    if (error) { toast.error('Erro ao salvar: ' + error.message); return; }
    toast.success('Configurações salvas!');
  };

  const handleTest = async () => {
    if (!config?.whatsapp_number) { toast.error('Informe o número de WhatsApp'); return; }
    setTestSending(true);
    try {
      const { data, error } = await supabase.functions.invoke('whatsapp-notify', {
        body: { order_id: 'test' },
      });
      if (error) { toast.error('Erro: ' + error.message); }
      else if (data?.data?.sent) { toast.success('Mensagem de teste enviada!'); }
      else { toast.info(data?.data?.reason || 'Não enviado'); }
    } catch (e: any) {
      toast.error('Erro: ' + e.message);
    }
    setTestSending(false);
  };

  if (loading) {
    return (
      <AdminLayout title="Notificações">
        <div className="flex items-center justify-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      </AdminLayout>
    );
  }

  if (!config) {
    return (
      <AdminLayout title="Notificações">
        <div className="p-8 text-center text-muted-foreground">Configuração não encontrada</div>
      </AdminLayout>
    );
  }

  const previewMessage = (config.message_template || '')
    .replace(/{order_number}/g, '12345')
    .replace(/{total}/g, 'R$ 150,00')
    .replace(/{customer_name}/g, 'João Silva')
    .replace(/{status}/g, 'Concluído');

  return (
    <AdminLayout title="Notificações" subtitle="Configure alertas e notificações da loja">
      <div className="max-w-3xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center">
              <Bell className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-foreground text-balance">Notificações WhatsApp</h1>
              <p className="text-sm text-muted-foreground">Receba alertas de novos pedidos no WhatsApp</p>
            </div>
          </div>
          <div className="flex items-center gap-3 shrink-0">
            <div className="flex items-center gap-2">
              <Switch
                checked={config.whatsapp_enabled}
                onCheckedChange={v => setField('whatsapp_enabled', v)}
                id="whatsapp_enabled"
              />
              <Label htmlFor="whatsapp_enabled" className="text-sm cursor-pointer">
                {config.whatsapp_enabled
                  ? <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200 dark:bg-emerald-900/30 dark:text-emerald-400">Ativo</Badge>
                  : <Badge variant="secondary">Inativo</Badge>}
              </Label>
            </div>
            <Button onClick={handleSave} disabled={saving} className="gap-2 h-9">
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              Salvar
            </Button>
          </div>
        </div>

        {/* Configuração WhatsApp */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <MessageCircle className="h-4 w-4 text-[#25D366]" />
              Configuração do WhatsApp
            </CardTitle>
            <CardDescription>Escolha o provider e configure os dados</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">Número do WhatsApp</Label>
                <Input
                  value={config.whatsapp_number}
                  onChange={e => setField('whatsapp_number', e.target.value)}
                  placeholder="5511999999999 (com DDI e DDD)"
                />
                <p className="text-xs text-muted-foreground">Formato: 55 + DDD + número, sem espaços ou traços</p>
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">Provider</Label>
                <Select value={config.whatsapp_provider} onValueChange={v => setField('whatsapp_provider', v)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="callmebot">CallMeBot (Gratuito)</SelectItem>
                    <SelectItem value="webhook">Webhook Customizado</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-muted-foreground">
                  {config.whatsapp_provider === 'callmebot'
                    ? 'API gratuita. Obtenha sua API Key em callmebot.com'
                    : 'Envie para qualquer endpoint HTTP de sua escolha'}
                </p>
              </div>
            </div>

            {config.whatsapp_provider === 'callmebot' && (
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">API Key (CallMeBot)</Label>
                <Input
                  type="password"
                  value={config.whatsapp_api_key}
                  onChange={e => setField('whatsapp_api_key', e.target.value)}
                  placeholder="Sua API Key do CallMeBot"
                />
                <p className="text-xs text-muted-foreground">
                  Acesse <a href="https://www.callmebot.com/blog/free-api-whatsapp-messages/" target="_blank" rel="noopener noreferrer" className="text-primary underline">callmebot.com</a> para obter sua API key gratuita
                </p>
              </div>
            )}

            {config.whatsapp_provider === 'webhook' && (
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">URL do Webhook</Label>
                <Input
                  value={config.whatsapp_webhook_url}
                  onChange={e => setField('whatsapp_webhook_url', e.target.value)}
                  placeholder="https://sua-api.com/webhook/whatsapp"
                />
                <p className="text-xs text-muted-foreground">Endpoint que receberá POST com {`{phone, message, order}`}</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Template da mensagem */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Template da Mensagem</CardTitle>
            <CardDescription>Personalize o texto enviado no WhatsApp</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Textarea
              value={config.message_template}
              onChange={e => setField('message_template', e.target.value)}
              rows={4}
              className="resize-none font-mono text-sm"
            />
            <div className="flex flex-wrap gap-2">
              {['{order_number}', '{total}', '{customer_name}', '{status}'].map(v => (
                <Badge key={v} variant="secondary" className="text-xs cursor-pointer hover:bg-muted font-mono" onClick={() => setField('message_template', config.message_template + v)}>
                  {v}
                </Badge>
              ))}
            </div>
            <p className="text-xs text-muted-foreground">Clique nas variáveis para inseri-las no template</p>

            <Separator />

            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Prévia da Mensagem</p>
              <div className="bg-[#e7fbe6] dark:bg-[#1a3320] border border-[#25D366]/30 rounded-xl p-4">
                <div className="flex items-center gap-2 mb-2">
                  <div className="h-7 w-7 rounded-full bg-[#25D366] flex items-center justify-center">
                    <MessageCircle className="h-3.5 w-3.5 text-white" />
                  </div>
                  <span className="text-xs font-semibold text-foreground">WhatsApp</span>
                </div>
                <p className="text-sm text-foreground whitespace-pre-line">{previewMessage}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Testar */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Info className="h-4 w-4 text-info" />
              Testar Envio
            </CardTitle>
            <CardDescription>Envie uma mensagem de teste para verificar a configuração</CardDescription>
          </CardHeader>
          <CardContent>
            <Button
              onClick={handleTest}
              disabled={testSending || !config.whatsapp_enabled || !config.whatsapp_number}
              className="gap-2 bg-[#25D366] hover:bg-[#20b558] text-white border-0"
            >
              {testSending ? <Loader2 className="h-4 w-4 animate-spin" /> : <MessageCircle className="h-4 w-4" />}
              Enviar Mensagem de Teste
            </Button>
            <p className="text-xs text-muted-foreground mt-2">
              Recomendamos testar antes de ativar as notificações automáticas
            </p>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}
