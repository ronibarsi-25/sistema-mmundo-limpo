import { useState, useEffect } from 'react';
import { Search, Eye, ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Separator } from '@/components/ui/separator';
import { Skeleton } from '@/components/ui/skeleton';
import { AdminLayout } from '@/components/layouts/AdminLayout';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import type { Order, OrderStatus } from '@/types/types';

const STATUS_CONFIG: Record<OrderStatus, { label: string; color: string }> = {
  pending: { label: 'Pendente', color: 'bg-warning/15 text-warning-foreground' },
  processing: { label: 'Processando', color: 'bg-info/15 text-info-foreground' },
  shipped: { label: 'Enviado', color: 'bg-primary/15 text-primary' },
  delivered: { label: 'Entregue', color: 'bg-success/15 text-success' },
  cancelled: { label: 'Cancelado', color: 'bg-destructive/15 text-destructive' },
  completed: { label: 'Concluído', color: 'bg-success/15 text-success' },
};

const ALL_STATUSES: OrderStatus[] = ['pending', 'processing', 'shipped', 'delivered', 'cancelled', 'completed'];

export default function AdminOrders() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [updatingStatus, setUpdatingStatus] = useState<string | null>(null);

  const load = async () => {
    const { data } = await supabase.from('orders').select('*').order('created_at', { ascending: false });
    setOrders(Array.isArray(data) ? data : []);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const updateStatus = async (orderId: string, status: OrderStatus) => {
    setUpdatingStatus(orderId);
    const { error } = await supabase.from('orders').update({ status, updated_at: new Date().toISOString() }).eq('id', orderId);
    if (error) { toast.error('Erro ao atualizar status'); setUpdatingStatus(null); return; }
    toast.success('Status atualizado!');
    setUpdatingStatus(null);
    load();
    if (selectedOrder?.id === orderId) setSelectedOrder(prev => prev ? { ...prev, status } : null);
  };

  const filtered = orders.filter(o => {
    const matchSearch = search === '' || o.order_number?.toLowerCase().includes(search.toLowerCase()) || o.customer_name?.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === 'all' || o.status === statusFilter;
    return matchSearch && matchStatus;
  });

  return (
    <AdminLayout title="Pedidos">
      <div className="space-y-4">
        <div className="flex items-center gap-3 flex-wrap">
          <div className="relative flex-1 min-w-40">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar pedido ou cliente..." className="pl-9 h-9" />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-44 h-9"><SelectValue placeholder="Status" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os status</SelectItem>
              {ALL_STATUSES.map(s => <SelectItem key={s} value={s}>{STATUS_CONFIG[s].label}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>

        <div className="bg-card rounded-xl border border-border overflow-hidden">
          {loading ? (
            <div className="p-5 space-y-3">{[...Array(5)].map((_, i) => <Skeleton key={i} className="h-12 bg-muted" />)}</div>
          ) : filtered.length === 0 ? (
            <div className="p-10 text-center text-muted-foreground text-sm">Nenhum pedido encontrado</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-max">
                <thead><tr className="border-b border-border bg-muted/40">
                  {['Pedido', 'Cliente', 'Total', 'Pagamento', 'Status', 'Data', 'Ações'].map(h => <th key={h} className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground whitespace-nowrap">{h}</th>)}
                </tr></thead>
                <tbody>
                  {filtered.map(order => {
                    const s = STATUS_CONFIG[order.status] || { label: order.status, color: 'bg-muted' };
                    return (
                      <tr key={order.id} className="border-b border-border last:border-0 hover:bg-muted/20 transition-colors">
                        <td className="px-4 py-3 text-sm font-mono font-medium whitespace-nowrap">{order.order_number}</td>
                        <td className="px-4 py-3 text-sm text-muted-foreground whitespace-nowrap">{order.customer_name || '—'}</td>
                        <td className="px-4 py-3 text-sm font-medium whitespace-nowrap">{order.total_amount?.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</td>
                        <td className="px-4 py-3 text-sm text-muted-foreground whitespace-nowrap capitalize">{order.payment_method}</td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <Select value={order.status} onValueChange={(v) => updateStatus(order.id, v as OrderStatus)} disabled={updatingStatus === order.id}>
                            <SelectTrigger className="h-7 w-36 text-xs border-0 p-0 bg-transparent shadow-none focus:ring-0">
                              <Badge className={`${s.color} border-0 text-xs cursor-pointer`}>{s.label}</Badge>
                            </SelectTrigger>
                            <SelectContent>
                              {ALL_STATUSES.map(st => <SelectItem key={st} value={st} className="text-xs">{STATUS_CONFIG[st].label}</SelectItem>)}
                            </SelectContent>
                          </Select>
                        </td>
                        <td className="px-4 py-3 text-xs text-muted-foreground whitespace-nowrap">{new Date(order.created_at).toLocaleDateString('pt-BR')}</td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setSelectedOrder(order)}><Eye className="h-3.5 w-3.5" /></Button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Order detail dialog */}
      <Dialog open={!!selectedOrder} onOpenChange={open => !open && setSelectedOrder(null)}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>Detalhes do Pedido {selectedOrder?.order_number}</DialogTitle></DialogHeader>
          {selectedOrder && (
            <div className="space-y-5">
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="bg-muted rounded-lg p-3">
                  <p className="text-xs text-muted-foreground">Cliente</p>
                  <p className="font-medium">{selectedOrder.customer_name || '—'}</p>
                  <p className="text-muted-foreground">{selectedOrder.customer_email}</p>
                  <p className="text-muted-foreground">{selectedOrder.customer_phone}</p>
                </div>
                <div className="bg-muted rounded-lg p-3">
                  <p className="text-xs text-muted-foreground">Entrega</p>
                  <p className="font-medium capitalize">{selectedOrder.delivery_type === 'pickup' ? 'Retirada na Loja' : 'Entrega'}</p>
                  {selectedOrder.delivery_address && (
                    <p className="text-muted-foreground text-xs">{selectedOrder.delivery_address.street}, {selectedOrder.delivery_address.number} — {selectedOrder.delivery_address.city}/{selectedOrder.delivery_address.state}</p>
                  )}
                </div>
              </div>
              <div>
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Produtos</p>
                <div className="space-y-2">
                  {selectedOrder.items?.map((item, i) => (
                    <div key={i} className="flex items-center gap-3 text-sm">
                      {item.image_url && <img src={item.image_url} alt={item.name} className="h-10 w-10 rounded-md object-cover shrink-0" />}
                      <div className="flex-1 min-w-0"><p className="font-medium truncate">{item.name}</p><p className="text-xs text-muted-foreground">Qtd: {item.quantity}</p></div>
                      <p className="font-medium shrink-0">{(item.price * item.quantity).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</p>
                    </div>
                  ))}
                </div>
              </div>
              <Separator />
              <div className="space-y-1.5 text-sm">
                <div className="flex justify-between"><span className="text-muted-foreground">Subtotal</span><span>{selectedOrder.subtotal?.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Frete</span><span>{selectedOrder.freight_amount?.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span></div>
                <div className="flex justify-between font-bold"><span>Total</span><span>{selectedOrder.total_amount?.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span></div>
              </div>
              <div>
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Alterar Status</p>
                <div className="flex flex-wrap gap-2">
                  {ALL_STATUSES.map(st => (
                    <Button key={st} size="sm" variant={selectedOrder.status === st ? 'default' : 'outline'} className="h-7 text-xs"
                      onClick={() => updateStatus(selectedOrder.id, st)}>
                      {STATUS_CONFIG[st].label}
                    </Button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
}
