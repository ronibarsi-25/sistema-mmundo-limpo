import { useState, useEffect, useCallback } from 'react';
import {
  QrCode, CreditCard, Landmark, Wallet, FileText, Building2,
  ChevronUp, ChevronDown, Settings2, CheckCircle2, Loader2, Save,
  Plus, Pencil, Trash2, Smartphone, Ticket, DollarSign, ShoppingBag,
  Receipt, Banknote
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import {
  Collapsible, CollapsibleContent, CollapsibleTrigger
} from '@/components/ui/collapsible';
import { AdminLayout } from '@/components/layouts/AdminLayout';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import type { PaymentGateway } from '@/types/types';

// Mapa de ícones por nome
const ICON_COMPONENTS: Record<string, React.ElementType> = {
  QrCode, CreditCard, Landmark, Wallet, FileText, Building2,
  Smartphone, Ticket, DollarSign, ShoppingBag, Receipt, Banknote,
};

// Gateways sem campos de configuração própria (usam config global da loja)
const NO_CONFIG_GATEWAYS = new Set(['pix', 'stripe']);

export default function AdminPaymentGateways() {
  const [gateways, setGateways] = useState<PaymentGateway[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState<string | null>(null);
  const [expanded, setExpanded] = useState<string | null>(null);
  const [drafts, setDrafts] = useState<Record<string, Record<string, string>>>({});

  // Dialog CRUD
  const [showDialog, setShowDialog] = useState(false);
  const [editing, setEditing] = useState<PaymentGateway | null>(null);
  const [form, setForm] = useState({ id: '', name: '', description: '', icon: 'CreditCard', is_active: true, sort_order: 0, configJson: '{}' });
  const [submitting, setSubmitting] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const fetchGateways = useCallback(async () => {
    const { data } = await supabase
      .from('payment_gateways')
      .select('*')
      .order('sort_order', { ascending: true });
    const rows = (Array.isArray(data) ? data : []) as PaymentGateway[];
    setGateways(rows);
    const initial: Record<string, Record<string, string>> = {};
    rows.forEach(g => { initial[g.id] = { ...g.config }; });
    setDrafts(initial);
    setLoading(false);
  }, []);

  useEffect(() => { fetchGateways(); }, [fetchGateways]);

  const openNew = () => {
    setEditing(null);
    setForm({ id: '', name: '', description: '', icon: 'CreditCard', is_active: true, sort_order: gateways.length + 1, configJson: '{}' });
    setShowDialog(true);
  };

  const openEdit = (gw: PaymentGateway) => {
    setEditing(gw);
    setForm({ id: gw.id, name: gw.name, description: gw.description || '', icon: gw.icon, is_active: gw.is_active, sort_order: gw.sort_order, configJson: JSON.stringify(gw.config || {}, null, 2) });
    setShowDialog(true);
  };

  const handleSave = async () => {
    if (!form.id.trim() || !form.name.trim()) { toast.error('Preencha ID e nome do gateway'); return; }
    setSubmitting(true);
    let config: Record<string, string> = {};
    try {
      config = JSON.parse(form.configJson || '{}');
    } catch { toast.error('JSON de configuração inválido'); setSubmitting(false); return; }

    const payload = {
      id: form.id.trim().toLowerCase().replace(/\s+/g, '_'),
      name: form.name.trim(),
      description: form.description.trim() || null,
      icon: form.icon,
      is_active: form.is_active,
      sort_order: form.sort_order,
      config,
    };

    const query = editing
      ? supabase.from('payment_gateways').update({ ...payload, updated_at: new Date().toISOString() }).eq('id', editing.id)
      : supabase.from('payment_gateways').insert(payload);
    const { error } = await query;
    setSubmitting(false);
    if (error) { toast.error(`Erro: ${error.message}`); return; }
    toast.success(editing ? 'Gateway atualizado!' : 'Gateway cadastrado!');
    setShowDialog(false);
    fetchGateways();
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    const { error } = await supabase.from('payment_gateways').delete().eq('id', deleteId);
    if (error) { toast.error(`Erro: ${error.message}`); }
    else { toast.success('Gateway removido'); fetchGateways(); }
    setDeleteId(null);
  };

  const toggleActive = async (gw: PaymentGateway) => {
    const next = !gw.is_active;
    // Otimista
    setGateways(prev => prev.map(g => g.id === gw.id ? { ...g, is_active: next } : g));
    const { error } = await supabase
      .from('payment_gateways')
      .update({ is_active: next, updated_at: new Date().toISOString() })
      .eq('id', gw.id);
    if (error) {
      setGateways(prev => prev.map(g => g.id === gw.id ? { ...g, is_active: !next } : g));
      toast.error('Erro ao atualizar gateway: ' + error.message);
    } else {
      toast.success(next ? `${gw.name} ativado!` : `${gw.name} desativado.`);
    }
  };

  const moveOrder = async (gw: PaymentGateway, dir: 'up' | 'down') => {
    const sorted = [...gateways].sort((a, b) => a.sort_order - b.sort_order);
    const idx = sorted.findIndex(g => g.id === gw.id);
    const swapIdx = dir === 'up' ? idx - 1 : idx + 1;
    if (swapIdx < 0 || swapIdx >= sorted.length) return;
    const swapGw = sorted[swapIdx];
    const updates = [
      { id: gw.id, sort_order: swapGw.sort_order },
      { id: swapGw.id, sort_order: gw.sort_order },
    ];
    // Otimista
    setGateways(prev =>
      prev.map(g => {
        const u = updates.find(u => u.id === g.id);
        return u ? { ...g, sort_order: u.sort_order } : g;
      })
    );
    await Promise.all(
      updates.map(u =>
        supabase.from('payment_gateways').update({ sort_order: u.sort_order }).eq('id', u.id)
      )
    );
  };

  const saveConfig = async (gw: PaymentGateway) => {
    setSaving(gw.id);
    const config = drafts[gw.id] || {};
    const { error } = await supabase
      .from('payment_gateways')
      .update({ config, updated_at: new Date().toISOString() })
      .eq('id', gw.id);
    setSaving(null);
    if (error) {
      toast.error('Erro ao salvar: ' + error.message);
    } else {
      setGateways(prev => prev.map(g => g.id === gw.id ? { ...g, config } : g));
      toast.success(`Configuração do ${gw.name} salva!`);
      setExpanded(null);
    }
  };

  const f = (k: string, v: string | boolean | number) => setForm(prev => ({ ...prev, [k]: v }));

  const setDraftField = (gwId: string, field: string, value: string) => {
    setDrafts(prev => ({ ...prev, [gwId]: { ...prev[gwId], [field]: value } }));
  };

  const sorted = [...gateways].sort((a, b) => a.sort_order - b.sort_order);

  return (
    <AdminLayout title="Gateways de Pagamento">
      <div className="space-y-5 max-w-2xl">
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground">
            Ative ou desative as formas de pagamento disponíveis no checkout. Cadastre novos gateways como Stone, Cielo, etc.
          </p>
          <Button size="sm" onClick={openNew}><Plus className="h-4 w-4 mr-2" /> Novo</Button>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-16">
            <Loader2 className="h-7 w-7 animate-spin text-muted-foreground" />
          </div>
        ) : (
          <div className="space-y-3">
            {sorted.map((gw, idx, arr) => {
              const Icon = ICON_COMPONENTS[gw.icon] || CreditCard;
              const hasConfig = !NO_CONFIG_GATEWAYS.has(gw.id);
              const isOpen = expanded === gw.id;

              return (
                <div key={gw.id} className="bg-card border border-border rounded-xl overflow-hidden">
                  <div className="flex items-center gap-3 p-4">
                    {/* Ordem */}
                    <div className="flex flex-col gap-0.5 shrink-0">
                      <button onClick={() => moveOrder(gw, 'up')} disabled={idx === 0}
                        className="p-0.5 text-muted-foreground hover:text-foreground disabled:opacity-30">
                        <ChevronUp className="h-4 w-4" />
                      </button>
                      <button onClick={() => moveOrder(gw, 'down')} disabled={idx === arr.length - 1}
                        className="p-0.5 text-muted-foreground hover:text-foreground disabled:opacity-30">
                        <ChevronDown className="h-4 w-4" />
                      </button>
                    </div>

                    {/* Ícone */}
                    <div className={`h-10 w-10 rounded-lg flex items-center justify-center shrink-0 ${gw.is_active ? 'bg-primary/10' : 'bg-muted'}`}>
                      <Icon className={`h-5 w-5 ${gw.is_active ? 'text-primary' : 'text-muted-foreground'}`} />
                    </div>

                    {/* Nome e descrição */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-semibold text-sm text-foreground">{gw.name}</span>
                        {gw.is_active
                          ? <Badge className="h-5 text-[10px] bg-emerald-500 hover:bg-emerald-600 text-white">Ativo</Badge>
                          : <Badge variant="secondary" className="h-5 text-[10px]">Inativo</Badge>
                        }
                      </div>
                      <p className="text-xs text-muted-foreground mt-0.5 truncate">{gw.description}</p>
                    </div>

                    {/* Ações */}
                    <div className="flex items-center gap-1 shrink-0">
                      <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(gw)}>
                        <Pencil className="h-4 w-4 text-muted-foreground" />
                      </Button>
                      {!NO_CONFIG_GATEWAYS.has(gw.id) && (
                        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setDeleteId(gw.id)}>
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      )}
                      {hasConfig && (
                        <Button variant="ghost" size="icon"
                          className="h-8 w-8 text-muted-foreground hover:text-foreground"
                          onClick={() => setExpanded(isOpen ? null : gw.id)}>
                          <Settings2 className="h-4 w-4" />
                        </Button>
                      )}
                      <Switch
                        checked={gw.is_active}
                        onCheckedChange={() => toggleActive(gw)}
                      />
                    </div>
                  </div>

                  {/* Mensagem especial para gateways sem config */}
                  {gw.id === 'pix' && gw.is_active && (
                    <div className="px-4 pb-3">
                      <p className="text-xs text-muted-foreground flex items-center gap-1.5">
                        <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500 shrink-0" />
                        Chave PIX configurada em <strong>Configurações da Loja</strong>.
                      </p>
                    </div>
                  )}
                  {gw.id === 'stripe' && gw.is_active && (
                    <div className="px-4 pb-3">
                      <p className="text-xs text-muted-foreground flex items-center gap-1.5">
                        <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500 shrink-0" />
                        Chave Stripe configurada nas variáveis de ambiente do servidor.
                      </p>
                    </div>
                  )}

                  {/* Painel de configuração expansível */}
                  {hasConfig && (
                    <Collapsible open={isOpen} onOpenChange={v => setExpanded(v ? gw.id : null)}>
                      <CollapsibleContent>
                        <Separator />
                        <div className="p-4 space-y-3 bg-muted/30">
                          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                            Configurações de {gw.name}
                          </p>
                          {Object.keys(drafts[gw.id] || {}).map(field => {
                            const label = field.replace(/_/g, ' ').replace(/^\w/, c => c.toUpperCase());
                            const value = drafts[gw.id]?.[field] ?? '';
                            const isTextarea = field === 'instructions';
                            return (
                              <div key={field} className="space-y-1.5">
                                <label className="text-sm font-normal text-foreground">{label}</label>
                                {isTextarea ? (
                                  <Textarea
                                    value={value}
                                    onChange={e => setDraftField(gw.id, field, e.target.value)}
                                    rows={3}
                                    className="text-sm resize-none"
                                    placeholder={label}
                                  />
                                ) : (
                                  <Input
                                    type={field.includes('token') || field.includes('access') || field.includes('password') ? 'password' : 'text'}
                                    value={value}
                                    onChange={e => setDraftField(gw.id, field, e.target.value)}
                                    placeholder={label}
                                    className="h-9 text-sm"
                                  />
                                )}
                              </div>
                            );
                          })}
                          <div className="flex justify-end pt-1">
                            <Button
                              size="sm"
                              className="h-8 text-xs bg-primary text-primary-foreground hover:bg-primary/90"
                              disabled={saving === gw.id}
                              onClick={() => saveConfig(gw)}
                            >
                              {saving === gw.id
                                ? <><Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" /> Salvando...</>
                                : <><Save className="h-3.5 w-3.5 mr-1.5" /> Salvar</>
                              }
                            </Button>
                          </div>
                        </div>
                      </CollapsibleContent>
                    </Collapsible>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* Dica de integração */}
        <div className="rounded-xl border border-dashed border-border p-4 text-sm text-muted-foreground space-y-1">
          <p className="font-medium text-foreground">ℹ️ Como funciona no checkout</p>
          <p>Apenas gateways <strong>ativos</strong> aparecem como opção para o cliente na tela de pagamento. A ordem acima define a sequência de exibição.</p>
          <ul className="mt-1 space-y-0.5 list-disc list-inside text-xs">
            <li><strong>PIX / Stripe</strong> — integrações automáticas via servidor</li>
            <li><strong>PagSeguro / Mercado Pago</strong> — pedido criado como pendente + link de pagamento</li>
            <li><strong>Boleto / Depósito / Stone / Cielo</strong> — gateway manual: apenas cria o pedido. O pagamento é confirmado pelo admin após recebimento.</li>
          </ul>
        </div>

        {/* Dialog Novo/Editar Gateway */}
        <Dialog open={showDialog} onOpenChange={setShowDialog}>
          <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg max-h-[90dvh] overflow-y-auto">
            <DialogHeader><DialogTitle className="text-balance">{editing ? 'Editar Gateway' : 'Novo Gateway de Pagamento'}</DialogTitle></DialogHeader>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-2">
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">ID (código interno) *</Label>
                <Input value={form.id} onChange={e => f('id', e.target.value)} placeholder="Ex: stone" disabled={!!editing} />
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">Nome *</Label>
                <Input value={form.name} onChange={e => f('name', e.target.value)} placeholder="Ex: Stone (Cartão)" />
              </div>
              <div className="space-y-1.5 md:col-span-2">
                <Label className="text-sm font-normal">Descrição</Label>
                <Input value={form.description} onChange={e => f('description', e.target.value)} placeholder="Ex: Pague com cartão via Stone" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">Ícone</Label>
                <Select value={form.icon} onValueChange={v => f('icon', v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {Object.entries(ICON_COMPONENTS).map(([name, Comp]) => (
                      <SelectItem key={name} value={name}>
                        <div className="flex items-center gap-2"><Comp className="h-4 w-4" />{name}</div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">Ordem de exibição</Label>
                <Input type="number" min={0} value={form.sort_order} onChange={e => f('sort_order', parseInt(e.target.value) || 0)} />
              </div>
              <div className="space-y-1.5 md:col-span-2">
                <Label className="text-sm font-normal">Configuração (JSON)</Label>
                <Textarea value={form.configJson} onChange={e => f('configJson', e.target.value)} rows={4} placeholder={`{"instructions":"Pague na maquininha na entrega"}`} />
                <p className="text-xs text-muted-foreground">Use JSON para campos extras (instruções, link, etc.). Deixe {"{}"} se não houver configuração.</p>
              </div>
              <div className="flex items-center gap-2 md:col-span-2">
                <Switch checked={form.is_active} onCheckedChange={v => f('is_active', v)} />
                <Label className="text-sm font-normal cursor-pointer">Ativo no checkout</Label>
              </div>
            </div>
            <DialogFooter className="gap-2">
              <Button variant="outline" onClick={() => setShowDialog(false)}>Cancelar</Button>
              <Button onClick={handleSave} disabled={submitting}>
                {submitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                <Save className="h-4 w-4 mr-2" /> Salvar
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Dialog Delete */}
        <Dialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
          <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
            <DialogHeader><DialogTitle className="text-balance">Remover Gateway</DialogTitle></DialogHeader>
            <p className="text-sm text-muted-foreground">Deseja realmente excluir este gateway de pagamento?</p>
            <DialogFooter className="gap-2">
              <Button variant="outline" onClick={() => setDeleteId(null)}>Cancelar</Button>
              <Button variant="destructive" onClick={handleDelete}><Trash2 className="h-4 w-4 mr-2" /> Remover</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </AdminLayout>
  );
}
