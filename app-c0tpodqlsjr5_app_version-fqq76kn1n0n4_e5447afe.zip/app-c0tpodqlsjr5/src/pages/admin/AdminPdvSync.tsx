import { useState, useEffect } from 'react';
import { RefreshCw, Loader2, ArrowRightLeft, Package, CheckCircle, AlertTriangle, Database } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AdminLayout } from '@/components/layouts/AdminLayout';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import type { ProductImage } from '@/types/types';

interface SyncStats {
  pdvCount: number;
  siteCount: number;
  synced: number;
  newOnPdv: number;
  missingOnSite: number;
  priceDiff: number;
  stockDiff: number;
}

function generateSlug(name: string): string {
  return name
    .toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9\s-]/g, '')
    .trim()
    .replace(/\s+/g, '-')
    .slice(0, 100);
}

function toProductImages(imagesRaw: unknown): ProductImage[] {
  if (!imagesRaw) return [];
  if (typeof imagesRaw === 'string') return [{ url: imagesRaw, alt: '' }];
  if (Array.isArray(imagesRaw)) {
    return imagesRaw.map((img: unknown) => {
      if (typeof img === 'string') return { url: img, alt: '' };
      if (img && typeof img === 'object') {
        const o = img as Record<string, unknown>;
        return { url: String(o.url || o.image_url || ''), alt: String(o.alt || '') };
      }
      return { url: '', alt: '' };
    }).filter(i => i.url);
  }
  return [];
}

export default function AdminPdvSync() {
  const [stats, setStats] = useState<SyncStats>({ pdvCount: 0, siteCount: 0, synced: 0, newOnPdv: 0, missingOnSite: 0, priceDiff: 0, stockDiff: 0 });
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [result, setResult] = useState<{ created: number; updated: number; skipped: number } | null>(null);

  const fetchStats = async () => {
    setLoading(true);
    const [{ data: pdv }, { data: site }] = await Promise.all([
      supabase.from('pdv_products').select('id, code, name, retail_price, stock_qty, active').limit(2000),
      supabase.from('products').select('id, code, name, price, stock_quantity, is_available, pdv_product_id').limit(2000),
    ]);
    const pdvProducts = Array.isArray(pdv) ? pdv : [];
    const siteProducts = Array.isArray(site) ? site : [];

    const siteByCode = new Map(siteProducts.map((p: any) => [p.code, p]));
    const pdvByCode = new Map(pdvProducts.map((p: any) => [p.code, p]));

    let synced = 0, newOnPdv = 0, missingOnSite = 0, priceDiff = 0, stockDiff = 0;

    pdvProducts.forEach((p: any) => {
      const s = siteByCode.get(p.code);
      if (!s) { newOnPdv++; }
      else {
        synced++;
        if (Math.abs((p.retail_price || 0) - (s.price || 0)) > 0.01) priceDiff++;
        if (Math.round(p.stock_qty || 0) !== (s.stock_quantity || 0)) stockDiff++;
      }
    });

    siteProducts.forEach((s: any) => {
      if (!pdvByCode.get(s.code)) missingOnSite++;
    });

    setStats({ pdvCount: pdvProducts.length, siteCount: siteProducts.length, synced, newOnPdv, missingOnSite, priceDiff, stockDiff });
    setLoading(false);
  };

  useEffect(() => { fetchStats(); }, []);

  const handleSync = async () => {
    setSyncing(true);
    setProgress(0);
    setResult(null);

    const [{ data: pdv }, { data: site }] = await Promise.all([
      supabase.from('pdv_products').select('id, code, name, description, retail_price, cost_price, stock_qty, category_id, barcode, unit, active, images, tenant_id').limit(2000),
      supabase.from('products').select('id, code, pdv_product_id, tenant_id').limit(2000),
    ]);

    const pdvProducts = Array.isArray(pdv) ? pdv : [];
    const siteProducts = Array.isArray(site) ? site : [];
    const siteByPdvId = new Map(siteProducts.map((p: any) => [p.pdv_product_id, p]));
    const siteByCode = new Map(siteProducts.map((p: any) => [p.code, p]));

    // Detect tenant_id from existing products if any
    const firstTenant = siteProducts.find((p: any) => p.tenant_id)?.tenant_id ?? null;

    let created = 0, updated = 0, skipped = 0;
    const total = pdvProducts.length;

    for (let i = 0; i < pdvProducts.length; i++) {
      const p = pdvProducts[i];
      const existing = siteByPdvId.get(p.id) || siteByCode.get(p.code);

      const images = toProductImages(p.images);
      const slug = generateSlug(p.name);
      const isAvailable = p.active === true;

      const payload = {
        code: p.code,
        name: p.name,
        slug,
        description: p.description || '',
        price: p.retail_price || 0,
        cost_price: p.cost_price || 0,
        stock_quantity: Math.round(p.stock_qty || 0),
        is_available: isAvailable,
        category_id: p.category_id || null,
        barcode: p.barcode || null,
        unit: p.unit || 'un',
        images,
        pdv_product_id: p.id,
        updated_at: new Date().toISOString(),
      };

      if (existing) {
        const { error } = await supabase.from('products').update(payload).eq('id', existing.id);
        if (!error) updated++; else { skipped++; console.error('Update error:', error); }
      } else {
        const { error } = await supabase.from('products').insert({
          ...payload,
          is_featured: false,
          compare_at_price: null,
          attributes: {},
          tenant_id: p.tenant_id || firstTenant || null,
          created_at: new Date().toISOString(),
        });
        if (!error) created++; else { skipped++; console.error('Insert error:', error); }
      }
      setProgress(Math.round(((i + 1) / total) * 100));
    }

    setResult({ created, updated, skipped });
    setSyncing(false);
    toast.success(`Sincronização concluída! ${created} criados, ${updated} atualizados.`);
    fetchStats();
  };

  const handleDeactivateMissing = async () => {
    const { data: site } = await supabase.from('products').select('id, code').eq('is_available', true).limit(2000);
    const { data: pdv } = await supabase.from('pdv_products').select('code').limit(2000);
    const siteProducts = Array.isArray(site) ? site : [];
    const pdvCodes = new Set((Array.isArray(pdv) ? pdv : []).map((p: any) => p.code));
    const toDeactivate = siteProducts.filter((s: any) => !pdvCodes.has(s.code));

    if (toDeactivate.length === 0) { toast.info('Nenhum produto para desativar'); return; }

    const ids = toDeactivate.map((s: any) => s.id);
    const { error } = await supabase.from('products').update({ is_available: false }).in('id', ids);
    if (error) { toast.error('Erro ao desativar: ' + error.message); return; }
    toast.success(`${toDeactivate.length} produto(s) desativado(s)`);
    fetchStats();
  };

  return (
    <AdminLayout title="Sincronizar PDV → Site" subtitle="Atualize os produtos do site a partir do PDV">
      <div className="max-w-4xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-accent/10 flex items-center justify-center">
              <ArrowRightLeft className="h-5 w-5 text-accent" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-foreground text-balance">Sincronizar Produtos</h1>
              <p className="text-sm text-muted-foreground">PDV → Site</p>
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <Button variant="outline" onClick={fetchStats} disabled={loading || syncing} className="gap-2 h-9 text-xs">
              <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} /> Atualizar
            </Button>
            <Button onClick={handleSync} disabled={syncing} className="gap-2 h-9">
              {syncing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Database className="h-4 w-4" />}
              Sincronizar Agora
            </Button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4 flex flex-col items-center text-center gap-1">
              <Package className="h-5 w-5 text-muted-foreground" />
              <p className="text-2xl font-bold">{stats.pdvCount}</p>
              <p className="text-xs text-muted-foreground">Produtos no PDV</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex flex-col items-center text-center gap-1">
              <Package className="h-5 w-5 text-muted-foreground" />
              <p className="text-2xl font-bold">{stats.siteCount}</p>
              <p className="text-xs text-muted-foreground">Produtos no Site</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex flex-col items-center text-center gap-1">
              <CheckCircle className="h-5 w-5 text-success" />
              <p className="text-2xl font-bold">{stats.synced}</p>
              <p className="text-xs text-muted-foreground">Sincronizados</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex flex-col items-center text-center gap-1">
              <AlertTriangle className="h-5 w-5 text-warning" />
              <p className="text-2xl font-bold">{stats.newOnPdv}</p>
              <p className="text-xs text-muted-foreground">Novos no PDV</p>
            </CardContent>
          </Card>
        </div>

        {/* Differences */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Diferenças Encontradas</CardTitle>
            <CardDescription>Comparação entre PDV e Site</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between p-3 rounded-lg bg-muted/40">
              <span className="text-sm">Produtos no PDV que não existem no Site</span>
              <Badge variant={stats.newOnPdv > 0 ? 'destructive' : 'secondary'}>{stats.newOnPdv}</Badge>
            </div>
            <div className="flex items-center justify-between p-3 rounded-lg bg-muted/40">
              <span className="text-sm">Produtos no Site que não existem no PDV</span>
              {stats.missingOnSite > 0 ? <Badge className="bg-warning text-warning-foreground">{stats.missingOnSite}</Badge> : <Badge variant="secondary">{stats.missingOnSite}</Badge>}
            </div>
            <div className="flex items-center justify-between p-3 rounded-lg bg-muted/40">
              <span className="text-sm">Produtos com preço diferente</span>
              {stats.priceDiff > 0 ? <Badge className="bg-warning text-warning-foreground">{stats.priceDiff}</Badge> : <Badge variant="secondary">{stats.priceDiff}</Badge>}
            </div>
            <div className="flex items-center justify-between p-3 rounded-lg bg-muted/40">
              <span className="text-sm">Produtos com estoque diferente</span>
              {stats.stockDiff > 0 ? <Badge className="bg-warning text-warning-foreground">{stats.stockDiff}</Badge> : <Badge variant="secondary">{stats.stockDiff}</Badge>}
            </div>

            {stats.missingOnSite > 0 && (
              <Alert className="bg-warning/5 border-warning/20">
                <AlertTriangle className="h-4 w-4 text-warning shrink-0" />
                <AlertDescription className="text-sm">
                  {stats.missingOnSite} produto(s) existem no Site mas não no PDV.
                  <Button variant="link" size="sm" className="h-auto p-0 ml-1 text-xs" onClick={handleDeactivateMissing}>
                    Desativar todos
                  </Button>
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>

        {/* Progress & Result */}
        {syncing && (
          <Card>
            <CardContent className="p-6 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Sincronizando produtos...</span>
                <span className="text-sm text-muted-foreground">{progress}%</span>
              </div>
              <Progress value={progress} className="h-2" />
            </CardContent>
          </Card>
        )}

        {result && !syncing && (
          <Card className="border-success/30 bg-success/5">
            <CardContent className="p-5 space-y-2">
              <div className="flex items-center gap-2 text-success">
                <CheckCircle className="h-5 w-5" />
                <p className="font-semibold">Sincronização concluída!</p>
              </div>
              <div className="grid grid-cols-3 gap-3 text-center">
                <div className="bg-card rounded-lg p-3 border border-border">
                  <p className="text-xl font-bold text-success">{result.created}</p>
                  <p className="text-xs text-muted-foreground">Criados</p>
                </div>
                <div className="bg-card rounded-lg p-3 border border-border">
                  <p className="text-xl font-bold text-info">{result.updated}</p>
                  <p className="text-xs text-muted-foreground">Atualizados</p>
                </div>
                <div className="bg-card rounded-lg p-3 border border-border">
                  <p className="text-xl font-bold text-muted-foreground">{result.skipped}</p>
                  <p className="text-xs text-muted-foreground">Ignorados</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </AdminLayout>
  );
}
