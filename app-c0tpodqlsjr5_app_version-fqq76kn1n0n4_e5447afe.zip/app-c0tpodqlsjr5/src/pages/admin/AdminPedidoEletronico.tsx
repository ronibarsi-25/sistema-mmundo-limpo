import { useState, useEffect, useMemo } from 'react';
import { supabase } from '@/db/supabase';
import { AdminLayout } from '@/components/layouts/AdminLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Search, ShoppingCart, TrendingUp, PackageCheck,
  AlertTriangle, Printer, ArrowDownAZ, Download, Package, DollarSign
} from 'lucide-react';
import type { Product } from '@/types/types';

interface AbcItem {
  product: Product;
  stockValue: number;
  stockValuePct: number;
  accumPct: number;
  curve: 'A' | 'B' | 'C';
  suggestedQty: number;
  needsReorder: boolean;
}

export default function AdminPedidoEletronico() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [minStockA, setMinStockA] = useState(10);
  const [minStockB, setMinStockB] = useState(5);
  const [minStockC, setMinStockC] = useState(3);

  useEffect(() => {
    loadProducts();
  }, []);

  const loadProducts = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('products')
      .select('*, categories(*)')
      .order('name');
    setProducts(Array.isArray(data) ? data : []);
    setLoading(false);
  };

  const abcData = useMemo((): AbcItem[] => {
    const valid = products
      .filter(p => (p.cost_price ?? 0) > 0 && p.stock_quantity >= 0)
      .map(p => ({
        product: p,
        stockValue: p.stock_quantity * (p.cost_price ?? 0),
      }));

    const total = valid.reduce((s, v) => s + v.stockValue, 0);
    if (total === 0) return [];

    const sorted = valid
      .sort((a, b) => b.stockValue - a.stockValue)
      .map(v => ({ ...v, stockValuePct: (v.stockValue / total) * 100 }));

    let accum = 0;
    const withCurve: AbcItem[] = sorted.map(v => {
      accum += v.stockValuePct;
      let curve: 'A' | 'B' | 'C' = 'C';
      if (accum <= 80) curve = 'A';
      else if (accum <= 95) curve = 'B';

      const min = curve === 'A' ? minStockA : curve === 'B' ? minStockB : minStockC;
      const needsReorder = v.product.stock_quantity < min;
      const suggestedQty = needsReorder ? Math.max(min - v.product.stock_quantity, 0) : 0;

      return {
        ...v,
        accumPct: accum,
        curve,
        needsReorder,
        suggestedQty,
      };
    });

    return withCurve;
  }, [products, minStockA, minStockB, minStockC]);

  const filtered = abcData.filter(i =>
    i.product.name.toLowerCase().includes(search.toLowerCase()) ||
    (i.product.code && i.product.code.toLowerCase().includes(search.toLowerCase()))
  );

  const curveCounts = useMemo(() => {
    const a = abcData.filter(i => i.curve === 'A').length;
    const b = abcData.filter(i => i.curve === 'B').length;
    const c = abcData.filter(i => i.curve === 'C').length;
    const reorder = abcData.filter(i => i.needsReorder).length;
    return { a, b, c, reorder };
  }, [abcData]);

  const totalStockValue = abcData.reduce((s, i) => s + i.stockValue, 0);
  const reorderValue = abcData.filter(i => i.needsReorder).reduce((s, i) => s + i.suggestedQty * (i.product.cost_price ?? 0), 0);

  const handlePrint = () => {
    const w = window.open('', '_blank');
    if (!w) return;
    const reorderItems = abcData.filter(i => i.needsReorder);
    const html = `
      <html><head><title>Pedido Eletrônico - Mundo Limpo</title>
      <style>body{font-family:sans-serif;padding:24px}table{border-collapse:collapse;width:100%}th,td{border:1px solid #ccc;padding:8px;text-align:left}th{background:#f3f4f6}</style>
      </head><body>
      <h2>Pedido de Reposição</h2>
      <p><strong>Data:</strong> ${new Date().toLocaleDateString('pt-BR')}</p>
      <p><strong>Itens para reposição:</strong> ${reorderItems.length}</p>
      <table>
        <thead><tr><th>Curva</th><th>Código</th><th>Produto</th><th>Estoque Atual</th><th>Qtd. Sugerida</th><th>Preço Custo</th><th>Valor Total</th></tr></thead>
        <tbody>
          ${reorderItems.map(i => `
            <tr>
              <td><strong>${i.curve}</strong></td>
              <td>${i.product.code || '-'}</td>
              <td>${i.product.name}</td>
              <td>${i.product.stock_quantity}</td>
              <td>${i.suggestedQty}</td>
              <td>R$ ${(i.product.cost_price ?? 0).toFixed(2)}</td>
              <td>R$ ${(i.suggestedQty * (i.product.cost_price ?? 0)).toFixed(2)}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>
      <p style="margin-top:16px"><strong>Valor total do pedido:</strong> R$ ${reorderValue.toFixed(2)}</p>
      </body></html>
    `;
    w.document.write(html);
    w.document.close();
    setTimeout(() => w.print(), 300);
  };

  const handleExportCSV = () => {
    const reorderItems = abcData.filter(i => i.needsReorder);
    const rows = [
      ['Curva', 'Codigo', 'Produto', 'Estoque Atual', 'Qtd Sugerida', 'Preço Custo', 'Valor Total'],
      ...reorderItems.map(i => [
        i.curve,
        i.product.code || '',
        i.product.name,
        String(i.product.stock_quantity),
        String(i.suggestedQty),
        (i.product.cost_price ?? 0).toFixed(2),
        (i.suggestedQty * (i.product.cost_price ?? 0)).toFixed(2),
      ]),
    ];
    const csv = rows.map(r => r.map(c => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `pedido-reposicao-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <AdminLayout title="Pedido Eletrônico — Curva ABC">
      <div className="space-y-5">
        {/* Resumo cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <Card className="bg-card">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="h-9 w-9 rounded-lg bg-emerald-100 dark:bg-emerald-900 flex items-center justify-center">
                <ArrowDownAZ className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Curva A</p>
                <p className="text-lg font-bold">{curveCounts.a} <span className="text-xs font-normal text-muted-foreground">itens</span></p>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-card">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="h-9 w-9 rounded-lg bg-blue-100 dark:bg-blue-900 flex items-center justify-center">
                <TrendingUp className="h-4 w-4 text-blue-600 dark:text-blue-400" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Curva B</p>
                <p className="text-lg font-bold">{curveCounts.b} <span className="text-xs font-normal text-muted-foreground">itens</span></p>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-card">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="h-9 w-9 rounded-lg bg-muted flex items-center justify-center">
                <Package className="h-4 w-4 text-muted-foreground" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Curva C</p>
                <p className="text-lg font-bold">{curveCounts.c} <span className="text-xs font-normal text-muted-foreground">itens</span></p>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-card">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="h-9 w-9 rounded-lg bg-destructive/10 flex items-center justify-center">
                <AlertTriangle className="h-4 w-4 text-destructive" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Para Repor</p>
                <p className="text-lg font-bold">{curveCounts.reorder} <span className="text-xs font-normal text-muted-foreground">itens</span></p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Valor total e pedido */}
        <div className="flex flex-col md:flex-row md:items-center gap-3">
          <div className="flex-1 flex items-center gap-3 bg-muted/50 rounded-xl px-4 py-3">
            <DollarSign className="h-5 w-5 text-primary shrink-0" />
            <div>
              <p className="text-xs text-muted-foreground">Valor total em estoque</p>
              <p className="text-base font-bold">R$ {totalStockValue.toFixed(2)}</p>
            </div>
          </div>
          <div className="flex-1 flex items-center gap-3 bg-destructive/5 rounded-xl px-4 py-3">
            <ShoppingCart className="h-5 w-5 text-destructive shrink-0" />
            <div>
              <p className="text-xs text-muted-foreground">Valor do pedido de reposição</p>
              <p className="text-base font-bold text-destructive">R$ {reorderValue.toFixed(2)}</p>
            </div>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" className="gap-1.5" onClick={handleExportCSV}>
              <Download className="h-4 w-4" /> CSV
            </Button>
            <Button size="sm" className="gap-1.5" onClick={handlePrint}>
              <Printer className="h-4 w-4" /> Imprimir Pedido
            </Button>
          </div>
        </div>

        {/* Filtros de estoque mínimo */}
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-semibold">Estoque Mínimo por Curva</CardTitle></CardHeader>
          <CardContent className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground">Curva A (alta rotatividade)</Label>
              <Input type="number" min={0} value={minStockA} onChange={e => setMinStockA(parseInt(e.target.value) || 0)} className="h-9" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground">Curva B (média rotatividade)</Label>
              <Input type="number" min={0} value={minStockB} onChange={e => setMinStockB(parseInt(e.target.value) || 0)} className="h-9" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground">Curva C (baixa rotatividade)</Label>
              <Input type="number" min={0} value={minStockC} onChange={e => setMinStockC(parseInt(e.target.value) || 0)} className="h-9" />
            </div>
          </CardContent>
        </Card>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar produto..." className="pl-9 h-10" />
        </div>

        {/* Table */}
        <div className="bg-card rounded-xl border border-border overflow-hidden">
          {loading ? (
            <div className="p-5 space-y-3">{[...Array(6)].map((_, i) => <Skeleton key={i} className="h-12 bg-muted" />)}</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-max">
                <thead>
                  <tr className="border-b border-border bg-muted/40">
                    {['Curva', 'Produto', 'Estoque', 'Custo', 'Preço Venda', 'Valor Estoque', '% Acum.', 'Status', 'Sugerido'].map(h => (
                      <th key={h} className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground whitespace-nowrap">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {filtered.map(item => (
                    <tr key={item.product.id} className={`border-b border-border last:border-0 hover:bg-muted/20 transition-colors ${item.needsReorder ? 'bg-destructive/5' : ''}`}>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <Badge className={`border-0 text-xs font-bold ${
                          item.curve === 'A' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900 dark:text-emerald-300' :
                          item.curve === 'B' ? 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300' :
                          'bg-muted text-muted-foreground'
                        }`}>{item.curve}</Badge>
                      </td>
                      <td className="px-4 py-3 text-sm font-medium whitespace-nowrap min-w-0">
                        <div className="truncate max-w-[220px]">{item.product.name}</div>
                        {item.product.code && <div className="text-[10px] text-muted-foreground">{item.product.code}</div>}
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <Badge className={`border-0 text-sm font-bold ${item.product.stock_quantity === 0 ? 'bg-destructive/15 text-destructive' : item.product.stock_quantity <= 5 ? 'bg-warning/15 text-warning-foreground' : 'bg-success/15 text-success'}`}>
                          {item.product.stock_quantity}
                        </Badge>
                      </td>
                      <td className="px-4 py-3 text-sm text-muted-foreground whitespace-nowrap">R$ {(item.product.cost_price ?? 0).toFixed(2)}</td>
                      <td className="px-4 py-3 text-sm text-muted-foreground whitespace-nowrap">R$ {item.product.price.toFixed(2)}</td>
                      <td className="px-4 py-3 text-sm font-medium whitespace-nowrap">R$ {item.stockValue.toFixed(2)}</td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <div className="flex items-center gap-2">
                          <Progress value={item.accumPct} className="h-1.5 w-16" />
                          <span className="text-xs text-muted-foreground">{item.accumPct.toFixed(1)}%</span>
                        </div>
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        {item.needsReorder ? (
                          <Badge className="border-0 bg-destructive/15 text-destructive text-xs gap-1"><AlertTriangle className="h-3 w-3" /> Repor</Badge>
                        ) : (
                          <Badge className="border-0 bg-success/15 text-success text-xs gap-1"><PackageCheck className="h-3 w-3" /> OK</Badge>
                        )}
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap text-sm font-bold text-foreground">
                        {item.suggestedQty > 0 ? `${item.suggestedQty} un` : <span className="text-muted-foreground font-normal text-xs">—</span>}
                      </td>
                    </tr>
                  ))}
                  {filtered.length === 0 && (
                    <tr><td colSpan={9} className="text-center text-sm text-muted-foreground py-8">Nenhum produto encontrado</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </AdminLayout>
  );
}

function Label({ children, className }: { children: React.ReactNode; className?: string }) {
  return <label className={`text-sm font-normal ${className || ''}`}>{children}</label>;
}
