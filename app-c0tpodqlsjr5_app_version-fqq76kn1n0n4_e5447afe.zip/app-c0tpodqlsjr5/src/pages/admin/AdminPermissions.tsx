import { useState, useEffect } from 'react';
import { Shield, Save, Loader2, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { AdminLayout } from '@/components/layouts/AdminLayout';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import type { UserRole } from '@/types/types';

interface Profile {
  id: string;
  full_name: string | null;
  email: string | null;
  role: UserRole;
}

const PERMISSIONS = [
  { key: 'edit_products', label: 'Editar Produtos', desc: 'Criar, editar e excluir produtos' },
  { key: 'view_reports', label: 'Ver Relatórios Financeiros', desc: 'Acessar vendas, faturamento e métricas' },
  { key: 'export_data', label: 'Exportar Dados', desc: 'Exportar produtos, vendas, estoque, etc.' },
  { key: 'import_products', label: 'Importar Produtos', desc: 'Importar produtos em lote via CSV' },
  { key: 'print_labels', label: 'Imprimir Etiquetas', desc: 'Gerar e imprimir etiquetas de produtos' },
  { key: 'manage_permissions', label: 'Gerenciar Permissões', desc: 'Alterar permissões de outros usuários' },
  { key: 'configure_banner', label: 'Configurar Banner', desc: 'Editar banner de inauguração e cupom' },
  { key: 'view_movements', label: 'Ver Movimentações', desc: 'Acessar histórico de movimentações de estoque' },
  { key: 'manage_stock', label: 'Gerenciar Estoque', desc: 'Ajustar quantidades e visualizar estoque' },
  { key: 'sync_pdv', label: 'Sincronizar PDV', desc: 'Sincronizar produtos entre PDV e Site' },
];

const ROLE_DEFAULTS: Record<UserRole, string[]> = {
  admin: PERMISSIONS.map(p => p.key),
  gestor: ['edit_products', 'view_reports', 'export_data', 'print_labels', 'view_movements', 'manage_stock', 'sync_pdv'],
  operador: ['edit_products', 'print_labels', 'manage_stock'],
  vendedor: ['view_movements', 'manage_stock'],
  user: [],
};

export default function AdminPermissions() {
  const [users, setUsers] = useState<Profile[]>([]);
  const [selectedUser, setSelectedUser] = useState<Profile | null>(null);
  const [userPerms, setUserPerms] = useState<Record<string, string[]>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    supabase.from('profiles').select('id, full_name, email, role').order('full_name').then(({ data }) => {
      const list = Array.isArray(data) ? data : [];
      setUsers(list);
      // Inicializar permissões com defaults por role
      const perms: Record<string, string[]> = {};
      list.forEach(u => {
        perms[u.id] = ROLE_DEFAULTS[u.role as UserRole] || [];
      });
      setUserPerms(perms);
      setLoading(false);
    });
  }, []);

  const togglePerm = (permKey: string) => {
    if (!selectedUser) return;
    const current = userPerms[selectedUser.id] || [];
    const next = current.includes(permKey)
      ? current.filter(p => p !== permKey)
      : [...current, permKey];
    setUserPerms({ ...userPerms, [selectedUser.id]: next });
  };

  const handleSave = async () => {
    if (!selectedUser) return;
    setSaving(true);
    // Salvar na tabela user_permissions
    const perms = userPerms[selectedUser.id] || [];
    const { error } = await supabase
      .from('user_permissions')
      .upsert({ user_id: selectedUser.id, permissions: perms, updated_at: new Date().toISOString() }, { onConflict: 'user_id' });
    if (error) {
      toast.error('Erro ao salvar: ' + error.message);
    } else {
      toast.success('Permissões salvas');
    }
    setSaving(false);
  };

  return (
    <AdminLayout title="Permissões de Usuários" subtitle="Controle granular de acesso">
      <div className="max-w-5xl mx-auto space-y-6">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-xl bg-accent/10 flex items-center justify-center">
            <Shield className="h-5 w-5 text-accent" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-foreground text-balance">Permissões</h1>
            <p className="text-sm text-muted-foreground">Gerencie o que cada usuário pode fazer</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Lista de usuários */}
          <Card className="md:col-span-1">
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Usuários</CardTitle>
            </CardHeader>
            <CardContent className="space-y-1 p-3">
              {loading ? (
                <p className="text-sm text-muted-foreground py-4 text-center">Carregando...</p>
              ) : users.map(u => (
                <button
                  key={u.id}
                  onClick={() => setSelectedUser(u)}
                  className={`w-full text-left px-3 py-2.5 rounded-lg text-sm transition-colors ${
                    selectedUser?.id === u.id ? 'bg-accent/10 text-accent font-medium' : 'text-foreground hover:bg-muted'
                  }`}
                >
                  <p className="font-medium truncate">{u.full_name || 'Sem nome'}</p>
                  <div className="flex items-center gap-1 mt-0.5">
                    <Badge variant="secondary" className="text-[10px] h-4 px-1">{u.role}</Badge>
                    <span className="text-[10px] text-muted-foreground truncate">{u.email}</span>
                  </div>
                </button>
              ))}
            </CardContent>
          </Card>

          {/* Permissões do usuário selecionado */}
          <Card className="md:col-span-2">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-base">
                    {selectedUser ? selectedUser.full_name || 'Usuário' : 'Selecione um usuário'}
                  </CardTitle>
                  <CardDescription>
                    {selectedUser ? `Perfil: ${selectedUser.role}` : 'Clique em um usuário para editar'}
                  </CardDescription>
                </div>
                {selectedUser && (
                  <Button onClick={handleSave} disabled={saving} size="sm" className="gap-2 h-9">
                    {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                    Salvar
                  </Button>
                )}
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              {!selectedUser ? (
                <div className="text-center py-10 text-muted-foreground text-sm">
                  Selecione um usuário na lista ao lado para gerenciar permissões.
                </div>
              ) : (
                PERMISSIONS.map(perm => {
                  const active = (userPerms[selectedUser.id] || []).includes(perm.key);
                  return (
                    <div key={perm.key} className="flex items-start justify-between gap-3 p-3 rounded-lg border border-border hover:bg-muted/20 transition-colors">
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium">{perm.label}</p>
                        <p className="text-xs text-muted-foreground">{perm.desc}</p>
                      </div>
                      <Switch checked={active} onCheckedChange={() => togglePerm(perm.key)} />
                    </div>
                  );
                })
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </AdminLayout>
  );
}
