import { useEffect, useState } from 'react';
import { Clock, Search, UserCheck, LogIn, Coffee, LogOut, ChevronRight, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { AdminLayout } from '@/components/layouts/AdminLayout';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';

interface Employee { id: string; name: string; role: string; department: string; status: string; }
interface TimeRecord {
  id: string; employee_id: string; punch_type: 'entry' | 'lunch_start' | 'lunch_end' | 'exit';
  punched_at: string; notes: string | null;
  employees?: { name: string; role: string } | null;
}

const PUNCH_TYPES: { value: string; label: string; icon: typeof LogIn; color: string }[] = [
  { value: 'entry', label: 'Entrada', icon: LogIn, color: 'text-success' },
  { value: 'lunch_start', label: 'Saída Almoço', icon: Coffee, color: 'text-warning' },
  { value: 'lunch_end', label: 'Retorno Almoço', icon: Coffee, color: 'text-info' },
  { value: 'exit', label: 'Saída', icon: LogOut, color: 'text-destructive' },
];

function calcHoursWorked(records: TimeRecord[]): { worked: number; overtime: number } {
  const sorted = [...records].sort((a, b) => new Date(a.punched_at).getTime() - new Date(b.punched_at).getTime());
  let entry: Date | null = null;
  let lunchStart: Date | null = null;
  let lunchDuration = 0;
  let worked = 0;

  for (const r of sorted) {
    const t = new Date(r.punched_at);
    if (r.punch_type === 'entry') entry = t;
    else if (r.punch_type === 'lunch_start') lunchStart = t;
    else if (r.punch_type === 'lunch_end' && lunchStart) { lunchDuration += (t.getTime() - lunchStart.getTime()) / 3600000; lunchStart = null; }
    else if (r.punch_type === 'exit' && entry) { worked = (t.getTime() - entry.getTime()) / 3600000 - lunchDuration; }
  }
  return { worked: Math.max(0, worked), overtime: Math.max(0, worked - 8) };
}

export default function AdminPonto() {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [records, setRecords] = useState<TimeRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [empFilter, setEmpFilter] = useState('all');
  const [dateFrom, setDateFrom] = useState(new Date().toISOString().split('T')[0]);
  const [dateTo, setDateTo] = useState(new Date().toISOString().split('T')[0]);
  const [showDialog, setShowDialog] = useState(false);
  const [punchForm, setPunchForm] = useState({ employee_id: '', punch_type: 'entry', notes: '' });
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => { loadEmployees(); }, []);
  useEffect(() => { loadRecords(); }, [dateFrom, dateTo, empFilter]);

  const loadEmployees = async () => {
    const { data } = await supabase.from('employees').select('id,name,role,department,status').eq('status','active').order('name');
    setEmployees((data as Employee[]) || []);
  };

  const loadRecords = async () => {
    setLoading(true);
    let q = supabase.from('time_records')
      .select('*, employees(name,role)')
      .gte('punched_at', dateFrom + 'T00:00:00')
      .lte('punched_at', dateTo + 'T23:59:59')
      .order('punched_at', { ascending: false });
    if (empFilter !== 'all') q = q.eq('employee_id', empFilter);
    const { data } = await q;
    setRecords((data as TimeRecord[]) || []);
    setLoading(false);
  };

  const handleRegister = async () => {
    if (!punchForm.employee_id) { toast.error('Selecione o funcionário'); return; }
    setSubmitting(true);
    const { error } = await supabase.from('time_records').insert({
      employee_id: punchForm.employee_id, punch_type: punchForm.punch_type,
      punched_at: new Date().toISOString(), notes: punchForm.notes || null,
    });
    setSubmitting(false);
    if (error) { toast.error('Erro ao registrar ponto: ' + error.message); return; }
    const typeLabel = PUNCH_TYPES.find(t => t.value === punchForm.punch_type)?.label || 'Ponto';
    toast.success(`${typeLabel} registrada com sucesso!`);
    setShowDialog(false);
    loadRecords();
  };

  // Group records by employee for frequency summary
  const grouped = records.reduce<Record<string, TimeRecord[]>>((acc, r) => {
    acc[r.employee_id] = acc[r.employee_id] || [];
    acc[r.employee_id].push(r);
    return acc;
  }, {});

  const filtered = records.filter(r => {
    const q = search.toLowerCase();
    return !q || r.employees?.name?.toLowerCase().includes(q) || r.employees?.role?.toLowerCase().includes(q);
  });

  const today = new Date().toISOString().split('T')[0];

  return (
    <AdminLayout title="Ponto Eletrônico" subtitle="Controle de jornada de trabalho"
      breadcrumbs={[{ label: 'Admin', path: '/admin' }, { label: 'Ponto Eletrônico' }]}>

      {/* Quick register + today stats */}
      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <Card className="flex-1 cursor-pointer hover:shadow-md transition-shadow" onClick={() => setShowDialog(true)}>
          <CardContent className="p-5 flex items-center gap-4">
            <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
              <UserCheck className="h-6 w-6 text-primary" />
            </div>
            <div>
              <p className="font-bold text-foreground">Registrar Ponto</p>
              <p className="text-sm text-muted-foreground">Clique para registrar entrada ou saída</p>
            </div>
            <ChevronRight className="h-5 w-5 text-muted-foreground ml-auto shrink-0" />
          </CardContent>
        </Card>
        <Card className="flex-1">
          <CardContent className="p-5">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Hoje — Batidas</p>
            <p className="text-3xl font-bold text-foreground">
              {records.filter(r => r.punched_at.startsWith(today)).length}
            </p>
          </CardContent>
        </Card>
        <Card className="flex-1">
          <CardContent className="p-5">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Funcionários no período</p>
            <p className="text-3xl font-bold text-foreground">{Object.keys(grouped).length}</p>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex flex-col md:flex-row gap-3 mb-5">
        <div className="relative flex-1 min-w-0">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Buscar funcionário..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
        </div>
        <Select value={empFilter} onValueChange={setEmpFilter}>
          <SelectTrigger className="w-full md:w-52 shrink-0"><SelectValue placeholder="Funcionário" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos os funcionários</SelectItem>
            {employees.map(e => <SelectItem key={e.id} value={e.id}>{e.name}</SelectItem>)}
          </SelectContent>
        </Select>
        <Input type="date" value={dateFrom} onChange={e => setDateFrom(e.target.value)} className="w-full md:w-36 shrink-0" />
        <Input type="date" value={dateTo} onChange={e => setDateTo(e.target.value)} className="w-full md:w-36 shrink-0" />
        <Button size="sm" onClick={() => setShowDialog(true)} className="shrink-0">
          <Clock className="h-4 w-4 mr-1.5" /> Registrar Ponto
        </Button>
      </div>

      {/* Records Table */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm min-w-max">
            <thead>
              <tr className="border-b border-border bg-muted/40">
                {['Funcionário', 'Tipo', 'Data/Hora', 'Observação'].map(h => (
                  <th key={h} className="text-left px-4 py-3 font-semibold text-muted-foreground uppercase text-[11px] tracking-wide whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {loading ? Array.from({ length: 5 }).map((_, i) => (
                <tr key={i}><td colSpan={4} className="px-4 py-3"><Skeleton className="h-5 w-full bg-muted" /></td></tr>
              )) : filtered.length === 0 ? (
                <tr><td colSpan={4} className="text-center py-12 text-muted-foreground">
                  <Clock className="h-8 w-8 mx-auto mb-2 opacity-30" />
                  <p>Nenhuma batida encontrada no período</p>
                </td></tr>
              ) : filtered.map(r => {
                const pType = PUNCH_TYPES.find(t => t.value === r.punch_type)!;
                return (
                  <tr key={r.id} className="hover:bg-muted/30 transition-colors">
                    <td className="px-4 py-3 font-medium whitespace-nowrap">
                      {r.employees?.name || '—'}
                      <p className="text-xs text-muted-foreground font-normal">{r.employees?.role}</p>
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <span className={`inline-flex items-center gap-1.5 text-xs font-medium ${pType.color}`}>
                        <pType.icon className="h-3.5 w-3.5" />
                        {pType.label}
                      </span>
                    </td>
                    <td className="px-4 py-3 font-mono text-xs whitespace-nowrap">
                      {new Date(r.punched_at).toLocaleString('pt-BR')}
                    </td>
                    <td className="px-4 py-3 text-muted-foreground whitespace-nowrap">{r.notes || '—'}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Hours summary per employee */}
      {Object.keys(grouped).length > 0 && (
        <div className="mt-6">
          <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3">Resumo de Horas no Período</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {Object.entries(grouped).map(([empId, recs]) => {
              const emp = employees.find(e => e.id === empId) || recs[0]?.employees;
              const { worked, overtime } = calcHoursWorked(recs);
              return (
                <div key={empId} className="bg-card border border-border rounded-xl p-4 flex items-center gap-3">
                  <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-sm shrink-0">
                    {(emp?.name || '?').slice(0, 2).toUpperCase()}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="font-medium truncate text-sm">{emp?.name || 'Funcionário'}</p>
                    <p className="text-xs text-muted-foreground">{recs.length} batida(s)</p>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="text-sm font-bold">{worked.toFixed(1)}h</p>
                    {overtime > 0 && <p className="text-xs text-warning">+{overtime.toFixed(1)}h extra</p>}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Register Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><Clock className="h-5 w-5 text-primary" /> Registrar Ponto</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Funcionário *</Label>
              <Select value={punchForm.employee_id} onValueChange={v => setPunchForm(p => ({ ...p, employee_id: v }))}>
                <SelectTrigger><SelectValue placeholder="Selecionar funcionário" /></SelectTrigger>
                <SelectContent>{employees.map(e => <SelectItem key={e.id} value={e.id}>{e.name} — {e.role}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Tipo de Batida</Label>
              <div className="grid grid-cols-2 gap-2">
                {PUNCH_TYPES.map(pt => (
                  <button key={pt.value} type="button"
                    onClick={() => setPunchForm(p => ({ ...p, punch_type: pt.value }))}
                    className={`flex items-center gap-2 p-3 rounded-lg border text-sm font-medium transition-colors ${
                      punchForm.punch_type === pt.value
                        ? 'border-primary bg-primary/10 text-primary'
                        : 'border-border bg-muted/30 text-muted-foreground hover:bg-muted/60'
                    }`}>
                    <pt.icon className={`h-4 w-4 ${punchForm.punch_type === pt.value ? 'text-primary' : pt.color}`} />
                    {pt.label}
                  </button>
                ))}
              </div>
            </div>
            <div className="bg-muted/40 rounded-lg p-3 text-sm text-center text-muted-foreground">
              <Clock className="h-4 w-4 inline mr-1.5 -mt-0.5" />
              Horário atual: <span className="font-bold text-foreground">{new Date().toLocaleTimeString('pt-BR')}</span>
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Observação (opcional)</Label>
              <Input value={punchForm.notes} onChange={e => setPunchForm(p => ({ ...p, notes: e.target.value }))} placeholder="Ex: Chegou 10 min atrasado" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDialog(false)}>Cancelar</Button>
            <Button onClick={handleRegister} disabled={submitting}>
              {submitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Registrar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
}
