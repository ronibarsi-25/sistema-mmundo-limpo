import { useState, useEffect } from 'react';
import { Plus, Pencil, Trash2, Search, Loader2, X, Image as ImageIcon, Globe, GlobeOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { Skeleton } from '@/components/ui/skeleton';
import { AdminLayout } from '@/components/layouts/AdminLayout';
import { ImageUploader } from '@/components/admin/ImageUploader';
import { useStore } from '@/contexts/StoreContext';
import { PLAN_LIMITS } from '@/types/types';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import { useForm } from 'react-hook-form';
import type { Product, Category } from '@/types/types';

interface ProductForm {
  name: string; description: string; price: string; compare_at_price: string;
  category_id: string; stock_quantity: string; is_available: boolean; is_featured: boolean;
  image_url: string; video_url: string;
}

export default function AdminProducts() {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [editing, setEditing] = useState<Product | null>(null);
  const [saving, setSaving] = useState(false);
  const [availabilityFilter, setAvailabilityFilter] = useState<'all' | 'available' | 'unavailable'>('all');
  const { subscription } = useStore();

  const form = useForm<ProductForm>({
    defaultValues: { name: '', description: '', price: '', compare_at_price: '', category_id: 'none', stock_quantity: '0', is_available: true, is_featured: false, image_url: '', video_url: '' }
  });

  const load = async () => {
    const [pRes, cRes] = await Promise.all([
      supabase.from('products').select('*, categories(*)').order('created_at', { ascending: false }),
      supabase.from('categories').select('*').eq('is_active', true).order('name')
    ]);
    setProducts(Array.isArray(pRes.data) ? pRes.data : []);
    setCategories(Array.isArray(cRes.data) ? cRes.data : []);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const openCreate = () => {
    if (subscription) {
      const limit = PLAN_LIMITS[subscription.plan_level || 'prata'].maxProducts;
      if (products.length >= limit) {
        toast.error(`Limite de produtos atingido para o plano ${subscription.plan_level}! Seu limite é de ${limit} produtos.`);
        return;
      }
    }
    setEditing(null);
    form.reset({ name: '', description: '', price: '', compare_at_price: '', category_id: 'none', stock_quantity: '0', is_available: true, is_featured: false, image_url: '', video_url: '' });
    setDialogOpen(true);
  };

  const openEdit = (product: Product) => {
    setEditing(product);
    form.reset({
      name: product.name, description: product.description || '',
      price: product.price.toString(), compare_at_price: product.compare_at_price?.toString() || '',
      category_id: product.category_id || 'none', stock_quantity: product.stock_quantity.toString(),
      is_available: product.is_available, is_featured: product.is_featured,
      image_url: product.images?.[0]?.url || '', video_url: product.video_url || ''
    });
    setDialogOpen(true);
  };

  const onSubmit = async (data: ProductForm) => {
    setSaving(true);
    const slug = data.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') + '-' + Date.now();
    const images = data.image_url ? [{ url: data.image_url, alt: data.name }] : (editing?.images || []);
    const payload = {
      name: data.name, slug: editing?.slug || slug,
      description: data.description || null, price: parseFloat(data.price),
      compare_at_price: data.compare_at_price ? parseFloat(data.compare_at_price) : null,
      category_id: data.category_id === 'none' ? null : data.category_id,
      stock_quantity: parseInt(data.stock_quantity), is_available: data.is_available,
      is_featured: data.is_featured, images, video_url: data.video_url || null,
      updated_at: new Date().toISOString()
    };
    if (editing) {
      const { error } = await supabase.from('products').update(payload).eq('id', editing.id);
      if (error) { toast.error('Erro ao atualizar produto'); setSaving(false); return; }
      toast.success('Produto atualizado!');
    } else {
      const { error } = await supabase.from('products').insert({ ...payload, attributes: {} });
      if (error) { toast.error('Erro ao criar produto'); setSaving(false); return; }
      toast.success('Produto criado!');
    }
    setDialogOpen(false); setSaving(false); load();
  };

  const deleteProduct = async (id: string) => {
    const { error } = await supabase.from('products').delete().eq('id', id);
    if (error) { toast.error('Erro ao excluir produto'); return; }
    toast.success('Produto excluído'); setDeleteId(null); load();
  };

  const toggleAvailability = async (product: Product) => {
    const nextState = !product.is_available;
    const { error } = await supabase
      .from('products')
      .update({ is_available: nextState, updated_at: new Date().toISOString() })
      .eq('id', product.id);

    if (error) {
      toast.error('Erro ao atualizar disponibilidade no site: ' + error.message);
      return;
    }

    toast.success(nextState ? `"${product.name}" agora está ativo no site!` : `"${product.name}" foi ocultado do site.`);
    setProducts(prev => prev.map(p => p.id === product.id ? { ...p, is_available: nextState } : p));
  };

  const totalCount = products.length;
  const availableCount = products.filter(p => p.is_available).length;
  const unavailableCount = products.filter(p => !p.is_available).length;

  const filtered = products.filter(p => {
    const matchSearch = p.name.toLowerCase().includes(search.toLowerCase());
    const matchAvail =
      availabilityFilter === 'all' ||
      (availabilityFilter === 'available' && p.is_available) ||
      (availabilityFilter === 'unavailable' && !p.is_available);
    return matchSearch && matchAvail;
  });

  return (
    <AdminLayout title="Produtos">
      <div className="space-y-4">
        {/* Filtros rápidos de disponibilidade no site */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <button
            type="button"
            onClick={() => setAvailabilityFilter('all')}
            className={`flex items-center justify-between p-3 rounded-lg border text-left transition-all ${
              availabilityFilter === 'all'
                ? 'bg-primary/10 border-primary shadow-sm ring-1 ring-primary/30'
                : 'bg-card border-border hover:bg-muted/40'
            }`}
          >
            <div className="space-y-0.5">
              <span className="text-xs font-medium text-muted-foreground">Todos no Catálogo</span>
              <p className="text-lg font-bold text-foreground">{totalCount}</p>
            </div>
            <Badge variant="outline">{totalCount}</Badge>
          </button>

          <button
            type="button"
            onClick={() => setAvailabilityFilter('available')}
            className={`flex items-center justify-between p-3 rounded-lg border text-left transition-all ${
              availabilityFilter === 'available'
                ? 'bg-emerald-500/10 border-emerald-500 shadow-sm ring-1 ring-emerald-500/30'
                : 'bg-card border-border hover:bg-muted/40'
            }`}
          >
            <div className="space-y-0.5">
              <span className="text-xs font-medium text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                <Globe className="h-3.5 w-3.5" /> Ativos no Site
              </span>
              <p className="text-lg font-bold text-emerald-700 dark:text-emerald-400">{availableCount}</p>
            </div>
            <Badge className="bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border-0">{availableCount}</Badge>
          </button>

          <button
            type="button"
            onClick={() => setAvailabilityFilter('unavailable')}
            className={`flex items-center justify-between p-3 rounded-lg border text-left transition-all ${
              availabilityFilter === 'unavailable'
                ? 'bg-amber-500/15 border-amber-500 shadow-sm ring-1 ring-amber-500/40'
                : 'bg-card border-border hover:bg-amber-500/5'
            }`}
          >
            <div className="space-y-0.5">
              <span className="text-xs font-semibold text-amber-700 dark:text-amber-400 flex items-center gap-1">
                <GlobeOff className="h-3.5 w-3.5 text-amber-600" /> Fora do Site (Ocultos)
              </span>
              <p className="text-lg font-bold text-amber-700 dark:text-amber-400">{unavailableCount}</p>
            </div>
            {unavailableCount > 0 ? (
              <Badge variant="outline" className="bg-amber-500/20 text-amber-800 dark:text-amber-300 border-amber-500/40 font-bold">
                {unavailableCount}
              </Badge>
            ) : (
              <Badge variant="outline">0</Badge>
            )}
          </button>
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          <div className="relative flex-1 min-w-48">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar produto..." className="pl-9 h-9" />
          </div>
          <Button onClick={openCreate} className="bg-accent text-accent-foreground hover:bg-accent/90 h-9 shrink-0">
            <Plus className="h-4 w-4 mr-2" /> Novo Produto
          </Button>
        </div>

        <div className="bg-card rounded-xl border border-border overflow-hidden">
          {loading ? (
            <div className="p-5 space-y-3">{[...Array(5)].map((_, i) => <Skeleton key={i} className="h-12 bg-muted" />)}</div>
          ) : filtered.length === 0 ? (
            <div className="p-10 text-center text-muted-foreground text-sm">Nenhum produto encontrado</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-max text-xs">
                <thead>
                  <tr className="border-b border-border bg-muted/40">
                    <th className="text-left px-2.5 py-2 text-xs font-semibold text-muted-foreground whitespace-nowrap">Produto</th>
                    <th className="text-left px-2 py-2 text-xs font-semibold text-muted-foreground whitespace-nowrap">Categoria</th>
                    <th className="text-left px-2 py-2 text-xs font-semibold text-muted-foreground whitespace-nowrap">Preço</th>
                    <th className="text-left px-2 py-2 text-xs font-semibold text-muted-foreground whitespace-nowrap">Estoque</th>
                    <th className="text-left px-2 py-2 text-xs font-semibold text-muted-foreground whitespace-nowrap">Disponível</th>
                    <th className="text-left px-2 py-2 text-xs font-semibold text-muted-foreground whitespace-nowrap">Destaque</th>
                    <th className="text-right px-2.5 py-2 text-xs font-semibold text-muted-foreground whitespace-nowrap">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map(p => (
                    <tr key={p.id} className="border-b border-border last:border-0 hover:bg-muted/20 transition-colors">
                      <td className="px-2.5 py-2">
                        <div className="flex items-center gap-2.5">
                          <div className="h-8 w-8 rounded-md overflow-hidden bg-muted shrink-0">
                            {p.images?.[0]?.url ? <img src={p.images[0].url} alt={p.name} className="w-full h-full object-cover" /> : <ImageIcon className="h-4 w-4 m-2 text-muted-foreground/40" />}
                          </div>
                          <span className="text-xs font-medium whitespace-nowrap max-w-44 truncate" title={p.name}>{p.name}</span>
                        </div>
                      </td>
                      <td className="px-2 py-2 text-xs text-muted-foreground whitespace-nowrap">
                        <span className="inline-block max-w-[85px] sm:max-w-[100px] truncate text-[10px] font-medium px-1.5 py-0.5 rounded bg-muted/60 border border-border/50 leading-tight" title={p.categories?.name || '—'}>
                          {p.categories?.name || '—'}
                        </span>
                      </td>
                      <td className="px-2 py-2 text-xs font-medium whitespace-nowrap">{p.price.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</td>
                      <td className="px-2 py-2 whitespace-nowrap">
                        <Badge className={`border-0 text-[10px] px-1.5 py-0 h-4 leading-none ${p.stock_quantity <= 5 ? 'bg-destructive/15 text-destructive' : 'bg-success/15 text-success'}`}>{p.stock_quantity}</Badge>
                      </td>
                      <td className="px-2 py-2 whitespace-nowrap">
                        <button
                          type="button"
                          onClick={() => toggleAvailability(p)}
                          className="cursor-pointer group flex items-center gap-1 focus:outline-none"
                          title="Clique para alternar presença no site"
                        >
                          <Badge className={`border-0 text-[10px] px-1.5 py-0 h-4 leading-none transition-colors group-hover:opacity-80 ${p.is_available ? 'bg-success/15 text-success' : 'bg-amber-500/15 text-amber-700 dark:text-amber-400'}`}>
                            {p.is_available ? <><Globe className="h-2.5 w-2.5 mr-0.5 inline" /> No Site</> : <><GlobeOff className="h-2.5 w-2.5 mr-0.5 inline" /> Fora</>}
                          </Badge>
                        </button>
                      </td>
                      <td className="px-2 py-2 whitespace-nowrap"><Badge className={`border-0 text-[10px] px-1.5 py-0 h-4 leading-none ${p.is_featured ? 'bg-accent/15 text-accent' : 'bg-muted text-muted-foreground'}`}>{p.is_featured ? 'Sim' : 'Não'}</Badge></td>
                      <td className="px-2.5 py-2 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-0.5">
                          <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => openEdit(p)}><Pencil className="h-3 w-3" /></Button>
                          <Button variant="ghost" size="icon" className="h-6 w-6 text-destructive hover:text-destructive" onClick={() => setDeleteId(p.id)}><Trash2 className="h-3 w-3" /></Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Create/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{editing ? 'Editar Produto' : 'Novo Produto'}</DialogTitle></DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField control={form.control} name="name" rules={{ required: 'Nome é obrigatório' }}
                  render={({ field }) => <FormItem className="md:col-span-2"><FormLabel>Nome</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>} />
                <FormField control={form.control} name="description"
                  render={({ field }) => <FormItem className="md:col-span-2"><FormLabel>Descrição</FormLabel><FormControl><Textarea {...field} rows={3} /></FormControl></FormItem>} />
                <FormField control={form.control} name="price" rules={{ required: 'Preço é obrigatório' }}
                  render={({ field }) => <FormItem><FormLabel>Preço (R$)</FormLabel><FormControl><Input {...field} type="number" step="0.01" min="0" /></FormControl><FormMessage /></FormItem>} />
                <FormField control={form.control} name="compare_at_price"
                  render={({ field }) => <FormItem><FormLabel>Preço Original (R$)</FormLabel><FormControl><Input {...field} type="number" step="0.01" min="0" placeholder="Opcional" /></FormControl></FormItem>} />
                <FormField control={form.control} name="category_id"
                  render={({ field }) => (
                    <FormItem><FormLabel>Categoria</FormLabel>
                      <Select value={field.value} onValueChange={field.onChange}>
                        <FormControl><SelectTrigger><SelectValue placeholder="Selecionar" /></SelectTrigger></FormControl>
                        <SelectContent>
                          <SelectItem value="none">Sem categoria</SelectItem>
                          {categories.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </FormItem>
                  )} />
                <FormField control={form.control} name="stock_quantity" rules={{ required: 'Estoque é obrigatório' }}
                  render={({ field }) => <FormItem><FormLabel>Quantidade em Estoque</FormLabel><FormControl><Input {...field} type="number" min="0" /></FormControl><FormMessage /></FormItem>} />
                <FormField control={form.control} name="image_url"
                  render={({ field }) => (
                    <FormItem className="md:col-span-2">
                      <FormControl>
                        <ImageUploader
                          value={field.value}
                          onChange={field.onChange}
                          label="Imagem do Produto"
                          aspectRatio="square"
                          folder="produtos"
                        />
                      </FormControl>
                    </FormItem>
                  )} />
                <FormField control={form.control} name="is_available"
                  render={({ field }) => <FormItem className="flex items-center gap-3 pt-2"><FormLabel className="mb-0">Disponível</FormLabel><FormControl><Switch checked={field.value} onCheckedChange={field.onChange} /></FormControl></FormItem>} />
                <FormField control={form.control} name="is_featured"
                  render={({ field }) => <FormItem className="flex items-center gap-3 pt-2"><FormLabel className="mb-0">Destaque</FormLabel><FormControl><Switch checked={field.value} onCheckedChange={field.onChange} /></FormControl></FormItem>} />
                <FormField control={form.control} name="video_url"
                  render={({ field }) => (
                    <FormItem className="md:col-span-2">
                      <FormLabel>Vídeo do Produto (URL)</FormLabel>
                      <FormControl><Input {...field} placeholder="YouTube, Vimeo, TikTok ou Instagram..." /></FormControl>
                      <p className="text-xs text-muted-foreground">
                        Suporta: YouTube (embed), Vimeo (embed), TikTok (embed) e Instagram (link direto)
                      </p>
                    </FormItem>
                  )} />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>Cancelar</Button>
                <Button type="submit" className="bg-accent text-accent-foreground hover:bg-accent/90" disabled={saving}>
                  {saving ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                  {editing ? 'Salvar' : 'Criar'}
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete confirmation */}
      <AlertDialog open={!!deleteId} onOpenChange={open => !open && setDeleteId(null)}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir produto</AlertDialogTitle>
            <AlertDialogDescription>Esta ação não pode ser desfeita. O produto será excluído permanentemente.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={() => deleteId && deleteProduct(deleteId)}>Excluir</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AdminLayout>
  );
}
