import { useState, useEffect, useCallback } from 'react';
import {
  Plus, Pencil, Trash2, Tag, Calendar, Percent, DollarSign,
  Loader2, CheckCircle2, XCircle, ToggleLeft, ToggleRight, Gift, TrendingUp
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from '@/components/ui/select';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter
} from '@/components/ui/dialog';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel,
  AlertDialogContent, AlertDialogDescription, AlertDialogFooter,
  AlertDialogHeader, AlertDialogTitle
} from '@/components/ui/alert-dialog';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Textarea } from '@/components/ui/textarea';
import { AdminLayout } from '@/components/layouts/AdminLayout';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import { useForm } from 'react-hook-form';
import type { Promotion, Category, Product, ProgressiveTier, PromotionType } from '@/types/types';

interface PromotionForm {
  name: string;
  description: string;
  discount_type: 'percent' | 'fixed';
  discount_value: string;
  starts_at: string;
  ends_at: string;
  scope: 'all' | 'categories' | 'products';
  banner_text: string;
  banner_color: string;
  is_active: boolean;
  promo_type: PromotionType;
  buy_quantity: string;
  get_quantity: string;
}

const toLocalDatetime = (iso: string) => iso ? iso.slice(0, 16) : '';
const toIso = (local: string) => local ? new Date(local).toISOString() : '';

const BANNER_COLORS = [
  { value: '#DC2626', label: 'Vermelho' },
  { value: '#2563EB', label: 'Azul' },
  { value: '#059669', label: 'Verde' },
  { value: '#7C3AED', label: 'Roxo' },
  { value: '#EA580C', label: 'Laranja' },
  { value: '#DB2777', label: 'Rosa' },
];

const DEFAULT_TIERS: ProgressiveTier[] = [
  { min_qty: 1, max_qty: 2, discount_percent: 5 },
  { min_qty: 3, max_qty: 4, discount_percent: 10 },
  { min_qty: 5, max_qty: null, discount_percent: 15 },
];

export default function AdminPromotions() {
  const [promotions, setPromotions] = useState<Promotion[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [editingPromo, setEditingPromo] = useState<Promotion | null>(null);
  const [saving, setSaving] = useState(false);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [tiers, setTiers] = useState<ProgressiveTier[]>(DEFAULT_TIERS);

  const form = useForm<PromotionForm>({
    defaultValues: {
      name: '', description: '', discount_type: 'percent', discount_value: '',
      starts_at: '', ends_at: '', scope: 'all', banner_text: '', banner_color: '#DC2626',
      is_active: true, promo_type: 'standard', buy_quantity: '2', get_quantity: '3',
    }
  });

  const scope = form.watch('scope');
  const promoType = form.watch('promo_type');

  const fetchAll = useCallback(async () => {
    const [promoRes, catRes, prodRes] = await Promise.all([
      supabase.from('promotions').select('*').order('created_at', { ascending: false }),
      supabase.from('categories').select('id, name').eq('is_active', true),
      supabase.from('products').select('id, name').eq('is_available', true).order('name'),
    ]);
    setPromotions(Array.isArray(promoRes.data) ? promoRes.data as Promotion[] : []);
    setCategories(Array.isArray(catRes.data) ? catRes.data as Category[] : []);
    setProducts(Array.isArray(prodRes.data) ? prodRes.data as Product[] : []);
    setLoading(false);
  }, []);

  useEffect(() => { fetchAll(); }, [fetchAll]);

  const openCreate = () => {
    setEditingPromo(null);
    setSelectedIds([]);
    setTiers(DEFAULT_TIERS);
    form.reset({
      name: '', description: '', discount_type: 'percent', discount_value: '',
      starts_at: '', ends_at: '', scope: 'all', banner_text: '', banner_color: '#DC2626',
      is_active: true, promo_type: 'standard', buy_quantity: '2', get_quantity: '3',
    });
    setDialogOpen(true);
  };

  const openEdit = (p: Promotion) => {
    setEditingPromo(p);
    setSelectedIds(p.scope_ids || []);
    setTiers(p.progressive_tiers || DEFAULT_TIERS);
    form.reset({
      name: p.name, description: p.description || '',
      discount_type: p.discount_type, discount_value: String(p.discount_value),
      starts_at: toLocalDatetime(p.starts_at), ends_at: toLocalDatetime(p.ends_at),
      scope: p.scope, banner_text: p.banner_text || '', banner_color: p.banner_color,
      is_active: p.is_active, promo_type: p.promo_type || 'standard',
      buy_quantity: String(p.buy_quantity || 2), get_quantity: String(p.get_quantity || 3),
    });
    setDialogOpen(true);
  };

  const onSubmit = async (data: PromotionForm) => {
    // Validação compre X leve Y
    if (data.promo_type === 'buy_x_get_y') {
      const bq = Number(data.buy_quantity), gq = Number(data.get_quantity);
      if (!bq || !gq || gq <= bq) {
        toast.error('Na promoção Compre X Leve Y, a quantidade Y deve ser maior que X.');
        return;
      }
    }
    setSaving(true);
    const payload: Partial<Promotion> & { updated_at: string } = {
      name: data.name, description: data.description || null,
      discount_type: data.discount_type, discount_value: parseFloat(data.discount_value),
      starts_at: toIso(data.starts_at), ends_at: toIso(data.ends_at),
      scope: data.scope, scope_ids: data.scope === 'all' ? [] : selectedIds,
      banner_text: data.banner_text || null, banner_color: data.banner_color, is_active: data.is_active,
      promo_type: data.promo_type,
      buy_quantity: data.promo_type === 'buy_x_get_y' ? Number(data.buy_quantity) : null,
      get_quantity: data.promo_type === 'buy_x_get_y' ? Number(data.get_quantity) : null,
      progressive_tiers: data.promo_type === 'progressive' ? tiers : null,
      updated_at: new Date().toISOString()
    };
    let error;
    if (editingPromo) {
      ({ error } = await supabase.from('promotions').update(payload).eq('id', editingPromo.id));
    } else {
      ({ error } = await supabase.from('promotions').insert(payload));
    }
    if (error) { toast.error('Erro ao salvar: ' + error.message); setSaving(false); return; }
    toast.success(editingPromo ? 'Promoção atualizada!' : 'Promoção criada!');
    setDialogOpen(false); setSaving(false); fetchAll();
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    const { error } = await supabase.from('promotions').delete().eq('id', deleteId);
    if (error) toast.error('Erro ao excluir'); else { toast.success('Promoção excluída!'); fetchAll(); }
    setDeleteId(null);
  };

  const toggleActive = async (p: Promotion) => {
    await supabase.from('promotions').update({ is_active: !p.is_active }).eq('id', p.id);
    fetchAll();
  };

  const toggleId = (id: string) =>
    setSelectedIds(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);

  const updateTier = (index: number, field: keyof ProgressiveTier, value: string) => {
    setTiers(prev => prev.map((t, i) => i === index ? { ...t, [field]: value === '' ? null : Number(value) } : t));
  };

  const addTier = () => setTiers(prev => [...prev, { min_qty: 0, max_qty: null, discount_percent: 0 }]);
  const removeTier = (i: number) => setTiers(prev => prev.filter((_, idx) => idx !== i));

  const isActive = (p: Promotion) => {
    const now = new Date();
    return p.is_active && new Date(p.starts_at) <= now && new Date(p.ends_at) >= now;
  };

  const promoTypeLabel = (p: Promotion) => {
    if (p.promo_type === 'buy_x_get_y') return `Compre ${p.buy_quantity} Leve ${p.get_quantity}`;
    if (p.promo_type === 'progressive') return 'Desconto Progressivo';
    return p.discount_type === 'percent' ? `${p.discount_value}% OFF` : `R$ ${p.discount_value.toFixed(2)} OFF`;
  };

  return (
    <AdminLayout title="Promoções">
      <div className="space-y-5">
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground">Crie promoções simples, Compre X Leve Y e descontos progressivos.</p>
          <Button onClick={openCreate} className="bg-primary text-primary-foreground hover:bg-primary/90 h-9">
            <Plus className="h-4 w-4 mr-2" /> Nova Promoção
          </Button>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-16"><Loader2 className="h-7 w-7 animate-spin text-muted-foreground" /></div>
        ) : promotions.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 gap-3 text-center border border-dashed rounded-xl">
            <Tag className="h-10 w-10 text-muted-foreground/40" />
            <p className="text-sm text-muted-foreground">Nenhuma promoção cadastrada.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {promotions.map(p => {
              const active = isActive(p);
              return (
                <div key={p.id} className="bg-card border border-border rounded-xl p-4">
                  <div className="flex items-start gap-3">
                    <div className="h-10 w-10 rounded-lg flex items-center justify-center shrink-0"
                      style={{ backgroundColor: p.banner_color + '22' }}>
                      {p.promo_type === 'buy_x_get_y' ? <Gift className="h-5 w-5" style={{ color: p.banner_color }} />
                        : p.promo_type === 'progressive' ? <TrendingUp className="h-5 w-5" style={{ color: p.banner_color }} />
                        : p.discount_type === 'percent' ? <Percent className="h-5 w-5" style={{ color: p.banner_color }} />
                        : <DollarSign className="h-5 w-5" style={{ color: p.banner_color }} />}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="font-semibold text-sm text-foreground">{p.name}</p>
                        <Badge className="text-xs h-5" style={{ backgroundColor: p.banner_color + '22', color: p.banner_color, border: 'none' }}>
                          {promoTypeLabel(p)}
                        </Badge>
                        {active
                          ? <Badge className="text-xs h-5 bg-success/15 text-success border-none"><CheckCircle2 className="h-3 w-3 mr-1" />Ativa</Badge>
                          : <Badge className="text-xs h-5 bg-muted text-muted-foreground border-none"><XCircle className="h-3 w-3 mr-1" />Inativa</Badge>}
                      </div>
                      <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground flex-wrap">
                        <span className="flex items-center gap-1">
                          <Calendar className="h-3.5 w-3.5" />
                          {new Date(p.starts_at).toLocaleDateString('pt-BR')} → {new Date(p.ends_at).toLocaleDateString('pt-BR')}
                        </span>
                        <span>{p.scope === 'all' ? 'Todos os produtos' : p.scope === 'categories' ? `${p.scope_ids.length} categorias` : `${p.scope_ids.length} produtos`}</span>
                      </div>
                      {p.banner_text && (
                        <p className="text-xs mt-1 font-medium" style={{ color: p.banner_color }}>📢 {p.banner_text}</p>
                      )}
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button onClick={() => toggleActive(p)} className="text-muted-foreground hover:text-foreground">
                        {p.is_active ? <ToggleRight className="h-5 w-5 text-success" /> : <ToggleLeft className="h-5 w-5" />}
                      </button>
                      <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(p)}>
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive"
                        onClick={() => setDeleteId(p.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-xl max-h-[90dvh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingPromo ? 'Editar Promoção' : 'Nova Promoção'}</DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField control={form.control} name="name" rules={{ required: 'Nome é obrigatório' }}
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Nome da Promoção</FormLabel>
                    <FormControl><Input {...field} placeholder="Ex: Liquidação de Inverno" className="h-10" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />

              <FormField control={form.control} name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Descrição (opcional)</FormLabel>
                    <FormControl><Textarea {...field} placeholder="Descreva a promoção..." rows={2} /></FormControl>
                  </FormItem>
                )} />

              {/* Tipo de promoção */}
              <FormField control={form.control} name="promo_type"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Tipo de Promoção</FormLabel>
                    <Select value={field.value} onValueChange={field.onChange}>
                      <FormControl><SelectTrigger className="h-10"><SelectValue /></SelectTrigger></FormControl>
                      <SelectContent>
                        <SelectItem value="standard">Desconto Padrão</SelectItem>
                        <SelectItem value="buy_x_get_y">Compre X Leve Y</SelectItem>
                        <SelectItem value="progressive">Desconto Progressivo</SelectItem>
                      </SelectContent>
                    </Select>
                  </FormItem>
                )} />

              {/* Campos desconto padrão */}
              {promoType === 'standard' && (
                <div className="grid grid-cols-2 gap-4">
                  <FormField control={form.control} name="discount_type"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Tipo de Desconto</FormLabel>
                        <Select value={field.value} onValueChange={field.onChange}>
                          <FormControl><SelectTrigger className="h-10"><SelectValue /></SelectTrigger></FormControl>
                          <SelectContent>
                            <SelectItem value="percent">Percentual (%)</SelectItem>
                            <SelectItem value="fixed">Valor Fixo (R$)</SelectItem>
                          </SelectContent>
                        </Select>
                      </FormItem>
                    )} />
                  <FormField control={form.control} name="discount_value" rules={{ required: 'Valor é obrigatório' }}
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Valor do Desconto</FormLabel>
                        <FormControl><Input {...field} type="number" step="0.01" min="0.01" placeholder="10" className="h-10" /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )} />
                </div>
              )}

              {/* Compre X Leve Y */}
              {promoType === 'buy_x_get_y' && (
                <div className="bg-muted/40 rounded-xl p-4 space-y-3 border border-border">
                  <div className="flex items-center gap-2">
                    <Gift className="h-4 w-4 text-primary" />
                    <p className="text-sm font-medium">Configuração: Compre X Leve Y</p>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <FormField control={form.control} name="buy_quantity" rules={{ required: true }}
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Compre (X unidades)</FormLabel>
                          <FormControl><Input {...field} type="number" min="1" placeholder="2" className="h-9" /></FormControl>
                          <FormMessage />
                        </FormItem>
                      )} />
                    <FormField control={form.control} name="get_quantity" rules={{ required: true }}
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Leve (Y unidades)</FormLabel>
                          <FormControl><Input {...field} type="number" min="2" placeholder="3" className="h-9" /></FormControl>
                          <FormMessage />
                        </FormItem>
                      )} />
                  </div>
                  <p className="text-xs text-muted-foreground">Ex: Compre 2 Leve 3 — cliente paga por 2 e leva 3 unidades.</p>
                </div>
              )}

              {/* Desconto Progressivo */}
              {promoType === 'progressive' && (
                <div className="bg-muted/40 rounded-xl p-4 space-y-3 border border-border">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <TrendingUp className="h-4 w-4 text-primary" />
                      <p className="text-sm font-medium">Faixas de Desconto Progressivo</p>
                    </div>
                    <Button type="button" variant="ghost" size="sm" className="h-7 text-xs" onClick={addTier}>
                      <Plus className="h-3 w-3 mr-1" /> Adicionar Faixa
                    </Button>
                  </div>
                  <div className="space-y-2">
                    <div className="grid grid-cols-3 gap-2 text-xs text-muted-foreground font-medium px-1">
                      <span>Mín. Unid.</span><span>Máx. Unid.</span><span>Desconto %</span>
                    </div>
                    {tiers.map((tier, i) => (
                      <div key={i} className="grid grid-cols-3 gap-2 items-center">
                        <Input type="number" min={1} value={tier.min_qty}
                          onChange={e => updateTier(i, 'min_qty', e.target.value)} className="h-8 text-sm" />
                        <Input type="number" min={1} value={tier.max_qty ?? ''}
                          onChange={e => updateTier(i, 'max_qty', e.target.value)}
                          placeholder="∞" className="h-8 text-sm" />
                        <div className="flex gap-1">
                          <Input type="number" min={0} max={100} value={tier.discount_percent}
                            onChange={e => updateTier(i, 'discount_percent', e.target.value)} className="h-8 text-sm" />
                          {tiers.length > 1 && (
                            <Button type="button" variant="ghost" size="icon" className="h-8 w-8 shrink-0 text-destructive hover:text-destructive" onClick={() => removeTier(i)}>
                              <Trash2 className="h-3.5 w-3.5" />
                            </Button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                  <p className="text-xs text-muted-foreground">Ex: 1-2 unid = 5%, 3-4 unid = 10%, 5+ unid = 15%</p>
                </div>
              )}

              <div className="grid grid-cols-2 gap-4">
                <FormField control={form.control} name="starts_at" rules={{ required: 'Data de início é obrigatória' }}
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Início</FormLabel>
                      <FormControl><Input {...field} type="datetime-local" className="h-10" /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />
                <FormField control={form.control} name="ends_at" rules={{ required: 'Data de fim é obrigatória' }}
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Término</FormLabel>
                      <FormControl><Input {...field} type="datetime-local" className="h-10" /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />
              </div>

              <FormField control={form.control} name="scope"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Produtos Elegíveis</FormLabel>
                    <Select value={field.value} onValueChange={field.onChange}>
                      <FormControl><SelectTrigger className="h-10"><SelectValue /></SelectTrigger></FormControl>
                      <SelectContent>
                        <SelectItem value="all">Todos os produtos</SelectItem>
                        <SelectItem value="categories">Categorias específicas</SelectItem>
                        <SelectItem value="products">Produtos específicos</SelectItem>
                      </SelectContent>
                    </Select>
                  </FormItem>
                )} />

              {scope === 'categories' && (
                <div>
                  <Label className="text-sm font-normal mb-2 block">Selecionar Categorias</Label>
                  <div className="flex flex-wrap gap-2 max-h-32 overflow-y-auto">
                    {categories.map(c => (
                      <button key={c.id} type="button" onClick={() => toggleId(c.id)}
                        className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-colors ${selectedIds.includes(c.id) ? 'bg-primary text-primary-foreground border-primary' : 'bg-background text-foreground border-border hover:border-primary'}`}>
                        {c.name}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {scope === 'products' && (
                <div>
                  <Label className="text-sm font-normal mb-2 block">Selecionar Produtos</Label>
                  <div className="flex flex-wrap gap-2 max-h-36 overflow-y-auto">
                    {products.map(p => (
                      <button key={p.id} type="button" onClick={() => toggleId(p.id)}
                        className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-colors ${selectedIds.includes(p.id) ? 'bg-primary text-primary-foreground border-primary' : 'bg-background text-foreground border-border hover:border-primary'}`}>
                        {p.name}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <Separator />

              <div className="grid grid-cols-2 gap-4">
                <FormField control={form.control} name="banner_text"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Texto do Banner (opcional)</FormLabel>
                      <FormControl><Input {...field} placeholder="Ex: Sale até 30% OFF!" className="h-10" /></FormControl>
                    </FormItem>
                  )} />
                <FormField control={form.control} name="banner_color"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Cor do Banner</FormLabel>
                      <div className="flex gap-2 flex-wrap pt-1">
                        {BANNER_COLORS.map(c => (
                          <button key={c.value} type="button" title={c.label}
                            onClick={() => field.onChange(c.value)}
                            className={`h-7 w-7 rounded-full border-2 transition-all ${field.value === c.value ? 'border-foreground scale-110' : 'border-transparent'}`}
                            style={{ backgroundColor: c.value }} />
                        ))}
                        <input type="color" value={field.value} onChange={e => field.onChange(e.target.value)}
                          className="h-7 w-7 rounded-full border border-border cursor-pointer p-0 overflow-hidden" title="Cor personalizada" />
                      </div>
                    </FormItem>
                  )} />
              </div>

              <FormField control={form.control} name="is_active"
                render={({ field }) => (
                  <div className="flex items-center gap-3">
                    <Switch checked={field.value} onCheckedChange={field.onChange} id="promo_active" />
                    <Label htmlFor="promo_active" className="text-sm">Promoção ativa</Label>
                  </div>
                )} />

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setDialogOpen(false)} className="h-9">Cancelar</Button>
                <Button type="submit" className="bg-primary text-primary-foreground hover:bg-primary/90 h-9" disabled={saving}>
                  {saving && <Loader2 className="h-4 w-4 animate-spin mr-2" />}
                  {editingPromo ? 'Salvar' : 'Criar Promoção'}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={v => !v && setDeleteId(null)}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir Promoção?</AlertDialogTitle>
            <AlertDialogDescription>Esta ação não pode ser desfeita.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground">Excluir</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AdminLayout>
  );
}
