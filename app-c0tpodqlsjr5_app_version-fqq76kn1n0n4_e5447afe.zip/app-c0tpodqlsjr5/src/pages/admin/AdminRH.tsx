import { useEffect, useState } from 'react';
import { Plus, Pencil, UserX, Search, Users, Loader2, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { AdminLayout } from '@/components/layouts/AdminLayout';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';

interface Employee {
  id: string;
  name: string;
  cpf: string;
  email: string | null;
  phone: string | null;
  role: string;
  department: string;
  base_salary: number;
  hired_at: string;
  fired_at: string | null;
  status: 'active' | 'inactive';
  notes: string | null;
}

const DEPARTMENTS = ['Administrativo', 'Vendas', 'Operações', 'Financeiro', 'TI', 'RH', 'Marketing', 'Estoque', 'Outro'];

const emptyForm = {
  name: '', cpf: '', email: '', phone: '',
  role: '', department: DEPARTMENTS[0],
  base_salary: '', hired_at: new Date().toISOString().split('T')[0],
  notes: '', status: 'active' as 'active' | 'inactive',
};

export default function AdminRH() {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [deptFilter, setDeptFilter] = useState('all');
  const [showDialog, setShowDialog] = useState(false);
  const [editing, setEditing] = useState<Employee | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [submitting, setSubmitting] = useState(false);
  const [fireId, setFireId] = useState<string | null>(null);

  useEffect(() => { load(); }, []);

  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from('employees').select('*').order('name');
    setEmployees((data as Employee[]) || []);
    setLoading(false);
  };

  const f = (key: string, val: unknown) => setForm(p => ({ ...p, [key]: val }));

  const openCreate = () => { setEditing(null); setForm(emptyForm); setShowDialog(true); };
  const openEdit = (emp: Employee) => {
    setEditing(emp);
    setForm({
      name: emp.name, cpf: emp.cpf, email: emp.email || '', phone: emp.phone || '',
      role: emp.role, department: emp.department,
      base_salary: String(emp.base_salary), hired_at: emp.hired_at,
      notes: emp.notes || '', status: emp.status,
    });
    setShowDialog(true);
  };

  const handleSave = async () => {
    if (!form.name.trim() || !form.cpf.trim() || !form.role.trim()) {
      toast.error('Preencha nome, CPF e cargo'); return;
    }
    setSubmitting(true);
    const payload = {
      name: form.name.trim(), cpf: form.cpf.replace(/\D/g, ''),
      email: form.email || null, phone: form.phone || null,
      role: form.role.trim(), department: form.department,
      base_salary: parseFloat(form.base_salary) || 0,
      hired_at: form.hired_at, notes: form.notes || null, status: form.status,
    };
    const query = editing
      ? supabase.from('employees').update({ ...payload, updated_at: new Date().toISOString() }).eq('id', editing.id)
      : supabase.from('employees').insert(payload);
    const { error } = await query;
    setSubmitting(false);
    if (error) { toast.error(error.message.includes('unique') ? 'CPF já cadastrado' : 'Erro ao salvar: ' + error.message); return; }
    toast.success(editing ? 'Funcionário atualizado!' : 'Funcionário cadastrado!');
    setShowDialog(false);
    load();
  };

  const handleFire = async () => {
    if (!fireId) return;
    const { error } = await supabase.from('employees').update({
      status: 'inactive', fired_at: new Date().toISOString().split('T')[0], updated_at: new Date().toISOString(),
    }).eq('id', fireId);
    if (error) { toast.error('Erro ao desligar funcionário'); }
    else { toast.success('Funcionário desligado'); load(); }
    setFireId(null);
  };

  const departments = Array.from(new Set(employees.map(e => e.department))).sort();

  const filtered = employees.filter(e => {
    const q = search.toLowerCase();
    return (
      (statusFilter === 'all' || e.status === statusFilter) &&
      (deptFilter === 'all' || e.department === deptFilter) &&
      (!q || e.name.toLowerCase().includes(q) || e.cpf.includes(q) || e.role.toLowerCase().includes(q))
    );
  });

  return (
    <AdminLayout title="Recursos Humanos" subtitle="Gestão de funcionários"
      breadcrumbs={[{ label: 'Admin', path: '/admin' }, { label: 'Recursos Humanos' }]}>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        {[
          { label: 'Total', value: employees.length, color: 'bg-primary/10 text-primary' },
          { label: 'Ativos', value: employees.filter(e => e.status === 'active').length, color: 'bg-success/10 text-success' },
          { label: 'Inativos', value: employees.filter(e => e.status === 'inactive').length, color: 'bg-muted text-muted-foreground' },
          { label: 'Departamentos', value: departments.length, color: 'bg-accent/10 text-accent' },
        ].map(s => (
          <div key={s.label} className={`rounded-xl p-4 ${s.color} flex items-center gap-3`}>
            <Users className="h-5 w-5 shrink-0" />
            <div>
              <p className="text-xl font-bold">{s.value}</p>
              <p className="text-xs font-medium opacity-80">{s.label}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Filters + Action */}
      <div className="flex flex-col md:flex-row gap-3 mb-5">
        <div className="relative flex-1 min-w-0">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Buscar por nome, CPF ou cargo..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-full md:w-36 shrink-0"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos</SelectItem>
            <SelectItem value="active">Ativos</SelectItem>
            <SelectItem value="inactive">Inativos</SelectItem>
          </SelectContent>
        </Select>
        <Select value={deptFilter} onValueChange={setDeptFilter}>
          <SelectTrigger className="w-full md:w-44 shrink-0"><SelectValue placeholder="Departamento" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos os departamentos</SelectItem>
            {departments.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}
          </SelectContent>
        </Select>
        <Button size="sm" onClick={openCreate} className="shrink-0">
          <Plus className="h-4 w-4 mr-1.5" /> Novo Funcionário
        </Button>
      </div>

      {/* Table */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm min-w-max">
            <thead>
              <tr className="border-b border-border bg-muted/40">
                {['Nome', 'CPF', 'Cargo', 'Departamento', 'Salário Base', 'Admissão', 'Status', 'Ações'].map(h => (
                  <th key={h} className="text-left px-4 py-3 font-semibold text-muted-foreground uppercase text-[11px] tracking-wide whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {loading ? Array.from({ length: 5 }).map((_, i) => (
                <tr key={i}><td colSpan={8} className="px-4 py-3"><Skeleton className="h-5 w-full bg-muted" /></td></tr>
              )) : filtered.length === 0 ? (
                <tr><td colSpan={8} className="text-center py-12 text-muted-foreground">
                  <Users className="h-8 w-8 mx-auto mb-2 opacity-30" />
                  <p>Nenhum funcionário encontrado</p>
                </td></tr>
              ) : filtered.map(emp => (
                <tr key={emp.id} className="hover:bg-muted/30 transition-colors">
                  <td className="px-4 py-3 font-medium whitespace-nowrap">{emp.name}</td>
                  <td className="px-4 py-3 font-mono text-xs whitespace-nowrap text-muted-foreground">{emp.cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4')}</td>
                  <td className="px-4 py-3 whitespace-nowrap">{emp.role}</td>
                  <td className="px-4 py-3 whitespace-nowrap">
                    <Badge variant="outline" className="text-xs">{emp.department}</Badge>
                  </td>
                  <td className="px-4 py-3 font-medium whitespace-nowrap">
                    {emp.base_salary.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                  </td>
                  <td className="px-4 py-3 text-muted-foreground whitespace-nowrap">
                    {new Date(emp.hired_at + 'T00:00:00').toLocaleDateString('pt-BR')}
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap">
                    <Badge className={emp.status === 'active' ? 'bg-success/15 text-success border-0' : 'bg-muted text-muted-foreground border-0'}>
                      {emp.status === 'active' ? 'Ativo' : 'Inativo'}
                    </Badge>
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap">
                    <div className="flex items-center gap-1.5 justify-end">
                      <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(emp)}>
                        <Pencil className="h-3.5 w-3.5" />
                      </Button>
                      {emp.status === 'active' && (
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive" onClick={() => setFireId(emp.id)}>
                          <UserX className="h-3.5 w-3.5" />
                        </Button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl max-h-[90dvh] overflow-y-auto">
          <DialogHeader><DialogTitle>{editing ? 'Editar Funcionário' : 'Novo Funcionário'}</DialogTitle></DialogHeader>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-2">
            <div className="space-y-1.5 md:col-span-2">
              <Label className="text-sm font-normal">Nome Completo *</Label>
              <Input value={form.name} onChange={e => f('name', e.target.value)} placeholder="Nome do funcionário" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">CPF *</Label>
              <Input value={form.cpf} onChange={e => f('cpf', e.target.value)} placeholder="000.000.000-00" maxLength={14} />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Telefone</Label>
              <Input value={form.phone} onChange={e => f('phone', e.target.value)} placeholder="(00) 00000-0000" />
            </div>
            <div className="space-y-1.5 md:col-span-2">
              <Label className="text-sm font-normal">E-mail</Label>
              <Input type="email" value={form.email} onChange={e => f('email', e.target.value)} placeholder="email@empresa.com" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Cargo *</Label>
              <Input value={form.role} onChange={e => f('role', e.target.value)} placeholder="Ex: Vendedor, Caixa..." />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Departamento</Label>
              <Select value={form.department} onValueChange={v => f('department', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{DEPARTMENTS.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Salário Base (R$)</Label>
              <Input type="number" min="0" step="0.01" value={form.base_salary} onChange={e => f('base_salary', e.target.value)} placeholder="0,00" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Data de Admissão *</Label>
              <Input type="date" value={form.hired_at} onChange={e => f('hired_at', e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Status</Label>
              <Select value={form.status} onValueChange={v => f('status', v as 'active' | 'inactive')}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Ativo</SelectItem>
                  <SelectItem value="inactive">Inativo</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5 md:col-span-2">
              <Label className="text-sm font-normal">Observações</Label>
              <Input value={form.notes} onChange={e => f('notes', e.target.value)} placeholder="Observações sobre o funcionário" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDialog(false)}>Cancelar</Button>
            <Button onClick={handleSave} disabled={submitting}>
              {submitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              {editing ? 'Salvar Alterações' : 'Cadastrar'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Fire confirm */}
      <AlertDialog open={!!fireId} onOpenChange={o => !o && setFireId(null)}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <AlertDialogHeader>
            <AlertDialogTitle>Desligar Funcionário</AlertDialogTitle>
            <AlertDialogDescription>O funcionário será marcado como inativo. Essa ação pode ser revertida editando o status.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleFire} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">Desligar</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AdminLayout>
  );
}
