import { useState, useEffect } from 'react';
import { TrendingUp, ShoppingCart, DollarSign, Package, Download } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { AdminLayout } from '@/components/layouts/AdminLayout';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import { supabase } from '@/db/supabase';

type Period = '7d' | '30d' | '3m' | '1y';

interface UnifiedSale {
  id: string;
  source: 'online' | 'pdv';
  created_at: string;
  total_amount: number;
  total_cost: number;
  items: { id: string; name: string; quantity: number; price: number; cost: number }[];
}

export default function AdminReports() {
  const [period, setPeriod] = useState<Period>('30d');
  const [sales, setSales] = useState<UnifiedSale[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadData() {
      setLoading(true);
      const now = new Date();
      const daysMap: Record<Period, number> = { '7d': 7, '30d': 30, '3m': 90, '1y': 365 };
      const from = new Date(now.getTime() - daysMap[period] * 24 * 60 * 60 * 1000).toISOString();

      try {
        const [ordersRes, pdvRes, prodRes] = await Promise.all([
          supabase.from('orders').select('*').gte('created_at', from).in('status', ['completed', 'delivered']),
          supabase.from('pdv_invoices')
            .select(`
              id, created_at, total, type, status,
              pdv_invoice_items ( product_id, quantity, unit_price, pdv_products (name) )
            `)
            .gte('created_at', from)
            .eq('type', 'saida')
            .eq('status', 'emitida'),
          supabase.from('pdv_products').select('id, site_product_id, cost_price')
        ]);

        const costById: Record<string, number> = {};
        const costBySiteId: Record<string, number> = {};
        (prodRes.data || []).forEach((p: any) => {
          costById[p.id] = p.cost_price || 0;
          if (p.site_product_id) costBySiteId[p.site_product_id] = p.cost_price || 0;
        });

        const unified: UnifiedSale[] = [];

        if (ordersRes.data) {
          ordersRes.data.forEach(o => {
            let orderCost = 0;
            const items = (o.items || []).map((i: any) => {
              const cost = costBySiteId[i.id] || 0;
              orderCost += cost * i.quantity;
              return { id: i.id, name: i.name, quantity: i.quantity, price: i.price, cost };
            });
            unified.push({
              id: o.id,
              source: 'online',
              created_at: o.created_at,
              total_amount: o.total_amount || 0,
              total_cost: orderCost,
              items
            });
          });
        }

        if (pdvRes.data) {
          pdvRes.data.forEach(p => {
            let pdvCost = 0;
            const items = (p.pdv_invoice_items || []).map((i: any) => {
              const cost = costById[i.product_id] || 0;
              pdvCost += cost * i.quantity;
              return {
                id: i.product_id,
                name: i.pdv_products?.name || 'Produto PDV',
                quantity: i.quantity,
                price: i.unit_price,
                cost
              };
            });
            unified.push({
              id: p.id,
              source: 'pdv',
              created_at: p.created_at,
              total_amount: p.total || 0,
              total_cost: pdvCost,
              items
            });
          });
        }

        // Sort by created_at ascending
        unified.sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
        setSales(unified);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, [period]);

  const revenue = sales.reduce((s, o) => s + (o.total_amount || 0), 0);
  const totalCost = sales.reduce((s, o) => s + (o.total_cost || 0), 0);
  const grossProfit = revenue - totalCost;
  const grossMargin = revenue > 0 ? (grossProfit / revenue) * 100 : 0;
  const avgTicket = sales.length > 0 ? revenue / sales.length : 0;
  const totalItems = sales.reduce((s, o) => s + (o.items?.reduce((si, i) => si + i.quantity, 0) || 0), 0);

  // Group by date for chart
  const chartData = (() => {
    const map: Record<string, { date: string; vendas: number; receita: number }> = {};
    sales.forEach(o => {
      const d = new Date(o.created_at).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
      if (!map[d]) map[d] = { date: d, vendas: 0, receita: 0 };
      map[d].vendas++;
      map[d].receita += o.total_amount || 0;
    });
    return Object.values(map).slice(-20);
  })();

  // Top products
  const productSales: Record<string, { name: string; qty: number; revenue: number }> = {};
  sales.forEach(o => {
    o.items?.forEach(item => {
      if (!productSales[item.id]) productSales[item.id] = { name: item.name, qty: 0, revenue: 0 };
      productSales[item.id].qty += item.quantity;
      productSales[item.id].revenue += item.price * item.quantity;
    });
  });
  const topProducts = Object.values(productSales).sort((a, b) => b.qty - a.qty).slice(0, 5);

  const stats = [
    { title: 'Receita Total', value: revenue.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }), icon: DollarSign, color: 'text-success' },
    { title: 'Margem de Lucro', value: `${grossMargin.toFixed(1)}%`, icon: TrendingUp, color: 'text-primary' },
    { title: 'Pedidos Concluídos', value: sales.length, icon: ShoppingCart, color: 'text-info' },
    { title: 'Ticket Médio', value: avgTicket.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }), icon: TrendingUp, color: 'text-accent' },
  ];

  return (
    <AdminLayout title="Relatórios">
      <div className="space-y-5 print:space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-3 print:hidden">
          <h2 className="text-base font-semibold">Resumo de Vendas</h2>
          <div className="flex items-center gap-2">
            <Select value={period} onValueChange={v => setPeriod(v as Period)}>
              <SelectTrigger className="w-36 h-9"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="7d">Últimos 7 dias</SelectItem>
                <SelectItem value="30d">Últimos 30 dias</SelectItem>
                <SelectItem value="3m">Últimos 3 meses</SelectItem>
                <SelectItem value="1y">Último ano</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" size="sm" onClick={() => window.print()} className="h-9">
              <Download className="h-4 w-4 mr-2" />
              Exportar PDF
            </Button>
          </div>
        </div>

        <div className="hidden print:block mb-4">
          <h1 className="text-2xl font-bold">Relatório de Vendas</h1>
          <p className="text-sm text-gray-500">Período selecionado: {period === '7d' ? 'Últimos 7 dias' : period === '30d' ? 'Últimos 30 dias' : period === '3m' ? 'Últimos 3 meses' : 'Último ano'}</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {stats.map(s => (
            <Card key={s.title}>
              <CardContent className="pt-5 pb-4 px-5">
                {loading ? <Skeleton className="h-12 bg-muted" /> : (
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-lg bg-muted flex items-center justify-center shrink-0">
                      <s.icon className={`h-5 w-5 ${s.color}`} />
                    </div>
                    <div className="min-w-0">
                      <p className="text-base md:text-xl font-bold text-foreground truncate">{s.value}</p>
                      <p className="text-xs text-muted-foreground">{s.title}</p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Revenue chart */}
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-semibold">Receita por Dia</CardTitle></CardHeader>
          <CardContent>
            {loading ? <Skeleton className="h-52 bg-muted" /> : chartData.length === 0 ? (
              <div className="h-52 flex items-center justify-center text-muted-foreground text-sm">Sem dados para o período</div>
            ) : (
              <div className="w-full min-w-0 overflow-hidden">
                <ResponsiveContainer width="100%" height={200}>
                  <BarChart data={chartData} margin={{ top: 4, right: 8, left: -10, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                    <YAxis tick={{ fontSize: 11 }} />
                    <Tooltip formatter={(v: number) => v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })} />
                    <Bar dataKey="receita" fill="hsl(var(--accent))" radius={[3, 3, 0, 0]} name="Receita" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Orders chart */}
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-semibold">Vendas por Dia</CardTitle></CardHeader>
          <CardContent>
            {loading ? <Skeleton className="h-44 bg-muted" /> : chartData.length === 0 ? (
              <div className="h-44 flex items-center justify-center text-muted-foreground text-sm">Sem dados para o período</div>
            ) : (
              <div className="w-full min-w-0 overflow-hidden">
                <ResponsiveContainer width="100%" height={160}>
                  <LineChart data={chartData} margin={{ top: 4, right: 8, left: -10, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                    <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                    <Tooltip />
                    <Line type="monotone" dataKey="vendas" stroke="hsl(var(--primary))" strokeWidth={2} dot={{ r: 3 }} name="Vendas" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Top products */}
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-semibold">Produtos Mais Vendidos</CardTitle></CardHeader>
          <CardContent className="p-0">
            {loading ? <div className="p-5 space-y-2">{[...Array(5)].map((_, i) => <Skeleton key={i} className="h-10 bg-muted" />)}</div>
              : topProducts.length === 0 ? <div className="p-8 text-center text-muted-foreground text-sm">Sem dados para o período</div>
                : (
                  <div className="overflow-x-auto">
                    <table className="w-full min-w-max">
                      <thead><tr className="border-b border-border bg-muted/40">
                        {['#', 'Produto', 'Qtd. Vendida', 'Receita'].map(h => <th key={h} className="text-left px-5 py-3 text-xs font-semibold text-muted-foreground whitespace-nowrap">{h}</th>)}
                      </tr></thead>
                      <tbody>
                        {topProducts.map((p, i) => (
                          <tr key={p.name} className="border-b border-border last:border-0 hover:bg-muted/20 transition-colors">
                            <td className="px-5 py-3 text-sm font-bold text-muted-foreground whitespace-nowrap">#{i + 1}</td>
                            <td className="px-5 py-3 text-sm font-medium whitespace-nowrap max-w-48 truncate">{p.name}</td>
                            <td className="px-5 py-3 text-sm whitespace-nowrap">{p.qty} unid.</td>
                            <td className="px-5 py-3 text-sm font-medium whitespace-nowrap">{p.revenue.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}
