import { useState, useEffect } from 'react';
import { Save, Loader2, Store, Truck, Shield, RefreshCw, MessageCircle, Package, Star, Zap, Heart, Gift, Clock, Phone } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { AdminLayout } from '@/components/layouts/AdminLayout';
import { ImageUploader } from '@/components/admin/ImageUploader';
import { useStore } from '@/contexts/StoreContext';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import { useForm } from 'react-hook-form';
import type { StoreFeature } from '@/types/types';

// Mapa de ícones disponíveis
const ICON_OPTIONS = [
  { value: 'Truck', label: 'Caminhão (Entrega)', icon: Truck },
  { value: 'Shield', label: 'Escudo (Segurança)', icon: Shield },
  { value: 'RefreshCw', label: 'Setas (Troca)', icon: RefreshCw },
  { value: 'MessageCircle', label: 'Balão (Suporte)', icon: MessageCircle },
  { value: 'Package', label: 'Caixa (Produto)', icon: Package },
  { value: 'Star', label: 'Estrela (Qualidade)', icon: Star },
  { value: 'Zap', label: 'Raio (Rápido)', icon: Zap },
  { value: 'Heart', label: 'Coração (Amor)', icon: Heart },
  { value: 'Gift', label: 'Presente (Brinde)', icon: Gift },
  { value: 'Clock', label: 'Relógio (Prazo)', icon: Clock },
  { value: 'Phone', label: 'Telefone (Contato)', icon: Phone },
];

export const ICON_MAP: Record<string, React.ComponentType<any>> = {
  Truck, Shield, RefreshCw, MessageCircle, Package, Star, Zap, Heart, Gift, Clock, Phone,
};

const DEFAULT_FEATURES: StoreFeature[] = [
  { icon: 'Truck', title: 'Entrega Rápida', desc: 'Todo o Brasil' },
  { icon: 'Shield', title: 'Compra Segura', desc: 'Pagamento protegido' },
  { icon: 'RefreshCw', title: 'Troca Fácil', desc: 'Sem burocracia' },
  { icon: 'MessageCircle', title: 'Suporte 24h', desc: 'Sempre disponível' },
];

interface SettingsForm {
  store_name: string; store_description: string; store_email: string;
  store_phone: string; store_address: string; store_city: string;
  store_state: string; store_zip: string; store_logo_url: string;
  pix_key: string; pix_key_type: string; freight_base_value: string;
}

export default function AdminSettings() {
  const { settings, reload } = useStore();
  const [saving, setSaving] = useState(false);
  const [features, setFeatures] = useState<StoreFeature[]>(DEFAULT_FEATURES);

  const form = useForm<SettingsForm>({
    defaultValues: {
      store_name: '', store_description: '', store_email: '', store_phone: '',
      store_address: '', store_city: '', store_state: '', store_zip: '',
      store_logo_url: '', pix_key: '', pix_key_type: 'email', freight_base_value: '10'
    }
  });

  useEffect(() => {
    if (settings) {
      form.reset({
        store_name: settings.store_name || '',
        store_description: settings.store_description || '',
        store_email: settings.store_email || '',
        store_phone: settings.store_phone || '',
        store_address: settings.store_address || '',
        store_city: settings.store_city || '',
        store_state: settings.store_state || '',
        store_zip: settings.store_zip || '',
        store_logo_url: settings.store_logo_url || '',
        pix_key: settings.pix_key || '',
        pix_key_type: settings.pix_key_type || 'email',
        freight_base_value: settings.freight_base_value?.toString() || '10',
      });
      if (settings.store_features && settings.store_features.length > 0) {
        setFeatures(settings.store_features);
      }
    }
  }, [settings]);

  const updateFeature = (index: number, field: keyof StoreFeature, value: string) => {
    setFeatures(prev => prev.map((f, i) => i === index ? { ...f, [field]: value } : f));
  };

  const onSubmit = async (data: SettingsForm) => {
    setSaving(true);
    const payload = {
      ...data,
      freight_base_value: parseFloat(data.freight_base_value) || 0,
      store_features: features,
      updated_at: new Date().toISOString()
    };
    let error;
    if (settings?.id) {
      ({ error } = await supabase.from('store_settings').update(payload).eq('id', settings.id));
    } else {
      ({ error } = await supabase.from('store_settings').insert(payload));
    }
    if (error) { toast.error('Erro ao salvar configurações'); setSaving(false); return; }
    await reload();
    toast.success('Configurações salvas!');
    setSaving(false);
  };

  return (
    <AdminLayout title="Configurações da Loja">
      <div className="max-w-2xl">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Store info */}
            <div className="bg-card rounded-xl border border-border p-5 space-y-4">
              <div className="flex items-center gap-2 mb-1">
                <Store className="h-4 w-4 text-accent" />
                <h2 className="font-semibold text-sm">Informações da Loja</h2>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField control={form.control} name="store_name" rules={{ required: 'Nome da loja é obrigatório' }}
                  render={({ field }) => <FormItem className="md:col-span-2"><FormLabel>Nome da Loja</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>} />
                <FormField control={form.control} name="store_description"
                  render={({ field }) => <FormItem className="md:col-span-2"><FormLabel>Descrição</FormLabel><FormControl><Textarea {...field} rows={2} /></FormControl></FormItem>} />
                <FormField control={form.control} name="store_logo_url"
                  render={({ field }) => (
                    <FormItem className="md:col-span-2">
                      <FormControl>
                        <ImageUploader
                          value={field.value}
                          onChange={field.onChange}
                          label="Logo da Loja"
                          aspectRatio="square"
                          folder="logo"
                        />
                      </FormControl>
                    </FormItem>
                  )} />
                <FormField control={form.control} name="store_email"
                  render={({ field }) => <FormItem><FormLabel>E-mail</FormLabel><FormControl><Input {...field} type="email" /></FormControl></FormItem>} />
                <FormField control={form.control} name="store_phone"
                  render={({ field }) => <FormItem><FormLabel>Telefone</FormLabel><FormControl><Input {...field} placeholder="(11) 99999-9999" /></FormControl></FormItem>} />
              </div>
            </div>

            {/* Features da página inicial */}
            <div className="bg-card rounded-xl border border-border p-5 space-y-4">
              <div className="flex items-center gap-2 mb-1">
                <Star className="h-4 w-4 text-accent" />
                <h2 className="font-semibold text-sm">4 Destaques da Página Inicial</h2>
              </div>
              <p className="text-xs text-muted-foreground">Personalize os 4 quadrados de destaque exibidos na página inicial da loja.</p>
              <div className="space-y-4">
                {features.map((feature, index) => {
                  const IconComp = ICON_MAP[feature.icon] || Truck;
                  return (
                    <div key={index} className="grid grid-cols-1 md:grid-cols-[auto_1fr_1fr_1fr] gap-3 p-3 bg-muted/40 rounded-lg border border-border items-center">
                      {/* Preview do ícone */}
                      <div className="h-10 w-10 rounded-lg bg-accent/10 flex items-center justify-center shrink-0 mx-auto md:mx-0">
                        <IconComp className="h-5 w-5 text-accent" />
                      </div>
                      {/* Seleção de ícone */}
                      <div className="space-y-1">
                        <label className="text-xs font-normal text-muted-foreground">Ícone {index + 1}</label>
                        <Select value={feature.icon} onValueChange={(val) => updateFeature(index, 'icon', val)}>
                          <SelectTrigger className="h-9 text-xs">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {ICON_OPTIONS.map(opt => (
                              <SelectItem key={opt.value} value={opt.value} className="text-xs">
                                {opt.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      {/* Título */}
                      <div className="space-y-1">
                        <label className="text-xs font-normal text-muted-foreground">Título</label>
                        <Input
                          value={feature.title}
                          onChange={(e) => updateFeature(index, 'title', e.target.value)}
                          className="h-9 text-xs"
                          placeholder="Ex: Entrega Rápida"
                          maxLength={30}
                        />
                      </div>
                      {/* Descrição */}
                      <div className="space-y-1">
                        <label className="text-xs font-normal text-muted-foreground">Descrição</label>
                        <Input
                          value={feature.desc}
                          onChange={(e) => updateFeature(index, 'desc', e.target.value)}
                          className="h-9 text-xs"
                          placeholder="Ex: Todo o Brasil"
                          maxLength={40}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Address */}
            <div className="bg-card rounded-xl border border-border p-5 space-y-4">
              <h2 className="font-semibold text-sm">Endereço</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField control={form.control} name="store_address"
                  render={({ field }) => <FormItem className="md:col-span-2"><FormLabel>Rua / Endereço</FormLabel><FormControl><Input {...field} /></FormControl></FormItem>} />
                <FormField control={form.control} name="store_city"
                  render={({ field }) => <FormItem><FormLabel>Cidade</FormLabel><FormControl><Input {...field} /></FormControl></FormItem>} />
                <FormField control={form.control} name="store_state"
                  render={({ field }) => <FormItem><FormLabel>Estado</FormLabel><FormControl><Input {...field} maxLength={2} /></FormControl></FormItem>} />
                <FormField control={form.control} name="store_zip"
                  render={({ field }) => <FormItem><FormLabel>CEP</FormLabel><FormControl><Input {...field} placeholder="00000-000" /></FormControl></FormItem>} />
              </div>
            </div>

            {/* Payments */}
            <div className="bg-card rounded-xl border border-border p-5 space-y-4">
              <h2 className="font-semibold text-sm">Pagamentos</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField control={form.control} name="pix_key_type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Tipo de Chave PIX</FormLabel>
                      <Select value={field.value} onValueChange={field.onChange}>
                        <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                        <SelectContent>
                          <SelectItem value="email">E-mail</SelectItem>
                          <SelectItem value="cpf">CPF</SelectItem>
                          <SelectItem value="cnpj">CNPJ</SelectItem>
                          <SelectItem value="telefone">Telefone</SelectItem>
                          <SelectItem value="aleatoria">Chave Aleatória</SelectItem>
                        </SelectContent>
                      </Select>
                    </FormItem>
                  )} />
                <FormField control={form.control} name="pix_key"
                  render={({ field }) => <FormItem><FormLabel>Chave PIX</FormLabel><FormControl><Input {...field} /></FormControl></FormItem>} />
                <FormField control={form.control} name="freight_base_value"
                  render={({ field }) => <FormItem><FormLabel>Valor Base do Frete (R$)</FormLabel><FormControl><Input {...field} type="number" step="0.01" min="0" /></FormControl></FormItem>} />
              </div>
            </div>

            <Button type="submit" className="bg-accent text-accent-foreground hover:bg-accent/90 h-10 w-full md:w-auto" disabled={saving}>
              {saving ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Save className="h-4 w-4 mr-2" />}
              Salvar Configurações
            </Button>
          </form>
        </Form>
      </div>
    </AdminLayout>
  );
}
