import { useState, useEffect } from 'react';
import { AlertTriangle, Plus, Minus, History, Search, TrendingUp, DollarSign, Package } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { AdminLayout } from '@/components/layouts/AdminLayout';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import type { Product, AdminStockMovement as StockMovement, StockMovementType } from '@/types/types';

export default function AdminStock() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [adjustProduct, setAdjustProduct] = useState<Product | null>(null);
  const [historyProduct, setHistoryProduct] = useState<Product | null>(null);
  const [movements, setMovements] = useState<StockMovement[]>([]);
  const [adjustQty, setAdjustQty] = useState('');
  const [adjustType, setAdjustType] = useState<StockMovementType>('ajuste');
  const [adjustNote, setAdjustNote] = useState('');
  const [saving, setSaving] = useState(false);

  const load = async () => {
    const { data } = await supabase.from('products').select('*, categories(*)').order('name');
    setProducts(Array.isArray(data) ? data : []);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const loadHistory = async (productId: string) => {
    const { data } = await supabase.from('stock_movements').select('*').eq('product_id', productId).order('created_at', { ascending: false }).limit(20);
    setMovements(Array.isArray(data) ? data : []);
  };

  const handleAdjust = async () => {
    if (!adjustProduct || !adjustQty) return;
    const qty = parseInt(adjustQty);
    if (isNaN(qty) || qty < 0) { toast.error('Quantidade inválida'); return; }
    setSaving(true);
    const newQty = adjustType === 'entrada' ? adjustProduct.stock_quantity + qty
      : adjustType === 'saida' ? adjustProduct.stock_quantity - qty
        : qty;
    if (newQty < 0) { toast.error('Estoque não pode ser negativo'); setSaving(false); return; }
    await supabase.from('products').update({ stock_quantity: newQty, is_available: newQty > 0, updated_at: new Date().toISOString() }).eq('id', adjustProduct.id);
    await supabase.from('stock_movements').insert({
      product_id: adjustProduct.id, type: adjustType, quantity: qty,
      previous_quantity: adjustProduct.stock_quantity, new_quantity: newQty,
      notes: adjustNote || null
    });
    toast.success('Estoque atualizado!');
    setAdjustProduct(null); setAdjustQty(''); setAdjustNote(''); setSaving(false); load();
  };

  const filtered = products.filter(p => p.name.toLowerCase().includes(search.toLowerCase()));
  const lowStock = filtered.filter(p => p.stock_quantity <= 5);

  const MOVEMENT_LABELS: Record<StockMovementType, string> = {
    entrada: 'Entrada', saida: 'Saída', ajuste: 'Ajuste', venda: 'Venda'
  };

  const totalCost = products.reduce((s, p) => s + (p.stock_quantity * (p.cost_price ?? 0)), 0);
  const totalValue = products.reduce((s, p) => s + (p.stock_quantity * p.price), 0);
  const totalItems = products.length;

  return (
    <AdminLayout title="Gestão de Estoque">
      <div className="space-y-5">
        {/* Resumo financeiro */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="bg-card rounded-xl border border-border p-4 flex items-center gap-3">
            <div className="h-9 w-9 rounded-lg bg-muted flex items-center justify-center shrink-0">
              <Package className="h-4 w-4 text-muted-foreground" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Produtos cadastrados</p>
              <p className="text-lg font-bold">{totalItems}</p>
            </div>
          </div>
          <div className="bg-card rounded-xl border border-border p-4 flex items-center gap-3">
            <div className="h-9 w-9 rounded-lg bg-emerald-100 dark:bg-emerald-900 flex items-center justify-center shrink-0">
              <DollarSign className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Valor de custo em estoque</p>
              <p className="text-lg font-bold">R$ {totalCost.toFixed(2)}</p>
            </div>
          </div>
          <div className="bg-card rounded-xl border border-border p-4 flex items-center gap-3">
            <div className="h-9 w-9 rounded-lg bg-blue-100 dark:bg-blue-900 flex items-center justify-center shrink-0">
              <TrendingUp className="h-4 w-4 text-blue-600 dark:text-blue-400" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Valor de venda em estoque</p>
              <p className="text-lg font-bold">R$ {totalValue.toFixed(2)}</p>
            </div>
          </div>
        </div>

        {/* Low stock alert */}
        {lowStock.length > 0 && (
          <div className="bg-warning/10 border border-warning/30 rounded-xl p-4 flex items-center gap-3">
            <AlertTriangle className="h-5 w-5 text-warning-foreground shrink-0" />
            <p className="text-sm text-warning-foreground font-medium">{lowStock.length} produto(s) com estoque baixo (≤5 unidades)</p>
          </div>
        )}

        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar produto..." className="pl-9 h-9" />
        </div>

        <div className="bg-card rounded-xl border border-border overflow-hidden">
          {loading ? (
            <div className="p-5 space-y-3">{[...Array(6)].map((_, i) => <Skeleton key={i} className="h-12 bg-muted" />)}</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-max">
                <thead><tr className="border-b border-border bg-muted/40">
                  {['Produto', 'Categoria', 'Estoque', 'Custo', 'Venda', 'Status', 'Ações'].map(h => <th key={h} className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground whitespace-nowrap">{h}</th>)}
                </tr></thead>
                <tbody>
                  {filtered.map(p => (
                    <tr key={p.id} className="border-b border-border last:border-0 hover:bg-muted/20 transition-colors">
                      <td className="px-4 py-3 text-sm font-medium whitespace-nowrap">{p.name}</td>
                      <td className="px-4 py-3 text-sm text-muted-foreground whitespace-nowrap">{p.categories?.name || '—'}</td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <Badge className={`border-0 text-sm font-bold ${p.stock_quantity === 0 ? 'bg-destructive/15 text-destructive' : p.stock_quantity <= 5 ? 'bg-warning/15 text-warning-foreground' : 'bg-success/15 text-success'}`}>
                          {p.stock_quantity}
                        </Badge>
                        {p.stock_quantity <= 5 && p.stock_quantity > 0 && <AlertTriangle className="inline h-3.5 w-3.5 ml-1 text-warning-foreground" />}
                      </td>
                      <td className="px-4 py-3 text-sm text-muted-foreground whitespace-nowrap">R$ {(p.cost_price ?? 0).toFixed(2)}</td>
                      <td className="px-4 py-3 text-sm font-medium whitespace-nowrap">R$ {p.price.toFixed(2)}</td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <Badge className={`border-0 text-xs ${p.is_available ? 'bg-success/15 text-success' : 'bg-muted text-muted-foreground'}`}>{p.is_available ? 'Disponível' : 'Indisponível'}</Badge>
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <div className="flex items-center gap-1">
                          <Button variant="outline" size="sm" className="h-7 text-xs" onClick={() => setAdjustProduct(p)}>
                            <Plus className="h-3 w-3 mr-1" /> Ajustar
                          </Button>
                          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => { setHistoryProduct(p); loadHistory(p.id); }}>
                            <History className="h-3.5 w-3.5" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Adjust dialog */}
      <Dialog open={!!adjustProduct} onOpenChange={open => !open && setAdjustProduct(null)}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-sm">
          <DialogHeader><DialogTitle>Ajustar Estoque — {adjustProduct?.name}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">Estoque atual: <span className="font-bold text-foreground">{adjustProduct?.stock_quantity}</span></p>
            <div className="space-y-1">
              <label className="text-sm font-normal">Tipo de movimento</label>
              <Select value={adjustType} onValueChange={v => setAdjustType(v as StockMovementType)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="entrada">Entrada (+)</SelectItem>
                  <SelectItem value="saida">Saída (-)</SelectItem>
                  <SelectItem value="ajuste">Ajuste (definir valor)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <label className="text-sm font-normal">{adjustType === 'ajuste' ? 'Novo estoque' : 'Quantidade'}</label>
              <Input type="number" min="0" value={adjustQty} onChange={e => setAdjustQty(e.target.value)} placeholder="0" />
            </div>
            <div className="space-y-1">
              <label className="text-sm font-normal">Observação (opcional)</label>
              <Textarea value={adjustNote} onChange={e => setAdjustNote(e.target.value)} rows={2} placeholder="Motivo do ajuste..." />
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setAdjustProduct(null)}>Cancelar</Button>
              <Button className="bg-accent text-accent-foreground hover:bg-accent/90" onClick={handleAdjust} disabled={saving || !adjustQty}>Confirmar</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* History dialog */}
      <Dialog open={!!historyProduct} onOpenChange={open => !open && setHistoryProduct(null)}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>Histórico — {historyProduct?.name}</DialogTitle></DialogHeader>
          {movements.length === 0 ? (
            <p className="text-muted-foreground text-sm text-center py-6">Nenhuma movimentação registrada</p>
          ) : (
            <div className="space-y-2">
              {movements.map(m => (
                <div key={m.id} className="flex items-start gap-3 p-3 bg-muted rounded-lg">
                  <div className={`h-8 w-8 rounded-full flex items-center justify-center shrink-0 ${m.type === 'entrada' ? 'bg-success/15 text-success' : m.type === 'saida' || m.type === 'venda' ? 'bg-destructive/15 text-destructive' : 'bg-info/15 text-info-foreground'}`}>
                    {m.type === 'entrada' ? <Plus className="h-4 w-4" /> : <Minus className="h-4 w-4" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-sm font-medium">{MOVEMENT_LABELS[m.type]}</span>
                      <span className="text-xs text-muted-foreground">{new Date(m.created_at).toLocaleDateString('pt-BR')}</span>
                    </div>
                    <p className="text-xs text-muted-foreground">{m.previous_quantity} → {m.new_quantity} unidades {m.type !== 'ajuste' ? `(${m.type === 'entrada' ? '+' : '-'}${m.quantity})` : ''}</p>
                    {m.notes && <p className="text-xs text-muted-foreground mt-0.5 italic">{m.notes}</p>}
                  </div>
                </div>
              ))}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
}
