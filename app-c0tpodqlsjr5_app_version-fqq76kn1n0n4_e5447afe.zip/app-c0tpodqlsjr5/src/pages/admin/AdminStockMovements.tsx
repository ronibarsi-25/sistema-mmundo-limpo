import { useState, useEffect } from 'react';
import { History, Download, Filter, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { AdminLayout } from '@/components/layouts/AdminLayout';
import { supabase } from '@/db/supabase';
import { exportToCsv } from '@/lib/export';
import { toast } from 'sonner';

interface Movement {
  id: string;
  product_id: string | null;
  type: string;
  quantity: number;
  notes: string | null;
  created_at: string;
  products?: { name: string; code: string } | null;
}

const TYPE_LABELS: Record<string, string> = {
  entrada: 'Entrada',
  saida: 'Saída',
  ajuste: 'Ajuste',
  venda: 'Venda',
  devolucao: 'Devolução',
  importacao: 'Importação',
  sync: 'Sincronização',
};

const TYPE_VARIANTS: Record<string, 'default' | 'secondary' | 'destructive' | 'outline'> = {
  entrada: 'default',
  saida: 'destructive',
  ajuste: 'secondary',
  venda: 'outline',
  devolucao: 'default',
  importacao: 'secondary',
  sync: 'outline',
};

export default function AdminStockMovements() {
  const [movements, setMovements] = useState<Movement[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterType, setFilterType] = useState('all');
  const [filterDate, setFilterDate] = useState('');
  const [page, setPage] = useState(0);
  const PAGE_SIZE = 25;

  const fetchMovements = async () => {
    setLoading(true);
    let query = supabase
      .from('stock_movements')
      .select('id, product_id, type, quantity, notes, created_at, products(name, code)')
      .order('created_at', { ascending: false })
      .range(page * PAGE_SIZE, (page + 1) * PAGE_SIZE - 1);

    if (filterType !== 'all') query = query.eq('type', filterType);
    if (filterDate) {
      const start = new Date(filterDate).toISOString();
      const end = new Date(filterDate + 'T23:59:59').toISOString();
      query = query.gte('created_at', start).lte('created_at', end);
    }

    const { data } = await query;
    const normalized = (Array.isArray(data) ? data : []).map((m: unknown) => {
      const row = m as Record<string, unknown>;
      const prod = row['products'];
      return {
        ...row,
        products: Array.isArray(prod) && prod.length > 0 ? (prod[0] as { name: string; code: string }) : (prod as { name: string; code: string } | null),
      } as Movement;
    });
    setMovements(normalized);
    setLoading(false);
  };

  useEffect(() => { fetchMovements(); }, [page, filterType, filterDate]);

  const handleExport = () => {
    const rows = movements.map(m => ({
      ID: m.id,
      Produto: m.products?.name || m.product_id || '',
      Codigo: m.products?.code || '',
      Tipo: TYPE_LABELS[m.type] || m.type,
      Quantidade: m.quantity,
      Observacao: m.notes || '',
      Data: m.created_at,
    }));
    exportToCsv('movimentacoes_estoque', rows);
    toast.success('Movimentações exportadas');
  };

  return (
    <AdminLayout title="Histórico de Movimentações" subtitle="Rastreabilidade completa do estoque">
      <div className="max-w-5xl mx-auto space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-accent/10 flex items-center justify-center">
              <History className="h-5 w-5 text-accent" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-foreground text-balance">Movimentações de Estoque</h1>
              <p className="text-sm text-muted-foreground">{movements.length} registros</p>
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <Button variant="outline" size="sm" onClick={handleExport} className="gap-2 h-9">
              <Download className="h-3.5 w-3.5" /> Exportar
            </Button>
          </div>
        </div>

        {/* Filtros */}
        <Card>
          <CardContent className="p-4 flex flex-col md:flex-row gap-3">
            <div className="flex items-center gap-2 flex-1">
              <Filter className="h-4 w-4 text-muted-foreground" />
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger className="w-40 h-9"><SelectValue placeholder="Tipo" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos</SelectItem>
                  <SelectItem value="entrada">Entrada</SelectItem>
                  <SelectItem value="saida">Saída</SelectItem>
                  <SelectItem value="ajuste">Ajuste</SelectItem>
                  <SelectItem value="venda">Venda</SelectItem>
                  <SelectItem value="devolucao">Devolução</SelectItem>
                  <SelectItem value="importacao">Importação</SelectItem>
                  <SelectItem value="sync">Sincronização</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Input type="date" value={filterDate} onChange={e => setFilterDate(e.target.value)} className="h-9 w-full md:w-44" />
          </CardContent>
        </Card>

        {/* Lista */}
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-muted/40">
                    <th className="text-left py-3 px-4 font-medium">Data</th>
                    <th className="text-left py-3 px-4 font-medium">Produto</th>
                    <th className="text-left py-3 px-4 font-medium">Tipo</th>
                    <th className="text-right py-3 px-4 font-medium">Qtd</th>
                    <th className="text-left py-3 px-4 font-medium">Observação</th>
                  </tr>
                </thead>
                <tbody>
                  {loading ? (
                    <tr><td colSpan={5} className="py-8 text-center text-muted-foreground"><Loader2 className="h-5 w-5 animate-spin mx-auto" /></td></tr>
                  ) : movements.length === 0 ? (
                    <tr><td colSpan={5} className="py-8 text-center text-muted-foreground">Nenhuma movimentação encontrada</td></tr>
                  ) : (
                    movements.map(m => (
                      <tr key={m.id} className="border-b border-border/50 hover:bg-muted/20">
                        <td className="py-3 px-4 whitespace-nowrap">{new Date(m.created_at).toLocaleString('pt-BR')}</td>
                        <td className="py-3 px-4">{m.products?.name || m.product_id?.slice(0, 8) || '-'}</td>
                        <td className="py-3 px-4"><Badge variant={TYPE_VARIANTS[m.type] || 'secondary'}>{TYPE_LABELS[m.type] || m.type}</Badge></td>
                        <td className="py-3 px-4 text-right font-medium">{m.quantity}</td>
                        <td className="py-3 px-4 text-muted-foreground truncate max-w-[200px]">{m.notes || '-'}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
            <div className="flex items-center justify-between p-4 border-t">
              <Button variant="outline" size="sm" onClick={() => setPage(p => Math.max(0, p - 1))} disabled={page === 0}>Anterior</Button>
              <span className="text-xs text-muted-foreground">Página {page + 1}</span>
              <Button variant="outline" size="sm" onClick={() => setPage(p => p + 1)} disabled={movements.length < PAGE_SIZE}>Próxima</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}
