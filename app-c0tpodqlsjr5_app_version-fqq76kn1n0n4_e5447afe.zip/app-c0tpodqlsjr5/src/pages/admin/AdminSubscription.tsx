import { useState, useEffect } from 'react';
import { CreditCard, Calendar, Clock, AlertCircle, CheckCircle2, ShieldCheck, Zap, Star, Award, Crown, Settings2 } from 'lucide-react';
import { AdminLayout } from '@/components/layouts/AdminLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import { Separator } from '@/components/ui/separator';
import { Skeleton } from '@/components/ui/skeleton';
import { useStore } from '@/contexts/StoreContext';
import { PLAN_LIMITS } from '@/types/types';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

const plans = [
  { level: 'prata', name: 'Plano Prata', price: 49.90, icon: Star, color: 'text-slate-400' },
  { level: 'ouro', name: 'Plano Ouro', price: 99.90, icon: Award, color: 'text-yellow-500' },
  { level: 'diamond', name: 'Plano Diamond', price: 199.90, icon: Crown, color: 'text-cyan-500' },
] as const;

export default function AdminSubscription() {
  const { subscription, loading, refreshSettings, isExpired } = useStore();
  const [saving, setSaving] = useState(false);
  const [productCount, setProductCount] = useState(0);
  // Config de revenda: dias de trial configurável
  const [trialDays, setTrialDays] = useState('7');
  const [monthlyPrice, setMonthlyPrice] = useState('49.90');

  useEffect(() => {
    supabase.from('products').select('id', { count: 'exact', head: true })
      .then(({ count }) => setProductCount(count || 0));
  }, []);

  // Preencher form com valores atuais quando carregar
  useEffect(() => {
    if (subscription) {
      setTrialDays(String(subscription.trial_days || 7));
      setMonthlyPrice(String(subscription.monthly_price || 49.90));
    }
  }, [subscription]);

  const handleRenew = async () => {
    if (!subscription) return;
    setSaving(true);
    try {
      const now = new Date();
      const expiresAt = new Date(subscription.expires_at);
      const newExpiry = new Date(Math.max(expiresAt.getTime(), now.getTime()) + 30 * 24 * 60 * 60 * 1000);
      const { error } = await supabase.from('subscriptions').update({
        status: 'active',
        expires_at: newExpiry.toISOString(),
        last_billing_date: now.toISOString(),
      }).eq('id', subscription.id);
      if (error) throw error;
      toast.success('Assinatura renovada por mais 30 dias!');
      await refreshSettings();
    } catch (e: any) {
      toast.error('Erro ao renovar: ' + e.message);
    } finally {
      setSaving(false);
    }
  };

  const handleUpdatePlan = async (level: 'prata' | 'ouro' | 'diamond', name: string, price: number) => {
    if (!subscription) return;
    setSaving(true);
    try {
      const { error } = await supabase.from('subscriptions').update({
        plan_level: level, plan_name: name, monthly_price: price,
      }).eq('id', subscription.id);
      if (error) throw error;
      toast.success(`Plano alterado para ${name}!`);
      await refreshSettings();
    } catch (e: any) {
      toast.error('Erro ao alterar plano: ' + e.message);
    } finally {
      setSaving(false);
    }
  };

  const handleSaveResellerConfig = async () => {
    if (!subscription) return;
    const days = parseInt(trialDays) || 7;
    const price = parseFloat(monthlyPrice) || 49.90;
    if (days < 1 || days > 90) { toast.error('Dias de teste deve ser entre 1 e 90.'); return; }
    setSaving(true);
    try {
      const newTrialEnd = new Date(Date.now() + days * 24 * 60 * 60 * 1000);
      const { error } = await supabase.from('subscriptions').update({
        trial_days: days,
        trial_ends_at: newTrialEnd.toISOString(),
        monthly_price: price,
      }).eq('id', subscription.id);
      if (error) throw error;
      toast.success('Configurações de revenda salvas!');
      await refreshSettings();
    } catch (e: any) {
      toast.error('Erro ao salvar: ' + e.message);
    } finally {
      setSaving(false);
    }
  };

  // Loading skeleton
  if (loading) {
    return (
      <AdminLayout>
        <div className="max-w-5xl mx-auto space-y-6">
          <Skeleton className="h-8 w-48" />
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-4">
              <Skeleton className="h-48 w-full" />
              <div className="grid grid-cols-3 gap-4">
                <Skeleton className="h-40" /><Skeleton className="h-40" /><Skeleton className="h-40" />
              </div>
            </div>
            <div className="space-y-4"><Skeleton className="h-40" /><Skeleton className="h-32" /></div>
          </div>
        </div>
      </AdminLayout>
    );
  }

  if (!subscription) {
    return (
      <AdminLayout>
        <div className="max-w-md mx-auto text-center py-16 space-y-4">
          <AlertCircle className="h-12 w-12 text-destructive mx-auto" />
          <p className="text-lg font-semibold">Nenhuma assinatura encontrada.</p>
          <p className="text-sm text-muted-foreground">Entre em contato com o suporte para ativar sua loja.</p>
          <Button variant="outline" onClick={() => window.open('https://wa.me/5511999999999', '_blank')}>Falar com Suporte</Button>
        </div>
      </AdminLayout>
    );
  }

  const trialEnds = new Date(subscription.trial_ends_at);
  const expiresAt = new Date(subscription.expires_at);
  const now = new Date();
  const isTrial = subscription.status === 'trial' && trialEnds > now;
  const daysLeft = isTrial
    ? Math.ceil((trialEnds.getTime() - now.getTime()) / (1000 * 60 * 60 * 24))
    : Math.ceil((expiresAt.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
  const progress = isTrial
    ? Math.max(0, Math.min(100, (daysLeft / subscription.trial_days) * 100))
    : Math.max(0, Math.min(100, (daysLeft / 30) * 100));
  const currentLimits = PLAN_LIMITS[subscription.plan_level || 'prata'];

  return (
    <AdminLayout>
      <div className="space-y-6 max-w-5xl mx-auto pb-10">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Minha Assinatura</h1>
          <p className="text-sm text-muted-foreground mt-1">Gerencie planos, vencimentos e configurações para revenda.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Coluna principal */}
          <div className="lg:col-span-2 space-y-6">

            {/* Status atual */}
            <Card>
              <CardHeader>
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <CardTitle className="text-lg">Status da Assinatura</CardTitle>
                    <CardDescription>Plano: <span className="font-bold text-foreground">{subscription.plan_name}</span></CardDescription>
                  </div>
                  <Badge variant={isExpired ? 'destructive' : 'default'}
                    className={!isExpired ? 'bg-emerald-500 hover:bg-emerald-600 shrink-0' : 'shrink-0'}>
                    {isExpired ? 'Expirado' : isTrial ? 'Teste' : 'Ativo'}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-5">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">{isTrial ? 'Teste restante' : 'Validade restante'}</span>
                      <span className="font-medium">{Math.max(0, daysLeft)} dias</span>
                    </div>
                    <Progress value={progress} className="h-2" />
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                      <Calendar className="h-3 w-3" />
                      Expira: {format(isTrial ? trialEnds : expiresAt, "dd/MM/yyyy", { locale: ptBR })}
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Produtos cadastrados</span>
                      <span className="font-medium">{productCount} / {currentLimits.maxProducts >= 9999 ? '∞' : currentLimits.maxProducts}</span>
                    </div>
                    <Progress value={Math.min(100, (productCount / currentLimits.maxProducts) * 100)} className="h-2" />
                    <p className="text-xs text-muted-foreground">
                      Banners: {currentLimits.maxBanners} | Cupons: {currentLimits.hasCoupons ? 'Sim' : 'Não'}
                    </p>
                  </div>
                </div>

                {isExpired && (
                  <div className="p-3 bg-destructive/10 rounded-lg flex gap-3 items-start border border-destructive/20">
                    <AlertCircle className="h-4 w-4 text-destructive shrink-0 mt-0.5" />
                    <p className="text-xs text-destructive/90 leading-relaxed">
                      <strong>Loja suspensa.</strong> Seus clientes não conseguem realizar compras. Renove agora para restaurar o acesso.
                    </p>
                  </div>
                )}
              </CardContent>
              <CardFooter className="bg-muted/30 border-t py-4">
                <div className="w-full flex flex-col sm:flex-row justify-between items-center gap-3">
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Clock className="h-3.5 w-3.5" />
                    Renovação manual a cada 30 dias.
                  </div>
                  <Button onClick={handleRenew} disabled={saving} size="sm" className="w-full sm:w-auto">
                    {saving && <Zap className="h-3.5 w-3.5 animate-spin mr-1.5" />}
                    Renovar 30 dias — R$ {subscription.monthly_price.toFixed(2)}
                  </Button>
                </div>
              </CardFooter>
            </Card>

            {/* Seleção de planos */}
            <div>
              <h2 className="text-sm font-semibold text-foreground mb-3">Escolher Plano</h2>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {plans.map((plan) => (
                  <Card key={plan.level} className={subscription.plan_level === plan.level ? 'border-primary ring-1 ring-primary' : ''}>
                    <CardHeader className="pb-2 pt-4 px-4">
                      <plan.icon className={`h-5 w-5 ${plan.color} mb-1`} />
                      <CardTitle className="text-sm">{plan.name}</CardTitle>
                      <CardDescription className="text-xs">R$ {plan.price.toFixed(2)}/mês</CardDescription>
                    </CardHeader>
                    <CardContent className="text-xs space-y-1.5 pb-3 px-4">
                      <div className="flex items-center gap-1.5">
                        <CheckCircle2 className="h-3 w-3 text-emerald-500 shrink-0" />
                        <span>{PLAN_LIMITS[plan.level].maxProducts >= 9999 ? 'Produtos ilimitados' : `Até ${PLAN_LIMITS[plan.level].maxProducts} produtos`}</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <CheckCircle2 className="h-3 w-3 text-emerald-500 shrink-0" />
                        <span>Até {PLAN_LIMITS[plan.level].maxBanners} banners</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        {PLAN_LIMITS[plan.level].hasCoupons
                          ? <CheckCircle2 className="h-3 w-3 text-emerald-500 shrink-0" />
                          : <AlertCircle className="h-3 w-3 text-muted-foreground shrink-0" />}
                        <span className={PLAN_LIMITS[plan.level].hasCoupons ? '' : 'text-muted-foreground'}>Cupons de desconto</span>
                      </div>
                    </CardContent>
                    <CardFooter className="pt-0 px-4 pb-4">
                      <Button
                        variant={subscription.plan_level === plan.level ? 'outline' : 'default'}
                        size="sm"
                        className="w-full h-7 text-xs"
                        disabled={saving || subscription.plan_level === plan.level}
                        onClick={() => handleUpdatePlan(plan.level, plan.name, plan.price)}
                      >
                        {subscription.plan_level === plan.level ? 'Plano Atual' : 'Selecionar'}
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            </div>

            {/* Configurações de Revenda */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Settings2 className="h-4 w-4 text-primary" />
                  <CardTitle className="text-base">Configurações de Revenda</CardTitle>
                </div>
                <CardDescription>
                  Defina o período de teste gratuito e o valor mensal para cada cliente da sua plataforma.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-sm font-medium text-foreground">
                      Dias de Teste Gratuito
                    </label>
                    <p className="text-xs text-muted-foreground">Quantos dias o cliente testa antes de pagar.</p>
                    <div className="flex items-center gap-2">
                      <Input
                        type="number"
                        min="1"
                        max="90"
                        value={trialDays}
                        onChange={e => setTrialDays(e.target.value)}
                        className="max-w-[120px]"
                      />
                      <span className="text-sm text-muted-foreground">dias</span>
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-sm font-medium text-foreground">
                      Valor Mensal Cobrado (R$)
                    </label>
                    <p className="text-xs text-muted-foreground">Valor que você cobra de cada cliente.</p>
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-muted-foreground">R$</span>
                      <Input
                        type="number"
                        min="0"
                        step="0.01"
                        value={monthlyPrice}
                        onChange={e => setMonthlyPrice(e.target.value)}
                        className="max-w-[140px]"
                      />
                    </div>
                  </div>
                </div>
                <Separator />
                <div className="p-3 bg-primary/5 rounded-lg border border-primary/15 text-xs text-muted-foreground space-y-1">
                  <p className="font-semibold text-foreground">Como funciona para revenda:</p>
                  <p>• Cada cliente começa com <strong>{trialDays} dias grátis</strong> para testar a loja.</p>
                  <p>• Após o período de teste, a loja é <strong>bloqueada automaticamente</strong> até o pagamento.</p>
                  <p>• Ao receber o pagamento, clique em <em>"Renovar 30 dias"</em> para liberar o acesso.</p>
                  <p>• O valor sugerido de cobrança é <strong>R$ {monthlyPrice}/mês</strong>.</p>
                </div>
              </CardContent>
              <CardFooter className="border-t pt-4">
                <Button onClick={handleSaveResellerConfig} disabled={saving} size="sm">
                  {saving && <Zap className="h-3.5 w-3.5 animate-spin mr-1.5" />}
                  Salvar Configurações de Revenda
                </Button>
              </CardFooter>
            </Card>

          </div>

          {/* Coluna lateral */}
          <div className="space-y-6">
            <Card className="bg-primary text-primary-foreground overflow-hidden relative">
              <CardHeader>
                <CardTitle className="text-lg">SaaS Ready</CardTitle>
                <CardDescription className="text-primary-foreground/80 text-xs">Plataforma pronta para revenda</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3 relative z-10 text-sm">
                <div className="flex gap-2.5"><ShieldCheck className="h-4 w-4 shrink-0" /><p>Bloqueio automático por vencimento</p></div>
                <div className="flex gap-2.5"><Zap className="h-4 w-4 shrink-0" /><p>Período de teste configurável</p></div>
                <div className="flex gap-2.5"><CheckCircle2 className="h-4 w-4 shrink-0" /><p>3 planos com limites diferentes</p></div>
                <div className="flex gap-2.5"><CreditCard className="h-4 w-4 shrink-0" /><p>Nome da loja personalizável</p></div>
              </CardContent>
              <div className="absolute -bottom-6 -right-6 opacity-10">
                <ShieldCheck className="h-28 w-28" />
              </div>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Precisa de ajuda?</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-sm text-muted-foreground">
                  Suporte técnico para configuração e revenda da plataforma.
                </p>
                <Button variant="outline" className="w-full" onClick={() => window.open('https://wa.me/5511999999999', '_blank')}>
                  Falar com Suporte
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}

