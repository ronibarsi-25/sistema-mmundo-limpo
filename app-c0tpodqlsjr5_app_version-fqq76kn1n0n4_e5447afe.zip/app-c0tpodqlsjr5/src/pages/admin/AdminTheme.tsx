import { useState } from 'react';
import { Palette, Save, Loader2, CheckCircle2, RefreshCw, Type, Sliders, Square, Eye } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { AdminLayout } from '@/components/layouts/AdminLayout';
import { useTheme, THEME_PRESETS, FONT_OPTIONS } from '@/contexts/ThemeContext';
import { toast } from 'sonner';

const SHADOW_OPTIONS = [
  { value: 'none', label: 'Sem sombra' },
  { value: 'sm', label: 'Suave' },
  { value: 'md', label: 'Média' },
  { value: 'lg', label: 'Pronunciada' },
];

const BUTTON_STYLES = [
  { value: 'solid', label: 'Sólido' },
  { value: 'rounded', label: 'Arredondado' },
  { value: 'pill', label: 'Pílula' },
  { value: 'sharp', label: 'Angular' },
];

interface ThemeState {
  primary: string;
  secondary: string;
  accent: string;
  bg: string;
  selectedPreset: string;
  fontFamily: string;
  borderRadius: number;
  shadowStyle: string;
  buttonStyle: string;
}

function ColorPicker({ label, desc, value, onChange }: { label: string; desc: string; value: string; onChange: (v: string) => void }) {
  return (
    <div className="space-y-2">
      <Label className="text-sm font-normal">{label}</Label>
      <p className="text-xs text-muted-foreground">{desc}</p>
      <div className="flex items-center gap-3">
        <div className="h-10 w-10 rounded-lg border border-border shrink-0 overflow-hidden cursor-pointer">
          <input type="color" value={value} onChange={e => onChange(e.target.value)}
            className="h-full w-full cursor-pointer border-0 p-0.5 bg-transparent" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="h-10 rounded-lg flex items-center justify-center text-sm font-semibold select-none"
            style={{ backgroundColor: value, color: '#fff', textShadow: '0 1px 3px rgba(0,0,0,0.5)' }}>
            {value.toUpperCase()}
          </div>
        </div>
      </div>
    </div>
  );
}

export default function AdminTheme() {
  const { theme, applyTheme, saveTheme } = useTheme();
  const [saving, setSaving] = useState(false);

  const [state, setState] = useState<ThemeState>({
    primary: theme?.primary_color || '#2563EB',
    secondary: theme?.secondary_color || '#7C3AED',
    accent: theme?.accent_color || '#F59E0B',
    bg: theme?.background_color || '#FAFAFA',
    selectedPreset: theme?.preset_name || 'azul-vibrante',
    fontFamily: theme?.font_family || 'Inter',
    borderRadius: Number(theme?.border_radius) || 8,
    shadowStyle: theme?.shadow_style || 'md',
    buttonStyle: theme?.button_style || 'solid',
  });

  const update = (patch: Partial<ThemeState>) => {
    const next = { ...state, ...patch };
    setState(next);
    // Aplica preview em tempo real
    applyTheme({
      primary_color: next.primary,
      secondary_color: next.secondary,
      accent_color: next.accent,
      background_color: next.bg,
      font_family: next.fontFamily,
      border_radius: String(next.borderRadius),
      shadow_style: next.shadowStyle,
      button_style: next.buttonStyle,
    });
  };

  const handlePreset = (preset: typeof THEME_PRESETS[0]) => {
    update({ selectedPreset: preset.name, primary: preset.primary, secondary: preset.secondary, accent: preset.accent, bg: preset.bg });
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await saveTheme({
        primary_color: state.primary,
        secondary_color: state.secondary,
        accent_color: state.accent,
        background_color: state.bg,
        preset_name: state.selectedPreset,
        font_family: state.fontFamily,
        border_radius: String(state.borderRadius),
        shadow_style: state.shadowStyle,
        button_style: state.buttonStyle,
      });
      toast.success('Tema salvo e aplicado com sucesso!');
    } catch {
      toast.error('Erro ao salvar tema. Tente novamente.');
    } finally {
      setSaving(false);
    }
  };

  const handleReset = () => handlePreset(THEME_PRESETS[0]);

  // Calcula border-radius do botão baseado no estilo
  const btnRadius = state.buttonStyle === 'pill' ? '9999px'
    : state.buttonStyle === 'sharp' ? '0px'
    : state.buttonStyle === 'rounded' ? '12px'
    : `${state.borderRadius}px`;

  return (
    <AdminLayout title="Editor Visual de Temas">
      <div className="max-w-3xl space-y-5">

        <Tabs defaultValue="cores">
          <TabsList className="grid grid-cols-4 w-full">
            <TabsTrigger value="cores" className="text-xs md:text-sm"><Palette className="h-3.5 w-3.5 mr-1 hidden md:inline" />Cores</TabsTrigger>
            <TabsTrigger value="tipografia" className="text-xs md:text-sm"><Type className="h-3.5 w-3.5 mr-1 hidden md:inline" />Fonte</TabsTrigger>
            <TabsTrigger value="formas" className="text-xs md:text-sm"><Square className="h-3.5 w-3.5 mr-1 hidden md:inline" />Formas</TabsTrigger>
            <TabsTrigger value="preview" className="text-xs md:text-sm"><Eye className="h-3.5 w-3.5 mr-1 hidden md:inline" />Prévia</TabsTrigger>
          </TabsList>

          {/* ABA: CORES */}
          <TabsContent value="cores" className="space-y-5 mt-4">
            {/* Paletas pré-definidas */}
            <div className="bg-card border border-border rounded-xl p-5 space-y-4">
              <div>
                <h2 className="font-semibold text-sm flex items-center gap-2"><Palette className="h-4 w-4 text-primary" />Paletas Prontas</h2>
                <p className="text-xs text-muted-foreground mt-0.5">Clique para aplicar — preview imediato.</p>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {THEME_PRESETS.map(preset => (
                  <button key={preset.name} type="button" onClick={() => handlePreset(preset)}
                    className={`relative rounded-xl p-3 border-2 transition-all text-left hover:shadow-md ${state.selectedPreset === preset.name ? 'border-primary shadow-md' : 'border-border hover:border-primary/50'}`}>
                    {state.selectedPreset === preset.name && (
                      <CheckCircle2 className="absolute top-2 right-2 h-4 w-4 text-primary" />
                    )}
                    <div className="flex gap-1 mb-2">
                      <div className="h-5 w-5 rounded-full" style={{ backgroundColor: preset.primary }} />
                      <div className="h-5 w-5 rounded-full" style={{ backgroundColor: preset.secondary }} />
                      <div className="h-5 w-5 rounded-full" style={{ backgroundColor: preset.accent }} />
                    </div>
                    <p className="text-xs font-medium leading-tight">{preset.label}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Cores personalizadas */}
            <div className="bg-card border border-border rounded-xl p-5 space-y-5">
              <div>
                <h2 className="font-semibold text-sm flex items-center gap-2"><Sliders className="h-4 w-4 text-primary" />Cores Personalizadas</h2>
                <p className="text-xs text-muted-foreground mt-0.5">Ajuste cada cor individualmente.</p>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <ColorPicker label="Cor Primária" desc="Botões, links, nav, destaques" value={state.primary}
                  onChange={v => update({ primary: v, selectedPreset: 'custom' })} />
                <ColorPicker label="Cor Secundária" desc="Elementos complementares" value={state.secondary}
                  onChange={v => update({ secondary: v, selectedPreset: 'custom' })} />
                <ColorPicker label="Cor de Destaque (Accent)" desc="Badges, promoções, etiquetas" value={state.accent}
                  onChange={v => update({ accent: v, selectedPreset: 'custom' })} />
                <ColorPicker label="Cor de Fundo" desc="Background geral das páginas" value={state.bg}
                  onChange={v => update({ bg: v, selectedPreset: 'custom' })} />
              </div>
            </div>
          </TabsContent>

          {/* ABA: TIPOGRAFIA */}
          <TabsContent value="tipografia" className="mt-4">
            <div className="bg-card border border-border rounded-xl p-5 space-y-6">
              <div>
                <h2 className="font-semibold text-sm flex items-center gap-2"><Type className="h-4 w-4 text-primary" />Tipografia</h2>
                <p className="text-xs text-muted-foreground mt-0.5">Define a família de fonte usada em todo o site.</p>
              </div>

              <div className="space-y-3">
                <Label className="text-sm font-normal">Família de Fonte</Label>
                <Select value={state.fontFamily} onValueChange={v => update({ fontFamily: v })}>
                  <SelectTrigger className="h-10">
                    <SelectValue placeholder="Escolha uma fonte" />
                  </SelectTrigger>
                  <SelectContent>
                    {FONT_OPTIONS.map(f => (
                      <SelectItem key={f.value} value={f.value}
                        style={{ fontFamily: `'${f.value}', system-ui, sans-serif` }}>
                        {f.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <Separator />

              {/* Preview da fonte */}
              <div className="rounded-lg border border-border p-4 space-y-2" style={{ fontFamily: `'${state.fontFamily}', system-ui, sans-serif` }}>
                <p className="text-xs text-muted-foreground uppercase tracking-widest">Prévia da fonte: {state.fontFamily}</p>
                <p className="text-2xl font-bold" style={{ color: state.primary }}>Título da Loja</p>
                <p className="text-base font-medium">Subtítulo do produto</p>
                <p className="text-sm text-muted-foreground">Descrição do produto com texto de tamanho normal para verificar legibilidade.</p>
                <div className="flex gap-2 mt-2">
                  <span className="px-3 py-1 text-xs font-semibold rounded text-white" style={{ backgroundColor: state.primary }}>Comprar Agora</span>
                  <span className="px-3 py-1 text-xs font-semibold rounded text-white" style={{ backgroundColor: state.accent }}>Promoção</span>
                </div>
              </div>
            </div>
          </TabsContent>

          {/* ABA: FORMAS */}
          <TabsContent value="formas" className="mt-4 space-y-5">
            <div className="bg-card border border-border rounded-xl p-5 space-y-6">
              <div>
                <h2 className="font-semibold text-sm flex items-center gap-2"><Square className="h-4 w-4 text-primary" />Formas e Bordas</h2>
                <p className="text-xs text-muted-foreground mt-0.5">Controla o arredondamento de cards e inputs.</p>
              </div>

              <div className="space-y-4">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="text-sm font-normal">Raio de borda geral</Label>
                    <span className="text-xs font-mono bg-muted px-2 py-0.5 rounded">{state.borderRadius}px</span>
                  </div>
                  <Slider min={0} max={24} step={2} value={[state.borderRadius]}
                    onValueChange={([v]) => update({ borderRadius: v })} className="w-full" />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>Angular (0)</span><span>Médio (8)</span><span>Suave (16)</span><span>Círculo (24)</span>
                  </div>
                </div>

                <div className="flex gap-3">
                  {[0, 6, 12, 20].map(r => (
                    <div key={r} className="flex-1 h-12 border-2 border-border flex items-center justify-center text-xs text-muted-foreground"
                      style={{ borderRadius: `${r}px`, backgroundColor: r === state.borderRadius ? state.primary + '20' : undefined }}>
                      {r}px
                    </div>
                  ))}
                </div>
              </div>

              <Separator />

              <div className="space-y-3">
                <Label className="text-sm font-normal">Estilo dos botões</Label>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                  {BUTTON_STYLES.map(bs => (
                    <button key={bs.value} type="button" onClick={() => update({ buttonStyle: bs.value })}
                      className={`p-3 border-2 rounded-xl transition-all text-center ${state.buttonStyle === bs.value ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/40'}`}>
                      <div className="h-7 mb-2 flex items-center justify-center text-xs font-semibold text-white"
                        style={{ backgroundColor: state.primary, borderRadius: btnRadius }}>
                        AA
                      </div>
                      <p className="text-xs text-foreground">{bs.label}</p>
                    </button>
                  ))}
                </div>
              </div>

              <Separator />

              <div className="space-y-3">
                <Label className="text-sm font-normal">Estilo de sombras</Label>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                  {SHADOW_OPTIONS.map(s => (
                    <button key={s.value} type="button" onClick={() => update({ shadowStyle: s.value })}
                      className={`p-3 border-2 rounded-xl transition-all ${state.shadowStyle === s.value ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/40'}`}>
                      <div className="h-8 rounded-lg bg-card border border-border mb-2 mx-auto w-12"
                        style={{
                          boxShadow: s.value === 'none' ? 'none' : s.value === 'sm' ? '0 1px 3px rgba(0,0,0,.12)'
                            : s.value === 'md' ? '0 4px 12px rgba(0,0,0,.15)' : '0 8px 24px rgba(0,0,0,.2)',
                        }} />
                      <p className="text-xs text-center text-foreground">{s.label}</p>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </TabsContent>

          {/* ABA: PRÉVIA */}
          <TabsContent value="preview" className="mt-4">
            <div className="bg-card border border-border rounded-xl p-5 space-y-4">
              <div>
                <h2 className="font-semibold text-sm flex items-center gap-2"><Eye className="h-4 w-4 text-primary" />Prévia do Tema</h2>
                <p className="text-xs text-muted-foreground mt-0.5">Simulação de como o site vai aparecer.</p>
              </div>

              {/* Simulação de cabeçalho */}
              <div className="rounded-xl overflow-hidden border border-border" style={{ fontFamily: `'${state.fontFamily}', system-ui, sans-serif` }}>
                {/* Header */}
                <div className="flex items-center gap-3 px-4 py-3" style={{ backgroundColor: state.primary }}>
                  <span className="font-bold text-sm text-white">🏪 Minha Loja</span>
                  <div className="flex-1" />
                  <span className="text-xs text-white/80 hidden md:block">Produtos</span>
                  <span className="text-xs text-white/80 hidden md:block">Categorias</span>
                  <div className="px-3 py-1 text-xs font-semibold text-white" style={{ backgroundColor: state.accent, borderRadius: btnRadius }}>
                    Carrinho
                  </div>
                </div>

                {/* Banner hero */}
                <div className="px-4 py-6 text-center" style={{ backgroundColor: state.primary + 'DD' }}>
                  <p className="text-lg font-bold text-white mb-1">Qualidade em cada detalhe</p>
                  <p className="text-xs text-white/70 mb-3">Descubra nossa seleção exclusiva</p>
                  <button className="px-4 py-1.5 text-xs font-semibold text-white" style={{ backgroundColor: state.accent, borderRadius: btnRadius }}>
                    Ver Produtos
                  </button>
                </div>

                {/* Cards de produto */}
                <div className="p-4 grid grid-cols-3 gap-3" style={{ backgroundColor: state.bg }}>
                  {[1, 2, 3].map(i => (
                    <div key={i} className="border border-border bg-white overflow-hidden"
                      style={{
                        borderRadius: `${state.borderRadius}px`,
                        boxShadow: state.shadowStyle === 'none' ? 'none' : state.shadowStyle === 'sm' ? '0 1px 3px rgba(0,0,0,.1)'
                          : state.shadowStyle === 'md' ? '0 4px 10px rgba(0,0,0,.12)' : '0 6px 20px rgba(0,0,0,.15)',
                      }}>
                      <div className="aspect-square" style={{ backgroundColor: [state.primary, state.secondary, state.accent][i - 1] + '30' }} />
                      <div className="p-2">
                        <p className="text-xs font-semibold truncate">Produto {i}</p>
                        <p className="text-xs font-bold" style={{ color: state.primary }}>R$ {(i * 49.9).toFixed(2)}</p>
                        <button className="mt-1.5 w-full py-0.5 text-xs font-medium text-white" style={{ backgroundColor: state.primary, borderRadius: btnRadius }}>
                          Comprar
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        {/* Ações globais */}
        <div className="flex items-center gap-3 pt-1">
          <Button type="button" variant="outline" onClick={handleReset} className="h-10">
            <RefreshCw className="h-4 w-4 mr-2" /> Restaurar Padrão
          </Button>
          <Button onClick={handleSave} disabled={saving} className="bg-primary text-primary-foreground hover:bg-primary/90 h-10 flex-1 md:flex-none min-w-36">
            {saving ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Save className="h-4 w-4 mr-2" />}
            Salvar Tema
          </Button>
        </div>
      </div>
    </AdminLayout>
  );
}
