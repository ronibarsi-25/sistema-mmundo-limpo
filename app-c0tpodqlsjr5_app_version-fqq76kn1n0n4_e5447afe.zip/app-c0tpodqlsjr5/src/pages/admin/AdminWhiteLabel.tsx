import { useState, useEffect, useRef } from 'react';
import { useForm } from 'react-hook-form';
import {
  Palette, Image, Upload, Loader2, Save, Undo2, Eye,
  Smartphone, Monitor
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import { useTenant } from '@/contexts/TenantContext';
import type { Tenant } from '@/types/types';

interface WhiteLabelForm {
  name: string;
  description: string;
  phone: string;
  email: string;
  primary_color: string;
  secondary_color: string;
  accent_color: string;
}

export default function AdminWhiteLabel() {
  const { tenant, refreshTenant } = useTenant();
  const [saving, setSaving] = useState(false);
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [logoPreview, setLogoPreview] = useState<string | null>(tenant?.logo_url || null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [previewMode, setPreviewMode] = useState<'desktop' | 'mobile'>('desktop');

  const form = useForm<WhiteLabelForm>({
    defaultValues: {
      name: tenant?.name || '',
      description: tenant?.description || '',
      phone: tenant?.phone || '',
      email: tenant?.email || '',
      primary_color: tenant?.primary_color || '#0f172a',
      secondary_color: tenant?.secondary_color || '#64748b',
      accent_color: tenant?.accent_color || '#f59e0b',
    },
  });

  useEffect(() => {
    if (tenant) {
      form.reset({
        name: tenant.name,
        description: tenant.description || '',
        phone: tenant.phone || '',
        email: tenant.email || '',
        primary_color: tenant.primary_color,
        secondary_color: tenant.secondary_color,
        accent_color: tenant.accent_color,
      });
      setLogoPreview(tenant.logo_url);
    }
  }, [tenant]);

  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 1024 * 1024) {
      toast.error('Imagem deve ter no máximo 1MB');
      return;
    }
    setLogoFile(file);
    const reader = new FileReader();
    reader.onloadend = () => setLogoPreview(reader.result as string);
    reader.readAsDataURL(file);
  };

  const uploadLogo = async (): Promise<string | null> => {
    if (!logoFile || !tenant) return null;
    const fileName = `tenant_${tenant.id}_${Date.now()}.${logoFile.name.split('.').pop()}`;
    const { error: uploadError } = await supabase.storage
      .from('tenant-logos')
      .upload(fileName, logoFile, { upsert: true });
    if (uploadError) {
      toast.error('Erro ao enviar logo');
      return null;
    }
    const { data } = supabase.storage.from('tenant-logos').getPublicUrl(fileName);
    return data.publicUrl;
  };

  const onSubmit = async (data: WhiteLabelForm) => {
    if (!tenant) { toast.error('Tenant não encontrado'); return; }
    setSaving(true);

    try {
      let logoUrl = tenant.logo_url;
      if (logoFile) {
        const uploaded = await uploadLogo();
        if (uploaded) logoUrl = uploaded;
      }

      const { error } = await supabase
        .from('tenants')
        .update({
          name: data.name,
          description: data.description,
          phone: data.phone,
          email: data.email,
          primary_color: data.primary_color,
          secondary_color: data.secondary_color,
          accent_color: data.accent_color,
          logo_url: logoUrl,
          updated_at: new Date().toISOString(),
        })
        .eq('id', tenant.id);

      if (error) {
        toast.error('Erro ao salvar configurações');
        setSaving(false);
        return;
      }

      await refreshTenant();
      toast.success('White label atualizado!');
      setLogoFile(null);
    } catch {
      toast.error('Erro inesperado');
    } finally {
      setSaving(false);
    }
  };

  const currentColors = form.watch();

  return (
    <div className="p-4 md:p-8 max-w-6xl mx-auto space-y-6">
      <div className="flex items-center gap-3">
        <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
          <Palette className="h-5 w-5 text-primary" />
        </div>
        <div>
          <h1 className="text-xl md:text-2xl font-bold text-balance">White Label</h1>
          <p className="text-sm text-muted-foreground">Personalize as cores e identidade da sua loja</p>
        </div>
      </div>

      <Tabs defaultValue="settings">
        <TabsList>
          <TabsTrigger value="settings" className="flex items-center gap-1.5">
            <Palette className="h-3.5 w-3.5" /> Configurações
          </TabsTrigger>
          <TabsTrigger value="preview" className="flex items-center gap-1.5">
            <Eye className="h-3.5 w-3.5" /> Pré-visualização
          </TabsTrigger>
        </TabsList>

        <TabsContent value="settings" className="space-y-6 mt-4">
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Logo */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base font-medium flex items-center gap-2">
                  <Image className="h-4 w-4" /> Logo da Loja
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className="h-20 w-20 rounded-xl border border-border bg-muted flex items-center justify-center overflow-hidden">
                    {logoPreview ? (
                      <img src={logoPreview} alt="Logo" className="h-full w-full object-contain p-2" />
                    ) : (
                      <span className="text-2xl font-bold text-primary">{form.watch('name')?.charAt(0) || 'L'}</span>
                    )}
                  </div>
                  <div className="space-y-2">
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      className="flex items-center gap-1.5"
                      onClick={() => fileInputRef.current?.click()}
                    >
                      <Upload className="h-3.5 w-3.5" /> Enviar Logo
                    </Button>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={handleLogoChange}
                    />
                    <p className="text-xs text-muted-foreground">Máx. 1MB. Recomendado: PNG com fundo transparente.</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Brand Info */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base font-medium">Informações da Marca</CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="name">Nome da Loja</Label>
                  <Input id="name" {...form.register('name')} />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="description">Descrição</Label>
                  <Input id="description" {...form.register('description')} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Telefone</Label>
                  <Input id="phone" {...form.register('phone')} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">E-mail</Label>
                  <Input id="email" type="email" {...form.register('email')} />
                </div>
              </CardContent>
            </Card>

            {/* Colors */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base font-medium flex items-center gap-2">
                  <Palette className="h-4 w-4" /> Cores
                </CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-3">
                  <Label>Cor Primária</Label>
                  <div className="flex items-center gap-3">
                    <input
                      type="color"
                      {...form.register('primary_color')}
                      className="h-10 w-10 rounded cursor-pointer border-0 p-0"
                    />
                    <Input
                      value={form.watch('primary_color')}
                      onChange={(e) => form.setValue('primary_color', e.target.value)}
                      className="w-28"
                    />
                  </div>
                  <p className="text-xs text-muted-foreground">Cabeçalhos, botões principais</p>
                </div>
                <div className="space-y-3">
                  <Label>Cor Secundária</Label>
                  <div className="flex items-center gap-3">
                    <input
                      type="color"
                      {...form.register('secondary_color')}
                      className="h-10 w-10 rounded cursor-pointer border-0 p-0"
                    />
                    <Input
                      value={form.watch('secondary_color')}
                      onChange={(e) => form.setValue('secondary_color', e.target.value)}
                      className="w-28"
                    />
                  </div>
                  <p className="text-xs text-muted-foreground">Textos, ícones, detalhes</p>
                </div>
                <div className="space-y-3">
                  <Label>Cor de Destaque</Label>
                  <div className="flex items-center gap-3">
                    <input
                      type="color"
                      {...form.register('accent_color')}
                      className="h-10 w-10 rounded cursor-pointer border-0 p-0"
                    />
                    <Input
                      value={form.watch('accent_color')}
                      onChange={(e) => form.setValue('accent_color', e.target.value)}
                      className="w-28"
                    />
                  </div>
                  <p className="text-xs text-muted-foreground">Promoções, destaques, call-to-action</p>
                </div>
              </CardContent>
            </Card>

            <div className="flex items-center gap-3">
              <Button type="submit" disabled={saving} className="flex items-center gap-2">
                {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                Salvar Alterações
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  if (tenant) form.reset({
                    name: tenant.name,
                    description: tenant.description || '',
                    phone: tenant.phone || '',
                    email: tenant.email || '',
                    primary_color: tenant.primary_color,
                    secondary_color: tenant.secondary_color,
                    accent_color: tenant.accent_color,
                  });
                  setLogoPreview(tenant?.logo_url || null);
                  setLogoFile(null);
                }}
              >
                <Undo2 className="h-4 w-4 mr-1" /> Restaurar
              </Button>
            </div>
          </form>
        </TabsContent>

        <TabsContent value="preview" className="mt-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-base font-medium">Pré-visualização do Site</CardTitle>
              <div className="flex items-center gap-2 bg-muted rounded-lg p-1">
                <button
                  onClick={() => setPreviewMode('desktop')}
                  className={`p-1.5 rounded ${previewMode === 'desktop' ? 'bg-background shadow-sm' : ''}`}
                >
                  <Monitor className="h-4 w-4" />
                </button>
                <button
                  onClick={() => setPreviewMode('mobile')}
                  className={`p-1.5 rounded ${previewMode === 'mobile' ? 'bg-background shadow-sm' : ''}`}
                >
                  <Smartphone className="h-4 w-4" />
                </button>
              </div>
            </CardHeader>
            <CardContent>
              <div className={`mx-auto border border-border rounded-xl overflow-hidden transition-all ${previewMode === 'mobile' ? 'max-w-sm' : 'max-w-full'}`}>
                {/* Fake Header */}
                <div
                  className="p-4 flex items-center justify-between"
                  style={{ backgroundColor: currentColors.primary_color }}
                >
                  <div className="flex items-center gap-2">
                    {logoPreview ? (
                      <img src={logoPreview} alt="" className="h-8 w-8 object-contain" />
                    ) : (
                      <div className="h-8 w-8 rounded bg-white/20 flex items-center justify-center text-white font-bold">
                        {currentColors.name?.charAt(0) || 'L'}
                      </div>
                    )}
                    <span className="text-white font-semibold text-sm">{currentColors.name || 'Minha Loja'}</span>
                  </div>
                  <div className="flex gap-2">
                    <div className="h-4 w-4 rounded-full bg-white/20" />
                    <div className="h-4 w-4 rounded-full bg-white/20" />
                  </div>
                </div>

                {/* Fake Hero */}
                <div
                  className="p-6 md:p-8 text-center"
                  style={{ background: `linear-gradient(135deg, ${currentColors.primary_color} 0%, ${currentColors.secondary_color} 100%)` }}
                >
                  <h2 className="text-white text-lg font-bold mb-2">{currentColors.name || 'Bem-vindo!'}</h2>
                  <p className="text-white/80 text-xs mb-4">{currentColors.description || 'Sua loja online'}</p>
                  <button
                    className="px-4 py-1.5 rounded-lg text-sm font-medium"
                    style={{ backgroundColor: currentColors.accent_color, color: '#fff' }}
                  >
                    Ver Produtos
                  </button>
                </div>

                {/* Fake Products */}
                <div className="p-4 bg-background grid grid-cols-2 gap-3">
                  {[1, 2, 3, 4].map((i) => (
                    <div key={i} className="border border-border rounded-lg p-3 space-y-2 bg-card">
                      <div className="aspect-square rounded-md bg-muted" />
                      <p className="text-xs font-medium">Produto {i}</p>
                      <p className="text-xs font-bold" style={{ color: currentColors.accent_color }}>R$ 99,90</p>
                    </div>
                  ))}
                </div>

                {/* Fake Footer */}
                <div
                  className="p-4 text-center text-xs"
                  style={{ backgroundColor: currentColors.primary_color, color: '#fff' }}
                >
                  <p>{currentColors.name || 'Minha Loja'} — {currentColors.phone || 'Contato'}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
