import React, { useState, useEffect, useRef } from 'react';
import html2canvas from 'html2canvas';
import { supabase } from '@/db/supabase';
import { PdvLayout } from '@/components/layouts/PdvLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Rss, Copy, Download, Check, AlertTriangle, ShieldCheck, Sparkles,
  ExternalLink, Instagram, Facebook, Share2, Image as ImageIcon,
  RefreshCw, CheckCircle2, XCircle, ArrowUpRight, MessageCircle,
  HelpCircle, Eye, ShoppingCart, Tag, Smartphone, Layers
} from 'lucide-react';
import { toast } from 'sonner';
import {
  generateMetaXml,
  generateMetaCsv,
  downloadFile,
  validateMetaProduct,
  sanitizeMetaImageUrl,
  type MetaProductItem,
} from '@/utils/metaFeedGenerator';

interface ProductItem {
  id: string;
  name: string;
  slug?: string;
  description?: string;
  price: number;
  stock_quantity: number;
  is_available: boolean;
  images?: Array<{ url: string }>;
  category_name?: string;
  barcode?: string;
  code?: string;
}

export default function MetaSocialFeed() {
  const [activeTab, setActiveTab] = useState<'feed' | 'posts' | 'tutorial'>('feed');
  const [products, setProducts] = useState<ProductItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [copiedUrl, setCopiedUrl] = useState<string | null>(null);
  const [filterStatus, setFilterStatus] = useState<'all' | 'ready' | 'pending'>('all');
  const [search, setSearch] = useState('');

  // Post Generator States
  const [selectedProductId, setSelectedProductId] = useState<string>('');
  const [postFormat, setPostFormat] = useState<'feed' | 'story'>('feed');
  const [postTheme, setPostTheme] = useState<'verde' | 'azul' | 'laranja' | 'dark'>('verde');
  const [postTag, setPostTag] = useState('Oferta Especial');
  const [discountPercent, setDiscountPercent] = useState('10');
  const [downloadingImg, setDownloadingImg] = useState(false);
  const postCanvasRef = useRef<HTMLDivElement>(null);

  const origin = window.location.origin;
  const feedXmlUrl = `${origin}/feed/meta?format=xml`;
  const feedCsvUrl = `${origin}/feed/meta?format=csv`;

  useEffect(() => {
    loadProducts();
  }, []);

  const loadProducts = async () => {
    setLoading(true);
    try {
      // 1. Produtos do site
      const { data: siteProducts } = await supabase
        .from('products')
        .select('id, name, slug, description, price, stock_quantity, is_available, images, barcode, category_id, categories(name)');

      // 2. Barcodes do PDV
      const { data: pdvItems } = await supabase
        .from('pdv_products')
        .select('name, code, barcode, site_product_id');

      const barcodeBySiteId = new Map<string, { barcode?: string; code?: string }>();
      const barcodeByName = new Map<string, { barcode?: string; code?: string }>();

      pdvItems?.forEach(p => {
        if (p.site_product_id) barcodeBySiteId.set(p.site_product_id, { barcode: p.barcode, code: p.code });
        barcodeByName.set(p.name.trim().toLowerCase(), { barcode: p.barcode, code: p.code });
      });

      const list: ProductItem[] = (siteProducts || []).map(p => {
        const pdvData = barcodeBySiteId.get(p.id) || barcodeByName.get(p.name.trim().toLowerCase());
        return {
          id: p.id,
          name: p.name,
          slug: p.slug,
          description: p.description,
          price: Number(p.price) || 0,
          stock_quantity: Number(p.stock_quantity) || 0,
          is_available: Boolean(p.is_available),
          images: p.images || [],
          category_name: (p.categories as any)?.name || 'Geral',
          barcode: p.barcode?.trim() || pdvData?.barcode || '',
          code: pdvData?.code || '',
        };
      });

      setProducts(list);
      if (list.length > 0 && !selectedProductId) {
        setSelectedProductId(list[0].id);
      }
    } catch (err: any) {
      console.error(err);
      toast.error('Erro ao carregar catálogo: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  // Convert to Meta items format
  const metaItems: MetaProductItem[] = products
    .filter(p => p.is_available)
    .map(p => ({
      id: p.id,
      title: p.name,
      description: p.description || p.name,
      availability: p.stock_quantity > 0 ? 'in stock' : 'out of stock',
      condition: 'new',
      price: `${p.price.toFixed(2)} BRL`,
      link: `${origin}/produto/${p.slug || p.id}`,
      image_link: sanitizeMetaImageUrl(p.images?.[0]?.url, origin, p.slug || p.id),
      brand: 'Mundo Limpo',
      gtin: p.barcode || '',
      fb_product_category: 'Health & Beauty > Personal Care',
    }));

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedUrl(id);
    toast.success('Link do feed copiado com sucesso! Cole no Gerenciador de Comércio da Meta.');
    setTimeout(() => setCopiedUrl(null), 2500);
  };

  const handleDownloadFeed = (fmt: 'xml' | 'csv') => {
    if (metaItems.length === 0) {
      toast.warning('Nenhum produto publicado no site para exportar no feed.');
      return;
    }
    const storeMeta = {
      storeName: 'Mundo Limpo',
      storeUrl: origin,
      storeDescription: 'Feed de Catálogo Oficial Mundo Limpo para Facebook e Instagram Shopping',
    };

    if (fmt === 'xml') {
      const xml = generateMetaXml(metaItems, storeMeta);
      downloadFile(xml, 'feed_catalogo_meta_facebook_instagram.xml', 'application/xml;charset=utf-8;');
    } else {
      const csv = generateMetaCsv(metaItems);
      downloadFile(csv, 'feed_catalogo_meta_facebook_instagram.csv', 'text/csv;charset=utf-8;');
    }
    toast.success(`Download do feed (${fmt.toUpperCase()}) concluído!`);
  };

  // Diagnostics counters
  const totalInFeed = metaItems.length;
  const readyProducts = metaItems.filter(item => validateMetaProduct(item).isReady);
  const pendingProducts = metaItems.filter(item => !validateMetaProduct(item).isReady);
  const inStockCount = metaItems.filter(item => item.availability === 'in stock').length;

  const filteredProducts = products.filter(p => {
    const s = search.toLowerCase();
    const matchSearch = !search || p.name.toLowerCase().includes(s) || p.barcode?.includes(s) || p.code?.includes(s);
    if (!matchSearch) return false;

    const validation = validateMetaProduct({
      title: p.name,
      image_link: p.images?.[0]?.url,
      price: `${p.price.toFixed(2)} BRL`,
      gtin: p.barcode,
    });

    if (filterStatus === 'ready') return validation.isReady;
    if (filterStatus === 'pending') return !validation.isReady;
    return true;
  });

  // Selected product for post generator
  const currentProduct = products.find(p => p.id === selectedProductId) || products[0];

  // Post caption and hashtags generator
  const generateSocialCaption = () => {
    if (!currentProduct) return '';
    const name = currentProduct.name;
    const price = currentProduct.price.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
    const link = `${origin}/produto/${currentProduct.slug || currentProduct.id}`;
    const desc = currentProduct.description ? `${currentProduct.description}\n\n` : '';

    return `✨ ${postTag.toUpperCase()} NA MUNDO LIMPO! ✨\n\n🔹 ${name}\n${desc}💰 Por apenas: ${price}\n\n🚀 Garanta o seu agora mesmo com entrega rápida e a máxima qualidade que só a Mundo Limpo oferece!\n\n📲 Compre pelo link na bio ou chame no WhatsApp!\n👉 ${link}\n\n#mundolimpo #produtosdelimpeza #limpezadomestica #limpeza #oferta #qualidade #promocao #brasil`;
  };

  const handleCopyCaption = () => {
    navigator.clipboard.writeText(generateSocialCaption());
    toast.success('Legenda do post copiada para a área de transferência!');
  };

  const handleDownloadPostImage = async () => {
    if (!postCanvasRef.current) return;
    setDownloadingImg(true);
    try {
      const canvas = await html2canvas(postCanvasRef.current, {
        scale: 2,
        useCORS: true,
        allowTaint: true,
        backgroundColor: null,
      });
      const dataUrl = canvas.toDataURL('image/png');
      const a = document.createElement('a');
      a.href = dataUrl;
      a.download = `post_${postFormat}_${currentProduct?.slug || 'produto'}.png`;
      a.click();
      toast.success('Criativo baixado com sucesso!');
    } catch (err: any) {
      toast.error('Erro ao gerar imagem: ' + err.message);
    } finally {
      setDownloadingImg(false);
    }
  };

  return (
    <PdvLayout title="Feed Facebook & Instagram Shopping">
      <div className="space-y-6 max-w-7xl mx-auto">
        {/* Header banner */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-xl border border-primary/20 bg-gradient-to-r from-primary/10 via-primary/5 to-transparent">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Badge className="bg-primary text-primary-foreground text-xs gap-1">
                <Rss className="h-3 w-3" /> Meta Commerce Manager
              </Badge>
              <Badge variant="outline" className="border-primary/30 text-primary text-xs gap-1">
                <Instagram className="h-3 w-3" /> Instagram Shopping
              </Badge>
              <Badge variant="outline" className="border-primary/30 text-primary text-xs gap-1">
                <Facebook className="h-3 w-3" /> Facebook Shop
              </Badge>
            </div>
            <h1 className="text-xl md:text-2xl font-bold tracking-tight text-foreground">
              Catálogo & Feed para Redes Sociais
            </h1>
            <p className="text-xs md:text-sm text-muted-foreground text-pretty">
              Sincronize os produtos da sua loja automaticamente com o Catálogo da Meta e crie publicações profissionais para o Feed e Stories.
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <Button
              size="sm"
              variant="outline"
              onClick={() => handleDownloadFeed('xml')}
              className="gap-1.5 text-xs h-9"
              title="Baixar arquivo XML RSS compatível com Meta e Google"
            >
              <Download className="h-3.5 w-3.5" />
              Baixar XML
            </Button>
            <Button
              size="sm"
              onClick={() => handleDownloadFeed('csv')}
              className="gap-1.5 text-xs h-9 bg-primary text-primary-foreground"
              title="Baixar planilha CSV no formato da Meta"
            >
              <Download className="h-3.5 w-3.5" />
              Baixar CSV
            </Button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <Tabs value={activeTab} onValueChange={(v: any) => setActiveTab(v)}>
          <TabsList className="grid grid-cols-3 max-w-md">
            <TabsTrigger value="feed" className="text-xs gap-1.5">
              <Rss className="h-3.5 w-3.5" /> Feed Meta
            </TabsTrigger>
            <TabsTrigger value="posts" className="text-xs gap-1.5">
              <Sparkles className="h-3.5 w-3.5" /> Gerador de Posts
            </TabsTrigger>
            <TabsTrigger value="tutorial" className="text-xs gap-1.5">
              <HelpCircle className="h-3.5 w-3.5" /> Como Configurar
            </TabsTrigger>
          </TabsList>

          {/* ──────────────────────────────────────────────────────────────────
              ABA 1: FEED DE CATÁLOGO META
             ────────────────────────────────────────────────────────────────── */}
          <TabsContent value="feed" className="space-y-6 mt-4">
            {/* Live Feed URLs box */}
            <Card className="border-border">
              <CardHeader className="py-3 px-4 md:px-6">
                <CardTitle className="text-sm md:text-base flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <ShieldCheck className="h-4 w-4 text-emerald-600" />
                    URLs Públicas de Sincronização Dinâmica (Meta / Google)
                  </span>
                  <Badge variant="outline" className="bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border-emerald-500/30 text-xs">
                    Sincronização Ativa 24h
                  </Badge>
                </CardTitle>
                <CardDescription className="text-xs">
                  Copie uma das URLs abaixo e cole no seu Gerenciador de Comércio da Meta. O catálogo é atualizado automaticamente sempre que preços ou estoques mudarem.
                </CardDescription>
              </CardHeader>
              <CardContent className="p-4 md:p-6 pt-0 space-y-3">
                {/* XML URL */}
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2 p-2.5 rounded-lg border border-border bg-muted/40">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className="text-xs font-semibold text-foreground">Formato XML RSS (Recomendado)</span>
                      <Badge className="text-[10px] px-1 py-0 bg-primary/20 text-primary border-0">Padrão Meta</Badge>
                    </div>
                    <code className="text-[11px] font-mono text-muted-foreground block truncate">
                      {feedXmlUrl}
                    </code>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-8 text-xs gap-1"
                      onClick={() => copyToClipboard(feedXmlUrl, 'xml')}
                    >
                      {copiedUrl === 'xml' ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
                      {copiedUrl === 'xml' ? 'Copiado!' : 'Copiar URL'}
                    </Button>
                    <Button size="sm" variant="ghost" className="h-8 text-xs gap-1" asChild>
                      <a href={feedXmlUrl} target="_blank" rel="noreferrer" title="Abrir XML no navegador">
                        <ExternalLink className="h-3.5 w-3.5" />
                      </a>
                    </Button>
                  </div>
                </div>

                {/* CSV URL */}
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2 p-2.5 rounded-lg border border-border bg-muted/40">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className="text-xs font-semibold text-foreground">Formato CSV (Planilha)</span>
                      <Badge variant="outline" className="text-[10px] px-1 py-0">Planilha Online</Badge>
                    </div>
                    <code className="text-[11px] font-mono text-muted-foreground block truncate">
                      {feedCsvUrl}
                    </code>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-8 text-xs gap-1"
                      onClick={() => copyToClipboard(feedCsvUrl, 'csv')}
                    >
                      {copiedUrl === 'csv' ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
                      {copiedUrl === 'csv' ? 'Copiado!' : 'Copiar URL'}
                    </Button>
                    <Button size="sm" variant="ghost" className="h-8 text-xs gap-1" asChild>
                      <a href={feedCsvUrl} target="_blank" rel="noreferrer" title="Abrir CSV no navegador">
                        <ExternalLink className="h-3.5 w-3.5" />
                      </a>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Diagnostic Counters */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <Card>
                <CardHeader className="py-3 px-4">
                  <CardTitle className="text-xs text-muted-foreground font-medium">Produtos no Catálogo</CardTitle>
                  <p className="text-2xl font-bold text-foreground">{totalInFeed}</p>
                  <span className="text-[11px] text-muted-foreground">Itens publicados no site</span>
                </CardHeader>
              </Card>
              <Card>
                <CardHeader className="py-3 px-4">
                  <CardTitle className="text-xs text-muted-foreground font-medium">Aptos para o Meta</CardTitle>
                  <p className="text-2xl font-bold text-emerald-600 dark:text-emerald-400">{readyProducts.length}</p>
                  <span className="text-[11px] text-muted-foreground">Foto, Preço e EAN prontos</span>
                </CardHeader>
              </Card>
              <Card>
                <CardHeader className="py-3 px-4">
                  <CardTitle className="text-xs text-muted-foreground font-medium">Com Pendências</CardTitle>
                  <p className="text-2xl font-bold text-amber-600 dark:text-amber-400">{pendingProducts.length}</p>
                  <span className="text-[11px] text-muted-foreground">Sem imagem ou sem EAN</span>
                </CardHeader>
              </Card>
              <Card>
                <CardHeader className="py-3 px-4">
                  <CardTitle className="text-xs text-muted-foreground font-medium">Disponíveis em Estoque</CardTitle>
                  <p className="text-2xl font-bold text-foreground">{inStockCount}</p>
                  <span className="text-[11px] text-muted-foreground">Status 'in stock'</span>
                </CardHeader>
              </Card>
            </div>

            {/* Filter and products list */}
            <div className="space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2 flex-1 min-w-[200px]">
                  <Input
                    placeholder="Filtrar por nome ou código..."
                    value={search}
                    onChange={e => setSearch(e.target.value)}
                    className="h-8 text-xs max-w-xs"
                  />
                  <Select value={filterStatus} onValueChange={(v: any) => setFilterStatus(v)}>
                    <SelectTrigger className="h-8 text-xs w-40 shrink-0">
                      <SelectValue placeholder="Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos ({products.length})</SelectItem>
                      <SelectItem value="ready">Apenas Aptos ({readyProducts.length})</SelectItem>
                      <SelectItem value="pending">Com Pendências ({pendingProducts.length})</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Button variant="ghost" size="sm" onClick={loadProducts} className="h-8 text-xs gap-1">
                  <RefreshCw className="h-3 w-3" /> Atualizar
                </Button>
              </div>

              {/* Table of items */}
              <div className="rounded-lg border border-border bg-card overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="border-b border-border bg-muted/40 text-muted-foreground">
                        <th className="text-left px-3 py-2 font-medium">Produto</th>
                        <th className="text-left px-3 py-2 font-medium">Categoria</th>
                        <th className="text-left px-3 py-2 font-medium">Cód. Barras (EAN)</th>
                        <th className="text-right px-3 py-2 font-medium">Preço</th>
                        <th className="text-right px-3 py-2 font-medium">Estoque</th>
                        <th className="text-center px-3 py-2 font-medium">Status Meta</th>
                        <th className="text-right px-3 py-2 font-medium">Link</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {loading ? (
                        <tr><td colSpan={7} className="text-center py-6 text-muted-foreground">Carregando catálogo...</td></tr>
                      ) : filteredProducts.length === 0 ? (
                        <tr><td colSpan={7} className="text-center py-6 text-muted-foreground">Nenhum produto encontrado.</td></tr>
                      ) : (
                        filteredProducts.map(p => {
                          const val = validateMetaProduct({
                            title: p.name,
                            image_link: p.images?.[0]?.url,
                            price: `${p.price.toFixed(2)} BRL`,
                            gtin: p.barcode,
                          });
                          return (
                            <tr key={p.id} className="hover:bg-muted/30 transition-colors">
                              <td className="px-3 py-2">
                                <div className="flex items-center gap-2">
                                  <div className="h-7 w-7 rounded bg-muted shrink-0 overflow-hidden flex items-center justify-center border border-border">
                                    {p.images?.[0]?.url ? (
                                      <img src={p.images[0].url} alt={p.name} className="h-full w-full object-cover" />
                                    ) : (
                                      <ImageIcon className="h-3.5 w-3.5 text-muted-foreground/40" />
                                    )}
                                  </div>
                                  <span className="font-medium text-foreground truncate max-w-[180px]" title={p.name}>
                                    {p.name}
                                  </span>
                                </div>
                              </td>
                              <td className="px-3 py-2 text-muted-foreground whitespace-nowrap">
                                <span className="max-w-[100px] truncate block">{p.category_name}</span>
                              </td>
                              <td className="px-3 py-2 font-mono whitespace-nowrap">
                                {p.barcode ? (
                                  <span className="text-foreground">{p.barcode}</span>
                                ) : (
                                  <span className="text-amber-600 text-[10px] font-semibold">Sem EAN</span>
                                )}
                              </td>
                              <td className="px-3 py-2 text-right font-medium whitespace-nowrap">
                                R$ {p.price.toFixed(2)}
                              </td>
                              <td className="px-3 py-2 text-right whitespace-nowrap">
                                <span className={p.stock_quantity <= 0 ? 'text-destructive' : 'text-foreground'}>
                                  {p.stock_quantity} un
                                </span>
                              </td>
                              <td className="px-3 py-2 text-center whitespace-nowrap">
                                {val.isReady ? (
                                  <Badge className="bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border-0 text-[10px] px-1.5 py-0 gap-1">
                                    <CheckCircle2 className="h-2.5 w-2.5" /> Apto Meta
                                  </Badge>
                                ) : (
                                  <Badge variant="outline" className="bg-amber-500/10 text-amber-700 dark:text-amber-400 border-amber-500/30 text-[10px] px-1.5 py-0 gap-1" title={val.issues.join(', ')}>
                                    <AlertTriangle className="h-2.5 w-2.5 text-amber-600" /> {val.issues[0]}
                                  </Badge>
                                )}
                              </td>
                              <td className="px-3 py-2 text-right whitespace-nowrap">
                                <Button variant="ghost" size="icon" className="h-6 w-6" asChild>
                                  <a href={`${origin}/produto/${p.slug || p.id}`} target="_blank" rel="noreferrer" title="Abrir produto na loja">
                                    <ArrowUpRight className="h-3 w-3" />
                                  </a>
                                </Button>
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </TabsContent>

          {/* ──────────────────────────────────────────────────────────────────
              ABA 2: GERADOR DE POSTS E STORIES (INSTAGRAM & FACEBOOK)
             ────────────────────────────────────────────────────────────────── */}
          <TabsContent value="posts" className="space-y-6 mt-4">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              {/* Left Column: Controls */}
              <div className="lg:col-span-5 space-y-4">
                <Card>
                  <CardHeader className="py-3 px-4">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <Sparkles className="h-4 w-4 text-primary" /> Configurar Post Promocional
                    </CardTitle>
                    <CardDescription className="text-xs">
                      Escolha o produto e personalize o criativo para Feed ou Stories.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="p-4 pt-0 space-y-4">
                    {/* Select Product */}
                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-foreground">Selecionar Produto</label>
                      <Select value={selectedProductId} onValueChange={setSelectedProductId}>
                        <SelectTrigger className="h-9 text-xs">
                          <SelectValue placeholder="Selecione um produto..." />
                        </SelectTrigger>
                        <SelectContent className="max-h-60">
                          {products.map(p => (
                            <SelectItem key={p.id} value={p.id} className="text-xs">
                              {p.name} — R$ {p.price.toFixed(2)}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Format and Theme */}
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold text-foreground">Formato</label>
                        <Select value={postFormat} onValueChange={(v: any) => setPostFormat(v)}>
                          <SelectTrigger className="h-8 text-xs">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="feed">Feed (1:1 Quadrado)</SelectItem>
                            <SelectItem value="story">Story/Reels (9:16)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold text-foreground">Estilo Visual</label>
                        <Select value={postTheme} onValueChange={(v: any) => setPostTheme(v)}>
                          <SelectTrigger className="h-8 text-xs">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="verde">Verde Mundo Limpo</SelectItem>
                            <SelectItem value="azul">Azul Profissional</SelectItem>
                            <SelectItem value="laranja">Laranja Destaque</SelectItem>
                            <SelectItem value="dark">Minimalista Dark</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    {/* Tag / Badge text */}
                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-foreground">Etiqueta de Destaque</label>
                      <Input
                        value={postTag}
                        onChange={e => setPostTag(e.target.value)}
                        placeholder="Ex: Oferta Especial, Mais Vendido"
                        className="h-8 text-xs"
                      />
                    </div>

                    {/* Actions */}
                    <div className="pt-2 flex flex-col gap-2">
                      <Button
                        onClick={handleDownloadPostImage}
                        disabled={downloadingImg || !currentProduct}
                        className="w-full gap-2 text-xs h-9 bg-primary text-primary-foreground font-semibold"
                      >
                        <Download className="h-3.5 w-3.5" />
                        {downloadingImg ? 'Gerando imagem...' : `Baixar Criativo para ${postFormat === 'feed' ? 'Feed' : 'Stories'}`}
                      </Button>
                      <Button
                        variant="outline"
                        onClick={handleCopyCaption}
                        className="w-full gap-2 text-xs h-9"
                      >
                        <Copy className="h-3.5 w-3.5" /> Copiar Legenda & Hashtags
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                {/* Caption preview box */}
                <Card>
                  <CardHeader className="py-2.5 px-4 border-b border-border">
                    <CardTitle className="text-xs font-semibold text-muted-foreground uppercase tracking-wider flex items-center justify-between">
                      <span>Texto Sugerido para Post</span>
                      <Button variant="ghost" size="sm" onClick={handleCopyCaption} className="h-6 text-[10px] px-2 gap-1">
                        <Copy className="h-3 w-3" /> Copiar
                      </Button>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-3">
                    <pre className="text-xs font-sans whitespace-pre-wrap text-muted-foreground leading-relaxed max-h-48 overflow-y-auto">
                      {generateSocialCaption()}
                    </pre>
                  </CardContent>
                </Card>
              </div>

              {/* Right Column: Interactive Visual Canvas Preview */}
              <div className="lg:col-span-7 flex flex-col items-center justify-center p-4 bg-muted/30 rounded-xl border border-border">
                <p className="text-xs font-semibold text-muted-foreground mb-3 flex items-center gap-1.5">
                  <Smartphone className="h-3.5 w-3.5" />
                  Pré-visualização do Post ({postFormat === 'feed' ? 'Feed 1:1 - 1080x1080' : 'Stories 9:16 - 1080x1920'})
                </p>

                {/* Canvas Container */}
                <div
                  ref={postCanvasRef}
                  className={`relative overflow-hidden shadow-2xl flex flex-col justify-between transition-all select-none ${
                    postFormat === 'feed'
                      ? 'w-[360px] h-[360px] rounded-xl'
                      : 'w-[280px] h-[497px] rounded-2xl'
                  }`}
                  style={{
                    background:
                      postTheme === 'verde'
                        ? 'linear-gradient(145deg, #04875F 0%, #064E3B 100%)'
                        : postTheme === 'azul'
                        ? 'linear-gradient(145deg, #1E40AF 0%, #0F172A 100%)'
                        : postTheme === 'laranja'
                        ? 'linear-gradient(145deg, #EA580C 0%, #9A3412 100%)'
                        : 'linear-gradient(145deg, #18181B 0%, #09090B 100%)',
                    color: '#FFFFFF',
                  }}
                >
                  {/* Decorative Circles */}
                  <div className="absolute -top-12 -right-12 w-36 h-36 rounded-full bg-white/10 blur-xl pointer-events-none" />
                  <div className="absolute -bottom-12 -left-12 w-36 h-36 rounded-full bg-white/10 blur-xl pointer-events-none" />

                  {/* Header */}
                  <div className="relative z-10 p-4 flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <div className="h-6 w-6 rounded bg-white flex items-center justify-center font-bold text-[10px] text-emerald-800">
                        ML
                      </div>
                      <span className="font-bold text-xs tracking-wide">Mundo Limpo</span>
                    </div>

                    {postTag && (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-400 text-slate-900 shadow-sm uppercase tracking-wider">
                        {postTag}
                      </span>
                    )}
                  </div>

                  {/* Product Image Stage */}
                  <div className="relative z-10 flex-1 flex items-center justify-center px-4">
                    <div className={`rounded-xl bg-white/95 p-3 shadow-lg flex items-center justify-center overflow-hidden border border-white/20 ${
                      postFormat === 'feed' ? 'w-44 h-44' : 'w-48 h-48 my-auto'
                    }`}>
                      {currentProduct?.images?.[0]?.url ? (
                        <img
                          src={currentProduct.images[0].url}
                          alt={currentProduct.name}
                          crossOrigin="anonymous"
                          className="w-full h-full object-contain"
                        />
                      ) : (
                        <div className="flex flex-col items-center justify-center text-slate-400 p-2">
                          <ImageIcon className="h-8 w-8 mb-1" />
                          <span className="text-[10px] text-center font-medium">Foto do Produto</span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Bottom details card */}
                  <div className="relative z-10 p-4 bg-black/30 backdrop-blur-md border-t border-white/10 space-y-1">
                    <p className="font-bold text-sm leading-tight line-clamp-1 drop-shadow-sm text-white">
                      {currentProduct?.name || 'Nome do Produto'}
                    </p>

                    <div className="flex items-baseline justify-between pt-0.5">
                      <div>
                        <span className="text-[9px] text-white/70 block uppercase tracking-wider">Apenas</span>
                        <span className="font-extrabold text-lg text-amber-300 drop-shadow">
                          {currentProduct?.price ? currentProduct.price.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }) : 'R$ 0,00'}
                        </span>
                      </div>

                      <div className="text-right">
                        <span className="text-[9px] px-2 py-1 rounded-full bg-white/20 font-semibold text-white inline-flex items-center gap-1">
                          <MessageCircle className="h-2.5 w-2.5" /> Peça pelo WhatsApp
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>

          {/* ──────────────────────────────────────────────────────────────────
              ABA 3: COMO CONFIGURAR NO META COMMERCE MANAGER
             ────────────────────────────────────────────────────────────────── */}
          <TabsContent value="tutorial" className="space-y-4 mt-4">
            <Card>
              <CardHeader className="py-4 px-6">
                <CardTitle className="text-base flex items-center gap-2">
                  <Instagram className="h-4 w-4 text-primary" /> Passo a Passo: Integrar com Facebook & Instagram Shopping
                </CardTitle>
                <CardDescription className="text-xs">
                  Siga estas etapas para vincular seu catálogo no Gerenciador de Comércio da Meta (Meta Business Suite).
                </CardDescription>
              </CardHeader>
              <CardContent className="px-6 pb-6 space-y-4 text-xs leading-relaxed text-muted-foreground">
                <div className="space-y-3">
                  <div className="flex items-start gap-3 p-3 rounded-lg border border-border bg-card">
                    <span className="h-6 w-6 rounded-full bg-primary/20 text-primary font-bold flex items-center justify-center shrink-0 text-xs">
                      1
                    </span>
                    <div>
                      <p className="font-semibold text-foreground text-sm">Acesse o Gerenciador de Comércio da Meta</p>
                      <p>
                        Entre no <a href="https://business.facebook.com/commerce" target="_blank" rel="noreferrer" className="text-primary hover:underline font-medium inline-flex items-center gap-1">Meta Commerce Manager <ExternalLink className="h-3 w-3" /></a> e selecione seu Catálogo ou Empresa.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3 p-3 rounded-lg border border-border bg-card">
                    <span className="h-6 w-6 rounded-full bg-primary/20 text-primary font-bold flex items-center justify-center shrink-0 text-xs">
                      2
                    </span>
                    <div>
                      <p className="font-semibold text-foreground text-sm">Adicionar Itens via Feed de Dados</p>
                      <p>
                        No menu lateral esquerdo, clique em <strong>Catálogo &gt; Fontes de Dados</strong> e escolha <strong>"Feed de Dados"</strong> (Data Feed).
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3 p-3 rounded-lg border border-border bg-card">
                    <span className="h-6 w-6 rounded-full bg-primary/20 text-primary font-bold flex items-center justify-center shrink-0 text-xs">
                      3
                    </span>
                    <div>
                      <p className="font-semibold text-foreground text-sm">Insira a URL do Feed Programado</p>
                      <p>
                        Selecione a opção <strong>"Feed Programado"</strong> e cole o link do feed XML fornecido na primeira aba:
                      </p>
                      <code className="bg-muted px-2 py-1 rounded text-[11px] font-mono text-foreground block my-1.5 break-all">
                        {feedXmlUrl}
                      </code>
                      <p>
                        Defina a frequência de atualização para <strong>Diária</strong> (ou a cada hora). Assim, todos os preços e estoques do Mundo Limpo sincronizarão automaticamente com seu Instagram e Facebook!
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3 p-3 rounded-lg border border-border bg-card">
                    <span className="h-6 w-6 rounded-full bg-primary/20 text-primary font-bold flex items-center justify-center shrink-0 text-xs">
                      4
                    </span>
                    <div>
                      <p className="font-semibold text-foreground text-sm">Marcar Produtos em Posts e Stories</p>
                      <p>
                        Pronto! Assim que a Meta concluir a leitura dos produtos, você poderá usar a ferramenta de <strong>"Marcar Produtos" (Sacolinha do Instagram)</strong> diretamente nas suas fotos, Reels e Stories.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </PdvLayout>
  );
}
