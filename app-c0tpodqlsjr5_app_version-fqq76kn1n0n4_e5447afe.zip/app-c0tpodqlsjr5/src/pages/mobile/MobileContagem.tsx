import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Html5Qrcode } from 'html5-qrcode';
import { supabase } from '@/db/supabase';
import { MobileLayout } from '@/components/layouts/MobileLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import { Barcode, Minus, Plus, Check, X, Camera, Keyboard, Loader2, ScanBarcode } from 'lucide-react';

interface CountedItem {
  productId: string;
  code: string;
  name: string;
  unit: string;
  count: number;
}

export default function MobileContagem() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<'camera' | 'input'>('input');
  const [items, setItems] = useState<CountedItem[]>([]);
  const [barcodeInput, setBarcodeInput] = useState('');
  const [scanning, setScanning] = useState(false);
  const [saving, setSaving] = useState(false);
  const [lastAdded, setLastAdded] = useState<string | null>(null);
  const scannerRef = useRef<Html5Qrcode | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (mode === 'input') inputRef.current?.focus();
  }, [mode]);

  const startCamera = async () => {
    setScanning(true);
    try {
      const scanner = new Html5Qrcode('contagem-scanner');
      scannerRef.current = scanner;
      await scanner.start(
        { facingMode: 'environment' },
        { fps: 10, qrbox: { width: 250, height: 150 }, aspectRatio: 1.5 },
        async (decodedText) => {
          await addByBarcode(decodedText);
        },
        () => {}
      );
    } catch {
      toast.error('Erro ao acessar câmera.');
      setScanning(false);
    }
  };

  const stopCamera = async () => {
    if (scannerRef.current) {
      try { await scannerRef.current.stop(); await scannerRef.current.clear(); } catch {}
      scannerRef.current = null;
    }
    setScanning(false);
  };

  useEffect(() => { return () => { stopCamera(); }; }, []);

  const addByBarcode = async (code: string) => {
    if (!code.trim()) return;
    const { data } = await supabase
      .from('pdv_products')
      .select('id,code,name,unit,stock_qty')
      .or(`barcode.eq.${code.trim()},code.eq.${code.trim()}`)
      .eq('active', true)
      .limit(1)
      .single();

    if (!data) {
      toast.error(`Produto não encontrado: ${code}`);
      return;
    }

    setItems(prev => {
      const idx = prev.findIndex(i => i.productId === data.id);
      if (idx >= 0) {
        const next = [...prev];
        next[idx] = { ...next[idx], count: next[idx].count + 1 };
        setLastAdded(data.id);
        setTimeout(() => setLastAdded(null), 1500);
        return next;
      }
      setLastAdded(data.id);
      setTimeout(() => setLastAdded(null), 1500);
      return [...prev, { productId: data.id, code: data.code, name: data.name, unit: data.unit || 'UN', count: 1 }];
    });

    toast.success(`${data.name} +1`);
  };

  const adjustCount = (productId: string, delta: number) => {
    setItems(prev => prev.map(i => i.productId === productId ? { ...i, count: Math.max(0, i.count + delta) } : i).filter(i => i.count > 0));
  };

  const setExactCount = (productId: string, val: number) => {
    const n = Math.max(0, Number(val) || 0);
    setItems(prev => prev.map(i => i.productId === productId ? { ...i, count: n } : i).filter(i => i.count > 0));
  };

  const handleApply = async () => {
    if (items.length === 0) { toast.error('Nenhum produto na contagem'); return; }
    setSaving(true);
    let updated = 0;
    for (const item of items) {
      const { error } = await supabase.from('pdv_products').update({
        stock_qty: item.count,
        updated_at: new Date().toISOString(),
      }).eq('id', item.productId);
      if (!error) updated++;
    }
    setSaving(false);
    if (updated === items.length) {
      toast.success(`${updated} produto(s) atualizado(s)!`);
      setItems([]);
    } else {
      toast.warning(`${updated}/${items.length} produto(s) atualizado(s)`);
    }
  };

  const totalItems = items.length;
  const totalUnits = items.reduce((s, i) => s + i.count, 0);

  return (
    <MobileLayout title="Contagem de Estoque" showBack>
      <div className="p-3 space-y-3">
        {/* Summary */}
        <div className="grid grid-cols-2 gap-2">
          <div className="bg-primary/10 rounded-xl p-3 text-center">
            <p className="text-2xl font-bold text-primary">{totalItems}</p>
            <p className="text-[10px] text-muted-foreground">Produtos Contados</p>
          </div>
          <div className="bg-green-50 rounded-xl p-3 text-center">
            <p className="text-2xl font-bold text-green-700">{totalUnits}</p>
            <p className="text-[10px] text-muted-foreground">Unidades Totais</p>
          </div>
        </div>

        {/* Mode toggle */}
        <div className="flex gap-2">
          <Button variant={mode === 'input' ? 'default' : 'outline'} className="flex-1 h-10 gap-1 text-xs" onClick={() => { stopCamera(); setMode('input'); }}>
            <Keyboard className="h-3 w-3" /> Scanner USB
          </Button>
          <Button variant={mode === 'camera' ? 'default' : 'outline'} className="flex-1 h-10 gap-1 text-xs" onClick={() => setMode('camera')}>
            <Camera className="h-3 w-3" /> Câmera
          </Button>
        </div>

        {/* Scanner */}
        {mode === 'camera' && !scanning && (
          <div className="border-2 border-dashed border-border rounded-xl p-6 text-center space-y-2">
            <ScanBarcode className="h-8 w-8 mx-auto text-muted-foreground" />
            <p className="text-xs text-muted-foreground">Ative a câmera para escanear</p>
            <Button size="sm" onClick={startCamera}><Barcode className="h-3 w-3 mr-1" /> Escanear</Button>
          </div>
        )}
        {mode === 'camera' && scanning && (
          <div className="relative">
            <div id="contagem-scanner" className="w-full rounded-xl overflow-hidden" />
            <Button variant="destructive" size="sm" className="absolute top-2 right-2" onClick={stopCamera}><X className="h-3 w-3" /></Button>
          </div>
        )}

        {/* Manual input */}
        {mode === 'input' && (
          <div className="flex gap-2">
            <Input
              ref={inputRef}
              value={barcodeInput}
              onChange={(e) => setBarcodeInput(e.target.value)}
              placeholder="Código de barras..."
              className="h-12 text-base flex-1"
              onKeyDown={(e) => {
                if (e.key === 'Enter') { addByBarcode(barcodeInput); setBarcodeInput(''); inputRef.current?.focus(); }
              }}
            />
            <Button className="h-12 px-4" onClick={() => { addByBarcode(barcodeInput); setBarcodeInput(''); inputRef.current?.focus(); }}>
              <Barcode className="h-4 w-4" />
            </Button>
          </div>
        )}

        {/* Items list */}
        <div className="space-y-2">
          {items.length === 0 && (
            <div className="text-center py-8 text-muted-foreground text-sm">
              <ScanBarcode className="h-8 w-8 mx-auto mb-2 opacity-30" />
              <p>Escaneie produtos para iniciar a contagem</p>
            </div>
          )}
          {items.map((item) => (
            <div
              key={item.productId}
              className={`flex items-center gap-2 p-3 rounded-xl border transition-colors ${
                lastAdded === item.productId ? 'bg-green-50 border-green-200' : 'bg-card'
              }`}
            >
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold truncate">{item.name}</p>
                <p className="text-[10px] text-muted-foreground">{item.code} · {item.unit}</p>
              </div>
              <div className="flex items-center gap-1">
                <button onClick={() => adjustCount(item.productId, -1)} className="h-8 w-8 rounded-full bg-destructive/10 text-destructive flex items-center justify-center">
                  <Minus className="h-3 w-3" />
                </button>
                <Input
                  type="number"
                  min={0}
                  value={item.count}
                  onChange={(e) => setExactCount(item.productId, Number(e.target.value))}
                  className="w-14 h-8 text-center text-sm font-bold p-0"
                />
                <button onClick={() => adjustCount(item.productId, 1)} className="h-8 w-8 rounded-full bg-green-100 text-green-700 flex items-center justify-center">
                  <Plus className="h-3 w-3" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Apply */}
        {items.length > 0 && (
          <div className="sticky bottom-0 bg-background p-2 border-t space-y-2">
            <Button className="w-full h-12 gap-2" onClick={handleApply} disabled={saving}>
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />}
              Aplicar Contagem ({totalItems} produtos)
            </Button>
            <Button variant="outline" className="w-full h-10" onClick={() => setItems([])}>
              Limpar Contagem
            </Button>
          </div>
        )}
      </div>
    </MobileLayout>
  );
}
