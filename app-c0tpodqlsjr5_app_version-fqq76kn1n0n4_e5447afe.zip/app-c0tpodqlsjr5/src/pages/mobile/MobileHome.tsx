import { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/db/supabase';
import { MobileLayout } from '@/components/layouts/MobileLayout';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { Search, Barcode, Package, TrendingUp, DollarSign, ScanLine, Loader2 } from 'lucide-react';

interface Product {
  id: string;
  code: string;
  name: string;
  barcode?: string;
  stock_qty: number;
  sale_price: number;
  cost_price: number;
  unit: string;
  active: boolean;
}

export default function MobileHome() {
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(false);
  const [stats, setStats] = useState({ total: 0, valorEstoque: 0, valorVenda: 0 });
  const inputRef = useRef<HTMLInputElement>(null);

  const fetchStats = useCallback(async () => {
    const { data } = await supabase.from('pdv_products').select('stock_qty,cost_price,sale_price').eq('active', true);
    if (!data) return;
    const total = data.length;
    const valorEstoque = data.reduce((s, p) => s + (Number(p.stock_qty) || 0) * (Number(p.cost_price) || 0), 0);
    const valorVenda = data.reduce((s, p) => s + (Number(p.stock_qty) || 0) * (Number(p.sale_price) || 0), 0);
    setStats({ total, valorEstoque, valorVenda });
  }, []);

  const searchProducts = useCallback(async (q: string) => {
    if (!q.trim()) { setProducts([]); return; }
    setLoading(true);
    const { data } = await supabase
      .from('pdv_products')
      .select('id,code,name,barcode,stock_qty,sale_price,cost_price,unit,active')
      .eq('active', true)
      .or(`name.ilike.%${q}%,code.ilike.%${q}%,barcode.ilike.%${q}%`)
      .order('name', { ascending: true })
      .limit(50);
    setProducts(data || []);
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchStats();
  }, [fetchStats]);

  useEffect(() => {
    const t = setTimeout(() => searchProducts(search), 300);
    return () => clearTimeout(t);
  }, [search, searchProducts]);

  const handleBarcode = (barcode: string) => {
    if (!barcode.trim()) return;
    setSearch(barcode.trim());
    searchProducts(barcode.trim());
    // if only one result, go to product
    supabase.from('pdv_products').select('id').eq('barcode', barcode.trim()).eq('active', true).single().then(({ data }) => {
      if (data?.id) navigate(`/mobile/produto/${data.id}`);
    });
  };

  const formatCurrency = (v: number) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(v);

  return (
    <MobileLayout title="Controle de Estoque" showBack={false}>
      <div className="p-3 space-y-3">
        {/* Stats */}
        <div className="grid grid-cols-3 gap-2">
          <div className="bg-primary/10 rounded-xl p-3 text-center">
            <Package className="h-5 w-5 mx-auto mb-1 text-primary" />
            <p className="text-lg font-bold text-primary">{stats.total}</p>
            <p className="text-[10px] text-muted-foreground">Produtos</p>
          </div>
          <div className="bg-green-50 rounded-xl p-3 text-center">
            <DollarSign className="h-5 w-5 mx-auto mb-1 text-green-600" />
            <p className="text-sm font-bold text-green-700">{formatCurrency(stats.valorEstoque)}</p>
            <p className="text-[10px] text-muted-foreground">Custo</p>
          </div>
          <div className="bg-amber-50 rounded-xl p-3 text-center">
            <TrendingUp className="h-5 w-5 mx-auto mb-1 text-amber-600" />
            <p className="text-sm font-bold text-amber-700">{formatCurrency(stats.valorVenda)}</p>
            <p className="text-[10px] text-muted-foreground">Venda</p>
          </div>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            ref={inputRef}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Buscar produto (nome, código, barcode...)"
            className="pl-9 h-12 text-base"
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                // Barcode scanners often send Enter after input
                handleBarcode(search);
              }
            }}
          />
          <Button
            variant="ghost"
            size="icon"
            className="absolute right-1 top-1/2 -translate-y-1/2"
            onClick={() => navigate('/mobile/scanner')}
          >
            <ScanLine className="h-5 w-5 text-primary" />
          </Button>
        </div>

        {/* Quick actions */}
        <div className="grid grid-cols-2 gap-2">
          <Button variant="outline" className="h-14 flex flex-col gap-1" onClick={() => navigate('/mobile/scanner')}>
            <Barcode className="h-5 w-5" />
            <span className="text-xs">Scanner</span>
          </Button>
          <Button variant="outline" className="h-14 flex flex-col gap-1" onClick={() => navigate('/mobile/contagem')}>
            <TrendingUp className="h-5 w-5" />
            <span className="text-xs">Contagem</span>
          </Button>
        </div>

        {/* Results */}
        <div className="space-y-2">
          {loading && (
            <div className="flex items-center justify-center py-8 gap-2 text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin" />
              <span className="text-sm">Buscando...</span>
            </div>
          )}
          {!loading && products.length === 0 && search && (
            <div className="text-center py-8 text-muted-foreground text-sm">
              <Package className="h-8 w-8 mx-auto mb-2 opacity-30" />
              <p>Nenhum produto encontrado</p>
            </div>
          )}
          {products.map((p) => (
            <button
              key={p.id}
              onClick={() => navigate(`/mobile/produto/${p.id}`)}
              className="w-full flex items-center gap-3 p-3 rounded-xl bg-card border text-left hover:border-primary transition-colors"
            >
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold truncate">{p.name}</p>
                <p className="text-xs text-muted-foreground">{p.code} · Estoque: {p.stock_qty} {p.unit}</p>
              </div>
              <div className="text-right shrink-0">
                <p className="text-sm font-bold">{formatCurrency(p.sale_price)}</p>
                <p className="text-[10px] text-muted-foreground">Custo {formatCurrency(p.cost_price)}</p>
              </div>
            </button>
          ))}
        </div>
      </div>
    </MobileLayout>
  );
}
