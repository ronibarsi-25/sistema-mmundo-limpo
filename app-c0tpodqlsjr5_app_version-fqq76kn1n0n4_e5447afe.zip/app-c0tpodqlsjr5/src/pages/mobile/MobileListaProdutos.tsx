import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/db/supabase';
import { MobileLayout } from '@/components/layouts/MobileLayout';
import { Input } from '@/components/ui/input';
import { Loader2, Search, Package } from 'lucide-react';

interface Product {
  id: string;
  code: string;
  name: string;
  stock_qty: number;
  sale_price: number;
  cost_price: number;
  unit: string;
}

export default function MobileListaProdutos() {
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(false);
  const [page, setPage] = useState(0);
  const [hasMore, setHasMore] = useState(true);

  const fetchProducts = useCallback(async (q: string, p: number) => {
    setLoading(true);
    const pageSize = 30;
    let query = supabase
      .from('pdv_products')
      .select('id,code,name,stock_qty,sale_price,cost_price,unit')
      .eq('active', true)
      .order('name', { ascending: true })
      .range(p * pageSize, (p + 1) * pageSize - 1);

    if (q.trim()) {
      query = query.or(`name.ilike.%${q}%,code.ilike.%${q}%`);
    }

    const { data } = await query;
    const items = data || [];
    setHasMore(items.length === pageSize);
    setProducts(prev => p === 0 ? items : [...prev, ...items]);
    setLoading(false);
  }, []);

  useEffect(() => {
    setPage(0);
    fetchProducts(search, 0);
  }, [search, fetchProducts]);

  const loadMore = () => {
    if (!hasMore || loading) return;
    const next = page + 1;
    setPage(next);
    fetchProducts(search, next);
  };

  const formatCurrency = (v: number) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(v);

  return (
    <MobileLayout title="Produtos" showBack>
      <div className="p-3 space-y-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Buscar produto..."
            className="pl-9 h-12 text-base"
          />
        </div>

        <div className="space-y-2">
          {products.length === 0 && !loading && (
            <div className="text-center py-8 text-muted-foreground text-sm">
              <Package className="h-8 w-8 mx-auto mb-2 opacity-30" />
              <p>Nenhum produto encontrado</p>
            </div>
          )}
          {products.map((p) => (
            <button
              key={p.id}
              onClick={() => navigate(`/mobile/produto/${p.id}`)}
              className="w-full flex items-center gap-3 p-3 rounded-xl bg-card border text-left hover:border-primary transition-colors"
            >
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold truncate">{p.name}</p>
                <p className="text-xs text-muted-foreground">{p.code} · Estoque: {p.stock_qty} {p.unit}</p>
              </div>
              <div className="text-right shrink-0">
                <p className="text-sm font-bold">{formatCurrency(p.sale_price)}</p>
              </div>
            </button>
          ))}
          {hasMore && (
            <button
              onClick={loadMore}
              disabled={loading}
              className="w-full py-3 text-sm text-primary font-medium"
            >
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <Loader2 className="h-4 w-4 animate-spin" /> Carregando...
                </span>
              ) : (
                'Carregar mais'
              )}
            </button>
          )}
        </div>
      </div>
    </MobileLayout>
  );
}
