import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '@/db/supabase';
import { MobileLayout } from '@/components/layouts/MobileLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { Package, Minus, Plus, Save, ArrowLeft, Loader2, Barcode } from 'lucide-react';

interface Product {
  id: string;
  code: string;
  name: string;
  description?: string;
  barcode?: string;
  unit: string;
  cost_price: number;
  sale_price: number;
  stock_qty: number;
}

export default function MobileProdutoDetalhe() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [tab, setTab] = useState<'estoque' | 'preco' | 'info'>('estoque');

  // Local edit state
  const [stockQty, setStockQty] = useState(0);
  const [costPrice, setCostPrice] = useState(0);
  const [salePrice, setSalePrice] = useState(0);
  const [description, setDescription] = useState('');
  const [name, setName] = useState('');

  useEffect(() => {
    if (!id) return;
    supabase.from('pdv_products').select('*').eq('id', id).single().then(({ data, error }) => {
      if (error || !data) { toast.error('Erro ao carregar produto'); navigate('/mobile'); return; }
      const p = data as Product;
      setProduct(p);
      setStockQty(Number(p.stock_qty) || 0);
      setCostPrice(Number(p.cost_price) || 0);
      setSalePrice(Number(p.sale_price) || 0);
      setDescription(p.description || '');
      setName(p.name || '');
      setLoading(false);
    });
  }, [id, navigate]);

  const save = async () => {
    if (!id || !product) return;
    setSaving(true);
    const { error } = await supabase.from('pdv_products').update({
      stock_qty: Math.max(0, stockQty),
      cost_price: Math.max(0, costPrice),
      sale_price: Math.max(0, salePrice),
      description: description.trim() || null,
      name: name.trim() || product.name,
      updated_at: new Date().toISOString(),
    }).eq('id', id);
    if (error) {
      toast.error(`Erro ao salvar: ${error.message}`);
    } else {
      toast.success('Produto atualizado com sucesso!');
      setProduct(p => p ? { ...p, stock_qty: Math.max(0, stockQty), cost_price: costPrice, sale_price: salePrice, description, name } : null);
    }
    setSaving(false);
  };

  const adjustStock = (delta: number) => {
    setStockQty(prev => Math.max(0, prev + delta));
  };

  const formatCurrency = (v: number) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(v);

  if (loading) {
    return (
      <MobileLayout title="Produto" showNav={false}>
        <div className="flex items-center justify-center h-full gap-2 text-muted-foreground">
          <Loader2 className="h-5 w-5 animate-spin" />
          <span>Carregando...</span>
        </div>
      </MobileLayout>
    );
  }

  if (!product) return null;

  return (
    <MobileLayout title="Editar Produto" showBack showNav={false}>
      <div className="p-3 space-y-4">
        {/* Product header */}
        <div className="bg-card border rounded-xl p-4">
          <div className="flex items-center gap-3 mb-2">
            <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <Package className="h-5 w-5 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-sm truncate">{product.name}</p>
              <p className="text-xs text-muted-foreground">{product.code}</p>
            </div>
          </div>
          {product.barcode && (
            <div className="flex items-center gap-1 text-xs text-muted-foreground">
              <Barcode className="h-3 w-3" />
              <span>{product.barcode}</span>
            </div>
          )}
        </div>

        {/* Tabs */}
        <div className="flex gap-1 p-1 bg-muted rounded-lg">
          {(['estoque', 'preco', 'info'] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`flex-1 py-2 text-xs font-semibold rounded-md transition-colors capitalize ${
                tab === t ? 'bg-card shadow-sm text-foreground' : 'text-muted-foreground'
              }`}
            >
              {t === 'estoque' ? 'Estoque' : t === 'preco' ? 'Preços' : 'Informações'}
            </button>
          ))}
        </div>

        {/* Estoque tab */}
        {tab === 'estoque' && (
          <div className="bg-card border rounded-xl p-4 space-y-4">
            <div className="text-center">
              <p className="text-xs text-muted-foreground mb-1">Quantidade em Estoque</p>
              <div className="flex items-center justify-center gap-4">
                <button
                  onClick={() => adjustStock(-1)}
                  className="h-14 w-14 rounded-full bg-destructive/10 text-destructive flex items-center justify-center active:scale-95 transition-transform"
                >
                  <Minus className="h-6 w-6" />
                </button>
                <div className="w-24">
                  <Input
                    type="number"
                    min={0}
                    value={stockQty}
                    onChange={(e) => setStockQty(Math.max(0, Number(e.target.value)))}
                    className="text-center text-2xl font-bold h-14"
                  />
                </div>
                <button
                  onClick={() => adjustStock(1)}
                  className="h-14 w-14 rounded-full bg-green-100 text-green-700 flex items-center justify-center active:scale-95 transition-transform"
                >
                  <Plus className="h-6 w-6" />
                </button>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2 text-center text-sm">
              <div className="bg-muted rounded-lg p-2">
                <p className="text-xs text-muted-foreground">Custo Unit.</p>
                <p className="font-semibold">{formatCurrency(costPrice)}</p>
              </div>
              <div className="bg-muted rounded-lg p-2">
                <p className="text-xs text-muted-foreground">Valor Estoque</p>
                <p className="font-semibold">{formatCurrency(costPrice * stockQty)}</p>
              </div>
            </div>
          </div>
        )}

        {/* Preço tab */}
        {tab === 'preco' && (
          <div className="bg-card border rounded-xl p-4 space-y-4">
            <div>
              <Label className="text-sm font-normal">Preço de Custo</Label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">R$</span>
                <Input
                  type="number"
                  step="0.01"
                  min={0}
                  value={costPrice}
                  onChange={(e) => setCostPrice(Math.max(0, Number(e.target.value)))}
                  className="pl-8 h-12 text-lg"
                />
              </div>
            </div>
            <div>
              <Label className="text-sm font-normal">Preço de Venda</Label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">R$</span>
                <Input
                  type="number"
                  step="0.01"
                  min={0}
                  value={salePrice}
                  onChange={(e) => setSalePrice(Math.max(0, Number(e.target.value)))}
                  className="pl-8 h-12 text-lg"
                />
              </div>
            </div>
            <div className="bg-muted rounded-lg p-3 text-center">
              <p className="text-xs text-muted-foreground">Margem de Lucro</p>
              <p className={`font-semibold ${salePrice > costPrice ? 'text-green-600' : 'text-destructive'}`}>
                {costPrice > 0 ? (((salePrice - costPrice) / costPrice) * 100).toFixed(1) : '0.0'}%
              </p>
            </div>
          </div>
        )}

        {/* Info tab */}
        {tab === 'info' && (
          <div className="bg-card border rounded-xl p-4 space-y-4">
            <div>
              <Label className="text-sm font-normal">Nome</Label>
              <Input value={name} onChange={(e) => setName(e.target.value)} className="h-12" />
            </div>
            <div>
              <Label className="text-sm font-normal">Descrição</Label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={3}
                className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                placeholder="Descrição do produto..."
              />
            </div>
          </div>
        )}

        {/* Save button */}
        <Button
          className="w-full h-14 text-base gap-2 sticky bottom-0"
          onClick={save}
          disabled={saving}
        >
          {saving ? <Loader2 className="h-5 w-5 animate-spin" /> : <Save className="h-5 w-5" />}
          Salvar Alterações
        </Button>
      </div>
    </MobileLayout>
  );
}
