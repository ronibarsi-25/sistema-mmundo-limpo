import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Html5Qrcode, Html5QrcodeScannerState } from 'html5-qrcode';
import { supabase } from '@/db/supabase';
import { MobileLayout } from '@/components/layouts/MobileLayout';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { Barcode, Keyboard, Camera, X, Loader2 } from 'lucide-react';

export default function MobileScanner() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<'camera' | 'input'>('input');
  const [barcodeInput, setBarcodeInput] = useState('');
  const [scanning, setScanning] = useState(false);
  const [found, setFound] = useState<{ id: string; name: string; code: string; stock_qty: number } | null>(null);
  const scannerRef = useRef<Html5Qrcode | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Auto-focus input on mount
  useEffect(() => {
    if (mode === 'input') inputRef.current?.focus();
  }, [mode]);

  const startCamera = async () => {
    if (!containerRef.current) return;
    setScanning(true);
    setFound(null);

    try {
      const scanner = new Html5Qrcode('scanner-camera');
      scannerRef.current = scanner;

      await scanner.start(
        { facingMode: 'environment' },
        { fps: 10, qrbox: { width: 250, height: 150 }, aspectRatio: 1.5 },
        async (decodedText) => {
          // stop scanner after first successful scan
          await stopCamera();
          handleBarcode(decodedText);
        },
        () => { /* ignore decode errors */ }
      );
    } catch (err) {
      toast.error('Erro ao acessar câmera. Verifique as permissões.');
      setScanning(false);
    }
  };

  const stopCamera = async () => {
    if (scannerRef.current) {
      try {
        if (scannerRef.current.getState() === Html5QrcodeScannerState.SCANNING) {
          await scannerRef.current.stop();
        }
        await scannerRef.current.clear();
      } catch { /* ignore */ }
      scannerRef.current = null;
    }
    setScanning(false);
  };

  const handleBarcode = async (code: string) => {
    if (!code.trim()) return;
    setFound(null);
    const { data } = await supabase
      .from('pdv_products')
      .select('id,name,code,stock_qty,barcode')
      .or(`barcode.eq.${code.trim()},code.eq.${code.trim()}`)
      .eq('active', true)
      .limit(1)
      .single();

    if (data) {
      setFound(data);
      toast.success(`Produto encontrado: ${data.name}`);
    } else {
      toast.error('Produto não encontrado. Verifique o código.');
    }
  };

  const goToProduct = () => {
    if (found?.id) navigate(`/mobile/produto/${found.id}`);
  };

  useEffect(() => {
    return () => { stopCamera(); };
  }, []);

  return (
    <MobileLayout title="Scanner" showBack>
      <div className="p-3 space-y-4">
        {/* Mode toggle */}
        <div className="flex gap-2">
          <Button
            variant={mode === 'input' ? 'default' : 'outline'}
            className="flex-1 h-12 gap-2"
            onClick={() => { stopCamera(); setMode('input'); setFound(null); }}
          >
            <Keyboard className="h-4 w-4" />
            <span className="text-sm">Digitar / Scanner USB</span>
          </Button>
          <Button
            variant={mode === 'camera' ? 'default' : 'outline'}
            className="flex-1 h-12 gap-2"
            onClick={() => { setMode('camera'); setFound(null); }}
          >
            <Camera className="h-4 w-4" />
            <span className="text-sm">Câmera</span>
          </Button>
        </div>

        {/* Camera mode */}
        {mode === 'camera' && (
          <div className="space-y-3">
            {!scanning && !found && (
              <div ref={containerRef} className="border-2 border-dashed border-border rounded-xl p-8 text-center space-y-3">
                <Camera className="h-10 w-10 mx-auto text-muted-foreground" />
                <p className="text-sm text-muted-foreground">Ative a câmera para escanear o código de barras</p>
                <Button onClick={startCamera} className="gap-2">
                  <Barcode className="h-4 w-4" /> Escanear
                </Button>
              </div>
            )}
            {scanning && (
              <div className="relative">
                <div id="scanner-camera" className="w-full rounded-xl overflow-hidden" />
                <Button
                  variant="destructive"
                  size="sm"
                  className="absolute top-2 right-2 gap-1"
                  onClick={stopCamera}
                >
                  <X className="h-3 w-3" /> Parar
                </Button>
              </div>
            )}
          </div>
        )}

        {/* Input mode */}
        {mode === 'input' && (
          <div className="space-y-3">
            <div className="relative">
              <Barcode className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                ref={inputRef}
                value={barcodeInput}
                onChange={(e) => setBarcodeInput(e.target.value)}
                placeholder="Digite ou escaneie o código de barras..."
                className="pl-9 h-14 text-lg"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    handleBarcode(barcodeInput);
                    setBarcodeInput('');
                    inputRef.current?.focus();
                  }
                }}
              />
            </div>
            <Button
              className="w-full h-12 gap-2"
              disabled={!barcodeInput.trim()}
              onClick={() => { handleBarcode(barcodeInput); setBarcodeInput(''); inputRef.current?.focus(); }}
            >
              <Loader2 className="h-4 w-4" /> Buscar Produto
            </Button>
          </div>
        )}

        {/* Found product */}
        {found && (
          <div className="bg-card border rounded-xl p-4 space-y-3">
            <div className="flex items-start gap-3">
              <div className="flex-1">
                <p className="font-semibold">{found.name}</p>
                <p className="text-sm text-muted-foreground">Código: {found.code}</p>
                <p className="text-sm text-muted-foreground">Estoque: {found.stock_qty}</p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button className="flex-1" onClick={goToProduct}>
                Ver / Editar Produto
              </Button>
              <Button variant="outline" className="flex-1" onClick={() => { setFound(null); if (mode === 'input') inputRef.current?.focus(); }}>
                Escanear Outro
              </Button>
            </div>
          </div>
        )}
      </div>
    </MobileLayout>
  );
}
