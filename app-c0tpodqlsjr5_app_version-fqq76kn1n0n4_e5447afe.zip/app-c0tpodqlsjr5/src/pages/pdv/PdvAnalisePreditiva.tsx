import { useEffect, useState } from 'react';
import { TrendingUp, BarChart2, Package, AlertTriangle, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend } from 'recharts';
import { PdvLayout } from '@/components/layouts/PdvLayout';
import { supabase } from '@/db/supabase';

interface SalePoint { month: string; receitas: number; despesas: number; }
interface TopProduct { name: string; code: string; total_qty: number; total_revenue: number; }
interface LowStock { id: string; name: string; code: string; stock_qty: number; min_stock: number; }
interface Prediction { month: string; predicted: number; }

function generatePredictions(data: SalePoint[]): Prediction[] {
  if (data.length < 2) return [];
  const values = data.map(d => d.receitas);
  const avg = values.reduce((s, v) => s + v, 0) / values.length;
  const lastVal = values[values.length - 1];
  const trend = values.length > 1 ? (values[values.length - 1] - values[0]) / (values.length - 1) : 0;
  const MONTH_NAMES = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
  const now = new Date();
  return [1, 2, 3].map(offset => {
    const d = new Date(now.getFullYear(), now.getMonth() + offset);
    const predicted = Math.max(0, lastVal + trend * offset * 0.8 + (avg - lastVal) * 0.1 * offset);
    return { month: `${MONTH_NAMES[d.getMonth()]}/${String(d.getFullYear()).slice(-2)}`, predicted: Math.round(predicted * 100) / 100 };
  });
}

export default function PdvAnalisePreditiva() {
  const [salesData, setSalesData] = useState<SalePoint[]>([]);
  const [topProducts, setTopProducts] = useState<TopProduct[]>([]);
  const [lowStock, setLowStock] = useState<LowStock[]>([]);
  const [predictions, setPredictions] = useState<Prediction[]>([]);
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState('6');

  useEffect(() => { loadData(); }, [period]);

  const loadData = async () => {
    setLoading(true);
    const months = parseInt(period);
    const from = new Date();
    from.setMonth(from.getMonth() - months);
    const fromStr = from.toISOString().split('T')[0];

    const [txRes, invRes, lowStockRes] = await Promise.all([
      supabase.from('transactions').select('transaction_date,amount,type').gte('transaction_date', fromStr).order('transaction_date'),
      supabase.from('pdv_invoice_items').select('product_id, quantity, total_price, pdv_products(name,code)').gte('created_at', fromStr + 'T00:00:00'),
      supabase.from('pdv_products').select('id,name,code,stock_qty,min_stock').lt('stock_qty', 10).order('stock_qty').limit(10),
    ]);

    // Build monthly chart
    const monthMap = new Map<string, { receitas: number; despesas: number }>();
    const MONTH_NAMES = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
    for (let i = months - 1; i >= 0; i--) {
      const d = new Date(); d.setMonth(d.getMonth() - i);
      const key = `${MONTH_NAMES[d.getMonth()]}/${String(d.getFullYear()).slice(-2)}`;
      monthMap.set(key, { receitas: 0, despesas: 0 });
    }
    (txRes.data || []).forEach((t: { transaction_date: string; amount: number; type: string }) => {
      const d = new Date(t.transaction_date + 'T00:00:00');
      const key = `${MONTH_NAMES[d.getMonth()]}/${String(d.getFullYear()).slice(-2)}`;
      const entry = monthMap.get(key);
      if (entry) {
        if (t.type === 'receita') entry.receitas += t.amount;
        else entry.despesas += t.amount;
      }
    });
    const chartData = Array.from(monthMap.entries()).map(([month, v]) => ({ month, receitas: Math.round(v.receitas * 100) / 100, despesas: Math.round(v.despesas * 100) / 100 }));
    setSalesData(chartData);
    setPredictions(generatePredictions(chartData));

    // Top products by qty
    const prodMap = new Map<string, { name: string; code: string; total_qty: number; total_revenue: number }>();
    (invRes.data || []).forEach((item: { product_id: string; quantity: number; total_price: number; pdv_products: { name: string; code: string } | { name: string; code: string }[] | null }) => {
      const raw = item.pdv_products;
      const p = Array.isArray(raw) ? raw[0] : raw;
      if (!p) return;
      const key = item.product_id;
      const existing = prodMap.get(key) || { name: p.name, code: p.code, total_qty: 0, total_revenue: 0 };
      existing.total_qty += item.quantity;
      existing.total_revenue += item.total_price;
      prodMap.set(key, existing);
    });
    setTopProducts(Array.from(prodMap.values()).sort((a, b) => b.total_revenue - a.total_revenue).slice(0, 10));
    setLowStock((lowStockRes.data as LowStock[]) || []);
    setLoading(false);
  };

  const totalReceitas = salesData.reduce((s, d) => s + d.receitas, 0);
  const totalDespesas = salesData.reduce((s, d) => s + d.despesas, 0);
  const lucro = totalReceitas - totalDespesas;
  const nextPrediction = predictions[0]?.predicted || 0;

  const chartColors = { receitas: 'hsl(var(--primary))', despesas: 'hsl(var(--destructive))', predicted: 'hsl(var(--warning))' };

  return (
    <PdvLayout title="Análise Preditiva de Vendas" actions={
      <div className="flex gap-3 items-center">
        <Select value={period} onValueChange={setPeriod}>
          <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="3">Últimos 3 meses</SelectItem>
            <SelectItem value="6">Últimos 6 meses</SelectItem>
            <SelectItem value="12">Últimos 12 meses</SelectItem>
          </SelectContent>
        </Select>
        <Button size="sm" variant="outline" onClick={loadData}><RefreshCw className="h-4 w-4 mr-1.5" />Atualizar</Button>
      </div>
    }>
      <div className="space-y-4">
        {/* KPIs */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { label: `Receita (${period}m)`, val: `R$ ${totalReceitas.toFixed(2)}`, cls: 'text-success', icon: TrendingUp },
            { label: `Despesa (${period}m)`, val: `R$ ${totalDespesas.toFixed(2)}`, cls: 'text-destructive', icon: TrendingUp },
            { label: 'Lucro Bruto', val: `R$ ${lucro.toFixed(2)}`, cls: lucro >= 0 ? 'text-primary' : 'text-destructive', icon: BarChart2 },
            { label: 'Prev. próx. mês', val: `R$ ${nextPrediction.toFixed(2)}`, cls: 'text-warning', icon: TrendingUp },
          ].map((k, i) => (
            <div key={i} className="bg-card border border-border rounded-lg p-4">
              <div className="flex items-center gap-2 mb-1"><k.icon className={`h-4 w-4 ${k.cls}`} /><p className="text-xs text-muted-foreground">{k.label}</p></div>
              <p className={`text-base md:text-xl font-bold ${k.cls}`}>{k.val}</p>
            </div>
          ))}
        </div>

        {/* Chart histórico + previsão */}
        <div className="bg-card border border-border rounded-lg p-4">
          <h3 className="font-semibold text-sm mb-4 flex items-center gap-2"><BarChart2 className="h-4 w-4 text-primary" />Histórico de Receitas vs Despesas</h3>
          {loading ? <Skeleton className="h-64 w-full bg-muted" /> : (
            <div className="w-full min-w-0 overflow-hidden">
              <ResponsiveContainer width="100%" height={260}>
                <BarChart data={salesData} margin={{ top: 4, right: 8, left: 8, bottom: 4 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                  <YAxis tick={{ fontSize: 12 }} tickFormatter={v => `R$${(v / 1000).toFixed(0)}k`} />
                  <Tooltip formatter={(v: number) => [`R$ ${v.toFixed(2)}`, '']} />
                  <Legend layout="horizontal" wrapperStyle={{ paddingTop: 8 }} />
                  <Bar dataKey="receitas" name="Receitas" fill={chartColors.receitas} radius={[3, 3, 0, 0]} />
                  <Bar dataKey="despesas" name="Despesas" fill={chartColors.despesas} radius={[3, 3, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>

        {/* Previsão */}
        {predictions.length > 0 && (
          <div className="bg-card border border-border rounded-lg p-4">
            <h3 className="font-semibold text-sm mb-4 flex items-center gap-2"><TrendingUp className="h-4 w-4 text-warning" />Previsão de Receita (próximos 3 meses)</h3>
            <div className="w-full min-w-0 overflow-hidden">
              <ResponsiveContainer width="100%" height={180}>
                <BarChart data={predictions} margin={{ top: 4, right: 8, left: 8, bottom: 4 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                  <YAxis tick={{ fontSize: 12 }} tickFormatter={v => `R$${(v / 1000).toFixed(0)}k`} />
                  <Tooltip formatter={(v: number) => [`R$ ${v.toFixed(2)}`, 'Previsão']} />
                  <Bar dataKey="predicted" name="Previsão" fill={chartColors.predicted} radius={[3, 3, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
            <p className="text-xs text-muted-foreground mt-2 text-pretty">Previsão baseada em tendência histórica linear com suavização exponencial simples.</p>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Top Produtos */}
          <div className="bg-card border border-border rounded-lg overflow-hidden">
            <div className="px-4 py-3 border-b border-border flex items-center gap-2">
              <Package className="h-4 w-4 text-primary" />
              <h3 className="font-semibold text-sm">Top 10 Produtos</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead><tr className="border-b border-border bg-muted/40">
                  <th className="text-left px-4 py-2 font-medium text-muted-foreground whitespace-nowrap">Produto</th>
                  <th className="text-right px-4 py-2 font-medium text-muted-foreground whitespace-nowrap">Qtd</th>
                  <th className="text-right px-4 py-2 font-medium text-muted-foreground whitespace-nowrap">Receita</th>
                </tr></thead>
                <tbody className="divide-y divide-border">
                  {loading ? Array.from({ length: 4 }).map((_, i) => <tr key={i}><td colSpan={3} className="px-4 py-2"><Skeleton className="h-4 w-full bg-muted" /></td></tr>)
                    : topProducts.length === 0 ? <tr><td colSpan={3} className="text-center py-6 text-muted-foreground text-xs">Sem dados de vendas</td></tr>
                    : topProducts.map((p, i) => (
                      <tr key={i} className="hover:bg-muted/30">
                        <td className="px-4 py-2 whitespace-nowrap">
                          <p className="font-medium truncate max-w-[150px]">{p.name}</p>
                          <p className="text-xs text-muted-foreground font-mono">{p.code}</p>
                        </td>
                        <td className="px-4 py-2 text-right whitespace-nowrap">{p.total_qty}</td>
                        <td className="px-4 py-2 text-right font-medium text-success whitespace-nowrap">R$ {p.total_revenue.toFixed(2)}</td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Low Stock Alert */}
          <div className="bg-card border border-border rounded-lg overflow-hidden">
            <div className="px-4 py-3 border-b border-border flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-warning" />
              <h3 className="font-semibold text-sm">Alertas de Estoque Baixo</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead><tr className="border-b border-border bg-muted/40">
                  <th className="text-left px-4 py-2 font-medium text-muted-foreground whitespace-nowrap">Produto</th>
                  <th className="text-right px-4 py-2 font-medium text-muted-foreground whitespace-nowrap">Estoque</th>
                  <th className="text-right px-4 py-2 font-medium text-muted-foreground whitespace-nowrap">Mínimo</th>
                </tr></thead>
                <tbody className="divide-y divide-border">
                  {loading ? Array.from({ length: 4 }).map((_, i) => <tr key={i}><td colSpan={3} className="px-4 py-2"><Skeleton className="h-4 w-full bg-muted" /></td></tr>)
                    : lowStock.length === 0 ? <tr><td colSpan={3} className="text-center py-6 text-success text-xs">Estoque em dia!</td></tr>
                    : lowStock.map(p => (
                      <tr key={p.id} className="hover:bg-muted/30">
                        <td className="px-4 py-2 whitespace-nowrap">
                          <p className="font-medium truncate max-w-[150px]">{p.name}</p>
                          <p className="text-xs text-muted-foreground font-mono">{p.code}</p>
                        </td>
                        <td className={`px-4 py-2 text-right font-bold whitespace-nowrap ${p.stock_qty <= 0 ? 'text-destructive' : 'text-warning'}`}>{p.stock_qty}</td>
                        <td className="px-4 py-2 text-right text-muted-foreground whitespace-nowrap">{p.min_stock || 5}</td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </PdvLayout>
  );
}
