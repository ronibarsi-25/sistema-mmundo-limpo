import { useEffect, useState } from 'react';
import { supabase } from '@/db/supabase';
import { PdvLayout } from '@/components/layouts/PdvLayout';
import { 
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow 
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Shield, Search, FilterX } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

interface AuditLog {
  id: string;
  created_at: string;
  user_id: string;
  module: string;
  action: string;
  description: string | null;
  metadata: any;
  profiles: {
    full_name: string | null;
    email: string | null;
  } | null;
}

export default function PdvAuditoria() {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [moduleFilter, setModuleFilter] = useState<string>('all');

  // Módulos únicos para o filtro
  const [availableModules, setAvailableModules] = useState<string[]>([]);

  useEffect(() => {
    loadLogs();
  }, []);

  const loadLogs = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('audit_logs')
        .select(`
          *,
          profiles:user_id (full_name, email)
        `)
        .order('created_at', { ascending: false })
        .limit(100);

      if (error) throw error;
      
      const logsData = (data || []) as AuditLog[];
      setLogs(logsData);
      
      // Extrair módulos únicos
      const modules = Array.from(new Set(logsData.map(l => l.module))).filter(Boolean).sort();
      setAvailableModules(modules);
    } catch (error) {
      console.error('Erro ao carregar auditoria:', error);
    } finally {
      setLoading(false);
    }
  };

  const getActionColor = (action: string) => {
    const a = action.toLowerCase();
    if (a.includes('create') || a.includes('insert') || a.includes('add') || a.includes('criar')) return 'bg-success';
    if (a.includes('update') || a.includes('edit') || a.includes('editar')) return 'bg-info';
    if (a.includes('delete') || a.includes('remove') || a.includes('excluir')) return 'bg-destructive';
    if (a.includes('login') || a.includes('auth')) return 'bg-accent';
    return 'bg-secondary';
  };

  const filteredLogs = logs.filter(log => {
    const matchesSearch = 
      (log.description?.toLowerCase() || '').includes(searchTerm.toLowerCase()) ||
      (log.action.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (log.profiles?.full_name?.toLowerCase() || '').includes(searchTerm.toLowerCase());
      
    const matchesModule = moduleFilter === 'all' || log.module === moduleFilter;

    return matchesSearch && matchesModule;
  });

  return (
    <PdvLayout title="Auditoria de Sistema">
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h2 className="text-2xl font-bold tracking-tight">Logs de Auditoria</h2>
            <p className="text-muted-foreground text-sm">
              Monitore todas as ações realizadas pelos usuários no sistema.
            </p>
          </div>
        </div>

        <Card>
          <CardHeader className="pb-4">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div className="flex-1 w-full relative max-w-sm">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar ação, descrição ou usuário..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-9"
                />
              </div>
              <div className="flex items-center gap-2 w-full sm:w-auto">
                <Select value={moduleFilter} onValueChange={setModuleFilter}>
                  <SelectTrigger className="w-full sm:w-[180px]">
                    <SelectValue placeholder="Filtrar Módulo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos os Módulos</SelectItem>
                    {availableModules.map(m => (
                      <SelectItem key={m} value={m}>{m}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {(searchTerm || moduleFilter !== 'all') && (
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    onClick={() => { setSearchTerm(''); setModuleFilter('all'); }}
                    title="Limpar Filtros"
                  >
                    <FilterX className="h-4 w-4" />
                  </Button>
                )}
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="rounded-md border overflow-hidden">
              <div className="w-full overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50">
                      <TableHead className="w-[160px] whitespace-nowrap">Data / Hora</TableHead>
                      <TableHead className="whitespace-nowrap">Usuário</TableHead>
                      <TableHead className="whitespace-nowrap">Módulo</TableHead>
                      <TableHead className="whitespace-nowrap">Ação</TableHead>
                      <TableHead className="w-full min-w-[200px]">Descrição</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {loading ? (
                      Array.from({ length: 5 }).map((_, i) => (
                        <TableRow key={i}>
                          <TableCell><Skeleton className="h-4 w-[120px]" /></TableCell>
                          <TableCell><Skeleton className="h-4 w-[150px]" /></TableCell>
                          <TableCell><Skeleton className="h-6 w-[80px]" /></TableCell>
                          <TableCell><Skeleton className="h-6 w-[100px]" /></TableCell>
                          <TableCell><Skeleton className="h-4 w-full" /></TableCell>
                        </TableRow>
                      ))
                    ) : filteredLogs.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={5} className="h-32 text-center">
                          <div className="flex flex-col items-center justify-center text-muted-foreground">
                            <Shield className="h-8 w-8 mb-2 opacity-20" />
                            <p>Nenhum registro de auditoria encontrado</p>
                          </div>
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredLogs.map((log) => (
                        <TableRow key={log.id}>
                          <TableCell className="whitespace-nowrap text-sm text-muted-foreground">
                            {new Date(log.created_at).toLocaleString('pt-BR', {
                              day: '2-digit', month: '2-digit', year: 'numeric',
                              hour: '2-digit', minute: '2-digit', second: '2-digit'
                            })}
                          </TableCell>
                          <TableCell className="whitespace-nowrap">
                            <div className="flex flex-col">
                              <span className="text-sm font-medium">{log.profiles?.full_name || 'Usuário Desconhecido'}</span>
                              {log.profiles?.email && (
                                <span className="text-xs text-muted-foreground">{log.profiles.email}</span>
                              )}
                            </div>
                          </TableCell>
                          <TableCell className="whitespace-nowrap">
                            <Badge variant="outline" className="font-mono text-xs">{log.module}</Badge>
                          </TableCell>
                          <TableCell className="whitespace-nowrap">
                            <Badge className={`${getActionColor(log.action)} text-white border-none shadow-none`}>
                              {log.action}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <span className="text-sm text-muted-foreground break-words line-clamp-2" title={log.description || ''}>
                              {log.description || '-'}
                            </span>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </div>
            
            {!loading && filteredLogs.length > 0 && (
              <div className="mt-4 text-xs text-muted-foreground text-right">
                Mostrando {filteredLogs.length} registros mais recentes
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </PdvLayout>
  );
}