import { useEffect, useState, useCallback } from 'react';
import {
  Search, Users, TrendingUp, ShoppingBag, DollarSign, Clock,
  Star, Phone, Mail, ChevronRight, Plus, Loader2, MessageSquare,
  PhoneCall, Send, MapPin, X, Tag, CalendarDays, BarChart3,
  ArrowUpRight, Cake, StickyNote,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Separator } from '@/components/ui/separator';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { PdvLayout } from '@/components/layouts/PdvLayout';
import { supabase } from '@/db/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

// ─── Tipos ────────────────────────────────────────────────────────────────────
interface CrmCustomer {
  id: string;
  name: string;
  email: string | null;
  phone: string | null;
  cpf_cnpj: string | null;
  birth_date: string | null;
  active: boolean;
  created_at: string;
  total_orders: number;
  total_spent: number;
  last_purchase_at: string | null;
  avg_ticket: number;
  total_notes: number;
}

interface CrmNote {
  id: string;
  customer_id: string;
  author_id: string | null;
  type: string;
  content: string;
  created_at: string;
  profiles?: { full_name: string | null; username: string | null } | null;
}

interface PurchaseHistory {
  id: string;
  number: string;
  issued_at: string;
  total: number;
  payment_method: string;
  status: string;
}

const NOTE_TYPES = [
  { value: 'nota', label: 'Nota Interna', icon: StickyNote },
  { value: 'ligacao', label: 'Ligação', icon: PhoneCall },
  { value: 'email', label: 'E-mail', icon: Send },
  { value: 'visita', label: 'Visita', icon: MapPin },
  { value: 'reclamacao', label: 'Reclamação', icon: MessageSquare },
  { value: 'elogio', label: 'Elogio', icon: Star },
];

const NOTE_COLORS: Record<string, string> = {
  nota: 'bg-muted text-muted-foreground',
  ligacao: 'bg-primary/10 text-primary',
  email: 'bg-secondary/30 text-secondary-foreground',
  visita: 'bg-success/15 text-success',
  reclamacao: 'bg-destructive/15 text-destructive',
  elogio: 'bg-warning/15 text-warning',
};

const PAYMENT_LABELS: Record<string, string> = {
  dinheiro: 'Dinheiro', cartao_debito: 'Débito',
  cartao_credito: 'Crédito', pix: 'PIX', outros: 'Outros',
};

function fmt(v: number) { return v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }); }

function segmentLabel(c: CrmCustomer): { label: string; color: string } {
  if (c.total_spent >= 5000) return { label: 'VIP', color: 'bg-warning/20 text-warning border-warning/30' };
  if (c.total_orders >= 10) return { label: 'Fiel', color: 'bg-primary/15 text-primary border-primary/30' };
  if (c.total_orders >= 3) return { label: 'Recorrente', color: 'bg-success/15 text-success border-success/30' };
  if (c.total_orders >= 1) return { label: 'Ativo', color: 'bg-secondary/40 text-secondary-foreground border-border' };
  return { label: 'Novo', color: 'bg-muted text-muted-foreground border-border' };
}

// ─── Componente principal ─────────────────────────────────────────────────────
export default function PdvCRM() {
  const { profile } = useAuth();
  const [customers, setCustomers] = useState<CrmCustomer[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [segmentFilter, setSegmentFilter] = useState('all');

  // Detalhes do cliente selecionado
  const [selected, setSelected] = useState<CrmCustomer | null>(null);
  const [notes, setNotes] = useState<CrmNote[]>([]);
  const [purchases, setPurchases] = useState<PurchaseHistory[]>([]);
  const [loadingDetail, setLoadingDetail] = useState(false);

  // Nova nota
  const [showNoteDialog, setShowNoteDialog] = useState(false);
  const [noteType, setNoteType] = useState('nota');
  const [noteContent, setNoteContent] = useState('');
  const [savingNote, setSavingNote] = useState(false);

  // ── Métricas gerais ──────────────────────────────────────────────────────────
  const [metrics, setMetrics] = useState({ total: 0, vip: 0, active: 0, newThisMonth: 0 });

  const loadCustomers = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase.from('customer_crm_metrics').select('*').order('total_spent', { ascending: false });
    const list = (data as CrmCustomer[]) || [];
    setCustomers(list);
    const now = new Date();
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();
    setMetrics({
      total: list.length,
      vip: list.filter(c => c.total_spent >= 5000).length,
      active: list.filter(c => c.total_orders > 0).length,
      newThisMonth: list.filter(c => c.created_at >= monthStart).length,
    });
    setLoading(false);
  }, []);

  useEffect(() => { loadCustomers(); }, [loadCustomers]);

  const loadDetail = async (c: CrmCustomer) => {
    setSelected(c);
    setLoadingDetail(true);
    const [notesRes, purchasesRes] = await Promise.all([
      supabase.from('crm_notes')
        .select('*, profiles(full_name, username)')
        .eq('customer_id', c.id)
        .order('created_at', { ascending: false })
        .limit(20),
      supabase.from('pdv_invoices')
        .select('id, number, issued_at, total, payment_method, status')
        .eq('customer_id', c.id)
        .eq('type', 'saida')
        .order('issued_at', { ascending: false })
        .limit(15),
    ]);
    setNotes((notesRes.data as CrmNote[]) || []);
    setPurchases((purchasesRes.data as PurchaseHistory[]) || []);
    setLoadingDetail(false);
  };

  const handleAddNote = async () => {
    if (!selected || !noteContent.trim()) { toast.error('Escreva o conteúdo da nota'); return; }
    setSavingNote(true);
    const { error } = await supabase.from('crm_notes').insert({
      customer_id: selected.id,
      author_id: profile?.id || null,
      type: noteType,
      content: noteContent.trim(),
    });
    setSavingNote(false);
    if (error) { toast.error('Erro ao salvar nota'); return; }
    toast.success('Nota adicionada!');
    setShowNoteDialog(false);
    setNoteContent('');
    setNoteType('nota');
    // Recarrega notas
    const { data } = await supabase.from('crm_notes')
      .select('*, profiles(full_name, username)')
      .eq('customer_id', selected.id)
      .order('created_at', { ascending: false })
      .limit(20);
    setNotes((data as CrmNote[]) || []);
    loadCustomers();
  };

  // ── Filtros ──────────────────────────────────────────────────────────────────
  const filtered = customers.filter(c => {
    const q = search.toLowerCase();
    const matchQ = !q || c.name.toLowerCase().includes(q) || (c.email || '').toLowerCase().includes(q) || (c.phone || '').includes(q) || (c.cpf_cnpj || '').includes(q);
    const seg = segmentLabel(c).label;
    const matchSeg = segmentFilter === 'all' || seg === segmentFilter;
    return matchQ && matchSeg;
  });

  // ── Aniversariantes do mês ───────────────────────────────────────────────────
  const currentMonth = new Date().getMonth() + 1;
  const birthdays = customers.filter(c => {
    if (!c.birth_date) return false;
    return new Date(c.birth_date).getMonth() + 1 === currentMonth;
  });

  return (
    <PdvLayout title="CRM — Gestão de Clientes">
      {/* Métricas */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
        {[
          { label: 'Total de Clientes', value: metrics.total, icon: Users, color: 'text-primary' },
          { label: 'Clientes VIP', value: metrics.vip, icon: Star, color: 'text-warning' },
          { label: 'Já Compraram', value: metrics.active, icon: ShoppingBag, color: 'text-success' },
          { label: 'Novos este Mês', value: metrics.newThisMonth, icon: ArrowUpRight, color: 'text-accent' },
        ].map(m => (
          <div key={m.label} className="bg-card border border-border rounded-lg p-4 flex flex-col gap-1 h-full">
            <div className="flex items-center justify-between">
              <span className="text-xs text-muted-foreground">{m.label}</span>
              <m.icon className={`h-4 w-4 ${m.color}`} />
            </div>
            <span className="text-2xl font-bold text-foreground">{loading ? '—' : m.value}</span>
          </div>
        ))}
      </div>

      {/* Aniversariantes do mês */}
      {birthdays.length > 0 && (
        <div className="mb-5 bg-warning/10 border border-warning/30 rounded-lg px-4 py-3 flex items-start gap-3">
          <Cake className="h-4 w-4 text-warning mt-0.5 shrink-0" />
          <div className="min-w-0">
            <p className="text-sm font-semibold text-warning">🎂 Aniversariantes deste mês ({birthdays.length})</p>
            <p className="text-xs text-muted-foreground mt-0.5 truncate">
              {birthdays.map(c => c.name).join(', ')}
            </p>
          </div>
        </div>
      )}

      {/* Filtros */}
      <div className="flex flex-col md:flex-row gap-3 mb-4">
        <div className="relative flex-1 min-w-0">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Buscar por nome, e-mail, CPF ou telefone..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
        </div>
        <Select value={segmentFilter} onValueChange={setSegmentFilter}>
          <SelectTrigger className="w-full md:w-44 shrink-0"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos segmentos</SelectItem>
            <SelectItem value="VIP">VIP</SelectItem>
            <SelectItem value="Fiel">Fiel</SelectItem>
            <SelectItem value="Recorrente">Recorrente</SelectItem>
            <SelectItem value="Ativo">Ativo</SelectItem>
            <SelectItem value="Novo">Novo</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Tabela */}
      <div className="bg-card border border-border rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/40">
                <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Cliente</th>
                <th className="text-center px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Segmento</th>
                <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Pedidos</th>
                <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Total Gasto</th>
                <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Ticket Médio</th>
                <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Última Compra</th>
                <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Notas</th>
                <th className="px-4 py-3 w-10"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {loading ? (
                Array.from({ length: 6 }).map((_, i) => (
                  <tr key={i}><td colSpan={8} className="px-4 py-3"><Skeleton className="h-5 w-full bg-muted" /></td></tr>
                ))
              ) : filtered.length === 0 ? (
                <tr><td colSpan={8} className="text-center py-12 text-muted-foreground">
                  <Users className="h-8 w-8 mx-auto mb-2 opacity-40" />
                  <p className="text-pretty">Nenhum cliente encontrado</p>
                </td></tr>
              ) : filtered.map(c => {
                const seg = segmentLabel(c);
                return (
                  <tr key={c.id} className="hover:bg-muted/30 transition-colors cursor-pointer" onClick={() => loadDetail(c)}>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <p className="font-medium text-foreground">{c.name}</p>
                      <p className="text-xs text-muted-foreground">{c.email || c.phone || '—'}</p>
                    </td>
                    <td className="px-4 py-3 text-center whitespace-nowrap">
                      <span className={`inline-flex items-center gap-1 text-xs font-medium px-2 py-0.5 rounded-full border ${seg.color}`}>
                        {seg.label === 'VIP' && <Star className="h-2.5 w-2.5" />}
                        {seg.label}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right whitespace-nowrap font-medium">{c.total_orders}</td>
                    <td className="px-4 py-3 text-right whitespace-nowrap font-semibold text-foreground">{fmt(c.total_spent)}</td>
                    <td className="px-4 py-3 text-right whitespace-nowrap text-muted-foreground">{fmt(c.avg_ticket)}</td>
                    <td className="px-4 py-3 text-right whitespace-nowrap text-muted-foreground text-xs">
                      {c.last_purchase_at ? new Date(c.last_purchase_at).toLocaleDateString('pt-BR') : '—'}
                    </td>
                    <td className="px-4 py-3 text-right whitespace-nowrap">
                      {c.total_notes > 0
                        ? <Badge variant="secondary" className="text-xs">{c.total_notes}</Badge>
                        : <span className="text-muted-foreground text-xs">—</span>}
                    </td>
                    <td className="px-4 py-3 text-right">
                      <ChevronRight className="h-4 w-4 text-muted-foreground" />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* ── Sheet de detalhes do cliente ─────────────────────────────────────── */}
      <Sheet open={!!selected} onOpenChange={open => { if (!open) setSelected(null); }}>
        <SheetContent side="right" className="w-full max-w-[calc(100%-2rem)] md:max-w-2xl overflow-y-auto p-0">
          {selected && (
            <div className="flex flex-col h-full">
              {/* Header */}
              <SheetHeader className="px-6 py-5 border-b border-border shrink-0">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <SheetTitle className="text-balance text-lg">{selected.name}</SheetTitle>
                    <div className="flex flex-wrap items-center gap-2 mt-1.5">
                      {(() => { const s = segmentLabel(selected); return <span className={`inline-flex items-center gap-1 text-xs font-medium px-2 py-0.5 rounded-full border ${s.color}`}>{s.label}</span>; })()}
                      {selected.email && (
                        <a href={`mailto:${selected.email}`} className="flex items-center gap-1 text-xs text-muted-foreground hover:text-primary">
                          <Mail className="h-3 w-3" />{selected.email}
                        </a>
                      )}
                      {selected.phone && (
                        <a href={`tel:${selected.phone}`} className="flex items-center gap-1 text-xs text-muted-foreground hover:text-primary">
                          <Phone className="h-3 w-3" />{selected.phone}
                        </a>
                      )}
                      {selected.birth_date && (
                        <span className="flex items-center gap-1 text-xs text-muted-foreground">
                          <Cake className="h-3 w-3" />{new Date(selected.birth_date).toLocaleDateString('pt-BR')}
                        </span>
                      )}
                    </div>
                  </div>
                  <Button
                    size="sm"
                    className="shrink-0"
                    onClick={() => setShowNoteDialog(true)}
                  >
                    <Plus className="h-3.5 w-3.5 mr-1" /> Nova Interação
                  </Button>
                </div>
              </SheetHeader>

              <div className="flex-1 overflow-y-auto px-6 py-5 space-y-6">
                {/* Métricas do cliente */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {[
                    { label: 'Pedidos', value: selected.total_orders, icon: ShoppingBag },
                    { label: 'Total Gasto', value: fmt(selected.total_spent), icon: DollarSign },
                    { label: 'Ticket Médio', value: fmt(selected.avg_ticket), icon: BarChart3 },
                    { label: 'Última Compra', value: selected.last_purchase_at ? new Date(selected.last_purchase_at).toLocaleDateString('pt-BR') : '—', icon: Clock },
                  ].map(m => (
                    <div key={m.label} className="bg-muted/40 border border-border rounded-lg p-3 h-full">
                      <div className="flex items-center gap-1.5 mb-1">
                        <m.icon className="h-3.5 w-3.5 text-muted-foreground" />
                        <span className="text-[11px] text-muted-foreground">{m.label}</span>
                      </div>
                      <span className="text-sm font-bold text-foreground">{m.value}</span>
                    </div>
                  ))}
                </div>

                {loadingDetail ? (
                  <div className="space-y-3">
                    <Skeleton className="h-24 w-full bg-muted" />
                    <Skeleton className="h-24 w-full bg-muted" />
                  </div>
                ) : (
                  <>
                    {/* Histórico de interações */}
                    <div>
                      <div className="flex items-center justify-between mb-3">
                        <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
                          <Tag className="h-4 w-4 text-primary" /> Interações ({notes.length})
                        </h3>
                      </div>
                      {notes.length === 0 ? (
                        <div className="text-center py-8 text-muted-foreground bg-muted/20 rounded-lg border border-dashed border-border">
                          <StickyNote className="h-6 w-6 mx-auto mb-1.5 opacity-40" />
                          <p className="text-xs text-pretty">Nenhuma interação registrada</p>
                          <Button size="sm" variant="ghost" className="mt-2 text-xs" onClick={() => setShowNoteDialog(true)}>
                            Registrar primeira interação
                          </Button>
                        </div>
                      ) : (
                        <div className="space-y-2">
                          {notes.map(n => {
                            const typeInfo = NOTE_TYPES.find(t => t.value === n.type);
                            const NoteIcon = typeInfo?.icon || StickyNote;
                            return (
                              <div key={n.id} className="bg-card border border-border rounded-lg px-4 py-3 space-y-1.5">
                                <div className="flex items-center justify-between flex-wrap gap-2">
                                  <span className={`inline-flex items-center gap-1 text-[11px] font-medium px-2 py-0.5 rounded-full ${NOTE_COLORS[n.type] || 'bg-muted text-muted-foreground'}`}>
                                    <NoteIcon className="h-2.5 w-2.5" />
                                    {typeInfo?.label || n.type}
                                  </span>
                                  <span className="text-[11px] text-muted-foreground">
                                    {new Date(n.created_at).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: '2-digit', hour: '2-digit', minute: '2-digit' })}
                                    {n.profiles && ` · ${n.profiles.full_name || n.profiles.username}`}
                                  </span>
                                </div>
                                <p className="text-sm text-foreground text-pretty">{n.content}</p>
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>

                    <Separator />

                    {/* Histórico de compras */}
                    <div>
                      <h3 className="text-sm font-semibold text-foreground flex items-center gap-2 mb-3">
                        <CalendarDays className="h-4 w-4 text-primary" /> Histórico de Compras ({purchases.length})
                      </h3>
                      {purchases.length === 0 ? (
                        <div className="text-center py-8 text-muted-foreground bg-muted/20 rounded-lg border border-dashed border-border">
                          <ShoppingBag className="h-6 w-6 mx-auto mb-1.5 opacity-40" />
                          <p className="text-xs">Nenhuma compra registrada</p>
                        </div>
                      ) : (
                        <div className="overflow-x-auto">
                          <table className="w-full text-xs">
                            <thead>
                              <tr className="border-b border-border">
                                <th className="text-left py-2 text-muted-foreground font-medium whitespace-nowrap">Nº</th>
                                <th className="text-left py-2 text-muted-foreground font-medium whitespace-nowrap">Data</th>
                                <th className="text-left py-2 text-muted-foreground font-medium whitespace-nowrap">Pagamento</th>
                                <th className="text-right py-2 text-muted-foreground font-medium whitespace-nowrap">Total</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-border">
                              {purchases.map(p => (
                                <tr key={p.id}>
                                  <td className="py-2 font-mono whitespace-nowrap">{p.number}</td>
                                  <td className="py-2 whitespace-nowrap">{new Date(p.issued_at).toLocaleDateString('pt-BR')}</td>
                                  <td className="py-2 whitespace-nowrap">{PAYMENT_LABELS[p.payment_method] || p.payment_method}</td>
                                  <td className="py-2 text-right font-semibold whitespace-nowrap">{fmt(p.total)}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      )}
                    </div>

                    {/* Tendência visual simples */}
                    {purchases.length >= 2 && (
                      <>
                        <Separator />
                        <div>
                          <h3 className="text-sm font-semibold text-foreground flex items-center gap-2 mb-3">
                            <TrendingUp className="h-4 w-4 text-primary" /> Tendência de Gastos
                          </h3>
                          <div className="flex items-end gap-1 h-16">
                            {purchases.slice().reverse().slice(-10).map((p, i) => {
                              const maxVal = Math.max(...purchases.map(x => x.total));
                              const pct = maxVal > 0 ? (p.total / maxVal) * 100 : 0;
                              return (
                                <div key={p.id} className="flex-1 min-w-0 flex flex-col items-center gap-1 group relative">
                                  <div
                                    className="w-full rounded-t bg-primary/70 hover:bg-primary transition-all"
                                    style={{ height: `${Math.max(pct, 4)}%` }}
                                    title={`${fmt(p.total)} — ${new Date(p.issued_at).toLocaleDateString('pt-BR')}`}
                                  />
                                </div>
                              );
                            })}
                          </div>
                          <p className="text-[11px] text-muted-foreground mt-1">Últimas {Math.min(purchases.length, 10)} compras</p>
                        </div>
                      </>
                    )}
                  </>
                )}
              </div>
            </div>
          )}
        </SheetContent>
      </Sheet>

      {/* Dialog nova interação */}
      <Dialog open={showNoteDialog} onOpenChange={setShowNoteDialog}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-balance flex items-center gap-2">
              <MessageSquare className="h-4 w-4 text-primary" />
              Nova Interação — {selected?.name}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-1">
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Tipo</Label>
              <div className="grid grid-cols-3 gap-2">
                {NOTE_TYPES.map(t => (
                  <button
                    key={t.value}
                    onClick={() => setNoteType(t.value)}
                    className={`flex flex-col items-center gap-1 px-2 py-2.5 rounded-lg border text-xs font-medium transition-colors ${noteType === t.value ? 'border-primary bg-primary/10 text-primary' : 'border-border text-muted-foreground hover:bg-muted/50'}`}
                  >
                    <t.icon className="h-4 w-4" />
                    {t.label}
                  </button>
                ))}
              </div>
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Observações</Label>
              <Textarea
                value={noteContent}
                onChange={e => setNoteContent(e.target.value)}
                placeholder="Descreva a interação com o cliente..."
                rows={4}
                autoFocus
              />
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setShowNoteDialog(false)}>Cancelar</Button>
            <Button onClick={handleAddNote} disabled={savingNote || !noteContent.trim()}>
              {savingNote && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Salvar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PdvLayout>
  );
}
