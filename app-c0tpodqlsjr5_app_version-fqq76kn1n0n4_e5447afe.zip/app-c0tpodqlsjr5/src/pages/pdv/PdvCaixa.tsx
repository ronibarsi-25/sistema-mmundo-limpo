import React, { useEffect, useRef, useState, useCallback } from 'react';
import { Link } from 'react-router-dom';
import {
  Plus, Minus, Trash2, Search, User, CreditCard, Banknote, QrCode, Loader2, X, CheckCircle2, Printer,
  Wallet, FileText, Receipt, DollarSign, Smartphone, Ticket, Landmark, SplitSquareHorizontal,
  Camera, Barcode, History, AlertTriangle, Volume2, Sparkles, XCircle, RotateCcw, ScanLine, ShoppingBag
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Skeleton } from '@/components/ui/skeleton';
import { PdvLayout } from '@/components/layouts/PdvLayout';
import { supabase } from '@/db/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import type { PdvProduct, Customer, CashRegister, PaymentMethod, PdvPaymentMethod } from '@/types/types';
import { printCupomFiscal, type CupomData, type CupomItem } from '@/utils/printCupom';
import { soundEffects } from '@/utils/soundEffects';
import { cancelPdvSale } from '@/utils/saleCancellation';
import { generateCancellationReportPdf, type CancelledSaleReportItem } from '@/utils/cancellationReportPdf';
import { metaPixel } from '@/utils/metaPixel';
import { Html5Qrcode } from 'html5-qrcode';

interface CartItem { product: PdvProduct; qty: number; discount: number; }

const PAYMENT_ICON_MAP: Record<string, React.ComponentType<{ className?: string }>> = {
  CreditCard, Banknote, QrCode, Wallet, FileText, Receipt, DollarSign,
  Smartphone, Ticket, Landmark,
};

const STATIC_PAYMENT_LABELS: Record<string, string> = {
  dinheiro: 'Dinheiro',
  cartao_debito: 'Cartão Débito',
  cartao_credito: 'Cartão Crédito',
  pix: 'PIX',
  outros: 'Outros',
  multiplo: 'Pagamento Combinado',
};

export default function PdvCaixa() {
  const { profile } = useAuth();
  const searchRef = useRef<HTMLInputElement>(null);

  const [cashRegister, setCashRegister] = useState<CashRegister | null>(null);
  const [loadingCash, setLoadingCash] = useState(true);
  const [openAmount, setOpenAmount] = useState('');
  const [showOpenDialog, setShowOpenDialog] = useState(false);
  const [showCloseDialog, setShowCloseDialog] = useState(false);
  const [closingAmount, setClosingAmount] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const [cart, setCart] = useState<CartItem[]>([]);
  const [search, setSearch] = useState('');
  const [searchResults, setSearchResults] = useState<PdvProduct[]>([]);
  const [searching, setSearching] = useState(false);
  const [fractionProduct, setFractionProduct] = useState<PdvProduct | null>(null);
  const [fractionQtyInput, setFractionQtyInput] = useState('');
  const [showPrintDialog, setShowPrintDialog] = useState(false);

  const [customer, setCustomer] = useState<Customer | null>(null);
  const [customerSearch, setCustomerSearch] = useState('');
  const [customerResults, setCustomerResults] = useState<Customer[]>([]);
  const [showCustomerPicker, setShowCustomerPicker] = useState(false);
  const [showNewCustomerForm, setShowNewCustomerForm] = useState(false);
  const [newCustomerName, setNewCustomerName] = useState('');
  const [newCustomerPhone, setNewCustomerPhone] = useState('');
  const [newCustomerCpf, setNewCustomerCpf] = useState('');
  const [savingCustomer, setSavingCustomer] = useState(false);
  const [autoPrint, setAutoPrint] = useState(false);

  const [discount, setDiscount] = useState('0');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('dinheiro');
  const [installments, setInstallments] = useState(1);
  const [amountPaid, setAmountPaid] = useState('');
  const [showPayDialog, setShowPayDialog] = useState(false);
  const [saleDone, setSaleDone] = useState(false);
  const [lastCupom, setLastCupom] = useState<CupomData | null>(null);
  const [paymentMethods, setPaymentMethods] = useState<PdvPaymentMethod[]>([]);
  const skipPrintCleanupRef = useRef(false);
  const [showReprintDialog, setShowReprintDialog] = useState(false);
  const [recentSales, setRecentSales] = useState<any[]>([]);
  const [reprintLoading, setReprintLoading] = useState(false);
  const [reprintSearch, setReprintSearch] = useState('');

  // Cancelamento de vendas no PDV
  const [saleToCancel, setSaleToCancel] = useState<any | null>(null);
  const [cancelReason, setCancelReason] = useState('');
  const [cancelling, setCancelling] = useState(false);

  // Scanner de código de barras responsivo & câmera
  const [autoFocusContinuous, setAutoFocusContinuous] = useState(true);
  const [showCameraScanner, setShowCameraScanner] = useState(false);
  const [cameraScanning, setCameraScanning] = useState(false);
  const [continuousScan, setContinuousScan] = useState(true);
  const [cameraFacing, setCameraFacing] = useState<'environment' | 'user'>('environment');
  const [lastScanned, setLastScanned] = useState<{ name: string; price: number; qty: number } | null>(null);
  const [mobileTab, setMobileTab] = useState<'scanner' | 'carrinho'>('scanner');

  const html5QrCodeRef = useRef<Html5Qrcode | null>(null);
  const lastScanTimeRef = useRef<number>(0);
  const lastScanCodeRef = useRef<string>('');

  // Pagamento combinado (múltiplas formas)
  interface SplitEntry { method: PaymentMethod; amount: string; installments: number; }
  const [splitMode, setSplitMode]         = useState(false);
  const [splitPayments, setSplitPayments] = useState<SplitEntry[]>([{ method: 'dinheiro', amount: '', installments: 1 }]);

  useEffect(() => { loadCashRegister(); loadPaymentMethods(); loadPrinterConfig(); }, []);

  // Atalhos de teclado: F1 = finalizar venda, F2 = ciclar forma de pagamento
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'F1') {
        e.preventDefault();
        if (cart.length > 0 && cashRegister && !submitting && !showPayDialog && !showOpenDialog && !showCloseDialog && !showPrintDialog && !fractionProduct) {
          setShowPayDialog(true);
          setInstallments(1); // Resetar parcelas ao abrir
        }
      }
      if (e.key === 'F2') {
        e.preventDefault();
        if (paymentMethods.length > 1) {
          const codes = paymentMethods.map(m => m.code as PaymentMethod);
          const idx = codes.indexOf(paymentMethod);
          const next = codes[(idx + 1) % codes.length];
          setPaymentMethod(next);
        }
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [cart.length, cashRegister, submitting, showPayDialog, showOpenDialog, showCloseDialog, showPrintDialog, fractionProduct, paymentMethods, paymentMethod]);

  const loadPrinterConfig = async () => {
    const { data } = await supabase.from('company').select('auto_print_cupom').limit(1).maybeSingle();
    if (data) setAutoPrint((data as any).auto_print_cupom ?? false);
  };

  const loadPaymentMethods = async () => {
    const { data } = await supabase.from('pdv_payment_methods').select('*').eq('is_active', true).order('name');
    setPaymentMethods(Array.isArray(data) ? data : []);
  };

  const loadCashRegister = async () => {
    setLoadingCash(true);
    const { data } = await supabase.from('cash_registers').select('*').eq('status', 'aberto').order('opened_at', { ascending: false }).limit(1).maybeSingle();
    setCashRegister(data);
    setLoadingCash(false);
    if (!data) setShowOpenDialog(true);
  };

  const handleOpenCash = async () => {
    if (!profile) return;
    setSubmitting(true);
    const { data, error } = await supabase.from('cash_registers').insert({
      operator_id: profile.id,
      opening_amount: parseFloat(openAmount) || 0,
      status: 'aberto',
    }).select().maybeSingle();
    setSubmitting(false);
    if (error) { toast.error('Erro ao abrir caixa'); return; }
    setCashRegister(data);
    setShowOpenDialog(false);
    toast.success('Caixa aberto com sucesso!');
  };

  const handleCloseCash = async () => {
    if (!cashRegister) return;
    setSubmitting(true);
    const closing = parseFloat(closingAmount) || 0;
    // calculate expected = opening + cash sales
    const { data: cashSales } = await supabase.from('pdv_invoices')
      .select('total').eq('cash_register_id', cashRegister.id)
      .eq('type', 'saida').eq('payment_method', 'dinheiro').eq('status', 'emitida');
    const cashTotal = (cashSales || []).reduce((s, v) => s + v.total, 0);
    const expected = cashRegister.opening_amount + cashTotal;
    const diff = closing - expected;
    const { error } = await supabase.from('cash_registers').update({
      closing_amount: closing, expected_amount: expected,
      difference: diff, status: 'fechado', closed_at: new Date().toISOString(),
    }).eq('id', cashRegister.id);
    setSubmitting(false);
    if (error) { toast.error('Erro ao fechar caixa'); return; }
    setCashRegister(null);
    setShowCloseDialog(false);
    toast.success(`Caixa fechado. Diferença: R$ ${diff.toFixed(2)}`);
  };

  const handleSearch = async (q: string) => {
    setSearch(q);
    if (q.trim().length < 1) { setSearchResults([]); return; }
    setSearching(true);
    const { data } = await supabase.from('pdv_products').select('*').eq('active', true)
      .or(`name.ilike.%${q}%,code.ilike.%${q}%,barcode.ilike.%${q}%`).order('name').limit(8);
    const results = (data as PdvProduct[]) || [];
    setSearchResults(results);
    setSearching(false);
  };

  const addToCart = (product: PdvProduct, customQty: number = 1) => {
    if (product.stock_qty <= 0) {
      soundEffects.playError();
      toast.warning('Produto sem estoque!');
      return false;
    }
    // Se for produto de fração, abrir input de quantidade
    if (product.is_fraction) {
      setFractionProduct(product);
      setFractionQtyInput(customQty > 1 ? String(customQty) : '');
      setSearch('');
      setSearchResults([]);
      return true;
    }

    let added = true;
    setCart(prev => {
      const ex = prev.find(i => i.product.id === product.id);
      if (ex) {
        const nextQty = ex.qty + customQty;
        if (nextQty > product.stock_qty) {
          soundEffects.playError();
          toast.warning(`Estoque insuficiente! Disponível: ${product.stock_qty}`);
          added = false;
          return prev;
        }
        return prev.map(i => i.product.id === product.id ? { ...i, qty: nextQty } : i);
      }
      if (customQty > product.stock_qty) {
        soundEffects.playError();
        toast.warning(`Estoque insuficiente! Disponível: ${product.stock_qty}`);
        added = false;
        return prev;
      }
      return [...prev, { product, qty: customQty, discount: 0 }];
    });

    if (added) {
      soundEffects.playSuccess();
      setLastScanned({ name: product.name, price: product.sale_price, qty: customQty });
      toast.success(`${customQty > 1 ? `${customQty}x ` : ''}${product.name} adicionado!`, { duration: 1600 });
      metaPixel.trackAddToCart({
        id: product.id,
        name: product.name,
        price: Number(product.sale_price) || 0,
        quantity: customQty,
      });
    }

    setSearch('');
    setSearchResults([]);
    if (autoFocusContinuous) {
      setTimeout(() => searchRef.current?.focus(), 60);
    }
    return added;
  };

  const handleBarcodeOrSearch = async (inputVal: string) => {
    const trimmed = inputVal.trim();
    if (!trimmed) return;

    // Suporte a multiplicador: ex "3*7891234567890" ou "2*CODIGO"
    let qty = 1;
    let code = trimmed;
    if (trimmed.includes('*')) {
      const parts = trimmed.split('*');
      if (parts.length === 2) {
        const parsed = parseFloat(parts[0].replace(',', '.'));
        if (!isNaN(parsed) && parsed > 0) {
          qty = parsed;
          code = parts[1].trim();
        }
      }
    }

    setSearching(true);
    try {
      // 1. Busca exata por código de barras ou código
      const { data: exactMatch } = await supabase
        .from('pdv_products')
        .select('*')
        .eq('active', true)
        .or(`barcode.eq.${code},code.eq.${code}`)
        .limit(1)
        .maybeSingle();

      if (exactMatch) {
        addToCart(exactMatch as PdvProduct, qty);
        return;
      }

      // 2. Se não achou exato, verificar na lista de busca atual
      if (searchResults.length === 1) {
        addToCart(searchResults[0], qty);
        return;
      }

      if (searchResults.length > 1) {
        addToCart(searchResults[0], qty);
        return;
      }

      // 3. Tenta buscar ilike rápido se for nome parcial ou código digitado
      const { data: fallbackMatch } = await supabase
        .from('pdv_products')
        .select('*')
        .eq('active', true)
        .or(`barcode.ilike.%${code}%,code.ilike.%${code}%,name.ilike.%${code}%`)
        .limit(1)
        .maybeSingle();

      if (fallbackMatch) {
        addToCart(fallbackMatch as PdvProduct, qty);
        return;
      }

      // Não encontrado
      soundEffects.playError();
      toast.error(`Produto com código "${code}" não foi encontrado.`, { duration: 2500 });
    } catch (err) {
      console.error(err);
      soundEffects.playError();
      toast.error('Erro ao consultar produto.');
    } finally {
      setSearching(false);
      if (autoFocusContinuous) {
        setTimeout(() => searchRef.current?.focus(), 60);
      }
    }
  };

  const stopCamera = useCallback(async () => {
    if (html5QrCodeRef.current) {
      try {
        if (html5QrCodeRef.current.isScanning) {
          await html5QrCodeRef.current.stop();
        }
      } catch (e) {
        console.warn(e);
      }
      html5QrCodeRef.current = null;
    }
    setCameraScanning(false);
  }, []);

  const startCamera = useCallback(async (facing: 'environment' | 'user' = cameraFacing) => {
    try {
      if (html5QrCodeRef.current) {
        await stopCamera();
      }
      const scanner = new Html5Qrcode('pdv-camera-reader-viewport');
      html5QrCodeRef.current = scanner;

      await scanner.start(
        { facingMode: facing },
        {
          fps: 15,
          qrbox: { width: 260, height: 160 },
          aspectRatio: 1.33,
        },
        async (decodedText) => {
          const now = Date.now();
          if (decodedText === lastScanCodeRef.current && now - lastScanTimeRef.current < 1800) {
            return;
          }
          lastScanTimeRef.current = now;
          lastScanCodeRef.current = decodedText;

          await handleBarcodeOrSearch(decodedText);

          if (!continuousScan) {
            await stopCamera();
            setShowCameraScanner(false);
          }
        },
        () => {}
      );
      setCameraScanning(true);
    } catch (err) {
      console.error('Erro ao abrir câmera:', err);
      toast.error('Não foi possível inicializar a câmera do dispositivo.');
      setCameraScanning(false);
    }
  }, [cameraFacing, continuousScan, stopCamera]);

  useEffect(() => {
    if (showCameraScanner) {
      const timer = setTimeout(() => {
        startCamera(cameraFacing);
      }, 300);
      return () => {
        clearTimeout(timer);
        stopCamera();
      };
    } else {
      stopCamera();
    }
  }, [showCameraScanner, cameraFacing, startCamera, stopCamera]);

  const handleCancelSaleInPdv = async () => {
    if (!saleToCancel) return;
    if (!cancelReason.trim()) {
      toast.error('Informe a justificativa do cancelamento.');
      return;
    }

    setCancelling(true);
    try {
      const res = await cancelPdvSale(saleToCancel.id, cancelReason.trim(), profile?.id);
      if (!res.success) {
        toast.error(res.error || 'Erro ao cancelar a venda.');
        return;
      }

      toast.success(res.message || 'Venda cancelada e estoque estornado!');
      setSaleToCancel(null);
      setCancelReason('');
      await loadRecentSales();
    } catch (err) {
      console.error(err);
      toast.error('Erro ao processar cancelamento.');
    } finally {
      setCancelling(false);
    }
  };

  const addFractionToCart = () => {
    if (!fractionProduct) return;
    const qty = parseFloat(fractionQtyInput.replace(',', '.'));
    if (!qty || qty <= 0) { toast.error('Informe uma quantidade válida'); return; }
    if (qty > fractionProduct.stock_qty) { toast.warning('Estoque insuficiente!'); return; }
    setCart(prev => {
      const ex = prev.find(i => i.product.id === fractionProduct.id);
      if (ex) {
        const totalQty = ex.qty + qty;
        if (totalQty > fractionProduct.stock_qty) { toast.warning('Estoque insuficiente!'); return prev; }
        return prev.map(i => i.product.id === fractionProduct.id ? { ...i, qty: totalQty } : i);
      }
      return [...prev, { product: fractionProduct, qty, discount: 0 }];
    });
    setFractionProduct(null);
    setFractionQtyInput('');
    searchRef.current?.focus();
  };

  const updateQty = (id: string, delta: number) => {
    setCart(prev => prev.map(i => {
      if (i.product.id !== id) return i;
      const nq = i.qty + delta;
      if (nq <= 0) return i;
      if (nq > i.product.stock_qty) { toast.warning('Estoque insuficiente!'); return i; }
      return { ...i, qty: nq };
    }).filter(i => i.qty > 0));
  };

  const removeFromCart = (id: string) => setCart(prev => prev.filter(i => i.product.id !== id));

  const subtotal = cart.reduce((s, i) => s + ((i.product.sale_price - (i.discount || 0)) * i.qty), 0);
  const discountVal = Math.min(parseFloat(discount) || 0, subtotal);
  const total = subtotal - discountVal;
  const change = Math.max(0, (parseFloat(amountPaid) || 0) - total);

  const handleSearchCustomer = async (q: string) => {
    setCustomerSearch(q);
    if (q.trim().length < 2) { setCustomerResults([]); return; }
    const { data } = await supabase.from('customers').select('*').eq('active', true)
      .or(`name.ilike.%${q}%,cpf_cnpj.ilike.%${q}%,phone.ilike.%${q}%`).limit(5);
    setCustomerResults((data as Customer[]) || []);
  };

  const splitTotal = splitPayments.reduce((s, e) => s + (parseFloat(e.amount) || 0), 0);
  const splitRemaining = Math.max(0, total - splitTotal);

  const addSplitRow = () => {
    const firstMethod = paymentMethods[0]?.code as PaymentMethod || 'dinheiro';
    setSplitPayments(p => [...p, { method: firstMethod, amount: splitRemaining > 0 ? splitRemaining.toFixed(2) : '', installments: 1 }]);
  };
  const removeSplitRow = (idx: number) => setSplitPayments(p => p.filter((_, i) => i !== idx));
  const updateSplit = (idx: number, field: keyof SplitEntry, value: string | number) =>
    setSplitPayments(p => p.map((e, i) => i === idx ? { ...e, [field]: value } : e));

  const finalizeSale = async () => {
    if (!cashRegister || !profile) { toast.error('Caixa não está aberto'); return; }
    if (cart.length === 0) { toast.error('Adicione produtos ao carrinho'); return; }

    // Validação pagamento combinado
    if (splitMode) {
      if (splitPayments.length === 0) { toast.error('Adicione pelo menos uma forma de pagamento'); return; }
      if (Math.abs(splitTotal - total) > 0.01) { toast.error(`Soma dos pagamentos (R$ ${splitTotal.toFixed(2)}) difere do total (R$ ${total.toFixed(2)})`); return; }
    }

    setSubmitting(true);
    try {
      const num = `V${Date.now()}`;
      const primaryMethod = splitMode ? 'multiplo' : paymentMethod;
      const primaryInstallments = splitMode ? 1 : (paymentMethod === 'cartao_credito' ? installments : 1);

      const { data: inv, error: invErr } = await supabase.from('pdv_invoices').insert({
        number: num, type: 'saida', status: 'emitida',
        customer_id: customer?.id || null,
        cash_register_id: cashRegister.id,
        subtotal, discount: discountVal, total,
        payment_method: primaryMethod,
        installments: primaryInstallments,
        created_by: profile.id,
      }).select().maybeSingle();
      if (invErr || !inv) throw invErr || new Error('Erro ao criar nota');

      const items = cart.map(i => ({
        invoice_id: inv.id, product_id: i.product.id,
        quantity: i.qty, unit_price: i.product.sale_price - (i.discount || 0),
        total_price: (i.product.sale_price - (i.discount || 0)) * i.qty,
      }));
      const { error: itemsErr } = await supabase.from('pdv_invoice_items').insert(items);
      if (itemsErr) throw itemsErr;

      // Grava transações — uma por forma de pagamento (ou única se não for combinado)
      const entries = splitMode
        ? splitPayments.map(e => ({
            type: 'receita', category: 'Venda', description: `Venda ${num}`,
            amount: parseFloat(e.amount) || 0,
            payment_method: e.method,
            installments: e.method === 'cartao_credito' ? e.installments : 1,
            invoice_id: inv.id,
            transaction_date: new Date().toISOString().split('T')[0],
            created_by: profile.id,
          }))
        : [{
            type: 'receita', category: 'Venda', description: `Venda ${num}`,
            amount: total, payment_method: paymentMethod,
            installments: paymentMethod === 'cartao_credito' ? installments : 1,
            invoice_id: inv.id,
            transaction_date: new Date().toISOString().split('T')[0],
            created_by: profile.id,
          }];
      await supabase.from('transactions').insert(entries);

      const { data: company } = await supabase.from('company').select('*').limit(1).maybeSingle();

      // Rótulo das formas no cupom
      const payLabel = splitMode
        ? splitPayments.map(e => {
            const name = paymentMethods.find(m => m.code === e.method)?.name || STATIC_PAYMENT_LABELS[e.method] || e.method;
            return `${name}: R$ ${parseFloat(e.amount).toFixed(2)}`;
          }).join(' + ')
        : (paymentMethods.find(m => m.code === paymentMethod)?.name || STATIC_PAYMENT_LABELS[paymentMethod] || paymentMethod);

      const totalAmountPaid = splitMode ? splitTotal : (parseFloat(amountPaid) || 0);
      const totalChange     = splitMode ? 0 : change;

      const cupom: CupomData = {
        number: num,
        issued_at: new Date().toISOString(),
        store_name: company?.nome_fantasia || company?.razao_social || 'Loja',
        cnpj: company?.cnpj,
        logradouro: company?.logradouro,
        numero: company?.numero,
        bairro: company?.bairro,
        cidade: company?.cidade,
        estado: company?.estado,
        telefone: company?.telefone,
        items: cart.map(i => ({
          name: i.product.name,
          qty: i.qty,
          unit: i.product.unit,
          unit_price: i.product.sale_price - (i.discount || 0),
          total_price: (i.product.sale_price - (i.discount || 0)) * i.qty,
          discount: i.discount || 0,
        })),
        subtotal, discount: discountVal, total,
        payment_method: payLabel,
        amount_paid: totalAmountPaid,
        change: totalChange,
        customer_name: customer?.name,
        operator_name: profile.full_name || profile.username || undefined,
      };

      setSubmitting(false);
      setLastCupom(cupom);
      setShowPayDialog(false);
      toast.success(`Venda ${num} finalizada! Total: R$ ${total.toFixed(2)}`);

      // Disparar evento Purchase no Meta Pixel
      metaPixel.trackPurchase({
        orderId: num,
        totalValue: total,
        itemsCount: cart.reduce((acc, it) => acc + it.qty, 0),
        items: cart.map(i => ({ id: i.product.id, quantity: i.qty })),
      });

      if (autoPrint && cupom) {
        printCupomFiscal(cupom);
        clearAfterSale();
      } else {
        skipPrintCleanupRef.current = false;
        setShowPrintDialog(true);
      }
    } catch (err: any) {
      console.error('finalizeSale error:', err);
      const msg = err?.message || err?.details || 'Erro ao finalizar venda';
      toast.error(msg);
      setSubmitting(false);
    }
  };

  const handlePrintCupom = () => {
    if (lastCupom) printCupomFiscal(lastCupom);
    skipPrintCleanupRef.current = true;
    clearAfterSale();
  };

  const handleSkipPrint = () => {
    skipPrintCleanupRef.current = true;
    clearAfterSale();
  };

  const clearAfterSale = () => {
    setCart([]); setDiscount('0'); setAmountPaid(''); setCustomer(null); setInstallments(1);
    setSplitMode(false); setSplitPayments([{ method: 'dinheiro', amount: '', installments: 1 }]);
    setShowPrintDialog(false);
    setSaleDone(true);
    setTimeout(() => setSaleDone(false), 6000);
  };

  const loadRecentSales = async () => {
    if (!cashRegister) return;
    setReprintLoading(true);
    const { data } = await supabase
      .from('pdv_invoices')
      .select('id, number, status, total, payment_method, notes, cancellation_reason, created_at, customers(name)')
      .eq('cash_register_id', cashRegister.id)
      .order('created_at', { ascending: false })
      .limit(50);
    setRecentSales(data || []);
    setReprintLoading(false);
  };

  const handleReprintSale = async (invoiceId: string, invoiceNumber: string) => {
    setReprintLoading(true);
    try {
      const { data: inv } = await supabase
        .from('pdv_invoices')
        .select('*, customers(name), pdv_invoice_items(*, pdv_products(name, unit))')
        .eq('id', invoiceId)
        .maybeSingle();
      if (!inv) { toast.error('Venda não encontrada'); return; }

      const { data: company } = await supabase.from('company').select('*').limit(1).maybeSingle();

      const items: CupomItem[] = (inv.pdv_invoice_items || []).map((it: any) => ({
        name: it.pdv_products?.name || 'Item',
        qty: it.quantity,
        unit: it.pdv_products?.unit || 'un',
        unit_price: it.unit_price,
        total_price: it.total_price,
      }));

      const cupom: CupomData = {
        number: inv.number,
        issued_at: inv.created_at,
        store_name: company?.nome_fantasia || company?.razao_social || 'Loja',
        cnpj: company?.cnpj,
        logradouro: company?.logradouro,
        numero: company?.numero,
        bairro: company?.bairro,
        cidade: company?.cidade,
        estado: company?.estado,
        telefone: company?.telefone,
        items,
        subtotal: inv.subtotal || 0,
        discount: inv.discount || 0,
        total: inv.total || 0,
        payment_method: inv.payment_method || 'outros',
        amount_paid: inv.total || 0,
        change: 0,
        customer_name: inv.customers?.name,
        operator_name: profile?.full_name || profile?.username || undefined,
      };

      printCupomFiscal(cupom);
      toast.success(`Cupom ${invoiceNumber} reimpresso`);
    } catch (err) {
      console.error(err);
      toast.error('Erro ao reimprimir cupom');
    } finally {
      setReprintLoading(false);
    }
  };

  if (loadingCash) {
    return (
      <PdvLayout title="Caixa">
        <div className="space-y-4"><Skeleton className="h-20 w-full bg-muted" /><Skeleton className="h-64 w-full bg-muted" /></div>
      </PdvLayout>
    );
  }

  return (
    <PdvLayout title="Caixa">
      {/* Header status */}
      {cashRegister ? (
        <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <div className="h-2.5 w-2.5 rounded-full bg-success animate-pulse" />
            <span className="text-sm font-medium text-foreground">Caixa Aberto</span>
            <span className="text-xs text-muted-foreground">desde {new Date(cashRegister.opened_at).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</span>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <Button variant="outline" size="sm" asChild className="gap-1.5">
              <Link to="/pdv/vendas">
                <History className="h-4 w-4 text-primary" />
                <span className="hidden sm:inline">Vendas &</span> Cancelamentos
              </Link>
            </Button>
            <Button variant="outline" size="sm" onClick={() => { loadRecentSales(); setShowReprintDialog(true); }} className="gap-1.5">
              <Receipt className="h-4 w-4" /> Reimprimir
            </Button>
            <Button variant="outline" size="sm" onClick={() => setShowCloseDialog(true)} className="text-destructive border-destructive/40 hover:bg-destructive/10">
              Fechar Caixa
            </Button>
          </div>
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-20 gap-4">
          <CreditCard className="h-12 w-12 text-muted-foreground" />
          <p className="text-muted-foreground text-pretty text-center">Nenhum caixa aberto. Abra o caixa para iniciar as vendas.</p>
          <Button onClick={() => setShowOpenDialog(true)}>Abrir Caixa</Button>
        </div>
      )}

      {cashRegister && (
        <div className="space-y-3">
          {/* Alternador de visualização exclusivo para Mobile */}
          <div className="flex md:hidden border border-border rounded-lg p-1 bg-muted/40">
            <button
              type="button"
              onClick={() => setMobileTab('scanner')}
              className={`flex-1 py-2 text-xs font-semibold rounded-md flex items-center justify-center gap-1.5 transition-colors ${
                mobileTab === 'scanner' ? 'bg-background shadow-sm text-foreground' : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              <Barcode className="h-4 w-4 text-primary" />
              <span>Scanner & Produtos</span>
            </button>
            <button
              type="button"
              onClick={() => setMobileTab('carrinho')}
              className={`flex-1 py-2 text-xs font-semibold rounded-md flex items-center justify-center gap-1.5 transition-colors ${
                mobileTab === 'carrinho' ? 'bg-background shadow-sm text-foreground' : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              <ShoppingBag className="h-4 w-4 text-primary" />
              <span>Carrinho ({cart.length}) · R$ {total.toFixed(2)}</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            {/* Coluna 1: Leitor de código de barras e lista de produtos/carrinho — 3 cols */}
            <div className={`md:col-span-3 space-y-3 ${mobileTab === 'carrinho' ? 'hidden md:block' : 'block'}`}>
              {/* Barra de Leitura / Busca de Produtos */}
              <div className="bg-card border border-border rounded-xl p-3 md:p-4 shadow-sm space-y-2.5">
                <div className="flex items-center gap-2">
                  <div className="relative flex-1">
                    <div className="absolute left-3 top-1/2 -translate-y-1/2 flex items-center gap-1 text-muted-foreground pointer-events-none">
                      <Barcode className="h-5 w-5 text-primary" />
                    </div>
                    <Input
                      ref={searchRef}
                      placeholder="Código de barras, código ou nome (ex: 3*código)..."
                      value={search}
                      onChange={e => handleSearch(e.target.value)}
                      onKeyDown={async e => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          await handleBarcodeOrSearch(search);
                        }
                      }}
                      className="pl-10 pr-9 h-11 md:h-12 text-sm md:text-base border-border focus-visible:ring-primary shadow-sm"
                      autoFocus
                    />
                    {search ? (
                      <button
                        type="button"
                        onClick={() => { setSearch(''); setSearchResults([]); searchRef.current?.focus(); }}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                        title="Limpar busca"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    ) : searching ? (
                      <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 animate-spin text-muted-foreground" />
                    ) : null}
                  </div>

                  {/* Botão de Câmera Scanner */}
                  <Button
                    type="button"
                    variant="default"
                    onClick={() => setShowCameraScanner(true)}
                    className="h-11 md:h-12 px-3 md:px-4 gap-1.5 shrink-0 bg-primary text-primary-foreground shadow-sm hover:bg-primary/90"
                    title="Abrir scanner com a câmera do celular/tablet"
                  >
                    <Camera className="h-4 w-4" />
                    <span className="hidden sm:inline text-xs font-semibold">Câmera</span>
                  </Button>
                </div>

                {/* Barra de utilitários: foco contínuo e dica rápida */}
                <div className="flex items-center justify-between text-xs text-muted-foreground flex-wrap gap-2 px-0.5">
                  <div className="flex items-center gap-2">
                    <Switch
                      id="auto-focus-switch"
                      checked={autoFocusContinuous}
                      onCheckedChange={setAutoFocusContinuous}
                    />
                    <Label htmlFor="auto-focus-switch" className="cursor-pointer text-xs font-normal text-muted-foreground flex items-center gap-1">
                      <ScanLine className="h-3.5 w-3.5 text-primary" /> Foco Contínuo (Leitor USB / Bluetooth)
                    </Label>
                  </div>
                  <span className="text-[11px] text-muted-foreground hidden sm:inline">
                    Multiplicador: digite <strong className="font-mono text-foreground">3*código</strong> e tecle Enter
                  </span>
                </div>

                {/* Badge visual do último produto lido */}
                {lastScanned && (
                  <div className="flex items-center justify-between px-3 py-1.5 bg-success/15 border border-success/30 rounded-md text-xs text-success animate-in fade-in">
                    <span className="font-semibold flex items-center gap-1.5">
                      <CheckCircle2 className="h-3.5 w-3.5" />
                      Último item lido: {lastScanned.qty > 1 ? `${lastScanned.qty}x ` : ''}{lastScanned.name}
                    </span>
                    <span className="font-bold">R$ {(lastScanned.price * lastScanned.qty).toFixed(2)}</span>
                  </div>
                )}
              </div>
            {searchResults.length > 0 && (
              <div className="bg-card border border-border rounded-lg overflow-hidden shadow-md">
                {searchResults.map(p => (
                  <button
                    key={p.id}
                    onClick={() => addToCart(p)}
                    className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-muted/60 transition-colors border-b border-border last:border-0 text-left"
                  >
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5">
                        <p className="text-sm font-medium text-foreground truncate">{p.name}</p>
                        {p.is_fraction && <span className="text-[10px] bg-amber-100 text-amber-800 px-1.5 py-0.5 rounded">Fração</span>}
                      </div>
                      <p className="text-xs text-muted-foreground">{p.code} · {p.stock_qty} {p.is_fraction ? p.fraction_unit : p.unit} em estoque</p>
                    </div>
                    <p className="text-sm font-bold text-primary shrink-0">R$ {p.sale_price.toFixed(2)}</p>
                  </button>
                ))}
              </div>
            )}

            {/* Cart items */}
            <div className="bg-card border border-border rounded-lg overflow-hidden">
              <div className="px-4 py-2.5 border-b border-border bg-muted/40">
                <p className="text-sm font-semibold text-foreground">Carrinho ({cart.length} {cart.length === 1 ? 'item' : 'itens'})</p>
              </div>
              {cart.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                  <ShoppingCartIcon className="h-8 w-8 mb-2 opacity-40" />
                  <p className="text-sm text-pretty">Adicione produtos ao carrinho</p>
                </div>
              ) : (
                <div className="divide-y divide-border">
                  {cart.map(item => (
                    <div key={item.product.id} className="flex items-start gap-3 px-4 py-3">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5">
                          <p className="text-sm font-medium text-foreground truncate">{item.product.name}</p>
                          {item.product.is_fraction && <span className="text-[10px] bg-amber-100 text-amber-800 px-1.5 py-0.5 rounded">{item.product.fraction_unit}</span>}
                        </div>
                        <p className="text-xs text-muted-foreground">R$ {item.product.sale_price.toFixed(2)} / {item.product.is_fraction ? item.product.fraction_unit : item.product.unit}</p>
                        {/* Desconto por item */}
                        <div className="flex items-center gap-1.5 mt-1">
                          <span className="text-[10px] text-muted-foreground">Desc. R$</span>
                          <input
                            type="number"
                            min="0"
                            step="0.01"
                            max={item.product.sale_price}
                            value={item.discount || 0}
                            onChange={e => {
                              const val = Math.min(parseFloat(e.target.value) || 0, item.product.sale_price);
                              setCart(prev => prev.map(i => i.product.id === item.product.id ? { ...i, discount: val } : i));
                            }}
                            className="w-16 h-5 text-xs text-right border rounded px-1 bg-background"
                          />
                          {(item.discount || 0) > 0 && (
                            <span className="text-[10px] text-destructive font-medium">-R$ {((item.discount || 0) * item.qty).toFixed(2)}</span>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-1 shrink-0">
                        {!item.product.is_fraction ? (
                          <>
                            <Button variant="outline" size="icon" className="h-7 w-7" onClick={() => updateQty(item.product.id, -1)}>
                              <Minus className="h-3 w-3" />
                            </Button>
                            <span className="w-8 text-center text-sm font-medium">{item.qty}</span>
                            <Button variant="outline" size="icon" className="h-7 w-7" onClick={() => updateQty(item.product.id, 1)}>
                              <Plus className="h-3 w-3" />
                            </Button>
                          </>
                        ) : (
                          <div className="flex items-center gap-1">
                            <input
                              type="number"
                              step="0.001"
                              min="0.001"
                              value={item.qty}
                              onChange={(e) => {
                                const val = parseFloat(e.target.value);
                                if (val > 0 && val <= item.product.stock_qty) {
                                  setCart(prev => prev.map(i => i.product.id === item.product.id ? { ...i, qty: val } : i));
                                }
                              }}
                              className="w-20 h-7 text-center text-sm border rounded-md px-1"
                            />
                          </div>
                        )}
                      </div>
                      <p className="text-sm font-bold text-foreground w-20 text-right shrink-0">
                        R$ {((item.product.sale_price - (item.discount || 0)) * item.qty).toFixed(2)}
                      </p>
                      <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive hover:bg-destructive/10 shrink-0" onClick={() => removeFromCart(item.product.id)}>
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Payment panel — 2 cols */}
          <div className={`md:col-span-2 space-y-3 ${mobileTab === 'scanner' ? 'hidden md:block' : 'block'}`}>
            {/* Customer */}
            <div className="bg-card border border-border rounded-lg p-4 space-y-2">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Cliente (Opcional)</p>
              {customer ? (
                <div className="flex items-center gap-2">
                  <User className="h-4 w-4 text-primary shrink-0" />
                  <span className="flex-1 text-sm font-medium truncate">{customer.name}</span>
                  <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => setCustomer(null)}>
                    <X className="h-3 w-3" />
                  </Button>
                </div>
              ) : (
                <Button variant="outline" size="sm" className="w-full text-xs" onClick={() => setShowCustomerPicker(true)}>
                  <User className="h-3.5 w-3.5 mr-1.5" /> Selecionar Cliente
                </Button>
              )}
            </div>

            {/* Totals */}
            <div className="bg-card border border-border rounded-lg p-4 space-y-3">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Resumo</p>
              <div className="space-y-1.5 text-sm">
                <div className="flex justify-between"><span className="text-muted-foreground">Subtotal</span><span>R$ {subtotal.toFixed(2)}</span></div>
                <div className="flex items-center justify-between gap-2">
                  <span className="text-muted-foreground">Desconto (R$)</span>
                  <Input value={discount} onChange={e => setDiscount(e.target.value)} className="w-24 h-7 text-sm text-right px-2" type="number" min="0" step="0.01" />
                </div>
                <Separator />
                <div className="flex justify-between font-bold text-base">
                  <span>Total</span>
                  <span className="text-primary">R$ {total.toFixed(2)}</span>
                </div>
              </div>
            </div>

            {/* Payment method */}
            <div className="bg-card border border-border rounded-lg p-4 space-y-3">
              <div className="flex items-center justify-between">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Forma de Pagamento</p>
                <kbd className="hidden sm:inline-flex h-5 items-center rounded border border-border bg-muted px-1.5 font-mono text-[10px] text-muted-foreground">F2</kbd>
              </div>
              <div className="flex flex-col gap-2">
                {paymentMethods.map((m) => {
                  const IconComp = PAYMENT_ICON_MAP[m.icon || 'CreditCard'] || CreditCard;
                  const isActive = paymentMethod === m.code;
                  return (
                    <button
                      key={m.code}
                      onClick={() => { setPaymentMethod(m.code as PaymentMethod); if (m.code !== 'cartao_credito') setInstallments(1); }}
                      className={`flex items-center gap-3 px-4 py-3.5 rounded-lg border text-left transition-all ${isActive ? 'border-primary bg-primary text-primary-foreground shadow-md' : 'border-border bg-background text-foreground hover:bg-muted/60'}`}
                    >
                      <div className={`h-10 w-10 rounded-full flex items-center justify-center shrink-0 ${isActive ? 'bg-primary-foreground/20' : 'bg-muted'}`}>
                        <IconComp className="h-5 w-5" />
                      </div>
                      <span className="text-sm font-semibold">{m.name}</span>
                      {isActive && (
                        <div className="ml-auto h-6 w-6 rounded-full bg-primary-foreground/20 flex items-center justify-center">
                          <CheckCircle2 className="h-4 w-4" />
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Installments for Credit Card */}
              {paymentMethod === 'cartao_credito' && (
                <div className="space-y-2 pt-1">
                  <Label className="text-sm font-normal">Parcelas</Label>
                  <Select value={String(installments)} onValueChange={(v) => setInstallments(Number(v))}>
                    <SelectTrigger className="h-11">
                      <SelectValue placeholder="Selecione as parcelas" />
                    </SelectTrigger>
                    <SelectContent>
                      {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map(n => (
                        <SelectItem key={n} value={String(n)}>
                          {n}x de {(total / n).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })} {n === 1 ? '(À vista)' : ''}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              {paymentMethod === 'dinheiro' && (
                <div className="space-y-2 pt-1">
                  <Label className="text-sm font-normal">Valor Pago</Label>
                  <Input value={amountPaid} onChange={e => setAmountPaid(e.target.value)} type="number" min="0" step="0.01" placeholder="0,00" className="h-11 text-base" />
                  {parseFloat(amountPaid) > 0 && (
                    <p className="text-sm text-success font-semibold flex items-center gap-1">
                      <CheckCircle2 className="h-4 w-4" /> Troco: R$ {change.toFixed(2)}
                    </p>
                  )}
                </div>
              )}
            </div>

            <Button
              className="w-full h-11 text-base font-semibold"
              disabled={cart.length === 0 || submitting}
              onClick={() => {
                metaPixel.trackInitiateCheckout({
                  itemsCount: cart.reduce((acc, it) => acc + it.qty, 0),
                  totalValue: total,
                  items: cart.map(i => ({ id: i.product.id, name: i.product.name, price: i.product.sale_price, quantity: i.qty })),
                });
                setShowPayDialog(true);
              }}
            >
              {submitting ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : null}
              <span className="flex-1 text-left">Finalizar Venda — R$ {total.toFixed(2)}</span>
              <kbd className="hidden sm:inline-flex h-5 items-center rounded border border-primary-foreground/30 bg-primary-foreground/20 px-1.5 font-mono text-[10px] text-primary-foreground">F1</kbd>
            </Button>
          </div>
        </div>

        {/* Barra flutuante inferior no Mobile quando estiver na aba de produtos com itens */}
        {mobileTab === 'scanner' && cart.length > 0 && (
          <div className="md:hidden sticky bottom-2 z-20 pt-2 animate-in slide-in-from-bottom-2">
            <Button
              onClick={() => setMobileTab('carrinho')}
              className="w-full h-12 shadow-lg bg-primary text-primary-foreground font-bold flex items-center justify-between px-4 text-sm rounded-xl"
            >
              <div className="flex items-center gap-2">
                <ShoppingBag className="h-4 w-4" />
                <span>{cart.length} {cart.length === 1 ? 'item' : 'itens'} no carrinho</span>
              </div>
              <div className="flex items-center gap-1.5 font-bold">
                <span>R$ {total.toFixed(2)}</span>
                <span className="text-xs bg-primary-foreground/20 px-2 py-0.5 rounded font-normal">Pagar →</span>
              </div>
            </Button>
          </div>
        )}
      </div>
      )}

      {/* Open Cash Dialog */}
      <Dialog open={showOpenDialog} onOpenChange={setShowOpenDialog}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <DialogHeader><DialogTitle className="text-balance">Abrir Caixa</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <Label className="text-sm font-normal">Valor Inicial em Dinheiro (R$)</Label>
            <Input type="number" min="0" step="0.01" placeholder="0,00" value={openAmount} onChange={e => setOpenAmount(e.target.value)} autoFocus />
          </div>
          <DialogFooter>
            <Button onClick={handleOpenCash} disabled={submitting} className="w-full">
              {submitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />} Abrir Caixa
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Close Cash Dialog */}
      <Dialog open={showCloseDialog} onOpenChange={setShowCloseDialog}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <DialogHeader><DialogTitle className="text-balance">Fechar Caixa</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <p className="text-sm text-muted-foreground text-pretty">Informe o valor físico em dinheiro contado no caixa.</p>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Valor em Caixa (R$)</Label>
              <Input type="number" min="0" step="0.01" placeholder="0,00" value={closingAmount} onChange={e => setClosingAmount(e.target.value)} />
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setShowCloseDialog(false)}>Cancelar</Button>
            <Button variant="destructive" onClick={handleCloseCash} disabled={submitting}>
              {submitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />} Confirmar Fechamento
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Customer Picker Dialog */}
      <Dialog open={showCustomerPicker} onOpenChange={(open) => { setShowCustomerPicker(open); if (!open) { setShowNewCustomerForm(false); setNewCustomerName(''); setNewCustomerPhone(''); setNewCustomerCpf(''); setCustomerSearch(''); setCustomerResults([]); } }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <DialogHeader><DialogTitle className="text-balance">{showNewCustomerForm ? 'Novo Cliente' : 'Selecionar Cliente'}</DialogTitle></DialogHeader>
          {!showNewCustomerForm ? (
            <div className="space-y-3 py-2">
              <Input placeholder="Buscar por nome, CPF ou telefone..." value={customerSearch} onChange={e => handleSearchCustomer(e.target.value)} autoFocus />
              <div className="max-h-60 overflow-y-auto space-y-1">
                {customerResults.map(c => (
                  <button key={c.id} onClick={() => { setCustomer(c); setShowCustomerPicker(false); setCustomerSearch(''); setCustomerResults([]); }}
                    className="w-full flex flex-col items-start px-3 py-2.5 rounded-md hover:bg-muted/60 transition-colors text-left border border-transparent hover:border-border">
                    <span className="text-sm font-medium text-foreground">{c.name}</span>
                    <span className="text-xs text-muted-foreground">{c.cpf_cnpj || ''} {c.phone ? `· ${c.phone}` : ''}</span>
                  </button>
                ))}
                {customerSearch.length >= 2 && customerResults.length === 0 && (
                  <p className="text-sm text-muted-foreground text-center py-4">Nenhum cliente encontrado</p>
                )}
              </div>
              <Button variant="outline" size="sm" className="w-full gap-1.5" onClick={() => setShowNewCustomerForm(true)}>
                <Plus className="h-3.5 w-3.5" /> Cadastrar Novo Cliente
              </Button>
            </div>
          ) : (
            <div className="space-y-3 py-2">
              <div className="space-y-1.5">
                <Label className="text-sm">Nome *</Label>
                <Input placeholder="Nome completo" value={newCustomerName} onChange={e => setNewCustomerName(e.target.value)} autoFocus />
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm">Telefone</Label>
                <Input placeholder="(00) 00000-0000" value={newCustomerPhone} onChange={e => setNewCustomerPhone(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm">CPF / CNPJ</Label>
                <Input placeholder="000.000.000-00" value={newCustomerCpf} onChange={e => setNewCustomerCpf(e.target.value)} />
              </div>
              <DialogFooter className="gap-2 pt-1">
                <Button variant="outline" size="sm" onClick={() => setShowNewCustomerForm(false)}>Voltar</Button>
                <Button size="sm" disabled={!newCustomerName.trim() || savingCustomer} onClick={async () => {
                  if (!newCustomerName.trim()) return;
                  setSavingCustomer(true);
                  try {
                    const { data: nc, error } = await supabase.from('customers').insert({ name: newCustomerName.trim(), phone: newCustomerPhone.trim() || null, cpf_cnpj: newCustomerCpf.trim() || null, active: true }).select().maybeSingle();
                    if (error) throw error;
                    toast.success('Cliente cadastrado!');
                    setCustomer(nc as Customer);
                    setShowCustomerPicker(false);
                    setShowNewCustomerForm(false);
                    setNewCustomerName(''); setNewCustomerPhone(''); setNewCustomerCpf('');
                  } catch (err) {
                    toast.error('Erro ao cadastrar cliente');
                  } finally {
                    setSavingCustomer(false);
                  }
                }}>
                  {savingCustomer ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : null}
                  Salvar Cliente
                </Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Payment confirm dialog */}
      <Dialog open={showPayDialog} onOpenChange={o => { setShowPayDialog(o); if (!o) { setSplitMode(false); setSplitPayments([{ method: 'dinheiro', amount: '', installments: 1 }]); } }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <DialogHeader><DialogTitle className="text-balance">Confirmar Venda</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2 max-h-[70vh] overflow-y-auto pr-1">
            {/* Resumo */}
            <div className="space-y-1 text-sm border border-border rounded-lg px-4 py-3">
              <div className="flex justify-between"><span className="text-muted-foreground">Itens</span><span>{cart.length}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Subtotal</span><span>R$ {subtotal.toFixed(2)}</span></div>
              {discountVal > 0 && <div className="flex justify-between text-destructive"><span>Desconto</span><span>-R$ {discountVal.toFixed(2)}</span></div>}
              <div className="flex justify-between font-bold text-base border-t border-border pt-2 mt-1">
                <span>Total</span><span className="text-primary">R$ {total.toFixed(2)}</span>
              </div>
              {customer && <div className="flex justify-between pt-1"><span className="text-muted-foreground">Cliente</span><span className="truncate ml-4">{customer.name}</span></div>}
            </div>

            {/* Toggle modo combinado */}
            <button
              onClick={() => {
                const next = !splitMode;
                setSplitMode(next);
                if (next) setSplitPayments([{ method: paymentMethod, amount: total.toFixed(2), installments }]);
                else setSplitPayments([{ method: 'dinheiro', amount: '', installments: 1 }]);
              }}
              className={`w-full flex items-center gap-2 px-4 py-2.5 rounded-lg border text-sm font-medium transition-all ${splitMode ? 'border-primary bg-primary/10 text-primary' : 'border-border bg-background text-foreground hover:bg-muted/60'}`}
            >
              <SplitSquareHorizontal className="h-4 w-4 shrink-0" />
              Pagamento Combinado (múltiplas formas)
              {splitMode && <CheckCircle2 className="h-4 w-4 ml-auto" />}
            </button>

            {/* Modo SIMPLES */}
            {!splitMode && (
              <div className="space-y-2">
                <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Forma de Pagamento</Label>
                <div className="grid grid-cols-2 gap-2">
                  {paymentMethods.map(m => {
                    const IconComp = PAYMENT_ICON_MAP[m.icon || 'CreditCard'] || CreditCard;
                    const active = paymentMethod === m.code;
                    return (
                      <button key={m.code} onClick={() => { setPaymentMethod(m.code as PaymentMethod); if (m.code !== 'cartao_credito') setInstallments(1); }}
                        className={`flex items-center gap-2 px-3 py-2.5 rounded-lg border text-sm transition-all ${active ? 'border-primary bg-primary text-primary-foreground' : 'border-border bg-background hover:bg-muted/60'}`}>
                        <IconComp className="h-4 w-4 shrink-0" />
                        <span className="font-medium truncate">{m.name}</span>
                        {active && <CheckCircle2 className="h-3.5 w-3.5 ml-auto shrink-0" />}
                      </button>
                    );
                  })}
                </div>
                {paymentMethod === 'cartao_credito' && (
                  <Select value={String(installments)} onValueChange={v => setInstallments(Number(v))}>
                    <SelectTrigger className="h-10"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {[1,2,3,4,5,6,7,8,9,10,11,12].map(n => (
                        <SelectItem key={n} value={String(n)}>{n}x de {(total/n).toLocaleString('pt-BR',{style:'currency',currency:'BRL'})} {n===1?'(À vista)':''}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
                {paymentMethod === 'dinheiro' && (
                  <div className="space-y-1.5">
                    <Label className="text-sm font-normal">Valor Pago (R$)</Label>
                    <Input value={amountPaid} onChange={e => setAmountPaid(e.target.value)} type="number" min="0" step="0.01" placeholder="0,00" className="h-10" />
                    {parseFloat(amountPaid) > 0 && (
                      <p className="text-sm text-success font-semibold flex items-center gap-1">
                        <CheckCircle2 className="h-3.5 w-3.5" /> Troco: R$ {change.toFixed(2)}
                      </p>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* Modo COMBINADO */}
            {splitMode && (
              <div className="space-y-2">
                <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Formas de Pagamento</Label>
                {splitPayments.map((entry, idx) => (
                  <div key={idx} className="flex items-start gap-2 rounded-lg border border-border bg-muted/30 p-3">
                    <div className="flex-1 space-y-2 min-w-0">
                      <div className="grid grid-cols-2 gap-2">
                        <div className="space-y-1">
                          <Label className="text-xs text-muted-foreground">Forma</Label>
                          <Select value={entry.method} onValueChange={v => { updateSplit(idx, 'method', v); if (v !== 'cartao_credito') updateSplit(idx, 'installments', 1); }}>
                            <SelectTrigger className="h-9 text-sm"><SelectValue /></SelectTrigger>
                            <SelectContent>
                              {paymentMethods.map(m => <SelectItem key={m.code} value={m.code}>{m.name}</SelectItem>)}
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs text-muted-foreground">Valor (R$)</Label>
                          <Input type="number" min="0" step="0.01" value={entry.amount}
                            onChange={e => updateSplit(idx, 'amount', e.target.value)}
                            className="h-9 text-sm" placeholder="0,00" />
                        </div>
                      </div>
                      {entry.method === 'cartao_credito' && (
                        <Select value={String(entry.installments)} onValueChange={v => updateSplit(idx, 'installments', Number(v))}>
                          <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {[1,2,3,4,5,6,7,8,9,10,11,12].map(n => {
                              const val = parseFloat(entry.amount) || 0;
                              return <SelectItem key={n} value={String(n)}>{n}x de R$ {val > 0 ? (val/n).toFixed(2) : '0,00'} {n===1?'(À vista)':''}</SelectItem>;
                            })}
                          </SelectContent>
                        </Select>
                      )}
                    </div>
                    {splitPayments.length > 1 && (
                      <button onClick={() => removeSplitRow(idx)} className="mt-7 shrink-0 h-7 w-7 rounded-md flex items-center justify-center text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors">
                        <X className="h-3.5 w-3.5" />
                      </button>
                    )}
                  </div>
                ))}

                <Button variant="outline" size="sm" className="w-full gap-1.5" onClick={addSplitRow}>
                  <Plus className="h-3.5 w-3.5" /> Adicionar forma de pagamento
                </Button>

                {/* Barra de progresso do total */}
                <div className="rounded-lg border border-border px-3 py-2.5 space-y-1.5 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Pago</span>
                    <span className={splitTotal > total + 0.01 ? 'text-destructive font-semibold' : splitTotal >= total - 0.01 ? 'text-success font-semibold' : 'font-medium'}>
                      R$ {splitTotal.toFixed(2)}
                    </span>
                  </div>
                  <div className="h-2 rounded-full bg-muted overflow-hidden">
                    <div className={`h-full rounded-full transition-all ${splitTotal > total + 0.01 ? 'bg-destructive' : 'bg-primary'}`}
                      style={{ width: `${Math.min(100, (splitTotal / total) * 100)}%` }} />
                  </div>
                  {splitRemaining > 0.005 && (
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>Falta</span><span>R$ {splitRemaining.toFixed(2)}</span>
                    </div>
                  )}
                  {splitTotal > total + 0.01 && (
                    <p className="text-xs text-destructive">Valor excede o total da venda</p>
                  )}
                  {Math.abs(splitTotal - total) <= 0.01 && (
                    <p className="text-xs text-success flex items-center gap-1"><CheckCircle2 className="h-3 w-3" /> Valores conferem</p>
                  )}
                </div>
              </div>
            )}
          </div>

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => { setShowPayDialog(false); setSplitMode(false); setSplitPayments([{ method: 'dinheiro', amount: '', installments: 1 }]); }}>Voltar</Button>
            {lastCupom && (
              <Button variant="outline" onClick={() => printCupomFiscal(lastCupom)} className="gap-1.5">
                <Printer className="h-4 w-4" /> Reimprimir
              </Button>
            )}
            <Button onClick={finalizeSale} disabled={submitting || (splitMode && Math.abs(splitTotal - total) > 0.01)}>
              {submitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />} Confirmar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Fraction qty dialog */}
      <Dialog open={!!fractionProduct} onOpenChange={(open) => { if (!open) { setFractionProduct(null); setFractionQtyInput(''); } }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-sm">
          <DialogHeader><DialogTitle className="text-balance">Quantidade por Fração</DialogTitle></DialogHeader>
          {fractionProduct && (
            <div className="space-y-4 py-2">
              <p className="text-sm text-muted-foreground">{fractionProduct.name}</p>
              <div>
                <Label>Quantidade ({fractionProduct.fraction_unit})</Label>
                <Input
                  type="number"
                  step="0.001"
                  min="0.001"
                  autoFocus
                  value={fractionQtyInput}
                  onChange={(e) => setFractionQtyInput(e.target.value)}
                  placeholder={`Ex: 0,350 ${fractionProduct.fraction_unit}`}
                  onKeyDown={(e) => { if (e.key === 'Enter') addFractionToCart(); }}
                />
                <p className="text-xs text-muted-foreground mt-1">Estoque disponível: {fractionProduct.stock_qty} {fractionProduct.fraction_unit}</p>
              </div>
              <DialogFooter className="gap-2">
                <Button variant="outline" onClick={() => { setFractionProduct(null); setFractionQtyInput(''); }}>Cancelar</Button>
                <Button onClick={addFractionToCart}>Adicionar</Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Print confirmation dialog */}
      <Dialog open={showPrintDialog} onOpenChange={(open) => {
        setShowPrintDialog(open);
        if (!open) {
          if (skipPrintCleanupRef.current) {
            skipPrintCleanupRef.current = false;
          } else {
            clearAfterSale();
          }
        }
      }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-balance flex items-center gap-2">
              <Printer className="h-5 w-5 text-primary" />
              Imprimir Cupom?
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2 text-sm text-muted-foreground text-pretty">
            <p>A venda foi finalizada com sucesso.</p>
            <p>Deseja imprimir o cupom fiscal da venda <strong>{lastCupom?.number}</strong>?</p>
          </div>
          <DialogFooter className="gap-2 flex-col md:flex-row">
            <Button variant="outline" onClick={handleSkipPrint} className="w-full md:w-auto">
              Não, Apenas Finalizar
            </Button>
            <Button onClick={handlePrintCupom} className="w-full md:w-auto gap-1.5">
              <Printer className="h-4 w-4" /> Sim, Imprimir Cupom
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reprint & Recent sales dialog with cancellation option */}
      <Dialog open={showReprintDialog} onOpenChange={setShowReprintDialog}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-xl max-h-[90dvh] overflow-y-auto">
          <DialogHeader>
            <div className="flex items-center justify-between pr-6 flex-wrap gap-2">
              <DialogTitle className="text-balance flex items-center gap-2">
                <Receipt className="h-5 w-5 text-primary" /> Vendas Recentes do Caixa
              </DialogTitle>
              <div className="flex items-center gap-1.5 flex-wrap">
                <Button
                  variant="outline"
                  size="sm"
                  className="text-xs gap-1 h-8 text-destructive border-destructive/30 hover:bg-destructive/10"
                  onClick={async () => {
                    const cancelledOnes = recentSales.filter(s => s.status === 'cancelada');
                    if (cancelledOnes.length === 0) {
                      toast.info('Nenhuma venda cancelada neste caixa no momento.');
                      return;
                    }
                    const reportItems: CancelledSaleReportItem[] = cancelledOnes.map(s => ({
                      id: s.id,
                      number: s.number,
                      created_at: s.created_at,
                      cancelled_at: s.cancelled_at,
                      cancelled_by_name: profile?.full_name || 'Operador do Caixa',
                      cancellation_reason: s.cancellation_reason || 'Desistência / Devolução',
                      total: Number(s.total) || 0,
                      payment_method: s.payment_method,
                      customer_name: s.customers?.name || 'Consumidor Final',
                      items_count: 1,
                    }));
                    await generateCancellationReportPdf({
                      periodLabel: 'Turno Atual do Caixa',
                      operatorName: profile?.full_name || profile?.username || undefined,
                      sales: reportItems,
                    });
                    toast.success('Relatório PDF de cancelamentos do caixa gerado com sucesso!');
                  }}
                >
                  <FileText className="h-3.5 w-3.5" />
                  <span>PDF Canceladas</span>
                </Button>
                <Button asChild variant="outline" size="sm" className="text-xs gap-1 h-8">
                  <Link to="/pdv/vendas" onClick={() => setShowReprintDialog(false)}>
                    <History className="h-3.5 w-3.5" /> Ver Todas & Filtros Avançados
                  </Link>
                </Button>
              </div>
            </div>
            <DialogDescription>
              Reimprima cupons fiscais ou cancele vendas emitidas diretamente pelo caixa.
            </DialogDescription>
          </DialogHeader>

          <div className="py-2 space-y-3">
            {/* Campo de filtro rápido por número ou cliente */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar por número da venda ou cliente..."
                value={reprintSearch}
                onChange={e => setReprintSearch(e.target.value)}
                className="pl-9 h-9 text-xs"
              />
            </div>

            {reprintLoading && recentSales.length === 0 ? (
              <div className="py-8 flex justify-center"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
            ) : recentSales.length === 0 ? (
              <div className="py-8 text-center text-muted-foreground text-sm">
                <Receipt className="h-8 w-8 mx-auto mb-2 opacity-40" />
                <p>Nenhuma venda encontrada neste caixa.</p>
              </div>
            ) : (
              <div className="space-y-2 max-h-[55vh] overflow-y-auto pr-1">
                {recentSales
                  .filter(s => {
                    if (!reprintSearch.trim()) return true;
                    const q = reprintSearch.toLowerCase();
                    return (
                      s.number?.toLowerCase().includes(q) ||
                      s.customers?.name?.toLowerCase().includes(q)
                    );
                  })
                  .map((s) => {
                    const isCancelled = s.status === 'cancelada';
                    return (
                      <div
                        key={s.id}
                        className={`flex items-center gap-3 p-3 rounded-lg border transition-colors ${
                          isCancelled
                            ? 'border-destructive/30 bg-destructive/5 opacity-80'
                            : 'border-border bg-muted/30 hover:bg-muted/60'
                        }`}
                      >
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className={`text-sm font-bold ${isCancelled ? 'line-through text-muted-foreground' : 'text-foreground'}`}>
                              {s.number}
                            </span>
                            <Badge variant={isCancelled ? 'destructive' : 'secondary'} className="text-[10px] px-1.5 py-0">
                              {isCancelled ? 'Cancelada' : (STATIC_PAYMENT_LABELS[s.payment_method] || s.payment_method)}
                            </Badge>
                          </div>
                          <p className="text-xs text-muted-foreground mt-0.5 truncate">
                            {new Date(s.created_at).toLocaleString('pt-BR')} · {s.customers?.name || 'Consumidor Final'}
                          </p>
                          {isCancelled && s.cancellation_reason && (
                            <p className="text-[11px] text-destructive italic mt-0.5 truncate">
                              Motivo: {s.cancellation_reason}
                            </p>
                          )}
                        </div>

                        <span className={`text-sm font-bold shrink-0 ${isCancelled ? 'line-through text-muted-foreground' : 'text-foreground'}`}>
                          R$ {Number(s.total).toFixed(2)}
                        </span>

                        <div className="flex items-center gap-1.5 shrink-0">
                          <Button
                            variant="outline"
                            size="sm"
                            className="h-8 px-2.5 gap-1 text-xs"
                            disabled={reprintLoading}
                            onClick={() => handleReprintSale(s.id, s.number)}
                            title="Reimprimir Cupom"
                          >
                            <Printer className="h-3.5 w-3.5" />
                            <span className="hidden sm:inline">Cupom</span>
                          </Button>

                          {!isCancelled && (
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-8 px-2 text-xs text-destructive hover:bg-destructive/10"
                              onClick={() => {
                                setSaleToCancel(s);
                                setCancelReason('');
                              }}
                              title="Cancelar esta venda"
                            >
                              <XCircle className="h-4 w-4 sm:mr-1" />
                              <span className="hidden sm:inline">Cancelar</span>
                            </Button>
                          )}
                        </div>
                      </div>
                    );
                  })}
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Modal de confirmação de cancelamento com justificativa obrigatória */}
      <Dialog open={!!saleToCancel} onOpenChange={(open) => { if (!open) { setSaleToCancel(null); setCancelReason(''); } }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-destructive flex items-center gap-2">
              <AlertTriangle className="h-5 w-5" /> Cancelar Venda {saleToCancel?.number}
            </DialogTitle>
            <DialogDescription>
              Esta operação cancelará a venda, devolverá os produtos ao estoque e cancelará os lançamentos financeiros vinculados.
            </DialogDescription>
          </DialogHeader>

          {saleToCancel && (
            <div className="space-y-4 py-2">
              <div className="rounded-lg bg-muted/50 p-3 text-xs space-y-1 border border-border">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Número:</span>
                  <span className="font-semibold text-foreground">{saleToCancel.number}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Valor Total:</span>
                  <span className="font-semibold text-foreground">R$ {Number(saleToCancel.total).toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Cliente:</span>
                  <span className="font-semibold text-foreground">{saleToCancel.customers?.name || 'Consumidor Final'}</span>
                </div>
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="cancel-reason-pdv" className="text-xs font-semibold flex items-center gap-1 text-foreground">
                  Motivo / Justificativa do Cancelamento <span className="text-destructive">*</span>
                </Label>
                <Textarea
                  id="cancel-reason-pdv"
                  rows={3}
                  placeholder="Ex: Cliente desistiu da compra, produto devolvido avariado, erro na forma de pagamento..."
                  value={cancelReason}
                  onChange={(e) => setCancelReason(e.target.value)}
                  className="text-xs resize-none"
                  autoFocus
                />
              </div>

              <DialogFooter className="gap-2 sm:gap-0">
                <Button
                  variant="outline"
                  onClick={() => { setSaleToCancel(null); setCancelReason(''); }}
                  disabled={cancelling}
                >
                  Voltar
                </Button>
                <Button
                  variant="destructive"
                  onClick={handleCancelSaleInPdv}
                  disabled={cancelling || !cancelReason.trim()}
                  className="gap-1.5"
                >
                  {cancelling && <Loader2 className="h-4 w-4 animate-spin" />}
                  Confirmar Cancelamento
                </Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Modal do Scanner por Câmera Responsivo */}
      <Dialog open={showCameraScanner} onOpenChange={(open) => {
        setShowCameraScanner(open);
        if (!open) stopCamera();
      }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md p-4">
          <DialogHeader>
            <div className="flex items-center justify-between pr-4">
              <DialogTitle className="text-balance flex items-center gap-2 text-base">
                <Camera className="h-5 w-5 text-primary" /> Scanner por Câmera
              </DialogTitle>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  const nextFacing = cameraFacing === 'environment' ? 'user' : 'environment';
                  setCameraFacing(nextFacing);
                  startCamera(nextFacing);
                }}
                className="h-8 px-2 text-xs gap-1"
                title="Trocar câmera (Traseira / Frontal)"
              >
                <RotateCcw className="h-3.5 w-3.5" />
                <span>Alternar</span>
              </Button>
            </div>
            <DialogDescription className="text-xs">
              Aponte a câmera para o código de barras (EAN-13, CODE-128, QR Code).
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-3 py-1">
            {/* Viewport do html5-qrcode */}
            <div className="relative overflow-hidden rounded-xl bg-black border border-border aspect-[4/3] flex items-center justify-center">
              <div id="pdv-camera-reader-viewport" className="w-full h-full" />
              {!cameraScanning && (
                <div className="absolute inset-0 flex flex-col items-center justify-center text-white/70 bg-black/80 gap-2">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  <p className="text-xs">Iniciando câmera...</p>
                </div>
              )}
            </div>

            {/* Opções e feedback */}
            <div className="flex items-center justify-between px-1 text-xs">
              <div className="flex items-center gap-2">
                <Switch
                  id="continuous-scan-switch"
                  checked={continuousScan}
                  onCheckedChange={setContinuousScan}
                />
                <Label htmlFor="continuous-scan-switch" className="cursor-pointer text-xs font-normal">
                  Modo Contínuo (manter aberta)
                </Label>
              </div>

              <div className="flex items-center gap-1 text-muted-foreground text-[11px]">
                <Volume2 className="h-3.5 w-3.5 text-success" />
                <span>Bip ativado</span>
              </div>
            </div>

            {lastScanned && (
              <div className="px-3 py-2 bg-success/15 border border-success/30 rounded-lg text-xs flex items-center justify-between text-success">
                <span className="font-semibold truncate">Lido: {lastScanned.name}</span>
                <span className="font-bold shrink-0">R$ {lastScanned.price.toFixed(2)}</span>
              </div>
            )}
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              className="w-full"
              onClick={() => {
                stopCamera();
                setShowCameraScanner(false);
              }}
            >
              Fechar Câmera
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Sale success overlay */}
      {saleDone && (
        <div className="fixed bottom-6 right-6 z-50 bg-success text-success-foreground px-5 py-3 rounded-lg shadow-lg flex items-center gap-3 animate-fade-in">
          <CheckCircle2 className="h-5 w-5 shrink-0" />
          <span className="font-semibold">Venda realizada!</span>
        </div>
      )}
    </PdvLayout>
  );
}

function ShoppingCartIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.5}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 3h1.386c.51 0 .955.343 1.087.835l.383 1.437M7.5 14.25a3 3 0 00-3 3h15.75m-12.75-3h11.218c1.121-2.3 2.1-4.684 2.924-7.138a60.114 60.114 0 00-16.536-1.84M7.5 14.25L5.106 5.272M6 20.25a.75.75 0 11-1.5 0 .75.75 0 011.5 0zm12.75 0a.75.75 0 11-1.5 0 .75.75 0 011.5 0z" />
    </svg>
  );
}
