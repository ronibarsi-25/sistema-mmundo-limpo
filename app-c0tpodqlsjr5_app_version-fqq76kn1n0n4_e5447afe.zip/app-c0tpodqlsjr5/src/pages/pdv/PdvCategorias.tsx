import { useEffect, useState } from 'react';
import { Plus, Pencil, Trash2, Tag } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Textarea } from '@/components/ui/textarea';
import { PdvLayout } from '@/components/layouts/PdvLayout';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import type { PdvCategory } from '@/types/types';

const COLORS = ['#0A5C5A', '#1E88E5', '#E53935', '#F4511E', '#43A047', '#8E24AA', '#FB8C00', '#546E7A', '#00ACC1', '#6D4C41'];

export default function PdvCategorias() {
  const [cats, setCats] = useState<PdvCategory[]>([]);
  const [loading, setLoading] = useState(true);
  const [showDialog, setShowDialog] = useState(false);
  const [editing, setEditing] = useState<PdvCategory | null>(null);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [color, setColor] = useState(COLORS[0]);
  const [submitting, setSubmitting] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  useEffect(() => { load(); }, []);

  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from('pdv_categories').select('*').order('name');
    setCats((data as PdvCategory[]) || []);
    setLoading(false);
  };

  const openCreate = () => { setEditing(null); setName(''); setDescription(''); setColor(COLORS[0]); setShowDialog(true); };
  const openEdit = (c: PdvCategory) => { setEditing(c); setName(c.name); setDescription(c.description || ''); setColor(c.color); setShowDialog(true); };

  const handleSave = async () => {
    if (!name.trim()) { toast.error('Informe o nome da categoria'); return; }
    setSubmitting(true);
    const payload = { name: name.trim(), description: description || null, color };
    const q = editing ? supabase.from('pdv_categories').update(payload).eq('id', editing.id) : supabase.from('pdv_categories').insert(payload);
    const { error } = await q;
    setSubmitting(false);
    if (error) { toast.error('Erro ao salvar: ' + error.message); return; }
    toast.success(editing ? 'Categoria atualizada!' : 'Categoria criada!');
    setShowDialog(false);
    load();
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    const { error } = await supabase.from('pdv_categories').delete().eq('id', deleteId);
    if (error) toast.error('Não é possível excluir categoria em uso');
    else { toast.success('Categoria excluída'); load(); }
    setDeleteId(null);
  };

  return (
    <PdvLayout title="Categorias" actions={<Button size="sm" onClick={openCreate}><Plus className="h-4 w-4 mr-1.5" />Nova Categoria</Button>}>
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-24 bg-muted rounded-lg" />)}
        </div>
      ) : cats.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-muted-foreground">
          <Tag className="h-10 w-10 mb-3 opacity-40" />
          <p className="text-sm text-pretty text-center">Nenhuma categoria criada. Crie a primeira!</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {cats.map(c => (
            <div key={c.id} className="bg-card border border-border rounded-lg p-4 flex items-center gap-3 h-full card-hover">
              <div className="h-10 w-10 rounded-lg shrink-0 flex items-center justify-center" style={{ background: c.color + '20', border: `2px solid ${c.color}40` }}>
                <Tag className="h-5 w-5" style={{ color: c.color }} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-foreground truncate">{c.name}</p>
                {c.description && <p className="text-xs text-muted-foreground truncate">{c.description}</p>}
              </div>
              <div className="flex items-center gap-1 shrink-0">
                <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openEdit(c)}><Pencil className="h-3.5 w-3.5" /></Button>
                <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive hover:bg-destructive/10" onClick={() => setDeleteId(c.id)}><Trash2 className="h-3.5 w-3.5" /></Button>
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <DialogHeader><DialogTitle className="text-balance">{editing ? 'Editar Categoria' : 'Nova Categoria'}</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Nome *</Label>
              <Input value={name} onChange={e => setName(e.target.value)} placeholder="Ex: Limpeza Doméstica" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Descrição</Label>
              <Textarea value={description} onChange={e => setDescription(e.target.value)} rows={2} placeholder="Descrição opcional" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Cor</Label>
              <div className="flex flex-wrap gap-2">
                {COLORS.map(c => (
                  <button key={c} onClick={() => setColor(c)}
                    className={`h-8 w-8 rounded-full transition-transform ${color === c ? 'scale-125 ring-2 ring-offset-2 ring-primary' : 'hover:scale-110'}`}
                    style={{ background: c }} />
                ))}
              </div>
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setShowDialog(false)}>Cancelar</Button>
            <Button onClick={handleSave} disabled={submitting}>Salvar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-balance">Excluir categoria?</AlertDialogTitle>
            <AlertDialogDescription className="text-pretty">Categorias com produtos vinculados não podem ser excluídas.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive hover:bg-destructive/90">Excluir</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </PdvLayout>
  );
}
