import { useEffect, useState } from 'react';
import { Plus, Pencil, Trash2, Search, UserCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Textarea } from '@/components/ui/textarea';
import { PdvLayout } from '@/components/layouts/PdvLayout';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import type { Customer } from '@/types/types';

const emptyForm = {
  name: '', cpf_cnpj: '', email: '', phone: '', birth_date: '',
  cep: '', logradouro: '', numero: '', complemento: '', bairro: '', cidade: '', estado: '', notes: '', active: true,
};

export default function PdvClientes() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showDialog, setShowDialog] = useState(false);
  const [editing, setEditing] = useState<Customer | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [submitting, setSubmitting] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  useEffect(() => { load(); }, []);
  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from('customers').select('*').order('name');
    setCustomers((data as Customer[]) || []);
    setLoading(false);
  };

  const openCreate = () => { setEditing(null); setForm(emptyForm); setShowDialog(true); };
  const openEdit = (c: Customer) => {
    setEditing(c);
    setForm({
      name: c.name, cpf_cnpj: c.cpf_cnpj || '', email: c.email || '', phone: c.phone || '',
      birth_date: c.birth_date || '', cep: c.cep || '', logradouro: c.logradouro || '',
      numero: c.numero || '', complemento: c.complemento || '', bairro: c.bairro || '',
      cidade: c.cidade || '', estado: c.estado || '', notes: c.notes || '', active: c.active,
    });
    setShowDialog(true);
  };

  const lookupCep = async () => {
    if (form.cep.replace(/\D/g, '').length !== 8) return;
    try {
      const r = await fetch(`https://viacep.com.br/ws/${form.cep.replace(/\D/g, '')}/json/`);
      const d = await r.json();
      if (!d.erro) setForm(p => ({ ...p, logradouro: d.logradouro, bairro: d.bairro, cidade: d.localidade, estado: d.uf }));
    } catch { /* silent */ }
  };

  const handleSave = async () => {
    if (!form.name.trim()) { toast.error('Informe o nome do cliente'); return; }
    setSubmitting(true);
    const payload = { name: form.name.trim(), cpf_cnpj: form.cpf_cnpj || null, email: form.email || null, phone: form.phone || null, birth_date: form.birth_date || null, cep: form.cep || null, logradouro: form.logradouro || null, numero: form.numero || null, complemento: form.complemento || null, bairro: form.bairro || null, cidade: form.cidade || null, estado: form.estado || null, notes: form.notes || null, active: form.active };
    const q = editing ? supabase.from('customers').update(payload).eq('id', editing.id) : supabase.from('customers').insert(payload);
    const { error } = await q;
    setSubmitting(false);
    if (error) { toast.error('Erro ao salvar: ' + error.message); return; }
    toast.success(editing ? 'Cliente atualizado!' : 'Cliente criado!');
    setShowDialog(false); load();
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    const { error } = await supabase.from('customers').delete().eq('id', deleteId);
    if (error) toast.error('Não é possível excluir cliente com notas fiscais');
    else { toast.success('Cliente excluído'); load(); }
    setDeleteId(null);
  };

  const f = (k: string, v: string | boolean) => setForm(p => ({ ...p, [k]: v }));
  const filtered = customers.filter(c => !search || c.name.toLowerCase().includes(search.toLowerCase()) || (c.cpf_cnpj || '').includes(search) || (c.phone || '').includes(search));

  return (
    <PdvLayout title="Clientes" actions={<Button size="sm" onClick={openCreate}><Plus className="h-4 w-4 mr-1.5" />Novo Cliente</Button>}>
      <div className="relative mb-5 max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input placeholder="Buscar por nome, CPF ou telefone..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
      </div>

      <div className="bg-card border border-border rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/40">
                <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Nome</th>
                <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">CPF/CNPJ</th>
                <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Telefone</th>
                <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Cidade</th>
                <th className="text-center px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Status</th>
                <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {loading ? (
                Array.from({ length: 5 }).map((_, i) => <tr key={i}><td colSpan={6} className="px-4 py-3"><Skeleton className="h-5 w-full bg-muted" /></td></tr>)
              ) : filtered.length === 0 ? (
                <tr><td colSpan={6} className="text-center py-12 text-muted-foreground">
                  <UserCheck className="h-8 w-8 mx-auto mb-2 opacity-40" />
                  <p className="text-pretty">Nenhum cliente encontrado</p>
                </td></tr>
              ) : filtered.map(c => (
                <tr key={c.id} className="hover:bg-muted/30 transition-colors">
                  <td className="px-4 py-3 font-medium text-foreground whitespace-nowrap">{c.name}</td>
                  <td className="px-4 py-3 text-muted-foreground whitespace-nowrap">{c.cpf_cnpj || '—'}</td>
                  <td className="px-4 py-3 text-muted-foreground whitespace-nowrap">{c.phone || '—'}</td>
                  <td className="px-4 py-3 text-muted-foreground whitespace-nowrap">{c.cidade ? `${c.cidade}/${c.estado}` : '—'}</td>
                  <td className="px-4 py-3 text-center whitespace-nowrap"><Badge variant={c.active ? 'default' : 'secondary'} className="text-xs">{c.active ? 'Ativo' : 'Inativo'}</Badge></td>
                  <td className="px-4 py-3 text-right whitespace-nowrap">
                    <div className="flex items-center justify-end gap-1">
                      <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openEdit(c)}><Pencil className="h-3.5 w-3.5" /></Button>
                      <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive hover:bg-destructive/10" onClick={() => setDeleteId(c.id)}><Trash2 className="h-3.5 w-3.5" /></Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl max-h-[90dvh] overflow-y-auto">
          <DialogHeader><DialogTitle className="text-balance">{editing ? 'Editar Cliente' : 'Novo Cliente'}</DialogTitle></DialogHeader>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-2">
            <div className="space-y-1.5 md:col-span-2"><Label className="text-sm font-normal">Nome *</Label><Input value={form.name} onChange={e => f('name', e.target.value)} placeholder="Nome completo" /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">CPF / CNPJ</Label><Input value={form.cpf_cnpj} onChange={e => f('cpf_cnpj', e.target.value)} placeholder="000.000.000-00" /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Data de Nascimento</Label><Input type="date" value={form.birth_date} onChange={e => f('birth_date', e.target.value)} /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Telefone / WhatsApp</Label><Input value={form.phone} onChange={e => f('phone', e.target.value)} placeholder="(00) 00000-0000" /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">E-mail</Label><Input type="email" value={form.email} onChange={e => f('email', e.target.value)} placeholder="email@exemplo.com" /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">CEP</Label><Input value={form.cep} onChange={e => f('cep', e.target.value)} onBlur={lookupCep} placeholder="00000-000" /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Logradouro</Label><Input value={form.logradouro} onChange={e => f('logradouro', e.target.value)} /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Número</Label><Input value={form.numero} onChange={e => f('numero', e.target.value)} /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Complemento</Label><Input value={form.complemento} onChange={e => f('complemento', e.target.value)} /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Bairro</Label><Input value={form.bairro} onChange={e => f('bairro', e.target.value)} /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Cidade</Label><Input value={form.cidade} onChange={e => f('cidade', e.target.value)} /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Estado</Label><Input value={form.estado} onChange={e => f('estado', e.target.value)} placeholder="SP" maxLength={2} /></div>
            <div className="space-y-1.5 md:col-span-2"><Label className="text-sm font-normal">Observações</Label><Textarea value={form.notes} onChange={e => f('notes', e.target.value)} rows={2} /></div>
            <div className="flex items-center gap-2 md:col-span-2">
              <input type="checkbox" id="cAtivo" checked={form.active as boolean} onChange={e => f('active', e.target.checked)} className="h-4 w-4 rounded border-border" />
              <Label htmlFor="cAtivo" className="text-sm font-normal cursor-pointer">Cliente ativo</Label>
            </div>
          </div>
          <DialogFooter className="gap-2"><Button variant="outline" onClick={() => setShowDialog(false)}>Cancelar</Button><Button onClick={handleSave} disabled={submitting}>Salvar</Button></DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <AlertDialogHeader><AlertDialogTitle className="text-balance">Excluir cliente?</AlertDialogTitle><AlertDialogDescription className="text-pretty">Esta ação não pode ser desfeita.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancelar</AlertDialogCancel><AlertDialogAction onClick={handleDelete} className="bg-destructive hover:bg-destructive/90">Excluir</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </PdvLayout>
  );
}
