import { useEffect, useState } from 'react';
import { DollarSign, Settings, TrendingUp, CheckCircle, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { PdvLayout } from '@/components/layouts/PdvLayout';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';

interface SellerConfig { id: string; profile_id: string; commission_pct: number; active: boolean; profiles?: { full_name: string } | null; }
interface Commission {
  id: string; profile_id: string; invoice_id: string | null; sale_amount: number;
  commission_pct: number; commission_value: number;
  status: 'pendente' | 'pago' | 'cancelado'; paid_at: string | null;
  notes: string | null; created_at: string;
  profiles?: { full_name: string } | null;
  pdv_invoices?: { invoice_number: string } | null;
}

export default function PdvComissoes() {
  const [configs, setConfigs] = useState<SellerConfig[]>([]);
  const [commissions, setCommissions] = useState<Commission[]>([]);
  const [profiles, setProfiles] = useState<{ id: string; full_name: string }[]>([]);
  const [loading, setLoading] = useState(true);
  const [showConfig, setShowConfig] = useState(false);
  const [editConfig, setEditConfig] = useState<SellerConfig | null>(null);
  const [configForm, setConfigForm] = useState({ profile_id: '', commission_pct: '5' });
  const [saving, setSaving] = useState(false);
  const [filterSeller, setFilterSeller] = useState('all');

  useEffect(() => { loadAll(); }, []);

  const loadAll = async () => {
    setLoading(true);
    const [cfgRes, comRes, profRes] = await Promise.all([
      supabase.from('seller_commissions_config').select('*, profiles(full_name)').order('created_at'),
      supabase.from('commissions').select('*, profiles(full_name), pdv_invoices(invoice_number)').order('created_at', { ascending: false }).limit(100),
      supabase.from('profiles').select('id,full_name').in('role', ['admin', 'gestor', 'operador']).order('full_name'),
    ]);
    setConfigs((cfgRes.data as SellerConfig[]) || []);
    setCommissions((comRes.data as Commission[]) || []);
    setProfiles(profRes.data || []);
    setLoading(false);
  };

  const openNewConfig = () => { setEditConfig(null); setConfigForm({ profile_id: '', commission_pct: '5' }); setShowConfig(true); };
  const openEditConfig = (c: SellerConfig) => { setEditConfig(c); setConfigForm({ profile_id: c.profile_id, commission_pct: String(c.commission_pct) }); setShowConfig(true); };

  const saveConfig = async () => {
    if (!configForm.profile_id) { toast.error('Selecione o vendedor'); return; }
    setSaving(true);
    const payload = { profile_id: configForm.profile_id, commission_pct: parseFloat(configForm.commission_pct), active: true, updated_at: new Date().toISOString() };
    let error;
    if (editConfig) {
      ({ error } = await supabase.from('seller_commissions_config').update(payload).eq('id', editConfig.id));
    } else {
      ({ error } = await supabase.from('seller_commissions_config').upsert(payload, { onConflict: 'profile_id' }));
    }
    setSaving(false);
    if (error) { toast.error('Erro: ' + error.message); return; }
    toast.success('Configuração salva!');
    setShowConfig(false);
    loadAll();
  };

  const markPaid = async (id: string) => {
    const { error } = await supabase.from('commissions').update({ status: 'pago', paid_at: new Date().toISOString() }).eq('id', id);
    if (error) { toast.error('Erro ao marcar como pago'); return; }
    toast.success('Comissão marcada como paga!');
    setCommissions(prev => prev.map(c => c.id === id ? { ...c, status: 'pago' as const, paid_at: new Date().toISOString() } : c));
  };

  const cf = (k: string, v: string) => setConfigForm(p => ({ ...p, [k]: v }));

  const filtered = commissions.filter(c => filterSeller === 'all' || c.profile_id === filterSeller);
  const pendingTotal = filtered.filter(c => c.status === 'pendente').reduce((s, c) => s + c.commission_value, 0);
  const paidTotal = filtered.filter(c => c.status === 'pago').reduce((s, c) => s + c.commission_value, 0);

  return (
    <PdvLayout title="Comissões de Vendedores" actions={
      <Button size="sm" onClick={openNewConfig}><Settings className="h-4 w-4 mr-1.5" />Configurar</Button>
    }>
      <div className="space-y-4">
        {/* KPIs */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {[
            { label: 'A Pagar', val: `R$ ${pendingTotal.toFixed(2)}`, cls: 'text-warning', icon: DollarSign },
            { label: 'Pago (período)', val: `R$ ${paidTotal.toFixed(2)}`, cls: 'text-success', icon: CheckCircle },
            { label: 'Vendedores Config.', val: configs.filter(c => c.active).length, cls: 'text-foreground', icon: TrendingUp },
          ].map((k, i) => (
            <div key={i} className="bg-card border border-border rounded-lg p-4">
              <div className="flex items-center gap-2 mb-1"><k.icon className={`h-4 w-4 ${k.cls}`} /><p className="text-xs text-muted-foreground">{k.label}</p></div>
              <p className="text-xl font-bold text-foreground">{k.val}</p>
            </div>
          ))}
        </div>

        <Tabs defaultValue="comissoes">
          <TabsList>
            <TabsTrigger value="comissoes">Comissões</TabsTrigger>
            <TabsTrigger value="config">Configuração</TabsTrigger>
          </TabsList>

          <TabsContent value="comissoes" className="mt-4 space-y-3">
            <div className="flex gap-3">
              <Select value={filterSeller} onValueChange={setFilterSeller}>
                <SelectTrigger className="w-48"><SelectValue placeholder="Todos os vendedores" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos</SelectItem>
                  {profiles.map(p => <SelectItem key={p.id} value={p.id}>{p.full_name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="bg-card border border-border rounded-lg overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead><tr className="border-b border-border bg-muted/40">
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Data</th>
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Vendedor</th>
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Nota</th>
                    <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Venda</th>
                    <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">%</th>
                    <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Comissão</th>
                    <th className="text-center px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Status</th>
                    <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Ação</th>
                  </tr></thead>
                  <tbody className="divide-y divide-border">
                    {loading ? Array.from({ length: 4 }).map((_, i) => <tr key={i}><td colSpan={8} className="px-4 py-3"><Skeleton className="h-5 w-full bg-muted" /></td></tr>)
                      : filtered.length === 0 ? <tr><td colSpan={8} className="text-center py-12 text-muted-foreground"><DollarSign className="h-8 w-8 mx-auto mb-2 opacity-40" /><p>Nenhuma comissão registrada</p></td></tr>
                      : filtered.map(c => (
                        <tr key={c.id} className="hover:bg-muted/30">
                          <td className="px-4 py-3 whitespace-nowrap">{new Date(c.created_at).toLocaleDateString('pt-BR')}</td>
                          <td className="px-4 py-3 font-medium whitespace-nowrap">{c.profiles?.full_name || '—'}</td>
                          <td className="px-4 py-3 font-mono text-xs whitespace-nowrap">{c.pdv_invoices?.invoice_number || '—'}</td>
                          <td className="px-4 py-3 text-right whitespace-nowrap">R$ {c.sale_amount.toFixed(2)}</td>
                          <td className="px-4 py-3 text-right whitespace-nowrap">{c.commission_pct}%</td>
                          <td className="px-4 py-3 text-right font-bold whitespace-nowrap text-primary">R$ {c.commission_value.toFixed(2)}</td>
                          <td className="px-4 py-3 text-center whitespace-nowrap">
                            <Badge className={`text-xs ${c.status === 'pago' ? 'bg-success/10 text-success border border-success/30' : c.status === 'cancelado' ? 'bg-muted text-muted-foreground border border-border' : 'bg-warning/10 text-warning border border-warning/30'}`}>
                              {c.status === 'pago' ? 'Pago' : c.status === 'cancelado' ? 'Cancelado' : 'Pendente'}
                            </Badge>
                          </td>
                          <td className="px-4 py-3 text-right whitespace-nowrap">
                            {c.status === 'pendente' && <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => markPaid(c.id)}><CheckCircle className="h-3 w-3 mr-1" />Pagar</Button>}
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="config" className="mt-4">
            <div className="flex justify-end mb-3">
              <Button size="sm" onClick={openNewConfig}><Plus className="h-4 w-4 mr-1.5" />Adicionar Vendedor</Button>
            </div>
            <div className="bg-card border border-border rounded-lg overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead><tr className="border-b border-border bg-muted/40">
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Vendedor</th>
                    <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Comissão %</th>
                    <th className="text-center px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Status</th>
                    <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Ação</th>
                  </tr></thead>
                  <tbody className="divide-y divide-border">
                    {loading ? Array.from({ length: 3 }).map((_, i) => <tr key={i}><td colSpan={4} className="px-4 py-3"><Skeleton className="h-5 w-full bg-muted" /></td></tr>)
                      : configs.length === 0 ? <tr><td colSpan={4} className="text-center py-10 text-muted-foreground">Nenhum vendedor configurado</td></tr>
                      : configs.map(c => (
                        <tr key={c.id} className="hover:bg-muted/30">
                          <td className="px-4 py-3 font-medium whitespace-nowrap">{c.profiles?.full_name || '—'}</td>
                          <td className="px-4 py-3 text-right whitespace-nowrap font-bold text-primary">{c.commission_pct}%</td>
                          <td className="px-4 py-3 text-center whitespace-nowrap"><Badge variant={c.active ? 'default' : 'secondary'} className="text-xs">{c.active ? 'Ativo' : 'Inativo'}</Badge></td>
                          <td className="px-4 py-3 text-right whitespace-nowrap"><Button variant="outline" size="sm" className="h-7 text-xs" onClick={() => openEditConfig(c)}>Editar</Button></td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      <Dialog open={showConfig} onOpenChange={setShowConfig}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-sm">
          <DialogHeader><DialogTitle className="text-balance">{editConfig ? 'Editar' : 'Adicionar'} Vendedor</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Vendedor *</Label>
              <Select value={configForm.profile_id || 'none'} onValueChange={v => cf('profile_id', v === 'none' ? '' : v)} disabled={!!editConfig}>
                <SelectTrigger><SelectValue placeholder="Selecione..." /></SelectTrigger>
                <SelectContent>{profiles.map(p => <SelectItem key={p.id} value={p.id}>{p.full_name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Percentual de Comissão (%)</Label><Input type="number" min="0" max="100" step="0.5" value={configForm.commission_pct} onChange={e => cf('commission_pct', e.target.value)} /></div>
          </div>
          <DialogFooter className="gap-2"><Button variant="outline" onClick={() => setShowConfig(false)}>Cancelar</Button><Button onClick={saveConfig} disabled={saving}>Salvar</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </PdvLayout>
  );
}
