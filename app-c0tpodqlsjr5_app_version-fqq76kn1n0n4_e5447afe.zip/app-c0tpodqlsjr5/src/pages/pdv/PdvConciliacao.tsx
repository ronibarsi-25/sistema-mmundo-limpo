import { useState } from 'react';
import { Upload, CheckCircle, AlertCircle, LinkIcon, Unlink, Banknote } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { PdvLayout } from '@/components/layouts/PdvLayout';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';

interface BankLine {
  date: string; description: string; amount: number; type: 'credito' | 'debito'; reconciled: boolean;
}

function parseCSV(text: string): BankLine[] {
  const lines = text.split('\n').map(l => l.trim()).filter(Boolean);
  const result: BankLine[] = [];
  for (const line of lines) {
    const cols = line.split(/[;,]/).map(c => c.replace(/"/g, '').trim());
    if (cols.length < 3) continue;
    const dateRaw = cols[0];
    const description = cols[1];
    const amountRaw = parseFloat(cols[2].replace(',', '.'));
    if (isNaN(amountRaw)) continue;
    result.push({ date: dateRaw, description, amount: Math.abs(amountRaw), type: amountRaw >= 0 ? 'credito' : 'debito', reconciled: false });
  }
  return result;
}

export default function PdvConciliacao() {
  const [lines, setLines] = useState<BankLine[]>([]);
  const [bankName, setBankName] = useState('');
  const [account, setAccount] = useState('');
  const [importing, setImporting] = useState(false);
  const [showGuide, setShowGuide] = useState(false);

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const text = ev.target?.result as string;
      const parsed = parseCSV(text);
      if (parsed.length === 0) { toast.error('Nenhuma transação encontrada. Verifique o formato do arquivo.'); return; }
      setLines(parsed);
      toast.success(`${parsed.length} transações importadas!`);
    };
    reader.readAsText(file, 'UTF-8');
    e.target.value = '';
  };

  const toggleReconcile = (idx: number) => {
    setLines(prev => prev.map((l, i) => i === idx ? { ...l, reconciled: !l.reconciled } : l));
  };

  const saveAll = async () => {
    if (!bankName.trim()) { toast.error('Informe o nome do banco'); return; }
    if (lines.length === 0) { toast.error('Importe um extrato primeiro'); return; }
    setImporting(true);
    const today = new Date().toISOString().split('T')[0];
    const payload = lines.map(l => ({
      bank_name: bankName, account: account || null, statement_date: l.date || today,
      description: l.description, amount: l.amount, type: l.type, reconciled: l.reconciled,
    }));
    const { error } = await supabase.from('bank_statements').insert(payload);
    setImporting(false);
    if (error) { toast.error('Erro ao salvar: ' + error.message); return; }
    toast.success(`${lines.length} transações salvas!`);
    setLines([]);
  };

  const reconciled = lines.filter(l => l.reconciled).length;
  const total = lines.length;
  const creditTotal = lines.filter(l => l.type === 'credito').reduce((s, l) => s + l.amount, 0);
  const debitTotal = lines.filter(l => l.type === 'debito').reduce((s, l) => s + l.amount, 0);

  return (
    <PdvLayout title="Conciliação Bancária" actions={
      <Button size="sm" variant="outline" onClick={() => setShowGuide(true)}>Formato CSV</Button>
    }>
      <div className="space-y-4">
        <div className="bg-card border border-border rounded-lg p-4 space-y-4">
          <h3 className="font-semibold text-sm">Importar Extrato Bancário</h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5"><Label className="text-sm font-normal">Nome do Banco *</Label><Input value={bankName} onChange={e => setBankName(e.target.value)} placeholder="Banco Itaú, Bradesco..." /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Conta</Label><Input value={account} onChange={e => setAccount(e.target.value)} placeholder="0001-5 / 12345-6" /></div>
          </div>
          <div>
            <input id="csv-upload" type="file" accept=".csv,.txt,.ofx" className="hidden" onChange={handleFile} />
            <label htmlFor="csv-upload">
              <div className="border-2 border-dashed border-border rounded-lg p-8 text-center cursor-pointer hover:border-primary/50 hover:bg-primary/5 transition-colors">
                <Upload className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                <p className="text-sm font-medium text-foreground">Clique para importar extrato CSV</p>
                <p className="text-xs text-muted-foreground mt-1">Formato: Data, Descrição, Valor</p>
              </div>
            </label>
          </div>
        </div>

        {lines.length > 0 && (
          <>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {[
                { label: 'Total Linhas', val: total, cls: 'text-foreground' },
                { label: 'Conciliados', val: reconciled, cls: 'text-success' },
                { label: 'Créditos', val: `R$ ${creditTotal.toFixed(2)}`, cls: 'text-success' },
                { label: 'Débitos', val: `R$ ${debitTotal.toFixed(2)}`, cls: 'text-destructive' },
              ].map((k, i) => (
                <div key={i} className="bg-card border border-border rounded-lg p-4">
                  <p className="text-xs text-muted-foreground mb-1">{k.label}</p>
                  <p className={`text-xl font-bold ${k.cls}`}>{k.val}</p>
                </div>
              ))}
            </div>

            <div className="bg-card border border-border rounded-lg overflow-hidden">
              <div className="flex items-center justify-between px-4 py-3 border-b border-border">
                <p className="text-sm font-semibold">Transações Importadas</p>
                <Button size="sm" onClick={saveAll} disabled={importing}><Banknote className="h-4 w-4 mr-1.5" />Salvar no Sistema</Button>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead><tr className="border-b border-border bg-muted/40">
                    <th className="text-left px-4 py-2 font-medium text-muted-foreground whitespace-nowrap">Data</th>
                    <th className="text-left px-4 py-2 font-medium text-muted-foreground whitespace-nowrap">Descrição</th>
                    <th className="text-center px-4 py-2 font-medium text-muted-foreground whitespace-nowrap">Tipo</th>
                    <th className="text-right px-4 py-2 font-medium text-muted-foreground whitespace-nowrap">Valor</th>
                    <th className="text-center px-4 py-2 font-medium text-muted-foreground whitespace-nowrap">Conciliado</th>
                    <th className="text-right px-4 py-2 font-medium text-muted-foreground whitespace-nowrap">Ação</th>
                  </tr></thead>
                  <tbody className="divide-y divide-border max-h-[400px] overflow-y-auto">
                    {lines.map((l, i) => (
                      <tr key={i} className={`hover:bg-muted/30 ${l.reconciled ? 'opacity-60' : ''}`}>
                        <td className="px-4 py-2 whitespace-nowrap text-muted-foreground text-xs">{l.date}</td>
                        <td className="px-4 py-2 max-w-[220px] truncate">{l.description}</td>
                        <td className="px-4 py-2 text-center whitespace-nowrap">
                          <Badge className={`text-xs ${l.type === 'credito' ? 'bg-success/10 text-success border-success/30' : 'bg-destructive/10 text-destructive border-destructive/30'}`}>
                            {l.type === 'credito' ? 'Crédito' : 'Débito'}
                          </Badge>
                        </td>
                        <td className={`px-4 py-2 text-right font-medium whitespace-nowrap ${l.type === 'credito' ? 'text-success' : 'text-destructive'}`}>
                          {l.type === 'debito' ? '-' : '+'}R$ {l.amount.toFixed(2)}
                        </td>
                        <td className="px-4 py-2 text-center whitespace-nowrap">
                          {l.reconciled ? <CheckCircle className="h-4 w-4 text-success mx-auto" /> : <AlertCircle className="h-4 w-4 text-muted-foreground mx-auto" />}
                        </td>
                        <td className="px-4 py-2 text-right whitespace-nowrap">
                          <Button variant="ghost" size="icon" className={`h-7 w-7 ${l.reconciled ? 'text-success' : ''}`} onClick={() => toggleReconcile(i)}>
                            {l.reconciled ? <Unlink className="h-3.5 w-3.5" /> : <LinkIcon className="h-3.5 w-3.5" />}
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        )}
      </div>

      <Dialog open={showGuide} onOpenChange={setShowGuide}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <DialogHeader><DialogTitle className="text-balance">Formato do Arquivo CSV</DialogTitle></DialogHeader>
          <div className="space-y-3 text-sm">
            <p className="text-muted-foreground">O arquivo CSV deve ter as colunas na seguinte ordem:</p>
            <div className="bg-muted rounded-lg p-3 font-mono text-xs space-y-1">
              <p>Data;Descrição;Valor</p>
              <p>01/06/2026;PIX Recebido Cliente X;500.00</p>
              <p>02/06/2026;Pagamento Fornecedor Y;-1200.00</p>
              <p>03/06/2026;Tarifa Bancária;-12.50</p>
            </div>
            <ul className="text-muted-foreground text-xs space-y-1 list-disc pl-4">
              <li>Separador: vírgula (,) ou ponto e vírgula (;)</li>
              <li>Valores positivos = crédito; negativos = débito</li>
              <li>Data em qualquer formato</li>
              <li>Sem cabeçalho obrigatório</li>
            </ul>
          </div>
          <DialogFooter><Button onClick={() => setShowGuide(false)}>Entendido</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </PdvLayout>
  );
}
