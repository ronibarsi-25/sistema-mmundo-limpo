import { useEffect, useRef, useState } from 'react';
import {
  Settings, Save, Upload, X, Tag, FileText,
  AlignLeft, AlignRight, AlignCenter, Image as ImageIcon
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { PdvLayout } from '@/components/layouts/PdvLayout';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import type { LabelConfig } from '@/types/types';

const PRESETS = [
  { label: '100 × 50 mm', value: '100x50', w: 100, h: 50 },
  { label: '50 × 25 mm', value: '50x25', w: 50, h: 25 },
  { label: '40 × 20 mm', value: '40x20', w: 40, h: 20 },
  { label: '80 × 40 mm', value: '80x40', w: 80, h: 40 },
  { label: '60 × 30 mm', value: '60x30', w: 60, h: 30 },
  { label: 'Personalizado', value: 'custom', w: 0, h: 0 },
];

const PAPER_SIZES = [
  { label: 'A4 (210 × 297 mm)', value: 'A4' },
  { label: 'A5 (148 × 210 mm)', value: 'A5' },
  { label: 'Carta (216 × 279 mm)', value: 'Carta' },
  { label: 'Ofício (216 × 356 mm)', value: 'Oficio' },
  { label: 'Rolo Térmico (contínua)', value: 'Termico' },
];

const LOGO_POSITIONS = [
  { label: 'Topo', value: 'top', Icon: AlignCenter },
  { label: 'Esquerda', value: 'left', Icon: AlignLeft },
  { label: 'Direita', value: 'right', Icon: AlignRight },
];

const DEFAULT_CONFIG: Omit<LabelConfig, 'id' | 'updated_at'> = {
  width_mm: 50, height_mm: 25, preset: '50x25',
  show_name: true, show_code: true, show_price: true, show_barcode: true, show_qr: false,
  logo_url: null, logo_position: 'top', logo_size_pct: 30,
  bg_image_url: null, bg_opacity: 20,
  cols: 4, rows: 6, paper_size: 'A4',
};

export default function PdvConfiguracaoEtiquetas() {
  const [cfg, setCfg] = useState<Omit<LabelConfig, 'id' | 'updated_at'>>(DEFAULT_CONFIG);
  const [configId, setConfigId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const [localLogoPreview, setLocalLogoPreview] = useState<string | null>(null);
  const [uploadingBg, setUploadingBg] = useState(false);
  const [localBgPreview, setLocalBgPreview] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const bgFileRef = useRef<HTMLInputElement>(null);

  useEffect(() => { loadConfig(); }, []);

  const loadConfig = async () => {
    const { data } = await supabase.from('label_config').select('*').order('updated_at', { ascending: false }).limit(1).maybeSingle();
    if (data) {
      const { id, updated_at, ...rest } = data as LabelConfig;
      setConfigId(id);
      setCfg(rest);
    }
  };

  const set = <K extends keyof typeof cfg>(key: K, val: (typeof cfg)[K]) =>
    setCfg(c => ({ ...c, [key]: val }));

  const handlePreset = (val: string) => {
    const p = PRESETS.find(x => x.value === val);
    if (!p) return;
    setCfg(c => ({ ...c, preset: val, ...(val !== 'custom' ? { width_mm: p.w, height_mm: p.h } : {}) }));
  };

  const handleColsRows = (type: 'cols' | 'rows', v: string) => {
    const n = Math.max(1, Math.min(type === 'cols' ? 10 : 20, parseInt(v) || 1));
    set(type, n);
  };

  const handleUploadLogo = async (file: File) => {
    if (!file.type.startsWith('image/')) { toast.error('Apenas imagens são aceitas (PNG, JPG, SVG)'); return; }
    if (file.size > 2 * 1024 * 1024) { toast.error('Imagem muito grande. Máximo: 2 MB'); return; }

    // Mostra preview local imediatamente enquanto faz upload
    const objectUrl = URL.createObjectURL(file);
    setLocalLogoPreview(objectUrl);
    setUploadingLogo(true);

    const ext = file.name.split('.').pop()?.toLowerCase() || 'png';
    const path = `logos/label_logo_${Date.now()}.${ext}`;
    const { error } = await supabase.storage
      .from('company-assets')
      .upload(path, file, { upsert: true, contentType: file.type });

    if (error) {
      console.error('Upload logo error:', error);
      toast.error(`Erro ao enviar logo: ${error.message}`);
      setLocalLogoPreview(null);
      setUploadingLogo(false);
      return;
    }

    const { data: urlData } = supabase.storage.from('company-assets').getPublicUrl(path);
    set('logo_url', urlData.publicUrl);
    // Após upload bem-sucedido, revoga o object URL local
    URL.revokeObjectURL(objectUrl);
    setLocalLogoPreview(null);
    setUploadingLogo(false);
    toast.success('Logo enviado com sucesso!');
  };

  const handleUploadBg = async (file: File) => {
    if (!file.type.startsWith('image/')) { toast.error('Apenas imagens são aceitas (PNG, JPG, SVG)'); return; }
    if (file.size > 5 * 1024 * 1024) { toast.error('Imagem muito grande. Máximo: 5 MB'); return; }
    const objectUrl = URL.createObjectURL(file);
    setLocalBgPreview(objectUrl);
    setUploadingBg(true);
    const ext = file.name.split('.').pop()?.toLowerCase() || 'png';
    const path = `backgrounds/label_bg_${Date.now()}.${ext}`;
    const { error } = await supabase.storage
      .from('company-assets')
      .upload(path, file, { upsert: true, contentType: file.type });
    if (error) {
      console.error('Upload bg error:', error);
      toast.error(`Erro ao enviar fundo: ${error.message}`);
      setLocalBgPreview(null);
      setUploadingBg(false);
      return;
    }
    const { data: urlData } = supabase.storage.from('company-assets').getPublicUrl(path);
    set('bg_image_url', urlData.publicUrl);
    URL.revokeObjectURL(objectUrl);
    setLocalBgPreview(null);
    setUploadingBg(false);
    toast.success('Imagem de fundo enviada com sucesso!');
  };

  const handleSave = async () => {
    if (cfg.width_mm <= 0 || cfg.height_mm <= 0) { toast.error('Dimensões inválidas'); return; }
    setSaving(true);
    let error;
    if (configId) {
      ({ error } = await supabase.from('label_config').update({ ...cfg, updated_at: new Date().toISOString() }).eq('id', configId));
    } else {
      const { data, error: e } = await supabase.from('label_config').insert({ ...cfg }).select().maybeSingle();
      error = e;
      if (data) setConfigId((data as LabelConfig).id);
    }
    setSaving(false);
    if (error) { toast.error('Erro ao salvar configuração'); return; }
    toast.success('Configuração de etiqueta salva!');
  };

  // Preview scale: safe guard against NaN when dimensions are 0
  const SCALE = 3.2;
  const safeW = cfg.width_mm > 0 ? cfg.width_mm : 50;
  const safeH = cfg.height_mm > 0 ? cfg.height_mm : 25;
  const previewW = Math.min(safeW * SCALE, 300);
  const previewH = safeH * SCALE * (previewW / (safeW * SCALE));
  // URL to show in preview: prefer committed URL, fall back to local object URL during upload
  const displayLogoUrl = cfg.logo_url || localLogoPreview;
  const displayBgUrl = cfg.bg_image_url || localBgPreview;

  return (
    <PdvLayout title="Configuração de Etiquetas">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* ─── CONFIGURAÇÕES ─── */}
        <div className="lg:col-span-2 space-y-5">

          {/* Tamanho */}
          <Section title="Tamanho da Etiqueta" icon={<Tag className="h-4 w-4" />}>
            <div className="space-y-3">
              <div>
                <Label className="text-sm mb-1.5 block">Preset</Label>
                <div className="flex flex-wrap gap-2">
                  {PRESETS.map(p => (
                    <button
                      key={p.value}
                      onClick={() => handlePreset(p.value)}
                      className={`px-3 py-1.5 rounded-md text-xs border transition-colors ${cfg.preset === p.value ? 'bg-primary text-primary-foreground border-primary' : 'bg-card border-border text-foreground hover:bg-muted'}`}
                    >
                      {p.label}
                    </button>
                  ))}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-sm mb-1.5 block">Largura (mm)</Label>
                  <Input type="number" min="10" max="500" value={cfg.width_mm}
                    onChange={e => { set('width_mm', parseFloat(e.target.value) || 0); set('preset', 'custom'); }}
                    className="px-3" />
                </div>
                <div>
                  <Label className="text-sm mb-1.5 block">Altura (mm)</Label>
                  <Input type="number" min="10" max="500" value={cfg.height_mm}
                    onChange={e => { set('height_mm', parseFloat(e.target.value) || 0); set('preset', 'custom'); }}
                    className="px-3" />
                </div>
              </div>
            </div>
          </Section>

          {/* Campos */}
          <Section title="Campos da Etiqueta" icon={<FileText className="h-4 w-4" />}>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {[
                { key: 'show_name', label: 'Nome do produto', desc: 'Exibe a descrição do produto' },
                { key: 'show_price', label: 'Preço de venda', desc: 'Exibe o preço em destaque' },
                { key: 'show_code', label: 'Código interno', desc: 'Código alfanumérico do produto' },
                { key: 'show_barcode', label: 'Código de barras', desc: 'Barras lineares (EAN/Code128)' },
                { key: 'show_qr', label: 'QR Code', desc: 'QR com código + nome + preço' },
              ].map(f => (
                <div key={f.key} className="flex items-center justify-between rounded-lg border border-border p-3 bg-card">
                  <div>
                    <p className="text-sm font-medium text-foreground">{f.label}</p>
                    <p className="text-xs text-muted-foreground">{f.desc}</p>
                  </div>
                  <Switch
                    checked={cfg[f.key as keyof typeof cfg] as boolean}
                    onCheckedChange={v => set(f.key as keyof typeof cfg, v as never)}
                  />
                </div>
              ))}
            </div>
          </Section>

          {/* Logo */}
          <Section title="Logo da Empresa" icon={<ImageIcon className="h-4 w-4" />}>
            <div className="space-y-3">
              <div className="flex items-start gap-4">
                {displayLogoUrl ? (
                  <div className="relative shrink-0">
                    <img src={displayLogoUrl} alt="Logo"
                      className={`w-20 h-20 object-contain rounded-md border border-border bg-muted ${uploadingLogo ? 'opacity-60' : ''}`} />
                    {uploadingLogo && (
                      <div className="absolute inset-0 flex items-center justify-center rounded-md bg-black/30">
                        <span className="text-white text-[10px] font-medium">Enviando...</span>
                      </div>
                    )}
                    {!uploadingLogo && (
                      <button onClick={() => { set('logo_url', null); setLocalLogoPreview(null); }}
                        className="absolute -top-1.5 -right-1.5 bg-destructive text-destructive-foreground rounded-full p-0.5 hover:opacity-80">
                        <X className="h-3 w-3" />
                      </button>
                    )}
                  </div>
                ) : (
                  <div className="shrink-0 w-20 h-20 rounded-md border-2 border-dashed border-border bg-muted/50 flex items-center justify-center">
                    <ImageIcon className="h-8 w-8 text-muted-foreground/40" />
                  </div>
                )}
                <div className="flex-1 min-w-0 space-y-2">
                  <input ref={fileRef} type="file" accept="image/png,image/jpeg,image/jpg,image/webp,image/svg+xml"
                    className="hidden"
                    onChange={e => {
                      if (e.target.files?.[0]) handleUploadLogo(e.target.files[0]);
                      // reset value so same file can be re-selected
                      e.target.value = '';
                    }} />
                  <Button variant="outline" size="sm" disabled={uploadingLogo} onClick={() => fileRef.current?.click()}>
                    <Upload className="h-3.5 w-3.5 mr-1.5" />
                    {uploadingLogo ? 'Enviando...' : displayLogoUrl ? 'Trocar Logo' : 'Enviar Logo'}
                  </Button>
                  <p className="text-xs text-muted-foreground">PNG, JPG, WEBP ou SVG · máx. 2 MB</p>
                </div>
              </div>

              {displayLogoUrl && (
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label className="text-sm mb-1.5 block">Posição</Label>
                    <div className="flex gap-2">
                      {LOGO_POSITIONS.map(({ label, value, Icon }) => (
                        <button key={value} onClick={() => set('logo_position', value as LabelConfig['logo_position'])}
                          className={`flex-1 flex flex-col items-center gap-1 py-2 rounded-md border text-xs transition-colors ${cfg.logo_position === value ? 'bg-primary text-primary-foreground border-primary' : 'bg-card border-border text-foreground hover:bg-muted'}`}>
                          <Icon className="h-3.5 w-3.5" />{label}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <Label className="text-sm mb-1.5 block">Tamanho do logo: {cfg.logo_size_pct}%</Label>
                    <input type="range" min="10" max="60" step="5" value={cfg.logo_size_pct}
                      onChange={e => set('logo_size_pct', parseInt(e.target.value))}
                      className="w-full accent-primary" />
                    <div className="flex justify-between text-xs text-muted-foreground mt-0.5"><span>10%</span><span>60%</span></div>
                  </div>
                </div>
              )}
            </div>
          </Section>

          {/* Fundo da Etiqueta */}
          <Section title="Imagem de Fundo (Sombreado)" icon={<ImageIcon className="h-4 w-4" />}>
            <div className="space-y-3">
              <p className="text-xs text-muted-foreground">
                Adicione uma imagem de fundo sombreada — ideal para marca d'água, textura ou padrão da empresa.
              </p>
              <div className="flex items-start gap-4">
                {displayBgUrl ? (
                  <div className="relative shrink-0">
                    <img src={displayBgUrl} alt="Fundo"
                      className={`w-20 h-14 object-cover rounded-md border border-border bg-muted ${uploadingBg ? 'opacity-60' : ''}`} />
                    {uploadingBg && (
                      <div className="absolute inset-0 flex items-center justify-center rounded-md bg-black/30">
                        <span className="text-white text-[10px] font-medium">Enviando...</span>
                      </div>
                    )}
                    {!uploadingBg && (
                      <button onClick={() => { set('bg_image_url', null); setLocalBgPreview(null); }}
                        className="absolute -top-1.5 -right-1.5 bg-destructive text-destructive-foreground rounded-full p-0.5 hover:opacity-80">
                        <X className="h-3 w-3" />
                      </button>
                    )}
                  </div>
                ) : (
                  <div className="shrink-0 w-20 h-14 rounded-md border-2 border-dashed border-border bg-muted/50 flex items-center justify-center">
                    <ImageIcon className="h-7 w-7 text-muted-foreground/30" />
                  </div>
                )}
                <div className="flex-1 min-w-0 space-y-2">
                  <input ref={bgFileRef} type="file" accept="image/png,image/jpeg,image/jpg,image/webp,image/svg+xml"
                    className="hidden"
                    onChange={e => { if (e.target.files?.[0]) handleUploadBg(e.target.files[0]); e.target.value = ''; }} />
                  <Button variant="outline" size="sm" disabled={uploadingBg} onClick={() => bgFileRef.current?.click()}>
                    <Upload className="h-3.5 w-3.5 mr-1.5" />
                    {uploadingBg ? 'Enviando...' : displayBgUrl ? 'Trocar Fundo' : 'Enviar Imagem de Fundo'}
                  </Button>
                  <p className="text-xs text-muted-foreground">PNG, JPG ou WEBP · máx. 5 MB</p>
                </div>
              </div>
              {displayBgUrl && (
                <div>
                  <Label className="text-sm mb-1.5 block">
                    Opacidade: <span className="font-semibold text-foreground">{cfg.bg_opacity}%</span>
                  </Label>
                  <input type="range" min="5" max="60" step="5" value={cfg.bg_opacity}
                    onChange={e => set('bg_opacity', parseInt(e.target.value))}
                    className="w-full accent-primary" />
                  <div className="flex justify-between text-xs text-muted-foreground mt-0.5">
                    <span>5% (sutil)</span><span>60% (escuro)</span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1.5">
                    💡 Use 10–25% para sombreado sutil que não dificulta a leitura.
                  </p>
                </div>
              )}
            </div>
          </Section>

          {/* Layout de impressão */}
          <Section title="Layout de Impressão" icon={<Settings className="h-4 w-4" />}>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <Label className="text-sm mb-1.5 block">Tipo de folha</Label>
                <Select value={cfg.paper_size} onValueChange={v => set('paper_size', v as LabelConfig['paper_size'])}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {PAPER_SIZES.map(p => <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-sm mb-1.5 block">Colunas por página</Label>
                <Input type="number" min="1" max="10" value={cfg.cols}
                  onChange={e => handleColsRows('cols', e.target.value)} className="px-3" />
              </div>
              <div>
                <Label className="text-sm mb-1.5 block">Linhas por página</Label>
                <Input type="number" min="1" max="20" value={cfg.rows}
                  onChange={e => handleColsRows('rows', e.target.value)} className="px-3" />
              </div>
            </div>
            <div className="mt-2 p-3 bg-muted/50 rounded-md">
              <p className="text-xs text-muted-foreground">
                Total: <span className="font-semibold text-foreground">{cfg.cols * cfg.rows} etiquetas</span> por página
                {' '}· Folha <span className="font-semibold text-foreground">{cfg.paper_size}</span>
              </p>
            </div>
          </Section>

          <Button className="w-full md:w-auto" disabled={saving} onClick={handleSave}>
            <Save className="h-4 w-4 mr-2" />
            {saving ? 'Salvando...' : 'Salvar Configuração'}
          </Button>
        </div>

        {/* ─── PREVIEW ─── */}
        <div className="space-y-3">
          <div className="bg-card border border-border rounded-lg p-4 sticky top-4">
            <div className="flex items-center gap-2 mb-3">
              <p className="text-sm font-semibold text-foreground">Pré-visualização</p>
              <Badge variant="outline" className="text-xs font-mono">{cfg.width_mm}×{cfg.height_mm}mm</Badge>
            </div>
            <Separator className="mb-4" />

            {/* Single label preview */}
            <div className="flex justify-center mb-4">
              <div
                style={{
                  width: previewW, height: previewH, minHeight: 60,
                  backgroundImage: displayBgUrl ? `url(${displayBgUrl})` : undefined,
                  backgroundSize: 'cover', backgroundPosition: 'center',
                  position: 'relative',
                }}
                className="border-2 border-dashed border-primary/40 rounded overflow-hidden shadow-sm"
              >
                {/* camada de opacidade sobre o fundo */}
                {displayBgUrl && (
                  <div style={{ position: 'absolute', inset: 0, background: `rgba(255,255,255,${1 - cfg.bg_opacity / 100})`, pointerEvents: 'none' }} />
                )}
                <div style={{ position: 'relative', zIndex: 1 }} className="flex flex-col items-center justify-center w-full h-full gap-0.5 p-2">
                  {displayLogoUrl && cfg.logo_position === 'top' && (
                    <img src={displayLogoUrl} alt="logo"
                      style={{ width: `${cfg.logo_size_pct}%`, maxHeight: previewH * 0.35, objectFit: 'contain' }} />
                  )}
                  <div className={`flex ${displayLogoUrl && cfg.logo_position !== 'top' ? 'flex-row gap-1 items-center' : 'flex-col items-center'} w-full`}>
                    {displayLogoUrl && cfg.logo_position === 'left' && (
                      <img src={displayLogoUrl} alt="logo"
                        style={{ width: `${cfg.logo_size_pct}%`, maxHeight: previewH * 0.6, objectFit: 'contain', flexShrink: 0 }} />
                    )}
                    <div className="flex flex-col items-center flex-1 min-w-0 gap-0.5">
                      {cfg.show_name && <p className="text-[8px] font-semibold text-gray-800 text-center leading-tight truncate w-full">Produto Exemplo</p>}
                      {cfg.show_code && <p className="text-[6px] text-gray-500 font-mono">COD-001</p>}
                      {cfg.show_barcode && (
                        <svg viewBox="0 0 80 16" className="w-full max-w-[70px] h-3">
                          {Array.from({ length: 30 }, (_, i) => (
                            <rect key={i} x={i * 2.5 + 2} y={0} width={i % 3 === 0 ? 2 : 1} height={14}
                              fill={i % 4 === 0 ? '#fff' : '#333'} />
                          ))}
                        </svg>
                      )}
                      {cfg.show_price && <p className="text-[10px] font-bold text-emerald-700">R$ 12,99</p>}
                      {cfg.show_qr && (
                        <svg viewBox="0 0 20 20" className="w-5 h-5">
                          <rect width="20" height="20" fill="white" />
                          {[0, 6, 14].map(ox => [0, 6, 14].map(oy => (
                            <rect key={`${ox}-${oy}`} x={ox} y={oy} width="4" height="4" fill="#333" rx="0.5" />
                          )))}
                          <rect x="1.5" y="1.5" width="1" height="1" fill="white" />
                          <rect x="7.5" y="1.5" width="1" height="1" fill="white" />
                          <rect x="1.5" y="7.5" width="1" height="1" fill="white" />
                          {[8, 10, 12].map(x => <rect key={x} x={x} y={8} width="1" height="1" fill="#333" />)}
                          {[8, 10, 12].map(y => <rect key={y} x={8} y={y} width="1" height="1" fill="#333" />)}
                        </svg>
                      )}
                    </div>
                    {displayLogoUrl && cfg.logo_position === 'right' && (
                      <img src={displayLogoUrl} alt="logo"
                        style={{ width: `${cfg.logo_size_pct}%`, maxHeight: previewH * 0.6, objectFit: 'contain', flexShrink: 0 }} />
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Page grid preview (mini) */}
            <Separator className="my-3" />
            <p className="text-xs text-muted-foreground mb-2">Grade na folha ({cfg.cols}×{cfg.rows})</p>
            <div
              className="bg-white border border-border rounded p-1.5 mx-auto"
              style={{ display: 'grid', gridTemplateColumns: `repeat(${Math.min(cfg.cols, 8)}, 1fr)`, gap: 2, maxWidth: 200 }}
            >
              {Array.from({ length: Math.min(cfg.cols * cfg.rows, 64) }).map((_, i) => (
                <div key={i} className="border border-dashed border-primary/30 rounded-[1px]"
                  style={{ aspectRatio: `${safeW}/${safeH}`, background: i < 3 ? 'hsl(var(--primary)/0.1)' : 'white' }} />
              ))}
            </div>
            <p className="text-xs text-center text-muted-foreground mt-2">
              {cfg.cols * cfg.rows} etiquetas / {cfg.paper_size}
            </p>
          </div>
        </div>
      </div>
    </PdvLayout>
  );
}

function Section({ title, icon, children }: { title: string; icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="bg-card border border-border rounded-lg p-4 space-y-3">
      <div className="flex items-center gap-2">
        <span className="text-primary">{icon}</span>
        <p className="text-sm font-semibold text-foreground">{title}</p>
      </div>
      <Separator />
      {children}
    </div>
  );
}
