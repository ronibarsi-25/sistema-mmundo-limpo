import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Settings, MessageCircle, Globe, Database, Download, Loader2, CheckCircle2, AlertTriangle, Printer, Ruler, Share2, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Skeleton } from '@/components/ui/skeleton';
import { PdvLayout } from '@/components/layouts/PdvLayout';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';

interface Config {
  whatsapp_number: string;
  whatsapp_message: string;
  site_url: string;
  site_name: string;
  support_email: string;
  invoice_footer: string;
  auto_print_cupom: boolean;
  printer_width_mm: number;
  printer_model: string;
}

const emptyConfig: Config = {
  whatsapp_number: '', whatsapp_message: 'Ola! Gostaria de informacoes sobre os produtos da Mundo Limpo.',
  site_url: '', site_name: 'Mundo Limpo', support_email: '', invoice_footer: '',
  auto_print_cupom: false, printer_width_mm: 80, printer_model: '',
};

export default function PdvConfiguracoes() {
  const [config, setConfig] = useState<Config>(emptyConfig);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [dbStats, setDbStats] = useState<{ products: number; customers: number; invoices: number; transactions: number } | null>(null);
  const [loadingStats, setLoadingStats] = useState(true);

  useEffect(() => { loadAll(); }, []);

  const loadAll = async () => {
    setLoading(true);
    setLoadingStats(true);
    const [compRes, statsRes] = await Promise.all([
      supabase.from('company').select('*').limit(1).maybeSingle(),
      Promise.all([
        supabase.from('pdv_products').select('id', { count: 'exact', head: true }),
        supabase.from('customers').select('id', { count: 'exact', head: true }),
        supabase.from('pdv_invoices').select('id', { count: 'exact', head: true }),
        supabase.from('transactions').select('id', { count: 'exact', head: true }),
      ]),
    ]);
    if (compRes.data) {
      const d = compRes.data as any;
      setConfig({
        whatsapp_number: d.whatsapp || '',
        whatsapp_message: d.whatsapp_message || emptyConfig.whatsapp_message,
        site_url: d.website || '',
        site_name: d.nome_fantasia || 'Mundo Limpo',
        support_email: d.email || '',
        invoice_footer: d.invoice_footer || '',
        auto_print_cupom: d.auto_print_cupom ?? false,
        printer_width_mm: d.printer_width_mm ?? 80,
        printer_model: d.printer_model || '',
      });
    }
    const [p, c, i, t] = statsRes;
    setDbStats({ products: p.count || 0, customers: c.count || 0, invoices: i.count || 0, transactions: t.count || 0 });
    setLoading(false);
    setLoadingStats(false);
  };

  const handleSave = async () => {
    setSaving(true);
    const { data: existing } = await supabase.from('company').select('id').limit(1).maybeSingle();
    const payload = {
      whatsapp: config.whatsapp_number, whatsapp_message: config.whatsapp_message,
      website: config.site_url, email: config.support_email, invoice_footer: config.invoice_footer,
      auto_print_cupom: config.auto_print_cupom, printer_width_mm: config.printer_width_mm,
      printer_model: config.printer_model,
    };
    const { error } = existing
      ? await supabase.from('company').update(payload).eq('id', existing.id)
      : await supabase.from('company').insert(payload);
    setSaving(false);
    if (error) { toast.error('Erro ao salvar: ' + error.message); return; }
    toast.success('Configuracoes salvas!');
  };

  const handleExport = async () => {
    setExporting(true);
    try {
      const [prodRes, custRes, invRes, trxRes] = await Promise.all([
        supabase.from('pdv_products').select('*'),
        supabase.from('customers').select('*'),
        supabase.from('pdv_invoices').select('*'),
        supabase.from('transactions').select('*'),
      ]);
      const exportData = {
        exported_at: new Date().toISOString(),
        products: prodRes.data || [],
        customers: custRes.data || [],
        invoices: invRes.data || [],
        transactions: trxRes.data || [],
      };
      const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `mundolimpo-backup-${new Date().toISOString().split('T')[0]}.json`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success('Backup exportado com sucesso!');
    } catch (err) {
      toast.error('Erro ao exportar dados');
    } finally {
      setExporting(false);
    }
  };

  const f = (k: keyof Config, v: string) => setConfig(p => ({ ...p, [k]: v }));

  const whatsappPreviewUrl = config.whatsapp_number
    ? `https://wa.me/55${config.whatsapp_number.replace(/\D/g, '')}?text=${encodeURIComponent(config.whatsapp_message)}`
    : '';

  return (
    <PdvLayout title="Configuracoes">
      <div className="max-w-3xl space-y-6">

        {/* WhatsApp */}
        <div className="bg-card border border-border rounded-lg p-5">
          <div className="flex items-center gap-2 mb-4">
            <MessageCircle className="h-4 w-4 text-success shrink-0" />
            <p className="text-sm font-semibold text-foreground">Integracao WhatsApp</p>
          </div>
          {loading ? <Skeleton className="h-20 w-full bg-muted" /> : (
            <div className="space-y-4">
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">Numero WhatsApp (DDD + numero)</Label>
                <Input value={config.whatsapp_number} onChange={e => f('whatsapp_number', e.target.value)} placeholder="11999999999" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">Mensagem padrao</Label>
                <Textarea value={config.whatsapp_message} onChange={e => f('whatsapp_message', e.target.value)} rows={3} />
              </div>
              {whatsappPreviewUrl && (
                <a href={whatsappPreviewUrl} target="_blank" rel="noopener noreferrer">
                  <Button variant="outline" size="sm" className="text-success border-success/40 hover:bg-success/10">
                    <MessageCircle className="h-3.5 w-3.5 mr-1.5" />
                    Testar Link WhatsApp
                  </Button>
                </a>
              )}
            </div>
          )}
        </div>

        {/* Impressora */}
        <div className="bg-card border border-border rounded-lg p-5">
          <div className="flex items-center gap-2 mb-4">
            <Printer className="h-4 w-4 text-primary shrink-0" />
            <p className="text-sm font-semibold text-foreground">Impressora de Cupom</p>
          </div>
          {loading ? <Skeleton className="h-20 w-full bg-muted" /> : (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-foreground">Imprimir automaticamente</p>
                  <p className="text-xs text-muted-foreground">Pula a pergunta e imprime o cupom logo apos a venda</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input type="checkbox" className="sr-only peer" checked={config.auto_print_cupom} onChange={e => f('auto_print_cupom', e.target.checked as any)} />
                  <div className="w-11 h-6 bg-muted peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary" />
                </label>
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">Modelo da Impressora</Label>
                <Input value={config.printer_model} onChange={e => f('printer_model', e.target.value)} placeholder="Ex: Epson TM-T20X" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">Largura do Papel (mm)</Label>
                <div className="flex items-center gap-2">
                  <Ruler className="h-4 w-4 text-muted-foreground shrink-0" />
                  <Input type="number" min="58" max="80" value={config.printer_width_mm} onChange={e => f('printer_width_mm', e.target.value)} className="w-32" />
                  <span className="text-xs text-muted-foreground">mm</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Site/System */}
        <div className="bg-card border border-border rounded-lg p-5">
          <div className="flex items-center gap-2 mb-4">
            <Globe className="h-4 w-4 text-info shrink-0" />
            <p className="text-sm font-semibold text-foreground">Site e Sistema</p>
          </div>
          {loading ? <Skeleton className="h-20 w-full bg-muted" /> : (
            <div className="space-y-4">
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">URL do Site</Label>
                <Input value={config.site_url} onChange={e => f('site_url', e.target.value)} placeholder="https://mundolimpo.com.br" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">E-mail de Suporte</Label>
                <Input type="email" value={config.support_email} onChange={e => f('support_email', e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">Rodape das Notas Fiscais</Label>
                <Textarea value={config.invoice_footer} onChange={e => f('invoice_footer', e.target.value)} rows={2} placeholder="Obrigado pela preferencia!" />
              </div>
            </div>
          )}
        </div>

        {/* Database stats */}
        <div className="bg-card border border-border rounded-lg p-5">
          <div className="flex items-center gap-2 mb-4">
            <Database className="h-4 w-4 text-primary shrink-0" />
            <p className="text-sm font-semibold text-foreground">Banco de Dados</p>
          </div>
          {loadingStats ? (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-16 bg-muted rounded-lg" />)}
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
              {[
                { label: 'Produtos', value: dbStats?.products || 0 },
                { label: 'Clientes', value: dbStats?.customers || 0 },
                { label: 'Notas Fiscais', value: dbStats?.invoices || 0 },
                { label: 'Lancamentos', value: dbStats?.transactions || 0 },
              ].map(s => (
                <div key={s.label} className="bg-muted/40 rounded-lg p-3 text-center">
                  <p className="text-xl font-bold text-foreground">{s.value.toLocaleString()}</p>
                  <p className="text-xs text-muted-foreground">{s.label}</p>
                </div>
              ))}
            </div>
          )}
          <div className="flex items-center gap-2 p-3 bg-success/5 border border-success/20 rounded-md">
            <CheckCircle2 className="h-4 w-4 text-success shrink-0" />
            <p className="text-xs text-muted-foreground">Supabase conectado — dados armazenados com seguranca na nuvem.</p>
          </div>
        </div>

        {/* Backup */}
        <div className="bg-card border border-border rounded-lg p-5">
          <div className="flex items-center gap-2 mb-2">
            <Download className="h-4 w-4 text-accent shrink-0" />
            <p className="text-sm font-semibold text-foreground">Backup de Dados</p>
          </div>
          <p className="text-xs text-muted-foreground mb-4 text-pretty">Exporte todos os dados do sistema em formato JSON. Inclui produtos, clientes, notas fiscais e transacoes financeiras.</p>
          <Button variant="outline" onClick={handleExport} disabled={exporting}>
            {exporting ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Download className="h-4 w-4 mr-2" />}
            {exporting ? 'Exportando...' : 'Exportar Backup (JSON)'}
          </Button>
        </div>

        {/* Meta Pixel & Marketing */}
        <div className="bg-card border border-border rounded-lg p-5">
          <div className="flex items-center justify-between mb-2 flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <Share2 className="h-4 w-4 text-primary shrink-0" />
              <p className="text-sm font-semibold text-foreground">Meta Pixel (Facebook Ads)</p>
            </div>
            <Link to="/pdv/marketing">
              <Button variant="outline" size="sm" className="gap-1.5 text-xs">
                <span>Configurar & Testar Pixel</span>
                <ArrowRight className="h-3.5 w-3.5" />
              </Button>
            </Link>
          </div>
          <p className="text-xs text-muted-foreground text-pretty">
            Conecte o Meta Pixel ID para rastrear visitas, visualizações de produtos, adições ao carrinho e compras no PDV para criar públicos personalizados e campanhas de anúncios na Meta.
          </p>
        </div>

        <Button className="w-full md:w-auto" onClick={handleSave} disabled={saving}>
          {saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Salvar Configuracoes
        </Button>
      </div>
    </PdvLayout>
  );
}
