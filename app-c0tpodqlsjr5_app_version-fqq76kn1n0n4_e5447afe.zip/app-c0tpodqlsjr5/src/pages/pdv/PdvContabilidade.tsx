import { useEffect, useState } from 'react';
import { Download, BookOpen, Plus, Pencil } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { PdvLayout } from '@/components/layouts/PdvLayout';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';

interface Account {
  id: string; code: string; name: string; type: string; parent_id: string | null; active: boolean;
}
interface Transaction {
  id: string; description: string; type: string; amount: number; category: string; payment_method: string; transaction_date: string;
}

const TYPE_LABELS: Record<string, string> = { ativo: 'Ativo', passivo: 'Passivo', receita: 'Receita', despesa: 'Despesa', patrimonio: 'Patrimônio' };
const TYPE_COLORS: Record<string, string> = { ativo: 'text-success', passivo: 'text-destructive', receita: 'text-primary', despesa: 'text-warning', patrimonio: 'text-muted-foreground' };

export default function PdvContabilidade() {
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAccount, setShowAccount] = useState(false);
  const [editAccount, setEditAccount] = useState<Account | null>(null);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ code: '', name: '', type: 'receita', parent_id: '' });
  const [exportStart, setExportStart] = useState(() => { const d = new Date(); d.setMonth(d.getMonth() - 1); return d.toISOString().split('T')[0]; });
  const [exportEnd, setExportEnd] = useState(new Date().toISOString().split('T')[0]);

  useEffect(() => { loadAccounts(); loadTransactions(); }, []);

  const loadAccounts = async () => {
    setLoading(true);
    const { data } = await supabase.from('accounting_accounts').select('*').order('code');
    setAccounts((data as Account[]) || []);
    setLoading(false);
  };

  const loadTransactions = async () => {
    const { data } = await supabase.from('transactions').select('id,description,type,amount,category,payment_method,transaction_date').order('transaction_date', { ascending: false }).limit(200);
    setTransactions((data as Transaction[]) || []);
  };

  const openNew = () => { setEditAccount(null); setForm({ code: '', name: '', type: 'receita', parent_id: '' }); setShowAccount(true); };
  const openEdit = (a: Account) => { setEditAccount(a); setForm({ code: a.code, name: a.name, type: a.type, parent_id: a.parent_id || '' }); setShowAccount(true); };

  const saveAccount = async () => {
    if (!form.code.trim() || !form.name.trim()) { toast.error('Preencha código e nome'); return; }
    setSaving(true);
    const payload = { code: form.code, name: form.name, type: form.type, parent_id: form.parent_id || null };
    let error;
    if (editAccount) {
      ({ error } = await supabase.from('accounting_accounts').update(payload).eq('id', editAccount.id));
    } else {
      ({ error } = await supabase.from('accounting_accounts').insert(payload));
    }
    setSaving(false);
    if (error) { toast.error('Erro: ' + error.message); return; }
    toast.success(editAccount ? 'Conta atualizada!' : 'Conta criada!');
    setShowAccount(false);
    loadAccounts();
  };

  const exportCSV = () => {
    const filtered = transactions.filter(t => t.transaction_date >= exportStart && t.transaction_date <= exportEnd);
    if (filtered.length === 0) { toast.error('Nenhuma transação no período'); return; }
    const header = 'Data;Descrição;Tipo;Categoria;Valor;Forma Pagamento';
    const rows = filtered.map(t => [
      new Date(t.transaction_date + 'T00:00:00').toLocaleDateString('pt-BR'),
      `"${t.description}"`, t.type === 'receita' ? 'Receita' : 'Despesa',
      t.category, t.amount.toFixed(2).replace('.', ','), t.payment_method,
    ].join(';'));
    const csv = [header, ...rows].join('\n');
    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `lancamentos_${exportStart}_${exportEnd}.csv`;
    a.click(); URL.revokeObjectURL(url);
    toast.success(`${filtered.length} lançamentos exportados!`);
  };

  const exportSPED = () => {
    const filtered = transactions.filter(t => t.transaction_date >= exportStart && t.transaction_date <= exportEnd);
    if (filtered.length === 0) { toast.error('Nenhuma transação no período'); return; }
    const lines = ['|0000|LECD|01|Mundo Limpo|00000000000001|RS|SP|0001|1|S|'];
    filtered.forEach(t => {
      const dateFormatted = t.transaction_date.replace(/-/g, '');
      lines.push(`|I050|${dateFormatted}|${t.amount.toFixed(2)}|${t.type === 'receita' ? '3.1' : '4.2'}|${t.description}|`);
    });
    lines.push('|9999|');
    const blob = new Blob([lines.join('\n')], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `sped_${exportStart}_${exportEnd}.txt`;
    a.click(); URL.revokeObjectURL(url);
    toast.success('SPED exportado!');
  };

  const ff = (k: string, v: string) => setForm(p => ({ ...p, [k]: v }));

  const rootAccounts = accounts.filter(a => !a.parent_id);

  return (
    <PdvLayout title="Exportação Contábil" actions={
      <Button size="sm" onClick={openNew}><Plus className="h-4 w-4 mr-1.5" />Nova Conta</Button>
    }>
      <div className="space-y-4">
        <Tabs defaultValue="exportar">
          <TabsList>
            <TabsTrigger value="exportar">Exportar</TabsTrigger>
            <TabsTrigger value="plano">Plano de Contas</TabsTrigger>
          </TabsList>

          <TabsContent value="exportar" className="mt-4">
            <div className="bg-card border border-border rounded-lg p-6 space-y-6">
              <div>
                <h3 className="font-semibold mb-3">Período de Exportação</h3>
                <div className="flex flex-col md:flex-row gap-4 items-end">
                  <div className="space-y-1.5 flex-1">
                    <Label className="text-sm font-normal">Data Inicial</Label>
                    <Input type="date" value={exportStart} onChange={e => setExportStart(e.target.value)} />
                  </div>
                  <div className="space-y-1.5 flex-1">
                    <Label className="text-sm font-normal">Data Final</Label>
                    <Input type="date" value={exportEnd} onChange={e => setExportEnd(e.target.value)} />
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <h3 className="font-semibold">Formatos Disponíveis</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="border border-border rounded-lg p-4 space-y-2">
                    <div className="flex items-center gap-2">
                      <Download className="h-5 w-5 text-primary" />
                      <h4 className="font-medium">Planilha CSV</h4>
                    </div>
                    <p className="text-sm text-muted-foreground text-pretty">Exporta todos os lançamentos financeiros do período em formato CSV, compatível com Excel e outros softwares de contabilidade.</p>
                    <Button size="sm" onClick={exportCSV}><Download className="h-4 w-4 mr-1.5" />Exportar CSV</Button>
                  </div>
                  <div className="border border-border rounded-lg p-4 space-y-2">
                    <div className="flex items-center gap-2">
                      <BookOpen className="h-5 w-5 text-primary" />
                      <h4 className="font-medium">SPED Contábil</h4>
                    </div>
                    <p className="text-sm text-muted-foreground text-pretty">Gera arquivo no formato SPED (Sistema Público de Escrituração Digital) para entrega ao fisco.</p>
                    <Button size="sm" variant="outline" onClick={exportSPED}><BookOpen className="h-4 w-4 mr-1.5" />Exportar SPED</Button>
                  </div>
                </div>
              </div>

              <div className="bg-muted/40 rounded-lg p-4 text-sm text-muted-foreground">
                <p className="font-medium text-foreground mb-1">Nota sobre o SPED</p>
                <p className="text-pretty">O arquivo SPED gerado é simplificado. Para uso oficial, recomenda-se validação em software homologado pela Receita Federal. Consulte seu contador.</p>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="plano" className="mt-4">
            <div className="bg-card border border-border rounded-lg overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead><tr className="border-b border-border bg-muted/40">
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Código</th>
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Nome</th>
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Tipo</th>
                    <th className="text-center px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Status</th>
                    <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Ação</th>
                  </tr></thead>
                  <tbody className="divide-y divide-border">
                    {loading ? Array.from({ length: 5 }).map((_, i) => <tr key={i}><td colSpan={5} className="px-4 py-3"><Skeleton className="h-5 w-full bg-muted" /></td></tr>)
                      : accounts.map(a => (
                        <tr key={a.id} className="hover:bg-muted/30">
                          <td className="px-4 py-3 font-mono text-xs whitespace-nowrap">{a.code}</td>
                          <td className={`px-4 py-3 whitespace-nowrap ${a.parent_id ? 'pl-8' : 'font-semibold'}`}>{a.name}</td>
                          <td className={`px-4 py-3 whitespace-nowrap text-sm font-medium ${TYPE_COLORS[a.type] || 'text-foreground'}`}>{TYPE_LABELS[a.type] || a.type}</td>
                          <td className="px-4 py-3 text-center whitespace-nowrap"><Badge variant={a.active ? 'secondary' : 'outline'} className="text-xs">{a.active ? 'Ativa' : 'Inativa'}</Badge></td>
                          <td className="px-4 py-3 text-right whitespace-nowrap"><Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openEdit(a)}><Pencil className="h-3.5 w-3.5" /></Button></td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      <Dialog open={showAccount} onOpenChange={setShowAccount}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-sm">
          <DialogHeader><DialogTitle className="text-balance">{editAccount ? 'Editar' : 'Nova'} Conta Contábil</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5"><Label className="text-sm font-normal">Código *</Label><Input value={form.code} onChange={e => ff('code', e.target.value)} placeholder="1.1.1" /></div>
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">Tipo *</Label>
                <Select value={form.type} onValueChange={v => ff('type', v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{Object.entries(TYPE_LABELS).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Nome *</Label><Input value={form.name} onChange={e => ff('name', e.target.value)} /></div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Conta Pai</Label>
              <Select value={form.parent_id || 'none'} onValueChange={v => ff('parent_id', v === 'none' ? '' : v)}>
                <SelectTrigger><SelectValue placeholder="Nenhuma (conta raiz)" /></SelectTrigger>
                <SelectContent><SelectItem value="none">Nenhuma (raiz)</SelectItem>{rootAccounts.map(a => <SelectItem key={a.id} value={a.id}>{a.code} - {a.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter className="gap-2"><Button variant="outline" onClick={() => setShowAccount(false)}>Cancelar</Button><Button onClick={saveAccount} disabled={saving}>Salvar</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </PdvLayout>
  );
}
