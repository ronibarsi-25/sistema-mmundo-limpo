import { useEffect, useState } from 'react';
import { Plus, Eye, DollarSign, TrendingDown, TrendingUp, CheckCircle, Clock, AlertCircle, CalendarCheck, ArrowRight, Coins, Pencil, Trash2, RefreshCcw, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { PdvLayout } from '@/components/layouts/PdvLayout';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';

interface Bill {
  id: string; type: 'pagar' | 'receber'; description: string; total_amount: number;
  installments: number; category: string; notes: string | null;
  supplier_id: string | null; customer_id: string | null;
  created_at: string;
  suppliers?: { razao_social: string } | null;
  customers?: { name: string } | null;
}

interface BillInstallment {
  id: string; bill_id: string; installment_number: number; amount: number;
  due_date: string; paid_date: string | null; paid_amount: number | null;
  partial_paid_amount: number | null; remaining_amount: number | null;
  status: 'pendente' | 'pago' | 'vencido' | 'cancelado' | 'parcial';
  payment_method: string; notes: string | null;
}

interface MonthlyCycle {
  id: string; month: number; year: number; type: string;
  status: 'aberto' | 'fechado'; pending_total: number; carried_over: number;
  notes: string | null; closed_at: string | null; created_at: string;
}

const today = new Date().toISOString().split('T')[0];
const curMonth = new Date().getMonth() + 1;
const curYear  = new Date().getFullYear();

const MONTH_NAMES = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
const YEARS = Array.from({ length: 5 }, (_, i) => curYear - i);

const STATUS_MAP: Record<string, { label: string; icon: typeof Clock; cls: string }> = {
  pendente:  { label: 'Pendente',  icon: Clock,        cls: 'text-warning bg-warning/10 border-warning/30' },
  pago:      { label: 'Pago',      icon: CheckCircle,  cls: 'text-success bg-success/10 border-success/30' },
  vencido:   { label: 'Vencido',   icon: AlertCircle,  cls: 'text-destructive bg-destructive/10 border-destructive/30' },
  cancelado: { label: 'Cancelado', icon: AlertCircle,  cls: 'text-muted-foreground bg-muted/40 border-border' },
  parcial:   { label: 'Parcial',   icon: Coins,        cls: 'text-primary bg-primary/10 border-primary/30' },
};

const PAY_METHODS = ['dinheiro','pix','cartao_debito','cartao_credito','transferencia','boleto'];
const PAY_LABELS: Record<string,string> = { dinheiro:'Dinheiro', pix:'PIX', cartao_debito:'Débito', cartao_credito:'Crédito', transferencia:'Transferência', boleto:'Boleto' };

const CATEGORIES_PAGAR   = ['Fornecedor','Aluguel','Salários','Energia','Água','Internet','Impostos','Manutenção','Marketing','Outros'];
const CATEGORIES_RECEBER = ['Venda','Serviço','Aluguel','Empréstimo','Outros'];

const fmt = (v: number) => `R$ ${(v || 0).toFixed(2)}`;

// Garante valor numérico seguro, nunca NaN nem null
const safeNum = (v: number | null | undefined, fallback = 0) =>
  v != null && !isNaN(Number(v)) ? Number(v) : fallback;

export default function PdvContasPagar() {
  const [bills, setBills]                           = useState<Bill[]>([]);
  const [installments, setInstallments]             = useState<BillInstallment[]>([]);
  const [cycles, setCycles]                         = useState<MonthlyCycle[]>([]);
  const [suppliers, setSuppliers]                   = useState<{ id: string; razao_social: string }[]>([]);
  const [customers, setCustomers]                   = useState<{ id: string; name: string }[]>([]);
  const [loading, setLoading]                       = useState(true);
  const [activeTab, setActiveTab]                   = useState('pagar');
  const [showNew, setShowNew]                       = useState(false);
  const [showDetail, setShowDetail]                 = useState<Bill | null>(null);
  const [detailInstallments, setDetailInstallments] = useState<BillInstallment[]>([]);
  const [loadingDetail, setLoadingDetail]           = useState(false);
  // Pay dialog — armazena bill_type separado para não depender de showDetail
  const [showPay, setShowPay]                       = useState<{ inst: BillInstallment; billType: 'pagar' | 'receber' } | null>(null);
  const [payMethod, setPayMethod]                   = useState('dinheiro');
  const [payAmount, setPayAmount]                   = useState('');
  const [saving, setSaving]                         = useState(false);
  const [showCloseCycle, setShowCloseCycle]         = useState(false);
  const [closingNotes, setClosingNotes]             = useState('');
  const [cycleClosing, setCycleClosing]             = useState(false);
  // Edit bill dialog
  const [showEditBill, setShowEditBill]             = useState<Bill | null>(null);
  const [editBillForm, setEditBillForm]             = useState({ description: '', total_amount: '', category: '', supplier_id: '', customer_id: '', notes: '' });
  // Edit installment dialog
  const [showEditInst, setShowEditInst]             = useState<BillInstallment | null>(null);
  const [editInstForm, setEditInstForm]             = useState({ due_date: '', amount: '', notes: '' });
  // Delete bill confirm
  const [confirmDelete, setConfirmDelete]           = useState<Bill | null>(null);

  // Filtro de mês/ano
  const [filterMonth, setFilterMonth] = useState(curMonth);
  const [filterYear,  setFilterYear]  = useState(curYear);
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [resetting, setResetting] = useState(false);

  const [form, setForm] = useState({
    type: 'pagar', description: '', total_amount: '', installments: '1',
    category: 'Outros', supplier_id: '', customer_id: '', notes: '', first_due_date: today,
  });

  useEffect(() => { load(); loadSuppliers(); loadCustomers(); }, []);
  useEffect(() => { if (showDetail) loadDetail(showDetail.id); }, [showDetail]);

  const load = async () => {
    setLoading(true);
    const [{ data: b }, { data: i }, { data: c }] = await Promise.all([
      supabase.from('bills').select('*, suppliers(razao_social), customers(name)').order('created_at', { ascending: false }),
      supabase.from('bill_installments').select('*').order('due_date'),
      supabase.from('monthly_cycles').select('*').order('year', { ascending: false }).order('month', { ascending: false }).limit(24),
    ]);
    setBills((b as Bill[]) || []);
    setCycles((c as MonthlyCycle[]) || []);
    // Auto-vencido (exclui status 'pago' e 'cancelado')
    const now = today;
    const rawInst = (i as BillInstallment[]) || [];
    const toUpdate = rawInst.filter(x => (x.status === 'pendente' || x.status === 'parcial') && x.due_date < now);
    if (toUpdate.length > 0) {
      await supabase.from('bill_installments').update({ status: 'vencido' }).in('id', toUpdate.map(x => x.id));
      setInstallments(rawInst.map(x =>
        toUpdate.find(u => u.id === x.id) ? { ...x, status: 'vencido' as const } : x
      ));
    } else {
      setInstallments(rawInst);
    }
    setLoading(false);
  };

  const loadDetail = async (billId: string) => {
    setLoadingDetail(true);
    const { data } = await supabase.from('bill_installments').select('*').eq('bill_id', billId).order('installment_number');
    setDetailInstallments((data as BillInstallment[]) || []);
    setLoadingDetail(false);
  };

  const loadSuppliers = async () => { const { data } = await supabase.from('suppliers').select('id,razao_social').order('razao_social'); setSuppliers(data || []); };
  const loadCustomers = async () => { const { data } = await supabase.from('customers').select('id,name').order('name'); setCustomers(data || []); };

  const handleCreateBill = async () => {
    if (!form.description.trim()) { toast.error('Informe a descrição'); return; }
    const total = parseFloat(form.total_amount);
    const numInstallments = parseInt(form.installments);
    if (!total || total <= 0) { toast.error('Informe o valor'); return; }
    setSaving(true);
    const { data: bill, error } = await supabase.from('bills').insert({
      type: form.type, description: form.description, total_amount: total,
      installments: numInstallments, category: form.category,
      supplier_id: form.supplier_id || null, customer_id: form.customer_id || null,
      notes: form.notes || null,
    }).select().single();
    if (error || !bill) { toast.error('Erro ao criar conta'); setSaving(false); return; }
    const installmentAmount = parseFloat((total / numInstallments).toFixed(2));
    const firstDue = new Date(form.first_due_date + 'T00:00:00');
    const inserts = Array.from({ length: numInstallments }, (_, i) => {
      const due = new Date(firstDue);
      due.setMonth(due.getMonth() + i);
      return {
        bill_id: bill.id, installment_number: i + 1,
        amount: installmentAmount, remaining_amount: installmentAmount,
        partial_paid_amount: 0,
        due_date: due.toISOString().split('T')[0], status: 'pendente', payment_method: 'dinheiro',
      };
    });
    await supabase.from('bill_installments').insert(inserts);
    setSaving(false);
    toast.success(`Conta criada com ${numInstallments} parcela(s)!`);
    setShowNew(false);
    setForm({ type: 'pagar', description: '', total_amount: '', installments: '1', category: 'Outros', supplier_id: '', customer_id: '', notes: '', first_due_date: today });
    load();
  };

  /* ── Pagamento (total ou parcial) ── CORRIGIDO ── */
  const handlePay = async () => {
    if (!showPay) return;
    const { inst } = showPay;
    const paid = parseFloat(payAmount);
    if (isNaN(paid) || paid <= 0) { toast.error('Informe um valor válido'); return; }

    // Garante remaining nunca NaN — usa safeNum para parcelas antigas sem remaining_amount
    const remaining = safeNum(inst.remaining_amount, safeNum(inst.amount));
    if (remaining <= 0) { toast.error('Esta parcela já está quitada'); return; }

    const isPartial = paid < remaining - 0.005; // tolerância de 0,5 centavo

    setSaving(true);
    if (isPartial) {
      const newPartialTotal = safeNum(inst.partial_paid_amount) + paid;
      const newRemaining    = remaining - paid;
      const { error } = await supabase.from('bill_installments').update({
        status: 'parcial',
        partial_paid_amount: parseFloat(newPartialTotal.toFixed(2)),
        remaining_amount:    parseFloat(newRemaining.toFixed(2)),
        paid_date:           today,
        payment_method:      payMethod,
      }).eq('id', inst.id);
      setSaving(false);
      if (error) { toast.error('Erro ao registrar pagamento parcial: ' + error.message); return; }
      toast.success(`Pagamento parcial de ${fmt(paid)} registrado! Saldo restante: ${fmt(newRemaining)}`);
    } else {
      const { error } = await supabase.from('bill_installments').update({
        status:              'pago',
        paid_date:           today,
        paid_amount:         paid,
        partial_paid_amount: safeNum(inst.partial_paid_amount) + paid,
        remaining_amount:    0,
        payment_method:      payMethod,
      }).eq('id', inst.id);
      setSaving(false);
      if (error) { toast.error('Erro ao registrar pagamento: ' + error.message); return; }
      toast.success('Pagamento registrado com sucesso!');
    }
    setShowPay(null);
    // Recarrega detalhe se o dialog de detalhe ainda estiver aberto
    if (showDetail) loadDetail(showDetail.id);
    load();
  };

  const handleDeleteBill = async () => {
    if (!confirmDelete) return;
    setSaving(true);
    // Exclui parcelas primeiro (FK), depois a conta
    await supabase.from('bill_installments').delete().eq('bill_id', confirmDelete.id);
    const { error } = await supabase.from('bills').delete().eq('id', confirmDelete.id);
    setSaving(false);
    if (error) { toast.error('Erro ao excluir conta: ' + error.message); return; }
    toast.success('Conta e parcelas excluídas!');
    setConfirmDelete(null);
    if (showDetail?.id === confirmDelete.id) setShowDetail(null);
    load();
  };

  /* ── Editar Conta (bill) ── */
  const openEditBill = (b: Bill) => {
    setEditBillForm({
      description:  b.description,
      total_amount: b.total_amount.toString(),
      category:     b.category,
      supplier_id:  b.supplier_id || '',
      customer_id:  b.customer_id || '',
      notes:        b.notes || '',
    });
    setShowEditBill(b);
  };

  const handleEditBill = async () => {
    if (!showEditBill) return;
    const total = parseFloat(editBillForm.total_amount);
    if (!editBillForm.description.trim()) { toast.error('Informe a descrição'); return; }
    if (!total || total <= 0) { toast.error('Informe um valor válido'); return; }
    setSaving(true);
    const { error } = await supabase.from('bills').update({
      description:  editBillForm.description,
      total_amount: total,
      category:     editBillForm.category,
      supplier_id:  editBillForm.supplier_id || null,
      customer_id:  editBillForm.customer_id || null,
      notes:        editBillForm.notes || null,
    }).eq('id', showEditBill.id);
    setSaving(false);
    if (error) { toast.error('Erro ao salvar: ' + error.message); return; }
    toast.success('Conta atualizada!');
    setShowEditBill(null);
    // Atualiza showDetail se for a mesma conta
    if (showDetail?.id === showEditBill.id) {
      setShowDetail(prev => prev ? { ...prev, description: editBillForm.description, total_amount: total, category: editBillForm.category } : null);
    }
    load();
  };

  /* ── Editar Parcela ── */
  const openEditInst = (inst: BillInstallment) => {
    setEditInstForm({
      due_date: inst.due_date,
      amount:   inst.amount.toString(),
      notes:    inst.notes || '',
    });
    setShowEditInst(inst);
  };

  const handleEditInst = async () => {
    if (!showEditInst) return;
    const amount = parseFloat(editInstForm.amount);
    if (!editInstForm.due_date) { toast.error('Informe a data de vencimento'); return; }
    if (!amount || amount <= 0) { toast.error('Informe um valor válido'); return; }
    setSaving(true);
    // Se parcela ainda não tiver pagamento parcial, atualiza remaining junto
    const hadPartial = safeNum(showEditInst.partial_paid_amount) > 0;
    const newRemaining = hadPartial
      ? parseFloat((amount - safeNum(showEditInst.partial_paid_amount)).toFixed(2))
      : amount;
    const { error } = await supabase.from('bill_installments').update({
      due_date:         editInstForm.due_date,
      amount:           amount,
      remaining_amount: newRemaining,
      notes:            editInstForm.notes || null,
    }).eq('id', showEditInst.id);
    setSaving(false);
    if (error) { toast.error('Erro ao salvar parcela: ' + error.message); return; }
    toast.success('Parcela atualizada!');
    setShowEditInst(null);
    if (showDetail) loadDetail(showDetail.id);
    load();
  };

  /* ── Fechar Mês ── */
  const handleCloseCycle = async () => {
    setCycleClosing(true);
    const typeInst = installments.filter(i => bills.find(b => b.id === i.bill_id)?.type === activeTab);
    const pendingInst = typeInst.filter(i => i.status === 'pendente' || i.status === 'vencido' || i.status === 'parcial');
    const pendingTotal = pendingInst.reduce((s, i) => s + safeNum(i.remaining_amount, safeNum(i.amount)), 0);

    const { error: closeErr } = await supabase.from('monthly_cycles').upsert({
      month: curMonth, year: curYear, type: activeTab,
      status: 'fechado', pending_total: pendingTotal,
      carried_over: pendingTotal,
      notes: closingNotes || null,
      closed_at: new Date().toISOString(),
    }, { onConflict: 'month,year,type' });

    if (closeErr) { toast.error('Erro ao fechar ciclo: ' + closeErr.message); setCycleClosing(false); return; }

    const nextMonth = curMonth === 12 ? 1  : curMonth + 1;
    const nextYear  = curMonth === 12 ? curYear + 1 : curYear;

    await supabase.from('monthly_cycles').upsert({
      month: nextMonth, year: nextYear, type: activeTab,
      status: 'aberto', pending_total: pendingTotal,
      carried_over: 0, notes: `Saldo arrastado de ${MONTH_NAMES[curMonth - 1]}/${curYear}: ${fmt(pendingTotal)}`,
    }, { onConflict: 'month,year,type' });

    if (pendingInst.length > 0) {
      for (const inst of pendingInst) {
        const due = new Date(inst.due_date + 'T00:00:00');
        due.setMonth(due.getMonth() + 1);
        await supabase.from('bill_installments').update({
          due_date: due.toISOString().split('T')[0],
          status:   'pendente',
        }).eq('id', inst.id);
      }
    }

    setCycleClosing(false);
    setShowCloseCycle(false);
    setClosingNotes('');
    toast.success(`Mês fechado! ${fmt(pendingTotal)} arrastado para ${MONTH_NAMES[nextMonth - 1]}/${nextYear}.`);
    load();
  };

  const f  = (k: string, v: string) => setForm(p => ({ ...p, [k]: v }));
  const fe = (k: string, v: string) => setEditBillForm(p => ({ ...p, [k]: v }));
  const fi = (k: string, v: string) => setEditInstForm(p => ({ ...p, [k]: v }));

  /* ── Limpar contas pagas do mês selecionado ── */
  const handleResetPaid = async () => {
    setResetting(true);
    // Busca parcelas pagas com paid_date no mês/ano selecionado
    const y = filterYear, m = filterMonth;
    const last = new Date(y, m, 0).getDate();
    const from = `${y}-${String(m).padStart(2,'0')}-01`;
    const to   = `${y}-${String(m).padStart(2,'0')}-${last}`;
    const typeFilter = activeTab;
    // Parcelas pagas do mês cujas bills são do tipo ativo
    const paidIds = installments
      .filter(i => {
        const bill = bills.find(b => b.id === i.bill_id);
        return bill?.type === typeFilter && i.status === 'pago' && i.paid_date && i.paid_date >= from && i.paid_date <= to;
      })
      .map(i => i.id);
    if (paidIds.length > 0) {
      await supabase.from('bill_installments').update({ status: 'pendente', paid_date: null, paid_amount: null, partial_paid_amount: 0 }).in('id', paidIds);
    }
    setResetting(false);
    setShowResetConfirm(false);
    toast.success(`${paidIds.length} parcela(s) redefinida(s) para pendente.`);
    load();
  };

  // Filtro de parcelas pelo mês/ano selecionado (usa due_date)
  const filterInstByMonth = (inst: BillInstallment[]) => {
    const y = filterYear, m = filterMonth;
    const from = `${y}-${String(m).padStart(2,'0')}-01`;
    const last = new Date(y, m, 0).getDate();
    const to   = `${y}-${String(m).padStart(2,'0')}-${last}`;
    return inst.filter(i => i.due_date >= from && i.due_date <= to);
  };

  const typeBills            = bills.filter(b => b.type === activeTab);
  const allTypeInstallments  = installments.filter(i => bills.find(b => b.id === i.bill_id)?.type === activeTab);
  // Parcelas filtradas pelo mês/ano selecionado (due_date)
  const typeInstallments     = filterInstByMonth(allTypeInstallments);
  const pending              = typeInstallments.filter(i => i.status === 'pendente' || i.status === 'vencido' || i.status === 'parcial');
  const overdue              = typeInstallments.filter(i => i.status === 'vencido');
  const pendingTotal         = pending.reduce((s, i) => s + safeNum(i.remaining_amount, safeNum(i.amount)), 0);
  // "Pago no período": somente parcelas cujo paid_date está no mês/ano filtrado
  const filterFrom = `${filterYear}-${String(filterMonth).padStart(2,'0')}-01`;
  const filterTo   = `${filterYear}-${String(filterMonth).padStart(2,'0')}-${new Date(filterYear, filterMonth, 0).getDate()}`;
  const paidTotal  = typeInstallments.filter(i =>
    i.status === 'pago' && i.paid_date && i.paid_date >= filterFrom && i.paid_date <= filterTo
  ).reduce((s, i) => s + safeNum(i.paid_amount, safeNum(i.amount)), 0);
  // Bills visíveis: apenas as que têm parcela no mês filtrado
  const filteredBillIds      = new Set(typeInstallments.map(i => i.bill_id));
  const visibleBills         = typeBills.filter(b => filteredBillIds.has(b.id));
  const currentCycle         = cycles.find(c => c.month === filterMonth && c.year === filterYear && c.type === activeTab);
  const prevCycle            = cycles.find(c => {
    const pm = filterMonth === 1 ? 12 : filterMonth - 1;
    const py = filterMonth === 1 ? filterYear - 1 : filterYear;
    return c.month === pm && c.year === py && c.type === activeTab;
  });
  const carriedBalance = currentCycle?.pending_total ?? prevCycle?.carried_over ?? 0;

  return (
    <PdvLayout title="Contas a Pagar / Receber" actions={
      <div className="flex gap-2 flex-wrap">
        <Button variant="outline" size="sm" onClick={() => setShowResetConfirm(true)} className="gap-1.5 text-warning border-warning/40 hover:bg-warning/10">
          <RefreshCcw className="h-4 w-4" />Limpar Pagas
        </Button>
        <Button variant="outline" size="sm" onClick={() => setShowCloseCycle(true)} className="gap-1.5">
          <CalendarCheck className="h-4 w-4" />Fechar Mês
        </Button>
        <Button size="sm" onClick={() => { setForm(p => ({ ...p, type: activeTab === 'pagar' ? 'pagar' : 'receber' })); setShowNew(true); }}>
          <Plus className="h-4 w-4 mr-1.5" />Nova Conta
        </Button>
      </div>
    }>
      <div className="space-y-4">
        {/* Filtro mês/ano */}
        <div className="bg-card border border-border rounded-lg px-4 py-3 flex flex-wrap items-center gap-3">
          <Filter className="h-4 w-4 text-muted-foreground shrink-0" />
          <span className="text-sm font-medium">Filtrar por:</span>
          <Select value={String(filterMonth)} onValueChange={v => setFilterMonth(Number(v))}>
            <SelectTrigger className="w-36 h-8 text-sm"><SelectValue /></SelectTrigger>
            <SelectContent>{MONTH_NAMES.map((m, i) => <SelectItem key={i+1} value={String(i+1)}>{m}</SelectItem>)}</SelectContent>
          </Select>
          <Select value={String(filterYear)} onValueChange={v => setFilterYear(Number(v))}>
            <SelectTrigger className="w-24 h-8 text-sm"><SelectValue /></SelectTrigger>
            <SelectContent>{YEARS.map(y => <SelectItem key={y} value={String(y)}>{y}</SelectItem>)}</SelectContent>
          </Select>
          {(filterMonth !== curMonth || filterYear !== curYear) && (
            <Button variant="ghost" size="sm" className="h-8 text-xs gap-1 text-muted-foreground" onClick={() => { setFilterMonth(curMonth); setFilterYear(curYear); }}>
              <RefreshCcw className="h-3 w-3" />Mês atual
            </Button>
          )}
        </div>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList>
            <TabsTrigger value="pagar"   className="flex items-center gap-1.5"><TrendingDown className="h-4 w-4" />A Pagar</TabsTrigger>
            <TabsTrigger value="receber" className="flex items-center gap-1.5"><TrendingUp   className="h-4 w-4" />A Receber</TabsTrigger>
          </TabsList>

          {['pagar', 'receber'].map(tab => (
            <TabsContent key={tab} value={tab} className="mt-4 space-y-4">

              {/* Ciclo atual */}
              <div className="bg-card border border-border rounded-lg p-3 flex flex-wrap items-center gap-3 text-sm">
                <CalendarCheck className="h-4 w-4 text-primary shrink-0" />
                <span className="font-medium">Ciclo: {MONTH_NAMES[filterMonth - 1]}/{filterYear}</span>
                {currentCycle?.status === 'fechado'
                  ? <Badge className="bg-success/10 text-success border-success/30 text-xs">Mês fechado</Badge>
                  : <Badge variant="outline" className="text-xs">Em aberto</Badge>
                }
                {carriedBalance > 0 && (
                  <span className="text-muted-foreground flex items-center gap-1">
                    <ArrowRight className="h-3.5 w-3.5" />
                    Arrastado do mês anterior: <strong className="text-foreground ml-1">{fmt(carriedBalance)}</strong>
                  </span>
                )}
              </div>

              {/* KPIs */}
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {[
                  { label: activeTab === 'pagar' ? 'Total a Pagar' : 'Total a Receber', val: fmt(pendingTotal), cls: 'text-destructive', icon: DollarSign },
                  { label: 'Vencidas', val: overdue.length, cls: 'text-warning', icon: AlertCircle },
                  { label: activeTab === 'pagar' ? 'Pago (período)' : 'Recebido (período)', val: fmt(paidTotal), cls: 'text-success', icon: CheckCircle },
                ].map((k, i) => (
                  <div key={i} className="bg-card border border-border rounded-lg p-4">
                    <p className="text-xs text-muted-foreground mb-1">{k.label}</p>
                    <p className={`text-xl font-bold ${k.cls}`}>{k.val}</p>
                  </div>
                ))}
              </div>

              {overdue.length > 0 && (
                <div className="bg-destructive/5 border border-destructive/20 rounded-lg p-4 flex items-start gap-3">
                  <AlertCircle className="h-5 w-5 text-destructive shrink-0 mt-0.5" />
                  <div className="text-sm">
                    <p className="font-medium text-destructive">{overdue.length} parcela(s) vencida(s)!</p>
                    <p className="text-muted-foreground mt-0.5">Total em atraso: {fmt(overdue.reduce((s, i) => s + (i.remaining_amount ?? i.amount), 0))}</p>
                  </div>
                </div>
              )}

              {/* Lista de contas */}
              <div className="bg-card border border-border rounded-lg overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-border bg-muted/40">
                        <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Descrição</th>
                        <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Categoria</th>
                        <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Forn./Cliente</th>
                        <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Total</th>
                        <th className="text-center px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Parcelas</th>
                        <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Ações</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {loading
                        ? Array.from({ length: 4 }).map((_, i) => (
                            <tr key={i}><td colSpan={6} className="px-4 py-3"><Skeleton className="h-5 w-full bg-muted" /></td></tr>
                          ))
                        : visibleBills.length === 0
                          ? (
                            <tr><td colSpan={6} className="text-center py-12 text-muted-foreground">
                              <DollarSign className="h-8 w-8 mx-auto mb-2 opacity-40" />
                              <p className="text-pretty">Nenhuma conta para {MONTH_NAMES[filterMonth-1]}/{filterYear}</p>
                            </td></tr>
                          )
                          : visibleBills.map(b => {
                              const bInst   = installments.filter(i => i.bill_id === b.id);
                              const paid    = bInst.filter(i => i.status === 'pago').length;
                              const partial = bInst.filter(i => i.status === 'parcial').length;
                              const hasOv   = bInst.some(i => i.status === 'vencido');
                              return (
                                <tr key={b.id} className="hover:bg-muted/30 transition-colors">
                                  <td className="px-4 py-3 font-medium whitespace-nowrap">{b.description}</td>
                                  <td className="px-4 py-3 text-muted-foreground whitespace-nowrap">{b.category}</td>
                                  <td className="px-4 py-3 text-muted-foreground whitespace-nowrap">{b.suppliers?.razao_social || b.customers?.name || '—'}</td>
                                  <td className="px-4 py-3 text-right font-medium whitespace-nowrap">{fmt(b.total_amount)}</td>
                                  <td className="px-4 py-3 text-center whitespace-nowrap">
                                    {hasOv ? (
                                      <Badge className="text-xs bg-destructive/10 text-destructive border border-destructive/30">{paid}/{b.installments} Vencida</Badge>
                                    ) : partial > 0 ? (
                                      <Badge className="text-xs bg-primary/10 text-primary border border-primary/30">{paid}/{b.installments} Parcial</Badge>
                                    ) : paid === b.installments ? (
                                      <Badge className="text-xs bg-success/10 text-success border border-success/30">Quitado</Badge>
                                    ) : (
                                      <Badge variant="secondary" className="text-xs">{paid}/{b.installments}</Badge>
                                    )}
                                  </td>
                                  <td className="px-4 py-3 text-right whitespace-nowrap">
                                    <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setShowDetail(b)}>
                                      <Eye className="h-3.5 w-3.5" />
                                    </Button>
                                    <Button variant="ghost" size="icon" className="h-7 w-7 ml-1" onClick={() => openEditBill(b)}>
                                      <Pencil className="h-3.5 w-3.5" />
                                    </Button>
                                    <Button variant="ghost" size="icon" className="h-7 w-7 ml-1 text-destructive hover:text-destructive" onClick={() => setConfirmDelete(b)}>
                                      <Trash2 className="h-3.5 w-3.5" />
                                    </Button>
                                  </td>
                                </tr>
                              );
                            })}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Histórico de ciclos */}
              {cycles.filter(c => c.type === tab).length > 0 && (
                <div className="bg-card border border-border rounded-lg overflow-hidden">
                  <div className="px-4 py-3 border-b border-border bg-muted/40">
                    <p className="text-sm font-medium">Histórico de Ciclos Mensais</p>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b border-border">
                          <th className="text-left px-4 py-2 text-xs font-medium text-muted-foreground whitespace-nowrap">Mês/Ano</th>
                          <th className="text-center px-4 py-2 text-xs font-medium text-muted-foreground whitespace-nowrap">Status</th>
                          <th className="text-right px-4 py-2 text-xs font-medium text-muted-foreground whitespace-nowrap">Pendente Arrastado</th>
                          <th className="text-left px-4 py-2 text-xs font-medium text-muted-foreground whitespace-nowrap">Fechamento</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-border">
                        {cycles.filter(c => c.type === tab).map(c => (
                          <tr key={c.id} className="hover:bg-muted/20">
                            <td className="px-4 py-2 font-medium whitespace-nowrap">{MONTH_NAMES[c.month - 1]}/{c.year}</td>
                            <td className="px-4 py-2 text-center whitespace-nowrap">
                              {c.status === 'fechado'
                                ? <Badge className="text-xs bg-success/10 text-success border-success/30">Fechado</Badge>
                                : <Badge variant="outline" className="text-xs">Aberto</Badge>
                              }
                            </td>
                            <td className="px-4 py-2 text-right whitespace-nowrap text-warning font-medium">{fmt(c.pending_total)}</td>
                            <td className="px-4 py-2 text-muted-foreground whitespace-nowrap text-xs">
                              {c.closed_at ? new Date(c.closed_at).toLocaleDateString('pt-BR') : '—'}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </TabsContent>
          ))}
        </Tabs>
      </div>

      {/* ── Dialog: Nova Conta ── */}
      <Dialog open={showNew} onOpenChange={setShowNew}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-balance">Nova Conta a {form.type === 'pagar' ? 'Pagar' : 'Receber'}</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4 py-2 max-h-[60vh] overflow-y-auto pr-1">
            <div className="col-span-2">
              <Label className="text-sm font-normal mb-1.5 block">Tipo</Label>
              <div className="flex gap-2">
                {['pagar','receber'].map(t => (
                  <Button key={t} size="sm" variant={form.type === t ? 'default' : 'outline'} onClick={() => f('type', t)}>
                    {t === 'pagar' ? 'A Pagar' : 'A Receber'}
                  </Button>
                ))}
              </div>
            </div>
            <div className="col-span-2 space-y-1.5"><Label className="text-sm font-normal">Descrição *</Label><Input value={form.description} onChange={e => f('description', e.target.value)} /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Valor Total (R$) *</Label><Input type="number" min="0" step="0.01" value={form.total_amount} onChange={e => f('total_amount', e.target.value)} /></div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Categoria</Label>
              <Select value={form.category} onValueChange={v => f('category', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{(form.type === 'pagar' ? CATEGORIES_PAGAR : CATEGORIES_RECEBER).map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Parcelas</Label><Input type="number" min="1" max="60" value={form.installments} onChange={e => f('installments', e.target.value)} /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">1ª Parcela</Label><Input type="date" value={form.first_due_date} onChange={e => f('first_due_date', e.target.value)} /></div>
            {form.type === 'pagar' && (
              <div className="col-span-2 space-y-1.5">
                <Label className="text-sm font-normal">Fornecedor</Label>
                <Select value={form.supplier_id || 'none'} onValueChange={v => f('supplier_id', v === 'none' ? '' : v)}>
                  <SelectTrigger><SelectValue placeholder="Selecione (opcional)" /></SelectTrigger>
                  <SelectContent><SelectItem value="none">Nenhum</SelectItem>{suppliers.map(s => <SelectItem key={s.id} value={s.id}>{s.razao_social}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            )}
            {form.type === 'receber' && (
              <div className="col-span-2 space-y-1.5">
                <Label className="text-sm font-normal">Cliente</Label>
                <Select value={form.customer_id || 'none'} onValueChange={v => f('customer_id', v === 'none' ? '' : v)}>
                  <SelectTrigger><SelectValue placeholder="Selecione (opcional)" /></SelectTrigger>
                  <SelectContent><SelectItem value="none">Nenhum</SelectItem>{customers.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            )}
            <div className="col-span-2 space-y-1.5"><Label className="text-sm font-normal">Observações</Label><Textarea value={form.notes} onChange={e => f('notes', e.target.value)} rows={2} /></div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setShowNew(false)}>Cancelar</Button>
            <Button onClick={handleCreateBill} disabled={saving}>{saving ? 'Criando...' : 'Criar Conta'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── Dialog: Detalhe da Conta ── */}
      <Dialog open={!!showDetail} onOpenChange={o => { if (!o) setShowDetail(null); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl max-h-[90dvh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-balance">{showDetail?.description}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="flex flex-wrap gap-2 text-sm text-muted-foreground">
              <span>Total: <strong className="text-foreground">{fmt(showDetail?.total_amount || 0)}</strong></span>
              <span>•</span>
              <span>Categoria: <strong className="text-foreground">{showDetail?.category}</strong></span>
              {showDetail?.suppliers && <><span>•</span><span>Fornecedor: <strong className="text-foreground">{showDetail.suppliers.razao_social}</strong></span></>}
            </div>
            <div className="overflow-x-auto rounded-lg border border-border">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border bg-muted/40">
                    <th className="text-left px-3 py-2 font-medium text-muted-foreground whitespace-nowrap">Parcela</th>
                    <th className="text-left px-3 py-2 font-medium text-muted-foreground whitespace-nowrap">Vencimento</th>
                    <th className="text-right px-3 py-2 font-medium text-muted-foreground whitespace-nowrap">Valor</th>
                    <th className="text-right px-3 py-2 font-medium text-muted-foreground whitespace-nowrap">Pago</th>
                    <th className="text-right px-3 py-2 font-medium text-muted-foreground whitespace-nowrap">Restante</th>
                    <th className="text-center px-3 py-2 font-medium text-muted-foreground whitespace-nowrap">Status</th>
                    <th className="text-right px-3 py-2 font-medium text-muted-foreground whitespace-nowrap">Ação</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {loadingDetail
                    ? Array.from({ length: 2 }).map((_, i) => (
                        <tr key={i}><td colSpan={7} className="px-3 py-2"><Skeleton className="h-4 w-full bg-muted" /></td></tr>
                      ))
                    : detailInstallments.map(inst => {
                        const s = STATUS_MAP[inst.status] || STATUS_MAP.pendente;
                        const paidAmt   = safeNum(inst.partial_paid_amount);
                        const remaining = safeNum(inst.remaining_amount, safeNum(inst.amount));
                        const canPay    = inst.status === 'pendente' || inst.status === 'vencido' || inst.status === 'parcial';
                        const billType  = showDetail?.type ?? 'pagar';
                        return (
                          <tr key={inst.id} className="hover:bg-muted/20">
                            <td className="px-3 py-2 font-medium whitespace-nowrap">{inst.installment_number}/{showDetail?.installments}</td>
                            <td className="px-3 py-2 whitespace-nowrap">{new Date(inst.due_date + 'T00:00:00').toLocaleDateString('pt-BR')}</td>
                            <td className="px-3 py-2 text-right whitespace-nowrap">{fmt(safeNum(inst.amount))}</td>
                            <td className="px-3 py-2 text-right whitespace-nowrap text-success">{paidAmt > 0 ? fmt(paidAmt) : '—'}</td>
                            <td className="px-3 py-2 text-right whitespace-nowrap font-medium">{remaining > 0 ? fmt(remaining) : '—'}</td>
                            <td className="px-3 py-2 text-center whitespace-nowrap">
                              <span className={`inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full border ${s.cls}`}>
                                <s.icon className="h-3 w-3" />{s.label}
                              </span>
                            </td>
                            <td className="px-3 py-2 text-right whitespace-nowrap">
                              <div className="flex items-center justify-end gap-1">
                                {canPay && (
                                  <Button size="sm" variant="outline" className="h-7 text-xs gap-1" onClick={() => {
                                    setShowPay({ inst, billType });
                                    setPayAmount(remaining.toFixed(2));
                                    setPayMethod('dinheiro');
                                  }}>
                                    <Coins className="h-3 w-3" />{billType === 'pagar' ? 'Pagar' : 'Receber'}
                                  </Button>
                                )}
                                <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openEditInst(inst)}>
                                  <Pencil className="h-3 w-3" />
                                </Button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                </tbody>
              </table>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* ── Dialog: Pagamento ── */}
      <Dialog open={!!showPay} onOpenChange={o => { if (!o) setShowPay(null); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-balance">
              Registrar {showPay?.billType === 'pagar' ? 'Pagamento' : 'Recebimento'}
            </DialogTitle>
            <DialogDescription className="text-pretty">
              Valor total da parcela: {fmt(safeNum(showPay?.inst.amount))}
              {safeNum(showPay?.inst.partial_paid_amount) > 0 && (
                <><br />Já pago: {fmt(safeNum(showPay?.inst.partial_paid_amount))} · Restante: {fmt(safeNum(showPay?.inst.remaining_amount, safeNum(showPay?.inst.amount)))}</>
              )}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Valor a pagar (R$)</Label>
              <Input type="number" min="0.01" step="0.01" value={payAmount} onChange={e => setPayAmount(e.target.value)} />
              {showPay && parseFloat(payAmount) > 0 && parseFloat(payAmount) < safeNum(showPay.inst.remaining_amount, safeNum(showPay.inst.amount)) - 0.005 && (
                <p className="text-xs text-primary flex items-center gap-1">
                  <Coins className="h-3 w-3" />Pagamento parcial — restará {fmt(safeNum(showPay.inst.remaining_amount, safeNum(showPay.inst.amount)) - parseFloat(payAmount))}
                </p>
              )}
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Forma de Pagamento</Label>
              <Select value={payMethod} onValueChange={setPayMethod}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{PAY_METHODS.map(m => <SelectItem key={m} value={m}>{PAY_LABELS[m]}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setShowPay(null)}>Cancelar</Button>
            <Button onClick={handlePay} disabled={saving}>{saving ? 'Registrando...' : 'Confirmar'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── Dialog: Fechar Mês ── */}
      <Dialog open={showCloseCycle} onOpenChange={setShowCloseCycle}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-balance">Fechar Mês — {MONTH_NAMES[curMonth - 1]}/{curYear}</DialogTitle>
            <DialogDescription className="text-pretty">
              Ao fechar o mês, todos os valores pendentes ({activeTab === 'pagar' ? 'a pagar' : 'a receber'}) serão arrastados como saldo devedor para {MONTH_NAMES[curMonth === 12 ? 0 : curMonth]}/{curMonth === 12 ? curYear + 1 : curYear}.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="bg-warning/5 border border-warning/20 rounded-lg p-4 space-y-1 text-sm">
              <p className="font-medium text-warning">Resumo do fechamento</p>
              <p>Parcelas pendentes/vencidas/parciais: <strong>{pending.length}</strong></p>
              <p>Valor total a arrastar: <strong className="text-foreground">{fmt(pendingTotal)}</strong></p>
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Observações (opcional)</Label>
              <Textarea value={closingNotes} onChange={e => setClosingNotes(e.target.value)} rows={2} placeholder="Ex: aguardando confirmação de pagamento..." />
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setShowCloseCycle(false)}>Cancelar</Button>
            <Button onClick={handleCloseCycle} disabled={cycleClosing}>
              {cycleClosing ? 'Fechando...' : <><CalendarCheck className="h-4 w-4 mr-1.5" />Confirmar Fechamento</>}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      {/* ── AlertDialog: Confirmar Exclusão ── */}
      <AlertDialog open={!!confirmDelete} onOpenChange={o => { if (!o) setConfirmDelete(null); }}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir conta?</AlertDialogTitle>
            <AlertDialogDescription className="text-pretty">
              A conta <strong>"{confirmDelete?.description}"</strong> e todas as suas {confirmDelete?.installments} parcela(s) serão excluídas permanentemente. Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="gap-2">
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={handleDeleteBill}
            >
              {saving ? 'Excluindo...' : 'Sim, excluir'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* ── Dialog: Editar Conta ── */}
      <Dialog open={!!showEditBill} onOpenChange={o => { if (!o) setShowEditBill(null); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-balance">Editar Conta</DialogTitle>
            <DialogDescription className="text-pretty">Altere os dados da conta. As parcelas existentes não são recalculadas automaticamente — edite-as individualmente se necessário.</DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4 py-2 max-h-[60vh] overflow-y-auto pr-1">
            <div className="col-span-2 space-y-1.5">
              <Label className="text-sm font-normal">Descrição *</Label>
              <Input value={editBillForm.description} onChange={e => fe('description', e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Valor Total (R$) *</Label>
              <Input type="number" min="0" step="0.01" value={editBillForm.total_amount} onChange={e => fe('total_amount', e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Categoria</Label>
              <Select value={editBillForm.category} onValueChange={v => fe('category', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {(showEditBill?.type === 'pagar' ? CATEGORIES_PAGAR : CATEGORIES_RECEBER).map(c => (
                    <SelectItem key={c} value={c}>{c}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            {showEditBill?.type === 'pagar' && (
              <div className="col-span-2 space-y-1.5">
                <Label className="text-sm font-normal">Fornecedor</Label>
                <Select value={editBillForm.supplier_id || 'none'} onValueChange={v => fe('supplier_id', v === 'none' ? '' : v)}>
                  <SelectTrigger><SelectValue placeholder="Selecione (opcional)" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Nenhum</SelectItem>
                    {suppliers.map(s => <SelectItem key={s.id} value={s.id}>{s.razao_social}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            )}
            {showEditBill?.type === 'receber' && (
              <div className="col-span-2 space-y-1.5">
                <Label className="text-sm font-normal">Cliente</Label>
                <Select value={editBillForm.customer_id || 'none'} onValueChange={v => fe('customer_id', v === 'none' ? '' : v)}>
                  <SelectTrigger><SelectValue placeholder="Selecione (opcional)" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Nenhum</SelectItem>
                    {customers.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            )}
            <div className="col-span-2 space-y-1.5">
              <Label className="text-sm font-normal">Observações</Label>
              <Textarea value={editBillForm.notes} onChange={e => fe('notes', e.target.value)} rows={2} />
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setShowEditBill(null)}>Cancelar</Button>
            <Button onClick={handleEditBill} disabled={saving}>{saving ? 'Salvando...' : 'Salvar Alterações'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── Dialog: Editar Parcela ── */}
      <Dialog open={!!showEditInst} onOpenChange={o => { if (!o) setShowEditInst(null); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-balance">Editar Parcela {showEditInst?.installment_number}</DialogTitle>
            <DialogDescription className="text-pretty">Altere o vencimento e o valor desta parcela.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Data de Vencimento *</Label>
              <Input type="date" value={editInstForm.due_date} onChange={e => fi('due_date', e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Valor (R$) *</Label>
              <Input type="number" min="0.01" step="0.01" value={editInstForm.amount} onChange={e => fi('amount', e.target.value)} />
              {showEditInst && safeNum(showEditInst.partial_paid_amount) > 0 && (
                <p className="text-xs text-muted-foreground">
                  Já pago: {fmt(safeNum(showEditInst.partial_paid_amount))} — o saldo restante será recalculado automaticamente.
                </p>
              )}
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Observações</Label>
              <Input value={editInstForm.notes} onChange={e => fi('notes', e.target.value)} />
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setShowEditInst(null)}>Cancelar</Button>
            <Button onClick={handleEditInst} disabled={saving}>{saving ? 'Salvando...' : 'Salvar Parcela'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── AlertDialog: Limpar Contas Pagas ── */}
      <AlertDialog open={showResetConfirm} onOpenChange={setShowResetConfirm}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <AlertDialogHeader>
            <AlertDialogTitle>Limpar contas pagas?</AlertDialogTitle>
            <AlertDialogDescription className="text-pretty">
              As parcelas com status <strong>"Pago"</strong> de <strong>{MONTH_NAMES[filterMonth-1]}/{filterYear}</strong> ({activeTab === 'pagar' ? 'A Pagar' : 'A Receber'}) terão o pagamento desfeito e voltarão para <strong>Pendente</strong>. Use para corrigir lançamentos errados.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="gap-2">
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              className="bg-warning text-warning-foreground hover:bg-warning/90"
              onClick={handleResetPaid}
              disabled={resetting}
            >
              {resetting ? 'Processando...' : 'Confirmar Reset'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </PdvLayout>
  );
}
