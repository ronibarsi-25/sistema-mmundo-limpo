import { useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/db/supabase';
import { PdvLayout } from '@/components/layouts/PdvLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { toast } from 'sonner';
import { Receipt, FileText, Printer, RotateCcw, Loader2, AlertTriangle, CheckCircle, XCircle, Clock, CalendarRange } from 'lucide-react';
import type { PdvCupom } from '@/types/types';

const statusMap: Record<string, { label: string; variant: 'default' | 'secondary' | 'destructive' | 'outline'; icon: typeof CheckCircle }> = {
  pendente:    { label: 'Pendente',     variant: 'outline',     icon: Clock },
  autorizado:  { label: 'Autorizado',   variant: 'default',     icon: CheckCircle },
  cancelado:   { label: 'Cancelado',    variant: 'destructive', icon: XCircle },
  rejeitado:   { label: 'Rejeitado',    variant: 'destructive', icon: AlertTriangle },
  contingencia:{ label: 'Contingência', variant: 'secondary',   icon: AlertTriangle },
};

/* ── Funções de impressão ── */
function printInFrame(html: string, ref: React.MutableRefObject<HTMLIFrameElement | null>) {
  let frame = ref.current;
  if (!frame) {
    frame = document.createElement('iframe');
    frame.style.cssText = 'position:fixed;top:-9999px;left:-9999px;width:800px;height:600px;border:none';
    document.body.appendChild(frame);
    ref.current = frame;
  }
  const doc = frame.contentDocument || frame.contentWindow?.document;
  if (!doc) return;
  doc.open(); doc.write(html); doc.close();
  setTimeout(() => frame!.contentWindow?.print(), 400);
}

function buildCupomHtml(
  cupons: PdvCupom[],
  fmt: (v: number) => string,
  dateFrom?: string,
  dateTo?: string,
): string {
  const periodLabel = dateFrom || dateTo
    ? `Período: ${dateFrom ? new Date(dateFrom + 'T00:00:00').toLocaleDateString('pt-BR') : '—'} a ${dateTo ? new Date(dateTo + 'T00:00:00').toLocaleDateString('pt-BR') : '—'}`
    : '';

  const totalGeral = cupons.reduce((s, c) => s + (c.total || 0), 0);

  const rows = cupons.map(c => {
    const items = (c.pdv_cupom_items || [])
      .map(i => `<tr><td style="padding:2px 8px">${i.product_name}</td><td style="padding:2px 8px;text-align:right">${i.quantity} ${i.unit}</td><td style="padding:2px 8px;text-align:right">${fmt(i.unit_price)}</td><td style="padding:2px 8px;text-align:right">${fmt(i.total_price)}</td></tr>`)
      .join('');
    return `
      <div class="cupom">
        <div class="cupom-header">
          <span class="num">${c.invoice_number}</span>
          <span class="type">${c.cupom_type === 'cfe' ? 'CF-e SAT' : 'NFC-e'}</span>
          <span class="date">${new Date(c.created_at).toLocaleString('pt-BR')}</span>
          <span class="status status-${c.status}">${c.status.toUpperCase()}</span>
          <span class="total">${fmt(c.total)}</span>
        </div>
        ${items ? `<table class="items"><thead><tr><th>Produto</th><th>Qtd</th><th>Unit</th><th>Total</th></tr></thead><tbody>${items}</tbody></table>` : ''}
        ${c.chave_acesso ? `<div class="chave">Chave: ${c.chave_acesso}</div>` : ''}
      </div>`;
  }).join('');

  return `<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8"/>
<title>Cupons Fiscais</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:Arial,sans-serif;font-size:12px;color:#111;padding:24px}
  h1{font-size:18px;margin-bottom:2px}
  .period{font-size:11px;color:#555;margin-bottom:16px}
  .cupom{border:1px solid #ddd;border-radius:6px;padding:12px;margin-bottom:12px;break-inside:avoid}
  .cupom-header{display:flex;gap:16px;align-items:center;flex-wrap:wrap;margin-bottom:6px}
  .num{font-weight:700;font-size:13px}
  .type{font-size:11px;background:#f0f0f0;padding:1px 6px;border-radius:3px}
  .date{font-size:11px;color:#666;margin-left:auto}
  .status{font-size:10px;font-weight:700;padding:1px 6px;border-radius:3px}
  .status-autorizado{background:#d1fae5;color:#065f46}
  .status-cancelado{background:#fee2e2;color:#991b1b}
  .status-pendente{background:#fef3c7;color:#92400e}
  .status-rejeitado{background:#fee2e2;color:#991b1b}
  .status-contingencia{background:#ede9fe;color:#5b21b6}
  .total{font-weight:700;font-size:14px;color:#111}
  .items{width:100%;border-collapse:collapse;margin-top:6px;font-size:11px}
  .items th{text-align:left;padding:2px 8px;border-bottom:1px solid #eee;color:#555}
  .items td{padding:2px 8px}
  .chave{font-family:monospace;font-size:9px;color:#888;margin-top:6px;word-break:break-all}
  .summary{border-top:2px solid #333;margin-top:16px;padding-top:12px;display:flex;justify-content:space-between;align-items:center}
  .summary .label{font-size:13px;color:#555}
  .summary .value{font-size:20px;font-weight:700}
  @media print{body{padding:10px}.cupom{break-inside:avoid}}
</style></head><body>
<h1>Relatório de Cupons Fiscais</h1>
${periodLabel ? `<p class="period">${periodLabel} · ${cupons.length} cupom(ns)</p>` : `<p class="period">${cupons.length} cupom(ns) · Emitido em ${new Date().toLocaleString('pt-BR')}</p>`}
${rows}
<div class="summary">
  <span class="label">Total Geral (${cupons.length} cupons)</span>
  <span class="value">${fmt(totalGeral)}</span>
</div>
</body></html>`;
}

export default function PdvCupomFiscal() {
  const [cupons, setCupons] = useState<PdvCupom[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [selected, setSelected] = useState<PdvCupom | null>(null);
  const [cancelReason, setCancelReason] = useState('');
  const [cancelling, setCancelling] = useState(false);
  const printFrameRef = useRef<HTMLIFrameElement | null>(null);

  const loadCupons = useCallback(async () => {
    setLoading(true);
    let q = supabase.from('pdv_cupons').select('*, pdv_cupom_items(*)').order('created_at', { ascending: false });
    if (statusFilter) q = q.eq('status', statusFilter);
    if (dateFrom) q = q.gte('created_at', dateFrom + 'T00:00:00');
    if (dateTo)   q = q.lte('created_at', dateTo   + 'T23:59:59');
    const { data } = await q;
    setCupons(Array.isArray(data) ? data : []);
    setLoading(false);
  }, [statusFilter, dateFrom, dateTo]);

  useEffect(() => { loadCupons(); }, [loadCupons]);

  const filtered = cupons.filter((c) => {
    const term = search.toLowerCase();
    return (
      c.invoice_number.toLowerCase().includes(term) ||
      c.chave_acesso?.toLowerCase().includes(term) ||
      c.cnpj_emitente?.toLowerCase().includes(term)
    );
  });

  const handleCancel = async () => {
    if (!selected || !cancelReason.trim()) {
      toast.error('Informe o motivo do cancelamento');
      return;
    }
    try {
      setCancelling(true);
      const { error } = await supabase.from('pdv_cupons').update({
        status: 'cancelado',
        cancelado_em: new Date().toISOString(),
        cancelado_motivo: cancelReason.trim(),
      }).eq('id', selected.id);

      if (error) {
        toast.error(`Erro: ${error.message}`);
      } else {
        toast.success('Cupom cancelado com sucesso');
        setSelected(null);
        setCancelReason('');
        loadCupons();
      }
    } finally {
      setCancelling(false);
    }
  };

  const formatCurrency = (val: number) =>
    new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val || 0);

  /* ── Impressão de cupom individual ── */
  const handlePrintCupom = (cupom: PdvCupom) => {
    const html = buildCupomHtml([cupom], formatCurrency);
    printInFrame(html, printFrameRef);
  };

  /* ── Impressão de todos os cupons filtrados por data ── */
  const handlePrintByDate = () => {
    if (filtered.length === 0) { toast.error('Nenhum cupom para imprimir.'); return; }
    const html = buildCupomHtml(filtered, formatCurrency, dateFrom, dateTo);
    printInFrame(html, printFrameRef);
  };

  const clearDateFilter = () => { setDateFrom(''); setDateTo(''); };

  return (
    <PdvLayout title="Cupom Fiscal (CF-e / NFC-e)">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header actions */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
          <div>
            <h2 className="text-lg font-semibold text-balance">Cupons Fiscais Emitidos</h2>
            <p className="text-sm text-muted-foreground text-pretty">Consulte, imprima e cancele cupons fiscais eletrônicos.</p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Input
              placeholder="Buscar por nº, chave ou CNPJ..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full md:w-56"
            />
            <select
              className="h-9 rounded-md border border-input bg-background px-3 text-sm"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <option value="">Todos os status</option>
              <option value="pendente">Pendente</option>
              <option value="autorizado">Autorizado</option>
              <option value="cancelado">Cancelado</option>
              <option value="rejeitado">Rejeitado</option>
              <option value="contingencia">Contingência</option>
            </select>
          </div>
        </div>

        {/* Filtro por data + impressão por data */}
        <Card>
          <CardContent className="p-4">
            <div className="flex flex-col md:flex-row md:items-end gap-3">
              <CalendarRange className="h-5 w-5 text-primary shrink-0 hidden md:block mt-1" />
              <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label className="text-xs text-muted-foreground">Data inicial</Label>
                  <Input type="date" value={dateFrom} onChange={e => setDateFrom(e.target.value)} />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs text-muted-foreground">Data final</Label>
                  <Input type="date" value={dateTo} onChange={e => setDateTo(e.target.value)} />
                </div>
              </div>
              <div className="flex gap-2 shrink-0">
                {(dateFrom || dateTo) && (
                  <Button variant="outline" size="sm" onClick={clearDateFilter} className="h-9">
                    Limpar
                  </Button>
                )}
                <Button
                  size="sm"
                  className="h-9 gap-1.5"
                  onClick={handlePrintByDate}
                  disabled={filtered.length === 0}
                >
                  <Printer className="h-4 w-4" />
                  Imprimir {filtered.length > 0 ? `(${filtered.length})` : ''}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          {['pendente', 'autorizado', 'cancelado', 'rejeitado', 'contingencia'].map((s) => {
            const count = cupons.filter((c) => c.status === s).length;
            const sm = statusMap[s];
            return (
              <Card key={s} className="h-full flex flex-col">
                <CardContent className="p-4 flex flex-col flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <sm.icon className="h-4 w-4 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">{sm.label}</span>
                  </div>
                  <p className="text-2xl font-bold">{count}</p>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Table */}
        <Card>
          <CardContent className="p-0">
            <div className="w-full max-w-full overflow-x-auto bg-card">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="whitespace-nowrap">Nº Cupom</TableHead>
                    <TableHead className="whitespace-nowrap">Tipo</TableHead>
                    <TableHead className="whitespace-nowrap">Status</TableHead>
                    <TableHead className="whitespace-nowrap">Chave de Acesso</TableHead>
                    <TableHead className="whitespace-nowrap">Total</TableHead>
                    <TableHead className="whitespace-nowrap">Itens</TableHead>
                    <TableHead className="whitespace-nowrap">Data</TableHead>
                    <TableHead className="whitespace-nowrap">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loading ? (
                    <TableRow>
                      <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                        <Loader2 className="h-5 w-5 mx-auto animate-spin" /> Carregando cupons...
                      </TableCell>
                    </TableRow>
                  ) : filtered.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                        Nenhum cupom fiscal encontrado.
                      </TableCell>
                    </TableRow>
                  ) : (
                    filtered.map((cupom) => {
                      const sm = statusMap[cupom.status] || statusMap.pendente;
                      return (
                        <TableRow key={cupom.id}>
                          <TableCell className="whitespace-nowrap font-medium">{cupom.invoice_number}</TableCell>
                          <TableCell className="whitespace-nowrap">{cupom.cupom_type === 'cfe' ? 'CF-e SAT' : 'NFC-e'}</TableCell>
                          <TableCell className="whitespace-nowrap">
                            <Badge variant={sm.variant} className="text-[10px]">{sm.label}</Badge>
                          </TableCell>
                          <TableCell className="whitespace-nowrap font-mono text-xs">
                            {cupom.chave_acesso ? cupom.chave_acesso.slice(0, 20) + '...' : '—'}
                          </TableCell>
                          <TableCell className="whitespace-nowrap">{formatCurrency(cupom.total)}</TableCell>
                          <TableCell className="whitespace-nowrap">{cupom.total_items}</TableCell>
                          <TableCell className="whitespace-nowrap">
                            {new Date(cupom.created_at).toLocaleDateString('pt-BR')}
                          </TableCell>
                          <TableCell className="whitespace-nowrap">
                            <div className="flex items-center gap-1">
                              <Button variant="ghost" size="sm" onClick={() => setSelected(cupom)}>
                                <FileText className="h-4 w-4 mr-1" /> Detalhes
                              </Button>
                              <Button variant="ghost" size="sm" onClick={() => handlePrintCupom(cupom)} title="Imprimir cupom">
                                <Printer className="h-4 w-4" />
                              </Button>
                              {cupom.status === 'autorizado' && (
                                <Button variant="ghost" size="sm" onClick={() => { setSelected(cupom); setCancelReason(''); }}>
                                  <RotateCcw className="h-4 w-4 text-destructive" />
                                </Button>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        {/* Cupom Fiscal Info */}
        <Card className="bg-muted/30">
          <CardContent className="p-4">
            <div className="flex items-start gap-2">
              <Receipt className="h-5 w-5 text-primary shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-medium">Sobre o Cupom Fiscal</p>
                <p className="text-xs text-muted-foreground text-pretty">
                  A emissão de CF-e SAT e NFC-e requer equipamento homologado pela SEFAZ e certificado digital válido.
                  As vendas realizadas no caixa podem ser convertidas em cupons fiscais após a configuração do equipamento.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Details Dialog */}
      <Dialog open={!!selected} onOpenChange={(open) => { if (!open) { setSelected(null); setCancelReason(''); } }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg max-h-[90dvh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-balance">Detalhes do Cupom</DialogTitle>
            <DialogDescription className="text-pretty">{selected?.invoice_number}</DialogDescription>
          </DialogHeader>
          {selected && (
            <div className="space-y-4 py-2">
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <p className="text-muted-foreground text-xs">Tipo</p>
                  <p className="font-medium">{selected.cupom_type === 'cfe' ? 'CF-e SAT' : 'NFC-e'}</p>
                </div>
                <div>
                  <p className="text-muted-foreground text-xs">Status</p>
                  <Badge variant={statusMap[selected.status]?.variant || 'outline'}>
                    {statusMap[selected.status]?.label || selected.status}
                  </Badge>
                </div>
                <div className="col-span-2">
                  <p className="text-muted-foreground text-xs">Chave de Acesso</p>
                  <p className="font-mono text-xs break-all">{selected.chave_acesso || '—'}</p>
                </div>
                <div>
                  <p className="text-muted-foreground text-xs">Total</p>
                  <p className="font-medium">{formatCurrency(selected.total)}</p>
                </div>
                <div>
                  <p className="text-muted-foreground text-xs">Itens</p>
                  <p className="font-medium">{selected.total_items}</p>
                </div>
                <div>
                  <p className="text-muted-foreground text-xs">Data Emissão</p>
                  <p className="font-medium">{new Date(selected.created_at).toLocaleString('pt-BR')}</p>
                </div>
                {selected.cancelado_em && (
                  <div>
                    <p className="text-muted-foreground text-xs">Cancelado em</p>
                    <p className="font-medium">{new Date(selected.cancelado_em).toLocaleString('pt-BR')}</p>
                  </div>
                )}
                {selected.cancelado_motivo && (
                  <div className="col-span-2">
                    <p className="text-muted-foreground text-xs">Motivo do Cancelamento</p>
                    <p>{selected.cancelado_motivo}</p>
                  </div>
                )}
              </div>

              {selected.pdv_cupom_items && selected.pdv_cupom_items.length > 0 && (
                <div>
                  <p className="text-sm font-medium mb-2">Itens do Cupom</p>
                  <div className="w-full max-w-full overflow-x-auto bg-card border rounded-md">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="whitespace-nowrap text-xs">Produto</TableHead>
                          <TableHead className="whitespace-nowrap text-xs">Qtd</TableHead>
                          <TableHead className="whitespace-nowrap text-xs">Unit</TableHead>
                          <TableHead className="whitespace-nowrap text-xs">Total</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {selected.pdv_cupom_items.map((item) => (
                          <TableRow key={item.id}>
                            <TableCell className="whitespace-nowrap text-xs">{item.product_name}</TableCell>
                            <TableCell className="whitespace-nowrap text-xs">{item.quantity} {item.unit}</TableCell>
                            <TableCell className="whitespace-nowrap text-xs">{formatCurrency(item.unit_price)}</TableCell>
                            <TableCell className="whitespace-nowrap text-xs">{formatCurrency(item.total_price)}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              )}

              <div className="flex gap-2 pt-2">
                <Button variant="outline" className="flex-1 gap-1.5" onClick={() => handlePrintCupom(selected)}>
                  <Printer className="h-4 w-4" />Imprimir Cupom
                </Button>
              </div>

              {selected.status === 'autorizado' && (
                <div className="border-t pt-4 space-y-3">
                  <p className="text-sm font-medium">Cancelar Cupom</p>
                  <div>
                    <Label>Motivo do Cancelamento</Label>
                    <Input value={cancelReason} onChange={(e) => setCancelReason(e.target.value)} placeholder="Informe o motivo..." />
                  </div>
                  <Button variant="destructive" onClick={handleCancel} disabled={cancelling} className="w-full">
                    {cancelling
                      ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Processando...</>
                      : <><RotateCcw className="h-4 w-4 mr-2" /> Cancelar Cupom</>}
                  </Button>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </PdvLayout>
  );
}
