import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  TrendingUp, TrendingDown, Package, Users, AlertTriangle,
  DollarSign, ShoppingCart, ArrowRight, CreditCard, Smartphone, QrCode,
  Bell, Wallet, ChevronRight as ChevronRightIcon
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { PdvLayout } from '@/components/layouts/PdvLayout';
import { supabase } from '@/db/supabase';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import QRCodeDataUrl from '@/components/ui/qrcodedataurl';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger,
} from '@/components/ui/dialog';
import { useVencimentoAlert } from '@/hooks/useVencimentoAlert';

const fmtBRL = (v: number) => (v || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

interface DashboardStats {
  vendasHoje: number;
  receitaHoje: number;
  despesaHoje: number;
  totalProdutos: number;
  totalClientes: number;
  estoqueBaixo: number;
  caixaAberto: boolean;
}

interface FinanceiroMes {
  totalPagar: number;
  totalReceber: number;
  paidPagar: number;
  paidReceber: number;
  vencidas: number;
}

interface LowStockProduct {
  id: string; name: string; stock_qty: number; stock_min: number; unit: string;
}

interface SalesChartItem { dia: string; total: number; }

export default function PdvDashboard() {
  const [stats, setStats]           = useState<DashboardStats | null>(null);
  const [finMes, setFinMes]         = useState<FinanceiroMes | null>(null);
  const [lowStock, setLowStock]     = useState<LowStockProduct[]>([]);
  const [salesChart, setSalesChart] = useState<SalesChartItem[]>([]);
  const [loading, setLoading]       = useState(true);
  const [loadingFin, setLoadingFin] = useState(true);

  // Alerta de vencimentos — roda uma vez por sessão
  const { itens: vencItens } = useVencimentoAlert();

  useEffect(() => {
    loadDashboard();
    loadFinanceiro();
  }, []);

  const loadDashboard = async () => {
    try {
      const today = new Date().toISOString().split('T')[0];
      const [vendasRes, produtosRes, clientesRes, caixaRes, estoqueBaixoRes, salesRes, despesasRes] = await Promise.all([
        supabase.from('pdv_invoices').select('total').eq('type', 'saida').eq('status', 'emitida')
          .gte('issued_at', `${today}T00:00:00`).lte('issued_at', `${today}T23:59:59`),
        supabase.from('pdv_products').select('id', { count: 'exact', head: true }).eq('active', true),
        supabase.from('customers').select('id', { count: 'exact', head: true }).eq('active', true),
        supabase.from('cash_registers').select('id').eq('status', 'aberto').limit(1),
        supabase.from('pdv_products').select('id, name, stock_qty, stock_min, unit').eq('active', true)
          .filter('stock_qty', 'lte', 'stock_min').order('stock_qty').limit(5),
        supabase.from('pdv_invoices').select('total, issued_at').eq('type', 'saida').eq('status', 'emitida')
          .gte('issued_at', new Date(Date.now() - 7 * 86400000).toISOString()),
        supabase.from('transactions').select('amount').eq('type', 'despesa').eq('transaction_date', today),
      ]);

      const vendas = vendasRes.data || [];
      const receitaHoje = vendas.reduce((s, v) => s + (v.total || 0), 0);
      const despesaHoje = (despesasRes.data || []).reduce((s, d) => s + (Number(d.amount) || 0), 0);

      const diasMap: Record<string, number> = {};
      for (let i = 6; i >= 0; i--) {
        const d = new Date(Date.now() - i * 86400000);
        diasMap[d.toLocaleDateString('pt-BR', { weekday: 'short' })] = 0;
      }
      (salesRes.data || []).forEach((inv) => {
        const key = new Date(inv.issued_at).toLocaleDateString('pt-BR', { weekday: 'short' });
        if (key in diasMap) diasMap[key] += inv.total || 0;
      });

      setStats({
        vendasHoje: vendas.length,
        receitaHoje,
        despesaHoje,
        totalProdutos: produtosRes.count || 0,
        totalClientes: clientesRes.count || 0,
        estoqueBaixo: (estoqueBaixoRes.data || []).length,
        caixaAberto: (caixaRes.data || []).length > 0,
      });
      setLowStock((estoqueBaixoRes.data as LowStockProduct[]) || []);
      setSalesChart(Object.entries(diasMap).map(([dia, total]) => ({ dia, total })));
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  };

  const loadFinanceiro = async () => {
    try {
      const now   = new Date();
      const y     = now.getFullYear();
      const m     = now.getMonth() + 1;
      const last  = new Date(y, m, 0).getDate();
      const from  = `${y}-${String(m).padStart(2,'0')}-01`;
      const to    = `${y}-${String(m).padStart(2,'0')}-${last}`;

      // Busca parcelas com due_date no mês (para totalPagar/totalReceber/vencidas)
      // E também parcelas com paid_date no mês (para paidPagar/paidReceber)
      const [dueRes, paidRes] = await Promise.all([
        supabase
          .from('bill_installments')
          .select('amount, remaining_amount, paid_amount, paid_date, status, bills(type)')
          .gte('due_date', from).lte('due_date', to),
        supabase
          .from('bill_installments')
          .select('paid_amount, bills(type)')
          .eq('status', 'pago')
          .gte('paid_date', from).lte('paid_date', to),
      ]);

      let totalPagar = 0, totalReceber = 0, paidPagar = 0, paidReceber = 0, vencidas = 0;
      (dueRes.data || []).forEach((i: any) => {
        const amt = Number(i.remaining_amount ?? i.amount) || 0;
        if (i.bills?.type === 'pagar') {
          totalPagar += i.status !== 'pago' ? amt : 0;
        } else if (i.bills?.type === 'receber') {
          totalReceber += i.status !== 'pago' ? amt : 0;
        }
        if (i.status === 'vencido') vencidas++;
      });
      // Pago no mês: usa paid_date para contagem correta
      (paidRes.data || []).forEach((i: any) => {
        const paidAmt = Number(i.paid_amount) || 0;
        if (i.bills?.type === 'pagar')   paidPagar   += paidAmt;
        else if (i.bills?.type === 'receber') paidReceber += paidAmt;
      });
      setFinMes({ totalPagar, totalReceber, paidPagar, paidReceber, vencidas });
    } catch (err) { console.error(err); }
    finally { setLoadingFin(false); }
  };

  const saldo = finMes ? finMes.totalReceber - finMes.totalPagar : 0;

  const StatCard = ({
    title, value, sub, icon: Icon, color, link
  }: { title: string; value: string; sub: string; icon: React.ElementType; color: string; link?: string }) => (
    <Card className="h-full">
      <CardContent className="p-5 flex items-start gap-4">
        <div className={`h-10 w-10 rounded-lg flex items-center justify-center shrink-0 ${color}`}>
          <Icon className="h-5 w-5 text-white" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-xs text-muted-foreground text-pretty">{title}</p>
          {loading ? <Skeleton className="h-6 w-20 mt-1 bg-muted" />
            : <p className="text-xl font-bold text-foreground">{value}</p>}
          <p className="text-xs text-muted-foreground mt-0.5">{sub}</p>
        </div>
        {link && (
          <Link to={link} className="shrink-0 text-muted-foreground hover:text-primary transition-colors">
            <ArrowRight className="h-4 w-4" />
          </Link>
        )}
      </CardContent>
    </Card>
  );

  const now = new Date();
  const mesLabel = now.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });
  // Vencendo hoje ou nos próximos 3 dias (do hook)
  const vencBreveLista = vencItens.filter(i => i.days >= 0 && i.days <= 3);

  return (
    <PdvLayout title="Dashboard">
      {/* Status caixa */}
      <div className="flex items-center justify-between mb-5 flex-wrap gap-3">
        <div className="flex items-center gap-2">
          <div className={`h-2.5 w-2.5 rounded-full ${stats?.caixaAberto ? 'bg-success animate-pulse' : 'bg-muted-foreground'}`} />
          <span className="text-sm text-muted-foreground">
            {stats?.caixaAberto ? 'Caixa aberto' : 'Caixa fechado'}
          </span>
        </div>
        <Link to="/pdv/caixa">
          <Button size="sm">
            <CreditCard className="h-4 w-4 mr-2" />
            {stats?.caixaAberto ? 'Ir para o Caixa' : 'Abrir Caixa'}
          </Button>
        </Link>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <StatCard title="Vendas Hoje"    value={stats ? stats.vendasHoje.toString() : '—'}       sub="transações"   icon={ShoppingCart} color="bg-primary"     link="/pdv/notas-fiscais" />
        <StatCard title="Receita Hoje"   value={stats ? fmtBRL(stats.receitaHoje)  : '—'}         sub="total vendido" icon={DollarSign}   color="bg-success"     link="/pdv/financeiro" />
        <StatCard title="Despesa Hoje"   value={stats ? fmtBRL(stats.despesaHoje)  : '—'}         sub="total pago"    icon={TrendingDown}  color="bg-destructive" link="/pdv/financeiro" />
        <StatCard title="Produtos Ativos" value={stats ? stats.totalProdutos.toString() : '—'}  sub="no catálogo"   icon={Package}      color="bg-info"        link="/pdv/produtos" />
        <StatCard title="Clientes"       value={stats ? stats.totalClientes.toString() : '—'}   sub="cadastrados"   icon={Users}        color="bg-accent"      link="/pdv/clientes" />
      </div>

      {/* ── Card Resumo Financeiro do Mês ── */}
      <Card className="mb-6 border-border">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Wallet className="h-4 w-4 text-primary shrink-0" />
              <CardTitle className="text-sm font-semibold text-balance">Resumo Financeiro — {mesLabel}</CardTitle>
            </div>
            <Link to="/pdv/contas" className="shrink-0">
              <Button variant="ghost" size="sm" className="h-7 text-xs gap-1 text-muted-foreground hover:text-primary">
                Ver Contas <ChevronRightIcon className="h-3.5 w-3.5" />
              </Button>
            </Link>
          </div>
        </CardHeader>
        <CardContent className="pt-0">
          {loadingFin ? (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {[...Array(4)].map((_, i) => <Skeleton key={i} className="h-16 bg-muted rounded-lg" />)}
            </div>
          ) : (
            <div className="space-y-4">
              {/* KPIs financeiros */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {[
                  { label: 'A Pagar', val: fmtBRL(finMes?.totalPagar || 0),   sub: 'pendente no mês',   cls: 'text-destructive', bg: 'bg-destructive/8', icon: TrendingDown },
                  { label: 'A Receber', val: fmtBRL(finMes?.totalReceber || 0), sub: 'pendente no mês', cls: 'text-success',     bg: 'bg-success/8',     icon: TrendingUp },
                  { label: 'Saldo',   val: fmtBRL(saldo),                      sub: 'receber − pagar',  cls: saldo >= 0 ? 'text-success' : 'text-destructive', bg: saldo >= 0 ? 'bg-success/8' : 'bg-destructive/8', icon: Wallet },
                  { label: 'Vencidas', val: String(finMes?.vencidas || 0),     sub: 'parcelas em atraso', cls: (finMes?.vencidas || 0) > 0 ? 'text-warning' : 'text-muted-foreground', bg: 'bg-warning/8', icon: AlertTriangle },
                ].map((k, i) => (
                  <div key={i} className={`rounded-lg border border-border ${k.bg} p-3 flex items-center gap-3`}>
                    <div className="h-8 w-8 rounded-md bg-card flex items-center justify-center shrink-0">
                      <k.icon className={`h-4 w-4 ${k.cls}`} />
                    </div>
                    <div className="min-w-0">
                      <p className={`text-base font-bold ${k.cls}`}>{k.val}</p>
                      <p className="text-xs text-muted-foreground">{k.label}</p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Alerta de vencimentos próximos */}
              {vencBreveLista.length > 0 && (
                <div className="bg-warning/5 border border-warning/25 rounded-lg p-3">
                  <div className="flex items-start gap-2.5">
                    <Bell className="h-4 w-4 text-warning shrink-0 mt-0.5" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-warning">
                        {vencBreveLista.length} parcela(s) vencem nos próximos 3 dias
                      </p>
                      <div className="mt-1.5 space-y-1">
                        {vencBreveLista.map(item => (
                          <div key={item.id} className="flex items-center justify-between gap-2 text-xs">
                            <span className="text-foreground truncate">
                              • {item.description}
                              <span className="text-muted-foreground ml-1">(parc. {item.installment_number})</span>
                            </span>
                            <div className="flex items-center gap-2 shrink-0">
                              <Badge variant="outline" className={`text-[10px] px-1.5 py-0 ${item.days === 0 ? 'text-destructive border-destructive/40' : 'text-warning border-warning/40'}`}>
                                {item.days === 0 ? 'Hoje' : `${item.days}d`}
                              </Badge>
                              <span className="font-medium">{fmtBRL(Number(item.remaining_amount ?? item.amount))}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                    <Link to="/pdv/contas" className="shrink-0">
                      <Button variant="ghost" size="sm" className="h-7 text-xs text-warning hover:text-warning hover:bg-warning/10">
                        Pagar <ChevronRightIcon className="h-3 w-3 ml-1" />
                      </Button>
                    </Link>
                  </div>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Quick Actions + Mobile App */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <Card className="bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20">
          <CardContent className="p-5">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg bg-primary flex items-center justify-center shrink-0">
                <Smartphone className="h-5 w-5 text-primary-foreground" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-foreground">App Mobile</p>
                <p className="text-xs text-muted-foreground text-pretty">Controle de estoque no celular</p>
              </div>
            </div>
            <div className="mt-3 flex items-center gap-3">
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm" className="gap-1 text-xs">
                    <QrCode className="h-3 w-3" /> Ver QR Code
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-sm">
                  <DialogHeader>
                    <DialogTitle className="text-center text-balance">Acesse pelo Celular</DialogTitle>
                  </DialogHeader>
                  <div className="flex flex-col items-center gap-3 py-2">
                    <QRCodeDataUrl text={`${window.location.origin}/mobile`} width={200} />
                    <p className="text-xs text-muted-foreground text-center text-pretty">
                      Escaneie com a câmera do celular para abrir o app de controle de estoque
                    </p>
                    <Button size="sm" variant="outline" className="text-xs" asChild>
                      <Link to="/mobile" target="_blank">Abrir App Mobile</Link>
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
              <Button size="sm" className="text-xs" asChild>
                <Link to="/mobile" target="_blank">Abrir</Link>
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-5">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg bg-info flex items-center justify-center shrink-0">
                <Package className="h-5 w-5 text-white" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold">Contagem</p>
                <p className="text-xs text-muted-foreground">Inventário rápido</p>
              </div>
            </div>
            <Button variant="outline" size="sm" className="w-full mt-3 text-xs" asChild>
              <Link to="/mobile/contagem">Iniciar Contagem</Link>
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-5">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg bg-success flex items-center justify-center shrink-0">
                <QrCode className="h-5 w-5 text-white" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold">Scanner</p>
                <p className="text-xs text-muted-foreground">Ler código de barras</p>
              </div>
            </div>
            <Button variant="outline" size="sm" className="w-full mt-3 text-xs" asChild>
              <Link to="/mobile/scanner">Abrir Scanner</Link>
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-5">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg bg-accent flex items-center justify-center shrink-0">
                <Package className="h-5 w-5 text-white" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold">Produtos</p>
                <p className="text-xs text-muted-foreground">Lista completa</p>
              </div>
            </div>
            <Button variant="outline" size="sm" className="w-full mt-3 text-xs" asChild>
              <Link to="/mobile/produtos">Ver Produtos</Link>
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Charts + Alerts row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Sales chart */}
        <Card className="md:col-span-2 h-full">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-balance">Vendas — Últimos 7 Dias</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            {loading ? <Skeleton className="h-48 w-full bg-muted" /> : (
              <div className="w-full min-w-0 overflow-hidden">
                <ResponsiveContainer width="100%" height={190}>
                  <BarChart data={salesChart} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis dataKey="dia" tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} />
                    <YAxis tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} />
                    <Tooltip
                      formatter={(v: number) => [`R$ ${v.toFixed(2)}`, 'Total']}
                      contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: 6, fontSize: 12 }}
                    />
                    <Bar dataKey="total" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Low stock alert */}
        <Card className="h-full">
          <CardHeader className="pb-2">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-warning shrink-0" />
              <CardTitle className="text-sm font-semibold text-balance">Estoque Baixo</CardTitle>
              {stats && stats.estoqueBaixo > 0 && (
                <Badge variant="destructive" className="ml-auto shrink-0 text-xs">{stats.estoqueBaixo}</Badge>
              )}
            </div>
          </CardHeader>
          <CardContent className="pt-0">
            {loading ? (
              <div className="space-y-2">{[1, 2, 3].map(i => <Skeleton key={i} className="h-8 w-full bg-muted" />)}</div>
            ) : lowStock.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-6 text-center">
                <TrendingUp className="h-8 w-8 text-success mb-2" />
                <p className="text-sm text-muted-foreground text-pretty">Todos os produtos com estoque adequado!</p>
              </div>
            ) : (
              <div className="space-y-2">
                {lowStock.map(p => (
                  <div key={p.id} className="flex items-center gap-2 p-2 bg-warning/5 border border-warning/20 rounded-md">
                    <TrendingDown className="h-3.5 w-3.5 text-warning shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-foreground truncate">{p.name}</p>
                      <p className="text-[11px] text-muted-foreground">{p.stock_qty} {p.unit} / mín {p.stock_min}</p>
                    </div>
                  </div>
                ))}
                <Link to="/pdv/estoque" className="block">
                  <Button variant="outline" size="sm" className="w-full mt-1 text-xs">
                    Ver Estoque Completo
                  </Button>
                </Link>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </PdvLayout>
  );
}
