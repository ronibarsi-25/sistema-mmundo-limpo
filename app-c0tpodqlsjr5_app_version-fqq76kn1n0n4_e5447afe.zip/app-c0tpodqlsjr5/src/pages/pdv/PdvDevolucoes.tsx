import { useEffect, useState } from 'react';
import { Plus, RefreshCw, ArrowLeftRight, Package } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { PdvLayout } from '@/components/layouts/PdvLayout';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';

interface ReturnRecord {
  id: string; original_invoice_id: string | null; customer_id: string | null;
  return_date: string; reason: string; resolution: 'credito' | 'troca' | 'reembolso';
  total_amount: number; credit_issued: number; notes: string | null; created_at: string;
  customers?: { name: string } | null;
  pdv_invoices?: { invoice_number: string } | null;
}

interface ReturnItem {
  product_id: string; quantity: number; unit_price: number; total_price: number;
  condition: 'bom' | 'danificado' | 'defeituoso'; restock: boolean;
}

const RESOLUTION_LABEL = { credito: 'Crédito', troca: 'Troca', reembolso: 'Reembolso' };
const CONDITION_LABEL = { bom: 'Bom', danificado: 'Danificado', defeituoso: 'Defeituoso' };

export default function PdvDevolucoes() {
  const [returns, setReturns] = useState<ReturnRecord[]>([]);
  const [products, setProducts] = useState<{ id: string; name: string; sale_price: number }[]>([]);
  const [customers, setCustomers] = useState<{ id: string; name: string }[]>([]);
  const [invoices, setInvoices] = useState<{ id: string; invoice_number: string }[]>([]);
  const [loading, setLoading] = useState(true);
  const [showDialog, setShowDialog] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    customer_id: '', original_invoice_id: '', reason: '', resolution: 'credito', notes: '',
    return_date: new Date().toISOString().split('T')[0],
  });
  const [items, setItems] = useState<ReturnItem[]>([{ product_id: '', quantity: 1, unit_price: 0, total_price: 0, condition: 'bom', restock: true }]);

  useEffect(() => { load(); loadProducts(); loadCustomers(); loadInvoices(); }, []);

  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from('returns').select('*, customers(name), pdv_invoices(invoice_number)').order('created_at', { ascending: false }).limit(50);
    setReturns((data as ReturnRecord[]) || []);
    setLoading(false);
  };

  const loadProducts = async () => { const { data } = await supabase.from('pdv_products').select('id,name,sale_price').order('name'); setProducts(data || []); };
  const loadCustomers = async () => { const { data } = await supabase.from('customers').select('id,name').order('name'); setCustomers(data || []); };
  const loadInvoices = async () => { const { data } = await supabase.from('pdv_invoices').select('id,invoice_number').eq('type', 'saida').order('invoice_number', { ascending: false }).limit(100); setInvoices(data || []); };

  const updateItem = (idx: number, key: keyof ReturnItem, val: string | number | boolean) => {
    setItems(prev => {
      const copy = [...prev];
      const item = { ...copy[idx], [key]: val };
      if (key === 'quantity' || key === 'unit_price') {
        item.total_price = item.quantity * item.unit_price;
      }
      if (key === 'product_id') {
        const p = products.find(x => x.id === val);
        if (p) { item.unit_price = p.sale_price; item.total_price = item.quantity * p.sale_price; }
      }
      copy[idx] = item;
      return copy;
    });
  };

  const handleSave = async () => {
    if (!form.reason.trim()) { toast.error('Informe o motivo da devolução'); return; }
    if (items.some(i => !i.product_id)) { toast.error('Selecione todos os produtos'); return; }
    setSaving(true);
    const total = items.reduce((s, i) => s + i.total_price, 0);
    const { data: ret, error } = await supabase.from('returns').insert({
      original_invoice_id: form.original_invoice_id || null,
      customer_id: form.customer_id || null,
      return_date: form.return_date, reason: form.reason,
      resolution: form.resolution, total_amount: total,
      credit_issued: form.resolution === 'credito' ? total : 0,
      notes: form.notes || null,
    }).select().single();
    if (error || !ret) { toast.error('Erro: ' + error?.message); setSaving(false); return; }
    await supabase.from('return_items').insert(items.map(i => ({ ...i, return_id: ret.id })));
    // Restock products with restock=true
    for (const item of items.filter(i => i.restock && i.product_id)) {
      const { data: prod } = await supabase.from('pdv_products').select('stock_qty').eq('id', item.product_id).single();
      if (prod) {
        const newQty = prod.stock_qty + item.quantity;
        await supabase.from('pdv_products').update({ stock_qty: newQty }).eq('id', item.product_id);
        await supabase.from('pdv_stock_movements').insert({ product_id: item.product_id, type: 'entrada', quantity: item.quantity, previous_qty: prod.stock_qty, new_qty: newQty, notes: `Devolução: ${form.reason}`, reference_type: 'return' });
      }
    }
    setSaving(false);
    toast.success('Devolução registrada! Estoque atualizado.');
    setShowDialog(false);
    setForm({ customer_id: '', original_invoice_id: '', reason: '', resolution: 'credito', notes: '', return_date: new Date().toISOString().split('T')[0] });
    setItems([{ product_id: '', quantity: 1, unit_price: 0, total_price: 0, condition: 'bom', restock: true }]);
    load();
  };

  const ff = (k: string, v: string) => setForm(p => ({ ...p, [k]: v }));

  return (
    <PdvLayout title="Devoluções e Trocas" actions={
      <Button size="sm" onClick={() => setShowDialog(true)}>
        <Plus className="h-4 w-4 mr-1.5" />Nova Devolução
      </Button>
    }>
      <div className="bg-card border border-border rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="border-b border-border bg-muted/40">
              <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Data</th>
              <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Cliente</th>
              <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Nota Orig.</th>
              <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Motivo</th>
              <th className="text-center px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Resolução</th>
              <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Valor</th>
            </tr></thead>
            <tbody className="divide-y divide-border">
              {loading ? Array.from({ length: 4 }).map((_, i) => (
                <tr key={i}><td colSpan={6} className="px-4 py-3"><Skeleton className="h-5 w-full bg-muted" /></td></tr>
              )) : returns.length === 0 ? (
                <tr><td colSpan={6} className="text-center py-12 text-muted-foreground">
                  <RefreshCw className="h-8 w-8 mx-auto mb-2 opacity-40" />
                  <p className="text-pretty">Nenhuma devolução registrada</p>
                </td></tr>
              ) : returns.map(r => (
                <tr key={r.id} className="hover:bg-muted/30 transition-colors">
                  <td className="px-4 py-3 whitespace-nowrap">{new Date(r.return_date + 'T00:00:00').toLocaleDateString('pt-BR')}</td>
                  <td className="px-4 py-3 whitespace-nowrap">{r.customers?.name || '—'}</td>
                  <td className="px-4 py-3 font-mono text-xs whitespace-nowrap">{r.pdv_invoices?.invoice_number || '—'}</td>
                  <td className="px-4 py-3 max-w-[200px] truncate">{r.reason}</td>
                  <td className="px-4 py-3 text-center whitespace-nowrap">
                    <Badge variant="secondary" className="text-xs">{RESOLUTION_LABEL[r.resolution]}</Badge>
                  </td>
                  <td className="px-4 py-3 text-right font-medium whitespace-nowrap">R$ {r.total_amount.toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl">
          <DialogHeader><DialogTitle className="text-balance">Registrar Devolução / Troca</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2 max-h-[65vh] overflow-y-auto pr-1">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5"><Label className="text-sm font-normal">Data</Label><Input type="date" value={form.return_date} onChange={e => ff('return_date', e.target.value)} /></div>
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">Resolução</Label>
                <Select value={form.resolution} onValueChange={v => ff('resolution', v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="credito">Crédito</SelectItem><SelectItem value="troca">Troca</SelectItem><SelectItem value="reembolso">Reembolso</SelectItem></SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">Cliente</Label>
                <Select value={form.customer_id || 'none'} onValueChange={v => ff('customer_id', v === 'none' ? '' : v)}>
                  <SelectTrigger><SelectValue placeholder="Selecione..." /></SelectTrigger>
                  <SelectContent><SelectItem value="none">Nenhum</SelectItem>{customers.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">Nota Fiscal Original</Label>
                <Select value={form.original_invoice_id || 'none'} onValueChange={v => ff('original_invoice_id', v === 'none' ? '' : v)}>
                  <SelectTrigger><SelectValue placeholder="Selecione (opcional)" /></SelectTrigger>
                  <SelectContent><SelectItem value="none">Nenhuma</SelectItem>{invoices.map(i => <SelectItem key={i.id} value={i.id}>{i.invoice_number}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="col-span-2 space-y-1.5"><Label className="text-sm font-normal">Motivo *</Label><Input value={form.reason} onChange={e => ff('reason', e.target.value)} placeholder="Descreva o motivo da devolução" /></div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-sm font-semibold">Produtos Devolvidos</Label>
                <Button size="sm" variant="outline" onClick={() => setItems(prev => [...prev, { product_id: '', quantity: 1, unit_price: 0, total_price: 0, condition: 'bom', restock: true }])}>
                  <Plus className="h-3.5 w-3.5 mr-1" />Add
                </Button>
              </div>
              {items.map((item, idx) => (
                <div key={idx} className="grid grid-cols-6 gap-2 bg-muted/30 rounded-lg p-3">
                  <div className="col-span-2">
                    <Select value={item.product_id || 'none'} onValueChange={v => updateItem(idx, 'product_id', v === 'none' ? '' : v)}>
                      <SelectTrigger className="h-8 text-xs"><SelectValue placeholder="Produto..." /></SelectTrigger>
                      <SelectContent>{products.map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                  <Input className="h-8 text-xs" type="number" min="1" placeholder="Qtd" value={item.quantity} onChange={e => updateItem(idx, 'quantity', parseFloat(e.target.value) || 1)} />
                  <Input className="h-8 text-xs" type="number" min="0" step="0.01" placeholder="Preço" value={item.unit_price} onChange={e => updateItem(idx, 'unit_price', parseFloat(e.target.value) || 0)} />
                  <div>
                    <Select value={item.condition} onValueChange={v => updateItem(idx, 'condition', v as ReturnItem['condition'])}>
                      <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                      <SelectContent>{Object.entries(CONDITION_LABEL).map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                  <div className="flex items-center gap-1">
                    <input type="checkbox" checked={item.restock} onChange={e => updateItem(idx, 'restock', e.target.checked)} id={`restock-${idx}`} className="h-4 w-4" />
                    <label htmlFor={`restock-${idx}`} className="text-xs text-muted-foreground">Repor</label>
                  </div>
                </div>
              ))}
              <p className="text-sm font-medium text-right">Total: R$ {items.reduce((s, i) => s + i.total_price, 0).toFixed(2)}</p>
            </div>

            <div className="space-y-1.5"><Label className="text-sm font-normal">Observações</Label><Textarea value={form.notes} onChange={e => ff('notes', e.target.value)} rows={2} /></div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setShowDialog(false)}>Cancelar</Button>
            <Button onClick={handleSave} disabled={saving}><ArrowLeftRight className="h-4 w-4 mr-1.5" />Registrar Devolução</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PdvLayout>
  );
}
