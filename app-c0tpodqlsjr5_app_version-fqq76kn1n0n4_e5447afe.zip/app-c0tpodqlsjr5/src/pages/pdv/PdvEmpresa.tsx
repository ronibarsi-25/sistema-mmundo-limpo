import { useEffect, useState } from 'react';
import { Building2, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Skeleton } from '@/components/ui/skeleton';
import { PdvLayout } from '@/components/layouts/PdvLayout';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';

interface Company {
  id?: string;
  razao_social: string;
  nome_fantasia: string;
  cnpj: string;
  inscricao_estadual: string;
  email: string;
  telefone: string;
  whatsapp: string;
  website: string;
  cep: string;
  logradouro: string;
  numero: string;
  complemento: string;
  bairro: string;
  cidade: string;
  estado: string;
  logo_url: string;
}

const emptyCompany: Company = {
  razao_social: '', nome_fantasia: '', cnpj: '', inscricao_estadual: '',
  email: '', telefone: '', whatsapp: '', website: '', cep: '', logradouro: '',
  numero: '', complemento: '', bairro: '', cidade: '', estado: '', logo_url: '',
};

export default function PdvEmpresa() {
  const [company, setCompany] = useState<Company>(emptyCompany);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => { load(); }, []);

  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from('company').select('*').limit(1).maybeSingle();
    if (data) setCompany(data as Company);
    setLoading(false);
  };

  const lookupCep = async () => {
    if (company.cep.replace(/\D/g, '').length !== 8) return;
    try {
      const r = await fetch(`https://viacep.com.br/ws/${company.cep.replace(/\D/g, '')}/json/`);
      const d = await r.json();
      if (!d.erro) setCompany(p => ({ ...p, logradouro: d.logradouro, bairro: d.bairro, cidade: d.localidade, estado: d.uf }));
    } catch { /* silent */ }
  };

  const handleSave = async () => {
    if (!company.razao_social.trim()) { toast.error('Informe a razao social'); return; }
    setSaving(true);
    const payload = { ...company };
    const { error } = company.id
      ? await supabase.from('company').update(payload).eq('id', company.id)
      : await supabase.from('company').insert(payload);
    setSaving(false);
    if (error) { toast.error('Erro ao salvar: ' + error.message); return; }
    toast.success('Dados da empresa salvos!');
    load();
  };

  const f = (k: keyof Company, v: string) => setCompany(p => ({ ...p, [k]: v }));

  if (loading) return (
    <PdvLayout title="Empresa">
      <div className="space-y-4">{Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-10 w-full bg-muted" />)}</div>
    </PdvLayout>
  );

  return (
    <PdvLayout title="Dados da Empresa" actions={
      <Button size="sm" onClick={handleSave} disabled={saving}>
        {saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Salvar
      </Button>
    }>
      <div className="max-w-3xl space-y-6">
        <div className="bg-card border border-border rounded-lg p-5">
          <p className="text-sm font-semibold text-foreground mb-4">Logo da Empresa</p>
          <div className="flex items-center gap-4">
            <div className="h-16 w-16 rounded-lg border-2 border-dashed border-border flex items-center justify-center bg-muted/40 shrink-0">
              {company.logo_url ? (
                <img src={company.logo_url} alt="Logo" className="h-full w-full object-contain rounded-lg" />
              ) : (
                <Building2 className="h-7 w-7 text-muted-foreground" />
              )}
            </div>
            <div className="flex-1 min-w-0 space-y-1.5">
              <Label className="text-sm font-normal">URL da Logo</Label>
              <Input value={company.logo_url} onChange={e => f('logo_url', e.target.value)} placeholder="https://exemplo.com/logo.png" />
            </div>
          </div>
        </div>

        <div className="bg-card border border-border rounded-lg p-5">
          <p className="text-sm font-semibold text-foreground mb-4">Identificacao</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1.5 md:col-span-2"><Label className="text-sm font-normal">Razao Social *</Label><Input value={company.razao_social} onChange={e => f('razao_social', e.target.value)} /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Nome Fantasia</Label><Input value={company.nome_fantasia} onChange={e => f('nome_fantasia', e.target.value)} /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">CNPJ</Label><Input value={company.cnpj} onChange={e => f('cnpj', e.target.value)} placeholder="00.000.000/0000-00" /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Inscricao Estadual</Label><Input value={company.inscricao_estadual} onChange={e => f('inscricao_estadual', e.target.value)} /></div>
          </div>
        </div>

        <div className="bg-card border border-border rounded-lg p-5">
          <p className="text-sm font-semibold text-foreground mb-4">Contato</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1.5"><Label className="text-sm font-normal">E-mail</Label><Input type="email" value={company.email} onChange={e => f('email', e.target.value)} /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Telefone</Label><Input value={company.telefone} onChange={e => f('telefone', e.target.value)} /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">WhatsApp</Label><Input value={company.whatsapp} onChange={e => f('whatsapp', e.target.value)} /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Website</Label><Input value={company.website} onChange={e => f('website', e.target.value)} /></div>
          </div>
        </div>

        <div className="bg-card border border-border rounded-lg p-5">
          <p className="text-sm font-semibold text-foreground mb-4">Endereco</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1.5"><Label className="text-sm font-normal">CEP</Label><Input value={company.cep} onChange={e => f('cep', e.target.value)} onBlur={lookupCep} placeholder="00000-000" /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Logradouro</Label><Input value={company.logradouro} onChange={e => f('logradouro', e.target.value)} /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Numero</Label><Input value={company.numero} onChange={e => f('numero', e.target.value)} /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Complemento</Label><Input value={company.complemento} onChange={e => f('complemento', e.target.value)} /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Bairro</Label><Input value={company.bairro} onChange={e => f('bairro', e.target.value)} /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Cidade</Label><Input value={company.cidade} onChange={e => f('cidade', e.target.value)} /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Estado</Label><Input value={company.estado} onChange={e => f('estado', e.target.value)} maxLength={2} placeholder="SP" /></div>
          </div>
        </div>

        <Button className="w-full md:w-auto" onClick={handleSave} disabled={saving}>
          {saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Salvar Dados da Empresa
        </Button>
      </div>
    </PdvLayout>
  );
}
