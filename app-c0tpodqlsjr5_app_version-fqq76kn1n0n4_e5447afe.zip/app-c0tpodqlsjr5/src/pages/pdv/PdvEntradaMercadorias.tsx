import { useEffect, useState, useRef } from 'react';
import {
  Plus, Trash2, Search, Loader2, Receipt, FileUp, FileText, CheckCircle2,
  Building2, Calendar, DollarSign, PackagePlus, AlertCircle, RefreshCw,
  Copy, Layers, ArrowRight, UploadCloud, Info
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Checkbox } from '@/components/ui/checkbox';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { PdvLayout } from '@/components/layouts/PdvLayout';
import { supabase } from '@/db/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle
} from '@/components/ui/alert-dialog';
import type { GoodsReceipt, Supplier, PdvProduct } from '@/types/types';
import {
  parseNfeXmlString, parseDanfePdf, recalculateInvoiceItems,
  type ParsedNfeData, type ParsedInvoiceItem
} from '@/utils/nfeParser';

interface ReceiptItem {
  product: PdvProduct;
  quantity: string;
  cost_price: string;
}

interface ReceiptWithSupplier extends GoodsReceipt {
  goods_receipt_items: Array<{
    quantity: number;
    cost_price: number;
    total_price: number;
    pdv_products: { name: string; unit: string; code: string } | null;
  }>;
}

export default function PdvEntradaMercadorias() {
  const { profile } = useAuth();
  const [receipts, setReceipts] = useState<ReceiptWithSupplier[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [products, setProducts] = useState<PdvProduct[]>([]);
  const [loading, setLoading] = useState(true);

  // Modal Manual
  const [showManualDialog, setShowManualDialog] = useState(false);
  const [supplierId, setSupplierId] = useState('');
  const [invoiceNumber, setInvoiceNumber] = useState('');
  const [notes, setNotes] = useState('');
  const [manualItems, setManualItems] = useState<ReceiptItem[]>([]);
  const [productSearch, setProductSearch] = useState('');
  const [productResults, setProductResults] = useState<PdvProduct[]>([]);
  const [submittingManual, setSubmittingManual] = useState(false);

  // Modal Importação Nota (XML / PDF)
  const [showImportDialog, setShowImportDialog] = useState(false);
  const [importingFile, setImportingFile] = useState(false);
  const [nfeData, setNfeData] = useState<ParsedNfeData | null>(null);
  const [defaultMarkup, setDefaultMarkup] = useState<number>(50);
  const [includeTaxes, setIncludeTaxes] = useState<boolean>(true);
  const [generateBill, setGenerateBill] = useState<boolean>(true);
  const [submittingImport, setSubmittingImport] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Expansão e Exclusão
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [filterQuery, setFilterQuery] = useState('');

  useEffect(() => {
    loadAll();
  }, []);

  const loadAll = async () => {
    setLoading(true);
    const [recRes, supRes, prodRes] = await Promise.all([
      supabase
        .from('goods_receipts')
        .select('*, suppliers(razao_social, nome_fantasia), goods_receipt_items(quantity, cost_price, total_price, pdv_products(name, unit, code))')
        .order('received_at', { ascending: false })
        .limit(50),
      supabase.from('suppliers').select('*').eq('active', true).order('razao_social'),
      supabase.from('pdv_products').select('*').eq('active', true).order('name'),
    ]);
    setReceipts((recRes.data as ReceiptWithSupplier[]) || []);
    setSuppliers((supRes.data as Supplier[]) || []);
    setProducts((prodRes.data as PdvProduct[]) || []);
    setLoading(false);
  };

  // -------------------------------------------------------------
  // Processamento e Vínculo Inteligente de Arquivo (XML / PDF)
  // -------------------------------------------------------------
  const handleFileSelected = async (file: File) => {
    const isXml = file.type === 'text/xml' || file.name.toLowerCase().endsWith('.xml');
    const isPdf = file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf');

    if (!isXml && !isPdf) {
      toast.error('Formato não suportado. Selecione um arquivo XML (.xml) ou PDF (.pdf)');
      return;
    }

    setImportingFile(true);
    try {
      let parsed: ParsedNfeData;
      if (isXml) {
        const text = await file.text();
        parsed = parseNfeXmlString(text, defaultMarkup, includeTaxes);
      } else {
        parsed = await parseDanfePdf(file, defaultMarkup, includeTaxes);
      }

      if (parsed.itens.length === 0) {
        toast.error('Nenhum item foi identificado no arquivo da nota fiscal.');
        setImportingFile(false);
        return;
      }

      // Match dos itens com o catálogo de produtos existente
      const matchedItens = parsed.itens.map(item => {
        let match: PdvProduct | undefined;

        // 1. Tenta por Código de Barras (EAN)
        if (item.barcode && item.barcode.trim().length > 3) {
          match = products.find(p => p.barcode && p.barcode.trim() === item.barcode.trim());
        }

        // 2. Tenta por Código interno (SKU)
        if (!match && item.codigoFornecedor) {
          match = products.find(
            p => p.code && p.code.toLowerCase() === item.codigoFornecedor.toLowerCase()
          );
        }

        // 3. Tenta por nome idêntico (ignorando maiúsculas)
        if (!match && item.descricao) {
          match = products.find(
            p => p.name.trim().toLowerCase() === item.descricao.trim().toLowerCase()
          );
        }

        if (match) {
          return {
            ...item,
            matchedProductId: match.id,
            matchedProductName: match.name,
            matchedCurrentStock: match.stock_qty,
            action: 'update' as const,
          };
        }

        return {
          ...item,
          action: 'create' as const,
        };
      });

      setNfeData({
        ...parsed,
        itens: matchedItens,
      });

      toast.success(
        `Nota ${parsed.numero ? `nº ${parsed.numero}` : ''} processada: ${matchedItens.length} itens extraídos!`
      );
    } catch (err) {
      console.error(err);
      toast.error(err instanceof Error ? err.message : 'Erro ao processar arquivo da nota fiscal');
    } finally {
      setImportingFile(false);
    }
  };

  // Recalcular ao alterar markup ou toggle de impostos/frete
  const handleMarkupChange = (newMarkup: number) => {
    setDefaultMarkup(newMarkup);
    if (!nfeData) return;
    const updated = recalculateInvoiceItems(nfeData.itens, nfeData.totais, newMarkup, includeTaxes);
    setNfeData({ ...nfeData, itens: updated });
  };

  const handleIncludeTaxesChange = (newInclude: boolean) => {
    setIncludeTaxes(newInclude);
    if (!nfeData) return;
    const updated = recalculateInvoiceItems(nfeData.itens, nfeData.totais, defaultMarkup, newInclude);
    setNfeData({ ...nfeData, itens: updated });
  };

  const toggleItemSelection = (id: string) => {
    if (!nfeData) return;
    setNfeData({
      ...nfeData,
      itens: nfeData.itens.map(it => (it.id === id ? { ...it, selected: !it.selected } : it)),
    });
  };

  const updateNfeItemField = (id: string, field: keyof ParsedInvoiceItem, value: any) => {
    if (!nfeData) return;
    setNfeData({
      ...nfeData,
      itens: nfeData.itens.map(it => {
        if (it.id !== id) return it;
        const updated = { ...it, [field]: value };
        if (field === 'quantidade' || field === 'custoRealUnitario') {
          updated.valorTotalBruto = Number((updated.quantidade * updated.custoRealUnitario).toFixed(2));
          updated.precoVendaSugerido = Number(
            (updated.custoRealUnitario * (1 + defaultMarkup / 100)).toFixed(2)
          );
        }
        return updated;
      }),
    });
  };

  const changeItemMatch = (id: string, productId: string) => {
    if (!nfeData) return;
    if (productId === 'new') {
      setNfeData({
        ...nfeData,
        itens: nfeData.itens.map(it =>
          it.id === id
            ? { ...it, matchedProductId: undefined, matchedProductName: undefined, matchedCurrentStock: undefined, action: 'create' }
            : it
        ),
      });
      return;
    }

    const prod = products.find(p => p.id === productId);
    if (!prod) return;

    setNfeData({
      ...nfeData,
      itens: nfeData.itens.map(it =>
        it.id === id
          ? {
              ...it,
              matchedProductId: prod.id,
              matchedProductName: prod.name,
              matchedCurrentStock: prod.stock_qty,
              action: 'update',
            }
          : it
      ),
    });
  };

  // -------------------------------------------------------------
  // Efetivar Entrada por Nota Fiscal (XML / PDF)
  // -------------------------------------------------------------
  const handleConfirmImport = async () => {
    if (!profile || !nfeData) return;
    const selectedItems = nfeData.itens.filter(it => it.selected);

    if (selectedItems.length === 0) {
      toast.error('Selecione pelo menos um item para dar entrada');
      return;
    }

    setSubmittingImport(true);
    try {
      // 1. Identificar ou Cadastrar Fornecedor
      let currentSupplierId: string | null = null;
      if (nfeData.fornecedor.cnpj) {
        const cleanCnpj = nfeData.fornecedor.cnpj.replace(/\D/g, '');
        const { data: existingSup } = await supabase
          .from('suppliers')
          .select('id, razao_social')
          .ilike('cnpj', `%${cleanCnpj}%`)
          .maybeSingle();

        if (existingSup) {
          currentSupplierId = existingSup.id;
        } else {
          // Cadastrar fornecedor automaticamente
          const { data: newSup, error: supErr } = await supabase
            .from('suppliers')
            .insert({
              cnpj: nfeData.fornecedor.cnpj,
              razao_social: nfeData.fornecedor.razaoSocial || 'Fornecedor Importado',
              nome_fantasia: nfeData.fornecedor.nomeFantasia || nfeData.fornecedor.razaoSocial,
              logradouro: nfeData.fornecedor.logradouro || null,
              numero: nfeData.fornecedor.numero || null,
              bairro: nfeData.fornecedor.bairro || null,
              cidade: nfeData.fornecedor.municipio || null,
              estado: nfeData.fornecedor.uf || null,
              cep: nfeData.fornecedor.cep || null,
              phone: nfeData.fornecedor.telefone || null,
              active: true,
            })
            .select('id')
            .maybeSingle();

          if (!supErr && newSup) {
            currentSupplierId = newSup.id;
          }
        }
      }

      // 2. Criar ou Atualizar Produtos e movimentações de estoque
      const itemsToInsertInReceipt: Array<{
        product_id: string;
        quantity: number;
        cost_price: number;
        total_price: number;
      }> = [];

      let totalCalculatedAmount = 0;

      for (const item of selectedItems) {
        let finalProductId = item.matchedProductId;
        const qtyToAdd = Number(item.quantidade) || 1;
        const itemCost = Number(item.custoRealUnitario) || 0;
        const itemSale = Number(item.precoVendaSugerido) || itemCost * 1.5;
        const itemTotal = Number((qtyToAdd * itemCost).toFixed(2));
        totalCalculatedAmount += itemTotal;

        if (finalProductId) {
          // Atualiza produto existente
          const existingProd = products.find(p => p.id === finalProductId);
          const currentStock = existingProd ? Number(existingProd.stock_qty) || 0 : 0;
          const newStock = currentStock + qtyToAdd;

          const { error: updErr } = await supabase
            .from('pdv_products')
            .update({
              stock_qty: newStock,
              cost_price: itemCost,
              sale_price: itemSale > 0 ? itemSale : undefined,
            })
            .eq('id', finalProductId);

          if (updErr) throw updErr;

          // Movimentação de estoque
          await supabase.from('stock_movements').insert({
            product_id: finalProductId,
            type: 'entrada',
            quantity: qtyToAdd,
            previous_quantity: currentStock,
            new_quantity: newStock,
            notes: `Entrada por NF ${nfeData.numero || 'S/N'} (${nfeData.fornecedor.razaoSocial.slice(0, 30)})`,
            created_by: profile.id,
          });
        } else {
          // Cria novo produto no estoque
          const generatedCode = item.codigoFornecedor || `NF_${Math.random().toString(36).slice(2, 8).toUpperCase()}`;

          // Verifica se código já existe
          let uniqueCode = generatedCode;
          const existsCode = products.some(p => p.code.toLowerCase() === uniqueCode.toLowerCase());
          if (existsCode) {
            uniqueCode = `${generatedCode}_${Date.now().toString().slice(-4)}`;
          }

          const { data: newProd, error: newProdErr } = await supabase
            .from('pdv_products')
            .insert({
              code: uniqueCode,
              name: item.descricao || 'Produto sem nome',
              unit: (item.unidade || 'UN').toUpperCase(),
              cost_price: itemCost,
              sale_price: itemSale,
              stock_qty: qtyToAdd,
              barcode: item.barcode || null,
              active: true,
            })
            .select('id')
            .maybeSingle();

          if (newProdErr || !newProd) throw newProdErr || new Error('Erro ao cadastrar novo produto');
          finalProductId = newProd.id;

          // Movimentação inicial
          await supabase.from('stock_movements').insert({
            product_id: finalProductId,
            type: 'entrada',
            quantity: qtyToAdd,
            previous_quantity: 0,
            new_quantity: qtyToAdd,
            notes: `Entrada e Cadastro Inicial por NF ${nfeData.numero || 'S/N'}`,
            created_by: profile.id,
          });
        }

        if (!finalProductId) continue;

        itemsToInsertInReceipt.push({
          product_id: finalProductId,
          quantity: qtyToAdd,
          cost_price: itemCost,
          total_price: itemTotal,
        });
      }

      // 3. Registrar a Entrada em goods_receipts
      const finalInvoiceTotal = nfeData.totais.valorTotal > 0 ? nfeData.totais.valorTotal : totalCalculatedAmount;

      const { data: rec, error: recErr } = await supabase
        .from('goods_receipts')
        .insert({
          supplier_id: currentSupplierId,
          invoice_number: nfeData.numero ? `NF ${nfeData.numero}` : 'S/N',
          total_amount: finalInvoiceTotal,
          notes: `Importação automática via ${nfeData.tipoArquivo.toUpperCase()} · Chave: ${nfeData.chaveAcesso || 'N/D'} · Emissão: ${new Date(nfeData.dataEmissao).toLocaleDateString('pt-BR')}`,
          received_by: profile.id,
        })
        .select('id')
        .maybeSingle();

      if (recErr || !rec) throw recErr || new Error('Erro ao registrar entrada de mercadorias');

      // 4. Inserir itens da entrada
      const insItems = itemsToInsertInReceipt.map(it => ({
        receipt_id: rec.id,
        product_id: it.product_id,
        quantity: it.quantity,
        cost_price: it.cost_price,
        total_price: it.total_price,
      }));

      const { error: insErr } = await supabase.from('goods_receipt_items').insert(insItems);
      if (insErr) throw insErr;

      // 5. Gerar Contas a Pagar caso ativado
      if (generateBill && finalInvoiceTotal > 0) {
        try {
          const installmentsCount = nfeData.duplicatas.length > 0 ? nfeData.duplicatas.length : 1;
          const { data: billData, error: billErr } = await supabase
            .from('bills')
            .insert({
              type: 'pagar',
              description: `NF ${nfeData.numero || 'S/N'} - ${nfeData.fornecedor.razaoSocial.slice(0, 50)}`,
              total_amount: finalInvoiceTotal,
              installments: installmentsCount,
              category: 'Fornecedores',
              supplier_id: currentSupplierId,
              notes: `Gerado automaticamente na entrada de mercadorias. Chave NF: ${nfeData.chaveAcesso || 'N/D'}`,
              created_by: profile.id,
            })
            .select('id')
            .maybeSingle();

          if (!billErr && billData) {
            if (nfeData.duplicatas.length > 0) {
              const instInserts = nfeData.duplicatas.map((dup, idx) => ({
                bill_id: billData.id,
                installment_number: idx + 1,
                amount: dup.valor || finalInvoiceTotal / installmentsCount,
                due_date: dup.vencimento || new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
                status: 'pendente',
              }));
              await supabase.from('bill_installments').insert(instInserts);
            } else {
              // Parcela única com vencimento em 30 dias
              await supabase.from('bill_installments').insert({
                bill_id: billData.id,
                installment_number: 1,
                amount: finalInvoiceTotal,
                due_date: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
                status: 'pendente',
              });
            }
          }
        } catch (billE) {
          console.warn('Aviso: falha não bloqueante ao criar conta a pagar', billE);
        }
      }

      toast.success(
        `Entrada de ${selectedItems.length} produto(s) confirmada com sucesso! Estoque e preços atualizados.`
      );
      setShowImportDialog(false);
      setNfeData(null);
      loadAll();
    } catch (err) {
      console.error(err);
      toast.error(err instanceof Error ? err.message : 'Erro ao efetivar entrada de mercadorias');
    } finally {
      setSubmittingImport(false);
    }
  };

  // -------------------------------------------------------------
  // Entrada Manual
  // -------------------------------------------------------------
  const searchProducts = (q: string) => {
    setProductSearch(q);
    if (q.trim().length < 1) {
      setProductResults([]);
      return;
    }
    const res = products
      .filter(
        p =>
          p.name.toLowerCase().includes(q.toLowerCase()) ||
          p.code.toLowerCase().includes(q.toLowerCase()) ||
          (p.barcode && p.barcode.toLowerCase().includes(q.toLowerCase()))
      )
      .slice(0, 6);
    setProductResults(res);
  };

  const addManualItem = (p: PdvProduct) => {
    const exists = manualItems.find(i => i.product.id === p.id);
    if (exists) {
      toast.warning('Produto já adicionado na lista');
      return;
    }
    setManualItems(prev => [
      ...prev,
      { product: p, quantity: '1', cost_price: String(p.cost_price || '0.00') },
    ]);
    setProductSearch('');
    setProductResults([]);
  };

  const updateManualItem = (id: string, field: 'quantity' | 'cost_price', val: string) => {
    setManualItems(prev => prev.map(i => (i.product.id === id ? { ...i, [field]: val } : i)));
  };

  const removeManualItem = (id: string) =>
    setManualItems(prev => prev.filter(i => i.product.id !== id));

  const totalManualAmount = manualItems.reduce(
    (s, i) => s + (parseFloat(i.quantity) || 0) * (parseFloat(i.cost_price) || 0),
    0
  );

  const handleSaveManual = async () => {
    if (!profile) return;
    if (manualItems.length === 0) {
      toast.error('Adicione pelo menos um produto');
      return;
    }
    setSubmittingManual(true);
    try {
      const { data: rec, error: recErr } = await supabase
        .from('goods_receipts')
        .insert({
          supplier_id: supplierId || null,
          invoice_number: invoiceNumber || null,
          total_amount: totalManualAmount,
          notes: notes || null,
          received_by: profile.id,
        })
        .select()
        .maybeSingle();

      if (recErr || !rec) throw recErr || new Error('Erro ao criar entrada');

      const insItems = manualItems.map(i => ({
        receipt_id: rec.id,
        product_id: i.product.id,
        quantity: parseFloat(i.quantity),
        cost_price: parseFloat(i.cost_price),
        total_price: parseFloat(i.quantity) * parseFloat(i.cost_price),
      }));

      const { error: itErr } = await supabase.from('goods_receipt_items').insert(insItems);
      if (itErr) throw itErr;

      // Incrementa o estoque dos produtos e gera movimentação
      for (const item of manualItems) {
        const qty = parseFloat(item.quantity);
        const cost = parseFloat(item.cost_price);
        const currentStock = Number(item.product.stock_qty) || 0;
        const newStock = currentStock + qty;

        await supabase
          .from('pdv_products')
          .update({
            stock_qty: newStock,
            cost_price: cost,
          })
          .eq('id', item.product.id);

        await supabase.from('stock_movements').insert({
          product_id: item.product.id,
          type: 'entrada',
          quantity: qty,
          previous_quantity: currentStock,
          new_quantity: newStock,
          notes: `Entrada Manual ${invoiceNumber ? `NF ${invoiceNumber}` : ''}`,
          created_by: profile.id,
        });
      }

      toast.success('Entrada de mercadorias registrada com sucesso!');
      setShowManualDialog(false);
      setManualItems([]);
      setSupplierId('');
      setInvoiceNumber('');
      setNotes('');
      loadAll();
    } catch (err) {
      console.error(err);
      toast.error('Erro ao registrar entrada');
    } finally {
      setSubmittingManual(false);
    }
  };

  const handleDeleteReceipt = async () => {
    if (!deleteId) return;
    try {
      const { error } = await supabase.from('goods_receipts').delete().eq('id', deleteId);
      if (error) throw error;
      toast.success('Lançamento excluído com sucesso');
      setDeleteId(null);
      loadAll();
    } catch (err) {
      console.error(err);
      toast.error('Erro ao excluir lançamento');
    }
  };

  // Filtragem
  const filteredReceipts = receipts.filter(r => {
    if (!filterQuery) return true;
    const q = filterQuery.toLowerCase();
    const sup = ((r.suppliers as any)?.nome_fantasia || (r.suppliers as any)?.razao_social || '').toLowerCase();
    const nf = (r.invoice_number || '').toLowerCase();
    const obs = (r.notes || '').toLowerCase();
    return sup.includes(q) || nf.includes(q) || obs.includes(q);
  });

  return (
    <PdvLayout
      title="Entrada de Mercadorias"
      actions={
        <div className="flex items-center gap-2">
          <Button
            size="sm"
            onClick={() => {
              setNfeData(null);
              setShowImportDialog(true);
            }}
            className="bg-primary hover:bg-primary/90 text-primary-foreground font-medium shadow-sm"
          >
            <FileUp className="h-4 w-4 mr-1.5" />
            Importar Nota (XML / PDF)
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowManualDialog(true)}
            className="border-border text-primary hover:bg-muted"
          >
            <Plus className="h-4 w-4 mr-1.5" />
            Entrada Manual
          </Button>
        </div>
      }
    >
      {/* Banner / Card de Ação Rápida */}
      <div className="bg-gradient-to-r from-primary/10 via-primary/5 to-transparent border border-primary/20 rounded-xl p-4 md:p-5 mb-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="p-2.5 bg-primary/20 text-primary rounded-lg shrink-0 mt-0.5">
            <Receipt className="h-6 w-6" />
          </div>
          <div>
            <h3 className="text-base font-semibold text-foreground">
              Entrada Inteligente por Nota Fiscal (XML ou PDF)
            </h3>
            <p className="text-sm text-muted-foreground mt-0.5 max-w-2xl text-pretty">
              Importe o XML da NF-e ou o PDF do DANFE recebido do seu fornecedor. O sistema vincula automaticamente aos produtos já cadastrados, atualiza estoques, recalcula o custo e sugere preços de venda.
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 w-full md:w-auto shrink-0">
          <Button
            size="sm"
            onClick={() => {
              setNfeData(null);
              setShowImportDialog(true);
            }}
            className="w-full md:w-auto"
          >
            <FileUp className="h-4 w-4 mr-1.5" />
            Importar Arquivo
          </Button>
        </div>
      </div>

      {/* Barra de Busca de Histórico */}
      <div className="flex items-center justify-between gap-4 mb-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Buscar por fornecedor, número de nota ou observação..."
            value={filterQuery}
            onChange={e => setFilterQuery(e.target.value)}
            className="pl-9 bg-card"
          />
        </div>
        <Button variant="ghost" size="sm" onClick={loadAll} className="shrink-0 text-muted-foreground">
          <RefreshCw className="h-4 w-4 mr-1" />
          Atualizar
        </Button>
      </div>

      {/* Lista de Histórico de Entradas */}
      {loading ? (
        <div className="space-y-3">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-20 w-full bg-muted rounded-xl" />
          ))}
        </div>
      ) : filteredReceipts.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 px-4 text-muted-foreground border border-dashed border-border rounded-xl bg-card">
          <Receipt className="h-12 w-12 mb-3 opacity-30 text-primary" />
          <p className="text-base font-medium text-foreground text-center">Nenhuma entrada encontrada</p>
          <p className="text-sm text-muted-foreground text-center mt-1 max-w-md">
            Importe o XML ou PDF da sua nota fiscal para atualizar os estoques e custos automaticamente.
          </p>
          <div className="flex items-center gap-3 mt-4">
            <Button
              size="sm"
              onClick={() => {
                setNfeData(null);
                setShowImportDialog(true);
              }}
            >
              <FileUp className="h-4 w-4 mr-1.5" />
              Importar Nota (XML / PDF)
            </Button>
            <Button variant="outline" size="sm" onClick={() => setShowManualDialog(true)}>
              <Plus className="h-4 w-4 mr-1.5" />
              Entrada Manual
            </Button>
          </div>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredReceipts.map(r => (
            <div
              key={r.id}
              className="bg-card border border-border rounded-xl overflow-hidden shadow-sm hover:border-primary/40 transition-colors"
            >
              <button
                className="w-full flex items-center gap-4 px-4 py-3.5 text-left hover:bg-muted/30 transition-colors"
                onClick={() => setExpandedId(expandedId === r.id ? null : r.id)}
              >
                <div className="p-2 bg-muted rounded-lg text-primary shrink-0">
                  <Receipt className="h-5 w-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="text-sm font-semibold text-foreground">
                      {(r.suppliers as any)?.nome_fantasia ||
                        (r.suppliers as any)?.razao_social ||
                        'Fornecedor não informado'}
                    </p>
                    {r.invoice_number && (
                      <Badge variant="secondary" className="text-xs font-normal">
                        {r.invoice_number}
                      </Badge>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    {new Date(r.received_at).toLocaleDateString('pt-BR', {
                      day: '2-digit',
                      month: '2-digit',
                      year: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}{' '}
                    · {(r.goods_receipt_items || []).length} produto(s)
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <p className="text-xs text-muted-foreground">Valor Total</p>
                    <p className="text-sm font-bold text-primary">R$ {r.total_amount.toFixed(2)}</p>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-destructive hover:bg-destructive/10"
                    onClick={e => {
                      e.stopPropagation();
                      setDeleteId(r.id);
                    }}
                    title="Excluir lançamento"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </button>

              {expandedId === r.id && (
                <div className="border-t border-border px-4 py-3 bg-muted/20">
                  <div className="overflow-x-auto">
                    <table className="w-full text-xs">
                      <thead>
                        <tr className="text-muted-foreground border-b border-border/60">
                          <th className="text-left py-2 font-medium whitespace-nowrap">Código</th>
                          <th className="text-left py-2 font-medium whitespace-nowrap">Produto</th>
                          <th className="text-right py-2 font-medium whitespace-nowrap">Qtd Recebida</th>
                          <th className="text-right py-2 font-medium whitespace-nowrap">Custo Unitário</th>
                          <th className="text-right py-2 font-medium whitespace-nowrap">Total</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-border/40">
                        {(r.goods_receipt_items || []).map((it, idx) => (
                          <tr key={idx} className="hover:bg-background/50">
                            <td className="py-2 pr-2 text-muted-foreground font-mono whitespace-nowrap">
                              {it.pdv_products?.code || '—'}
                            </td>
                            <td className="py-2 pr-3 font-medium whitespace-nowrap">
                              {it.pdv_products?.name || 'Item não encontrado'}
                            </td>
                            <td className="py-2 text-right whitespace-nowrap">
                              {it.quantity} {it.pdv_products?.unit || 'UN'}
                            </td>
                            <td className="py-2 text-right whitespace-nowrap">
                              R$ {it.cost_price.toFixed(2)}
                            </td>
                            <td className="py-2 text-right font-semibold text-foreground whitespace-nowrap">
                              R$ {it.total_price.toFixed(2)}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  {r.notes && (
                    <p className="mt-3 text-xs text-muted-foreground bg-background/60 p-2 rounded border border-border/40 italic">
                      Obs: {r.notes}
                    </p>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Modal de Exclusão de Lançamento */}
      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-balance">Excluir lançamento de entrada?</AlertDialogTitle>
            <AlertDialogDescription className="text-pretty">
              Esta ação removerá o registro histórico de entrada. Os saldos atuais de estoque não serão revertidos automaticamente.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteReceipt} className="bg-destructive hover:bg-destructive/90">
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* ============================================================ */}
      {/* MODAL: ENTRADA DE MERCADORIAS POR NOTA FISCAL (XML / PDF)    */}
      {/* ============================================================ */}
      <Dialog open={showImportDialog} onOpenChange={setShowImportDialog}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-5xl max-h-[92dvh] overflow-y-auto flex flex-col p-4 md:p-6">
          <DialogHeader>
            <div className="flex items-center gap-2">
              <div className="p-2 bg-primary/20 text-primary rounded-lg shrink-0">
                <FileUp className="h-5 w-5" />
              </div>
              <div>
                <DialogTitle className="text-balance text-lg md:text-xl font-bold">
                  Entrada por Nota Fiscal (XML ou PDF)
                </DialogTitle>
                <DialogDescription className="text-pretty text-xs md:text-sm">
                  Faça o upload do XML (NF-e padrão SEFAZ) ou do PDF (DANFE) para conferir os itens e dar entrada no estoque.
                </DialogDescription>
              </div>
            </div>
          </DialogHeader>

          {/* Se nenhum arquivo foi processado ainda */}
          {!nfeData && (
            <div className="py-6 space-y-4">
              <div
                onClick={() => fileInputRef.current?.click()}
                onDragOver={e => e.preventDefault()}
                onDrop={e => {
                  e.preventDefault();
                  const f = e.dataTransfer.files?.[0];
                  if (f) handleFileSelected(f);
                }}
                className="border-2 border-dashed border-primary/40 hover:border-primary bg-primary/5 hover:bg-primary/10 transition-colors rounded-xl p-8 flex flex-col items-center justify-center text-center cursor-pointer min-h-[220px]"
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".xml,.pdf,text/xml,application/pdf"
                  className="hidden"
                  onChange={e => {
                    const f = e.target.files?.[0];
                    if (f) handleFileSelected(f);
                  }}
                />
                {importingFile ? (
                  <div className="space-y-3 flex flex-col items-center">
                    <Loader2 className="h-10 w-10 text-primary animate-spin" />
                    <p className="text-sm font-semibold text-foreground">
                      Processando e extraindo dados da nota fiscal...
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Lendo cabeçalho, fornecedor, impostos e conferindo catálogo de produtos...
                    </p>
                  </div>
                ) : (
                  <div className="space-y-3 flex flex-col items-center">
                    <div className="p-4 bg-primary/20 text-primary rounded-full">
                      <UploadCloud className="h-8 w-8" />
                    </div>
                    <div>
                      <p className="text-base font-semibold text-foreground">
                        Clique para selecionar ou arraste o arquivo aqui
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        Formatos suportados: <strong>XML de NF-e (.xml)</strong> e <strong>DANFE em PDF (.pdf)</strong>
                      </p>
                    </div>
                    <div className="flex items-center gap-2 pt-2">
                      <Badge variant="outline" className="text-xs">
                        Leitura instantânea de XML
                      </Badge>
                      <Badge variant="outline" className="text-xs">
                        Extração inteligente de PDF
                      </Badge>
                      <Badge variant="outline" className="text-xs">
                        Vínculo automático por EAN
                      </Badge>
                    </div>
                  </div>
                )}
              </div>

              <div className="bg-muted/40 p-4 rounded-xl text-xs text-muted-foreground space-y-1 border border-border">
                <p className="font-semibold text-foreground flex items-center gap-1.5">
                  <Info className="h-4 w-4 text-primary" /> Como funciona a entrada automática:
                </p>
                <p>1. O sistema lê todos os itens, quantidades, unidades, preços de custo e códigos de barras (EAN).</p>
                <p>2. Produtos já existentes no estoque são vinculados automaticamente, atualizando quantidade e custo.</p>
                <p>3. Produtos novos são preparados para cadastro direto, com cálculo sugerido de preço de venda.</p>
                <p>4. Você pode configurar o Markup padrão (%) e decidir se deseja ratear frete e impostos no custo.</p>
              </div>
            </div>
          )}

          {/* Dados da Nota e Tabela de Conferência */}
          {nfeData && (
            <div className="space-y-4 py-2">
              {/* Cabeçalho da Nota e Fornecedor */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 bg-muted/30 p-3.5 rounded-xl border border-border text-xs">
                <div className="space-y-1">
                  <p className="text-muted-foreground font-medium flex items-center gap-1">
                    <Building2 className="h-3.5 w-3.5 text-primary" /> Fornecedor / Emitente
                  </p>
                  <p className="font-bold text-foreground text-sm truncate">
                    {nfeData.fornecedor.razaoSocial}
                  </p>
                  <p className="text-muted-foreground">
                    CNPJ: {nfeData.fornecedor.cnpj || 'Não informado'}{' '}
                    {nfeData.fornecedor.uf ? `· ${nfeData.fornecedor.municipio}/${nfeData.fornecedor.uf}` : ''}
                  </p>
                </div>

                <div className="space-y-1">
                  <p className="text-muted-foreground font-medium flex items-center gap-1">
                    <FileText className="h-3.5 w-3.5 text-primary" /> Dados da Nota Fiscal
                  </p>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-foreground text-sm">
                      NF {nfeData.numero || 'S/N'} {nfeData.serie ? `· Série ${nfeData.serie}` : ''}
                    </span>
                    <Badge variant="secondary" className="uppercase text-[10px]">
                      {nfeData.tipoArquivo}
                    </Badge>
                  </div>
                  <p className="text-muted-foreground flex items-center gap-1 truncate">
                    <Calendar className="h-3 w-3" /> Emissão:{' '}
                    {new Date(nfeData.dataEmissao).toLocaleDateString('pt-BR')}
                  </p>
                </div>

                <div className="space-y-1 md:text-right">
                  <p className="text-muted-foreground font-medium flex md:justify-end items-center gap-1">
                    <DollarSign className="h-3.5 w-3.5 text-primary" /> Totais da Nota
                  </p>
                  <p className="text-base font-bold text-primary">
                    R$ {nfeData.totais.valorTotal.toFixed(2)}
                  </p>
                  <p className="text-muted-foreground text-[11px]">
                    Prod: R$ {nfeData.totais.valorProdutos.toFixed(2)}
                    {nfeData.totais.frete > 0 && ` | Frete: R$ ${nfeData.totais.frete.toFixed(2)}`}
                    {nfeData.totais.ipi > 0 && ` | IPI: R$ ${nfeData.totais.ipi.toFixed(2)}`}
                  </p>
                </div>

                {nfeData.chaveAcesso && (
                  <div className="col-span-full pt-1.5 border-t border-border/50 flex items-center justify-between gap-2 text-[11px]">
                    <span className="text-muted-foreground truncate">
                      Chave de Acesso: <span className="font-mono text-foreground">{nfeData.chaveAcesso}</span>
                    </span>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-6 px-2 text-[11px]"
                      onClick={() => {
                        navigator.clipboard.writeText(nfeData.chaveAcesso);
                        toast.success('Chave de acesso copiada!');
                      }}
                    >
                      <Copy className="h-3 w-3 mr-1" /> Copiar
                    </Button>
                  </div>
                )}
              </div>

              {/* Barra de Ajuste de Markup e Rateio */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-card p-3 rounded-xl border border-border items-center">
                <div className="flex items-center gap-2">
                  <Label className="text-xs font-medium whitespace-nowrap">Markup Padrão (%):</Label>
                  <Input
                    type="number"
                    min="0"
                    step="5"
                    value={defaultMarkup}
                    onChange={e => handleMarkupChange(parseFloat(e.target.value) || 0)}
                    className="w-20 h-8 text-xs text-right"
                  />
                  <span className="text-xs text-muted-foreground">sugerir venda</span>
                </div>

                <div className="flex items-center justify-start sm:justify-center gap-2">
                  <Switch
                    id="tax-toggle"
                    checked={includeTaxes}
                    onCheckedChange={handleIncludeTaxesChange}
                  />
                  <Label htmlFor="tax-toggle" className="text-xs cursor-pointer">
                    Ratear Frete/Impostos no Custo
                  </Label>
                </div>

                <div className="flex items-center justify-start sm:justify-end gap-2">
                  <Switch
                    id="bill-toggle"
                    checked={generateBill}
                    onCheckedChange={setGenerateBill}
                  />
                  <Label htmlFor="bill-toggle" className="text-xs cursor-pointer">
                    Gerar Contas a Pagar
                  </Label>
                </div>
              </div>

              {/* Tabela de Conferência de Itens */}
              <div className="border border-border rounded-xl overflow-hidden bg-card shadow-sm">
                <div className="p-3 bg-muted/30 border-b border-border flex items-center justify-between gap-2 flex-wrap text-xs">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-foreground">
                      Conferência de Produtos ({nfeData.itens.filter(i => i.selected).length} de {nfeData.itens.length} selecionados)
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-7 text-xs"
                      onClick={() => {
                        const allSelected = nfeData.itens.every(i => i.selected);
                        setNfeData({
                          ...nfeData,
                          itens: nfeData.itens.map(i => ({ ...i, selected: !allSelected })),
                        });
                      }}
                    >
                      {nfeData.itens.every(i => i.selected) ? 'Desmarcar Todos' : 'Selecionar Todos'}
                    </Button>
                  </div>
                </div>

                <div className="overflow-x-auto max-h-[380px]">
                  <table className="w-full text-xs">
                    <thead className="sticky top-0 bg-muted/90 backdrop-blur-sm z-10 border-b border-border text-muted-foreground">
                      <tr>
                        <th className="py-2.5 px-3 text-center w-10"></th>
                        <th className="py-2.5 px-3 text-left font-medium whitespace-nowrap">Item / Descrição</th>
                        <th className="py-2.5 px-3 text-left font-medium whitespace-nowrap">Vínculo Estoque</th>
                        <th className="py-2.5 px-3 text-right font-medium whitespace-nowrap">Qtd Nota</th>
                        <th className="py-2.5 px-3 text-right font-medium whitespace-nowrap">Custo Unit. (R$)</th>
                        <th className="py-2.5 px-3 text-right font-medium whitespace-nowrap">Preço Venda (R$)</th>
                        <th className="py-2.5 px-3 text-right font-medium whitespace-nowrap">Subtotal (R$)</th>
                        <th className="py-2.5 px-2 text-center w-10"></th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border/60">
                      {nfeData.itens.map(item => (
                        <tr
                          key={item.id}
                          className={`transition-colors ${
                            item.selected ? 'hover:bg-muted/40' : 'opacity-50 bg-muted/10'
                          }`}
                        >
                          <td className="py-2.5 px-3 text-center">
                            <Checkbox
                              checked={item.selected}
                              onCheckedChange={() => toggleItemSelection(item.id)}
                            />
                          </td>

                          {/* Descrição e Códigos */}
                          <td className="py-2.5 px-3 max-w-[240px]">
                            <p className="font-semibold text-foreground truncate" title={item.descricao}>
                              {item.descricao}
                            </p>
                            <div className="flex items-center gap-2 mt-0.5 text-[11px] text-muted-foreground flex-wrap">
                              <span>Cód: {item.codigoFornecedor}</span>
                              {item.barcode && <span className="font-mono">EAN: {item.barcode}</span>}
                              <span>Un: {item.unidade}</span>
                            </div>
                          </td>

                          {/* Vínculo inteligente */}
                          <td className="py-2.5 px-3 min-w-[200px]">
                            {item.action === 'update' && item.matchedProductId ? (
                              <div className="space-y-1">
                                <Badge className="bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border-emerald-500/30 text-[11px] flex items-center gap-1 w-fit">
                                  <CheckCircle2 className="h-3 w-3" />
                                  Vinculado: {item.matchedProductName?.slice(0, 18)}...
                                </Badge>
                                <p className="text-[10px] text-muted-foreground">
                                  Estoque atual: {item.matchedCurrentStock} {item.unidade} (+{item.quantidade})
                                </p>
                              </div>
                            ) : (
                              <div className="space-y-1">
                                <Badge variant="outline" className="text-primary border-primary/30 text-[11px] flex items-center gap-1 w-fit">
                                  <PackagePlus className="h-3 w-3" />
                                  Novo Produto no Estoque
                                </Badge>
                              </div>
                            )}

                            {/* Seletor para alterar vínculo manualmente */}
                            <Select
                              value={item.matchedProductId || 'new'}
                              onValueChange={v => changeItemMatch(item.id, v)}
                            >
                              <SelectTrigger className="h-6 text-[10px] mt-1 w-full max-w-[180px]">
                                <SelectValue placeholder="Alterar vínculo..." />
                              </SelectTrigger>
                              <SelectContent className="max-h-56">
                                <SelectItem value="new">+ Cadastrar como Novo Produto</SelectItem>
                                {products.map(p => (
                                  <SelectItem key={p.id} value={p.id}>
                                    {p.name.slice(0, 24)} (Cód: {p.code})
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </td>

                          {/* Quantidade */}
                          <td className="py-2.5 px-3 text-right">
                            <Input
                              type="number"
                              min="0.001"
                              step="0.001"
                              value={item.quantidade}
                              onChange={e =>
                                updateNfeItemField(item.id, 'quantidade', parseFloat(e.target.value) || 0)
                              }
                              className="w-20 h-7 text-xs text-right ml-auto"
                            />
                          </td>

                          {/* Custo Real Unitário */}
                          <td className="py-2.5 px-3 text-right">
                            <Input
                              type="number"
                              min="0.01"
                              step="0.01"
                              value={item.custoRealUnitario}
                              onChange={e =>
                                updateNfeItemField(
                                  item.id,
                                  'custoRealUnitario',
                                  parseFloat(e.target.value) || 0
                                )
                              }
                              className="w-20 h-7 text-xs text-right ml-auto"
                            />
                            {includeTaxes && item.custoRealUnitario !== item.valorUnitarioBruto && (
                              <span className="text-[10px] text-muted-foreground block mt-0.5">
                                Bruto: R$ {item.valorUnitarioBruto.toFixed(2)}
                              </span>
                            )}
                          </td>

                          {/* Preço de Venda Sugerido */}
                          <td className="py-2.5 px-3 text-right">
                            <Input
                              type="number"
                              min="0.01"
                              step="0.01"
                              value={item.precoVendaSugerido}
                              onChange={e =>
                                updateNfeItemField(
                                  item.id,
                                  'precoVendaSugerido',
                                  parseFloat(e.target.value) || 0
                                )
                              }
                              className="w-20 h-7 text-xs text-right ml-auto text-emerald-600 dark:text-emerald-400 font-semibold"
                            />
                          </td>

                          {/* Subtotal */}
                          <td className="py-2.5 px-3 text-right font-bold text-foreground">
                            R$ {(item.quantidade * item.custoRealUnitario).toFixed(2)}
                          </td>

                          {/* Excluir da importação */}
                          <td className="py-2.5 px-2 text-center">
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-6 w-6 text-muted-foreground hover:text-destructive"
                              onClick={() => {
                                setNfeData({
                                  ...nfeData,
                                  itens: nfeData.itens.filter(i => i.id !== item.id),
                                });
                              }}
                              title="Remover item da conferência"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Resumo Rodapé da Tabela */}
                <div className="p-3 bg-muted/40 border-t border-border flex items-center justify-between flex-wrap gap-3 text-xs">
                  <div className="flex items-center gap-4 text-muted-foreground">
                    <span>
                      Total de Peças Selecionadas:{' '}
                      <strong className="text-foreground">
                        {nfeData.itens
                          .filter(i => i.selected)
                          .reduce((s, i) => s + i.quantidade, 0)
                          .toFixed(0)}
                      </strong>
                    </span>
                    <span>
                      Novos Produtos:{' '}
                      <strong className="text-foreground">
                        {nfeData.itens.filter(i => i.selected && i.action === 'create').length}
                      </strong>
                    </span>
                    <span>
                      Produtos Vinculados:{' '}
                      <strong className="text-foreground">
                        {nfeData.itens.filter(i => i.selected && i.action === 'update').length}
                      </strong>
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-muted-foreground">Custo Total dos Itens Selecionados:</span>
                    <span className="text-sm font-bold text-primary">
                      R${' '}
                      {nfeData.itens
                        .filter(i => i.selected)
                        .reduce((s, i) => s + i.quantidade * i.custoRealUnitario, 0)
                        .toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

          <DialogFooter className="gap-2 pt-2 border-t border-border">
            {nfeData ? (
              <>
                <Button
                  variant="outline"
                  onClick={() => {
                    setNfeData(null);
                  }}
                  disabled={submittingImport}
                >
                  Trocar Arquivo
                </Button>
                <Button
                  onClick={handleConfirmImport}
                  disabled={submittingImport || nfeData.itens.filter(i => i.selected).length === 0}
                  className="bg-primary hover:bg-primary/90 text-primary-foreground font-semibold"
                >
                  {submittingImport ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" /> Atualizando Estoque e Preços...
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="h-4 w-4 mr-2" /> Confirmar Entrada de Mercadorias (
                      {nfeData.itens.filter(i => i.selected).length} itens)
                    </>
                  )}
                </Button>
              </>
            ) : (
              <Button variant="outline" onClick={() => setShowImportDialog(false)}>
                Cancelar
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ============================================================ */}
      {/* MODAL: ENTRADA MANUAL DE MERCADORIAS                         */}
      {/* ============================================================ */}
      <Dialog open={showManualDialog} onOpenChange={setShowManualDialog}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl max-h-[90dvh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-balance font-bold">Nova Entrada Manual de Mercadorias</DialogTitle>
            <DialogDescription className="text-pretty text-xs">
              Informe os dados da compra e selecione os produtos manualmente para incrementar o estoque.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-xs font-normal">Fornecedor</Label>
                <Select value={supplierId || 'none'} onValueChange={v => setSupplierId(v === 'none' ? '' : v)}>
                  <SelectTrigger className="h-9">
                    <SelectValue placeholder="Selecionar fornecedor" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Nenhum</SelectItem>
                    {suppliers.map(s => (
                      <SelectItem key={s.id} value={s.id}>
                        {s.nome_fantasia || s.razao_social}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-normal">Número da Nota Fiscal</Label>
                <Input
                  value={invoiceNumber}
                  onChange={e => setInvoiceNumber(e.target.value)}
                  placeholder="Ex: NF-00123"
                  className="h-9"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label className="text-xs font-normal">Adicionar Produto do Catálogo</Label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar por nome, código ou código de barras..."
                  value={productSearch}
                  onChange={e => searchProducts(e.target.value)}
                  className="pl-9 h-9"
                />
              </div>
              {productResults.length > 0 && (
                <div className="border border-border rounded-md overflow-hidden bg-card shadow-md max-h-48 overflow-y-auto">
                  {productResults.map(p => (
                    <button
                      key={p.id}
                      onClick={() => addManualItem(p)}
                      className="w-full flex items-center justify-between px-3 py-2 text-xs hover:bg-muted/60 transition-colors border-b border-border/50 last:border-0 text-left"
                    >
                      <span className="font-medium truncate">
                        {p.name} <span className="text-muted-foreground font-normal">({p.code})</span>
                      </span>
                      <span className="text-muted-foreground shrink-0 ml-2">
                        Estoque atual: {p.stock_qty} {p.unit}
                      </span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {manualItems.length > 0 && (
              <div className="border border-border rounded-lg overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="border-b border-border bg-muted/40">
                        <th className="text-left px-3 py-2 font-medium text-muted-foreground whitespace-nowrap">
                          Produto
                        </th>
                        <th className="text-right px-3 py-2 font-medium text-muted-foreground whitespace-nowrap">
                          Qtd
                        </th>
                        <th className="text-right px-3 py-2 font-medium text-muted-foreground whitespace-nowrap">
                          Custo (R$)
                        </th>
                        <th className="text-right px-3 py-2 font-medium text-muted-foreground whitespace-nowrap">
                          Total
                        </th>
                        <th className="px-3 py-2 w-8"></th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {manualItems.map(item => (
                        <tr key={item.product.id}>
                          <td className="px-3 py-2 whitespace-nowrap">
                            <p className="font-medium truncate max-w-[160px]">{item.product.name}</p>
                            <span className="text-[10px] text-muted-foreground">{item.product.code}</span>
                          </td>
                          <td className="px-3 py-2 text-right whitespace-nowrap">
                            <Input
                              type="number"
                              min="0.001"
                              step="0.001"
                              value={item.quantity}
                              onChange={e =>
                                updateManualItem(item.product.id, 'quantity', e.target.value)
                              }
                              className="w-20 h-7 text-right text-xs px-2 ml-auto"
                            />
                          </td>
                          <td className="px-3 py-2 text-right whitespace-nowrap">
                            <Input
                              type="number"
                              min="0"
                              step="0.01"
                              value={item.cost_price}
                              onChange={e =>
                                updateManualItem(item.product.id, 'cost_price', e.target.value)
                              }
                              className="w-24 h-7 text-right text-xs px-2 ml-auto"
                            />
                          </td>
                          <td className="px-3 py-2 text-right font-semibold whitespace-nowrap">
                            R${' '}
                            {(
                              (parseFloat(item.quantity) || 0) * (parseFloat(item.cost_price) || 0)
                            ).toFixed(2)}
                          </td>
                          <td className="px-3 py-2 text-right whitespace-nowrap">
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-6 w-6 text-destructive hover:bg-destructive/10"
                              onClick={() => removeManualItem(item.product.id)}
                            >
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          </td>
                        </tr>
                      ))}
                      <tr className="border-t-2 border-border bg-muted/30">
                        <td colSpan={3} className="px-3 py-2 text-right font-semibold text-xs">
                          Total da Entrada
                        </td>
                        <td className="px-3 py-2 text-right font-bold text-primary">
                          R$ {totalManualAmount.toFixed(2)}
                        </td>
                        <td></td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            <div className="space-y-1.5">
              <Label className="text-xs font-normal">Observações</Label>
              <Textarea
                value={notes}
                onChange={e => setNotes(e.target.value)}
                rows={2}
                placeholder="Ex: Compra de reposição de estoque via fornecedor local"
                className="text-xs"
              />
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setShowManualDialog(false)}>
              Cancelar
            </Button>
            <Button
              onClick={handleSaveManual}
              disabled={submittingManual || manualItems.length === 0}
              className="bg-primary hover:bg-primary/90 text-primary-foreground font-semibold"
            >
              {submittingManual && <Loader2 className="h-4 w-4 mr-2 animate-spin" />} Registrar Entrada
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PdvLayout>
  );
}
