import { useEffect, useState } from 'react';
import { Plus, Truck, Calendar, CheckCircle, Clock, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { PdvLayout } from '@/components/layouts/PdvLayout';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';

interface Delivery {
  id: string; invoice_id: string | null; customer_id: string | null;
  scheduled_date: string; scheduled_time: string | null;
  address: string; city: string | null; state: string | null;
  driver_name: string | null; status: string; notes: string | null;
  delivered_at: string | null; created_at: string;
  customers?: { name: string; phone: string } | null;
  pdv_invoices?: { invoice_number: string } | null;
}

const STATUS_INFO: Record<string, { label: string; color: string; icon: React.ElementType }> = {
  agendado: { label: 'Agendado', color: 'bg-primary/10 text-primary border-primary/30', icon: Calendar },
  em_rota: { label: 'Em Rota', color: 'bg-warning/10 text-warning border-warning/30', icon: Truck },
  entregue: { label: 'Entregue', color: 'bg-success/10 text-success border-success/30', icon: CheckCircle },
  cancelado: { label: 'Cancelado', color: 'bg-destructive/10 text-destructive border-destructive/30', icon: Clock },
  reagendado: { label: 'Reagendado', color: 'bg-muted text-muted-foreground border-border', icon: Calendar },
};

const today = new Date().toISOString().split('T')[0];

// Generate calendar days for current month
function getMonthDays(year: number, month: number) {
  const days = [];
  const first = new Date(year, month, 1).getDay();
  const total = new Date(year, month + 1, 0).getDate();
  for (let i = 0; i < first; i++) days.push(null);
  for (let d = 1; d <= total; d++) days.push(d);
  return days;
}

export default function PdvEntregas() {
  const [deliveries, setDeliveries] = useState<Delivery[]>([]);
  const [customers, setCustomers] = useState<{ id: string; name: string }[]>([]);
  const [invoices, setInvoices] = useState<{ id: string; invoice_number: string }[]>([]);
  const [loading, setLoading] = useState(true);
  const [showDialog, setShowDialog] = useState(false);
  const [showStatus, setShowStatus] = useState<Delivery | null>(null);
  const [saving, setSaving] = useState(false);
  const [calDate, setCalDate] = useState(new Date());
  const [form, setForm] = useState({ customer_id: '', invoice_id: '', scheduled_date: today, scheduled_time: '', address: '', city: '', state: '', driver_name: '', notes: '' });

  useEffect(() => { loadDeliveries(); loadCustomers(); loadInvoices(); }, []);

  const loadDeliveries = async () => {
    setLoading(true);
    const { data } = await supabase.from('deliveries').select('*, customers(name,phone), pdv_invoices(invoice_number)').order('scheduled_date');
    setDeliveries((data as Delivery[]) || []);
    setLoading(false);
  };
  const loadCustomers = async () => { const { data } = await supabase.from('customers').select('id,name').order('name'); setCustomers(data || []); };
  const loadInvoices = async () => { const { data } = await supabase.from('pdv_invoices').select('id,invoice_number').eq('type', 'saida').order('invoice_number', { ascending: false }).limit(100); setInvoices(data || []); };

  const handleSave = async () => {
    if (!form.address.trim()) { toast.error('Informe o endereço de entrega'); return; }
    if (!form.scheduled_date) { toast.error('Informe a data agendada'); return; }
    setSaving(true);
    const { error } = await supabase.from('deliveries').insert({
      customer_id: form.customer_id || null, invoice_id: form.invoice_id || null,
      scheduled_date: form.scheduled_date, scheduled_time: form.scheduled_time || null,
      address: form.address, city: form.city || null, state: form.state || null,
      driver_name: form.driver_name || null, notes: form.notes || null, status: 'agendado',
    });
    setSaving(false);
    if (error) { toast.error('Erro: ' + error.message); return; }
    toast.success('Entrega agendada!');
    setShowDialog(false);
    setForm({ customer_id: '', invoice_id: '', scheduled_date: today, scheduled_time: '', address: '', city: '', state: '', driver_name: '', notes: '' });
    loadDeliveries();
  };

  const updateStatus = async (id: string, status: string) => {
    const update: Record<string, string | null> = { status, updated_at: new Date().toISOString() };
    if (status === 'entregue') update.delivered_at = new Date().toISOString();
    const { error } = await supabase.from('deliveries').update(update).eq('id', id);
    if (error) { toast.error('Erro'); return; }
    toast.success('Status atualizado!');
    setShowStatus(null);
    loadDeliveries();
  };

  const ff = (k: string, v: string) => setForm(p => ({ ...p, [k]: v }));

  const monthDays = getMonthDays(calDate.getFullYear(), calDate.getMonth());
  const deliveriesByDay: Record<string, Delivery[]> = {};
  deliveries.forEach(d => {
    deliveriesByDay[d.scheduled_date] = [...(deliveriesByDay[d.scheduled_date] || []), d];
  });

  const WEEKDAYS = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];

  return (
    <PdvLayout title="Agendamento de Entregas" actions={
      <Button size="sm" onClick={() => setShowDialog(true)}>
        <Plus className="h-4 w-4 mr-1.5" />Agendar Entrega
      </Button>
    }>
      <div className="space-y-4">
        <Tabs defaultValue="lista">
          <TabsList>
            <TabsTrigger value="lista">Lista</TabsTrigger>
            <TabsTrigger value="calendario">Calendário</TabsTrigger>
          </TabsList>

          <TabsContent value="lista" className="mt-4">
            <div className="bg-card border border-border rounded-lg overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead><tr className="border-b border-border bg-muted/40">
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Data</th>
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Hora</th>
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Cliente</th>
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Endereço</th>
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Entregador</th>
                    <th className="text-center px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Status</th>
                    <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Ação</th>
                  </tr></thead>
                  <tbody className="divide-y divide-border">
                    {loading ? Array.from({ length: 4 }).map((_, i) => <tr key={i}><td colSpan={7} className="px-4 py-3"><Skeleton className="h-5 w-full bg-muted" /></td></tr>)
                      : deliveries.length === 0 ? <tr><td colSpan={7} className="text-center py-12 text-muted-foreground"><Truck className="h-8 w-8 mx-auto mb-2 opacity-40" /><p>Nenhuma entrega agendada</p></td></tr>
                      : deliveries.map(d => {
                        const si = STATUS_INFO[d.status] || STATUS_INFO['agendado'];
                        return (
                          <tr key={d.id} className="hover:bg-muted/30">
                            <td className="px-4 py-3 whitespace-nowrap font-medium">{new Date(d.scheduled_date + 'T00:00:00').toLocaleDateString('pt-BR')}</td>
                            <td className="px-4 py-3 whitespace-nowrap text-muted-foreground">{d.scheduled_time ? d.scheduled_time.slice(0, 5) : '—'}</td>
                            <td className="px-4 py-3 whitespace-nowrap">{d.customers?.name || '—'}</td>
                            <td className="px-4 py-3 max-w-[180px] truncate text-muted-foreground">{d.address}{d.city ? `, ${d.city}` : ''}</td>
                            <td className="px-4 py-3 whitespace-nowrap text-muted-foreground">{d.driver_name || '—'}</td>
                            <td className="px-4 py-3 text-center whitespace-nowrap">
                              <span className={`inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full border ${si.color}`}>
                                <si.icon className="h-3 w-3" />{si.label}
                              </span>
                            </td>
                            <td className="px-4 py-3 text-right whitespace-nowrap">
                              {d.status !== 'entregue' && d.status !== 'cancelado' && (
                                <Button variant="outline" size="sm" className="h-7 text-xs" onClick={() => setShowStatus(d)}>Atualizar</Button>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                  </tbody>
                </table>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="calendario" className="mt-4">
            <div className="bg-card border border-border rounded-lg p-4">
              <div className="flex items-center justify-between mb-4">
                <Button variant="ghost" size="sm" onClick={() => setCalDate(d => new Date(d.getFullYear(), d.getMonth() - 1))}>‹</Button>
                <h3 className="font-semibold text-foreground">{calDate.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' })}</h3>
                <Button variant="ghost" size="sm" onClick={() => setCalDate(d => new Date(d.getFullYear(), d.getMonth() + 1))}>›</Button>
              </div>
              <div className="grid grid-cols-7 gap-1 mb-2">
                {WEEKDAYS.map(d => <div key={d} className="text-center text-xs font-medium text-muted-foreground py-1">{d}</div>)}
              </div>
              <div className="grid grid-cols-7 gap-1">
                {monthDays.map((day, idx) => {
                  if (!day) return <div key={idx} />;
                  const dateStr = `${calDate.getFullYear()}-${String(calDate.getMonth() + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
                  const dayDeliveries = deliveriesByDay[dateStr] || [];
                  const isToday = dateStr === today;
                  return (
                    <div key={idx} className={`min-h-14 p-1 rounded border text-xs ${isToday ? 'border-primary bg-primary/5' : 'border-border bg-background'}`}>
                      <p className={`font-medium mb-1 ${isToday ? 'text-primary' : 'text-foreground'}`}>{day}</p>
                      {dayDeliveries.slice(0, 2).map(d => {
                        const si = STATUS_INFO[d.status] || STATUS_INFO['agendado'];
                        return (
                          <div key={d.id} className={`text-[10px] px-1 py-0.5 rounded truncate border mb-0.5 ${si.color}`}>
                            {d.customers?.name || d.address.slice(0, 12)}
                          </div>
                        );
                      })}
                      {dayDeliveries.length > 2 && <p className="text-[10px] text-muted-foreground">+{dayDeliveries.length - 2}</p>}
                    </div>
                  );
                })}
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* New Delivery Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle className="text-balance">Agendar Entrega</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-4 py-2 max-h-[65vh] overflow-y-auto pr-1">
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Cliente</Label>
              <Select value={form.customer_id || 'none'} onValueChange={v => ff('customer_id', v === 'none' ? '' : v)}>
                <SelectTrigger><SelectValue placeholder="Selecione..." /></SelectTrigger>
                <SelectContent><SelectItem value="none">Nenhum</SelectItem>{customers.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Nota Fiscal</Label>
              <Select value={form.invoice_id || 'none'} onValueChange={v => ff('invoice_id', v === 'none' ? '' : v)}>
                <SelectTrigger><SelectValue placeholder="Opcional" /></SelectTrigger>
                <SelectContent><SelectItem value="none">Nenhuma</SelectItem>{invoices.map(i => <SelectItem key={i.id} value={i.id}>{i.invoice_number}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Data *</Label><Input type="date" value={form.scheduled_date} onChange={e => ff('scheduled_date', e.target.value)} /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Hora</Label><Input type="time" value={form.scheduled_time} onChange={e => ff('scheduled_time', e.target.value)} /></div>
            <div className="col-span-2 space-y-1.5"><Label className="text-sm font-normal">Endereço de Entrega *</Label><Input value={form.address} onChange={e => ff('address', e.target.value)} placeholder="Rua, número, bairro" /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Cidade</Label><Input value={form.city} onChange={e => ff('city', e.target.value)} /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Estado</Label><Input value={form.state} onChange={e => ff('state', e.target.value)} maxLength={2} placeholder="SP" /></div>
            <div className="col-span-2 space-y-1.5"><Label className="text-sm font-normal">Entregador</Label><Input value={form.driver_name} onChange={e => ff('driver_name', e.target.value)} placeholder="Nome do entregador" /></div>
            <div className="col-span-2 space-y-1.5"><Label className="text-sm font-normal">Observações</Label><Textarea value={form.notes} onChange={e => ff('notes', e.target.value)} rows={2} /></div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setShowDialog(false)}>Cancelar</Button>
            <Button onClick={handleSave} disabled={saving}><Truck className="h-4 w-4 mr-1.5" />Agendar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Update Status Dialog */}
      <Dialog open={!!showStatus} onOpenChange={o => { if (!o) setShowStatus(null); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-sm">
          <DialogHeader><DialogTitle className="text-balance">Atualizar Status da Entrega</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <div className="text-sm text-muted-foreground space-y-1">
              <p>Cliente: <strong className="text-foreground">{showStatus?.customers?.name || '—'}</strong></p>
              <div className="flex items-center gap-1 text-muted-foreground"><MapPin className="h-3.5 w-3.5" />{showStatus?.address}</div>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {Object.entries(STATUS_INFO).map(([key, info]) => (
                <Button key={key} variant="outline" className={`h-auto py-2 flex items-center gap-2 justify-start ${showStatus?.status === key ? 'border-primary bg-primary/5' : ''}`} onClick={() => updateStatus(showStatus!.id, key)}>
                  <info.icon className="h-4 w-4" /><span className="text-sm">{info.label}</span>
                </Button>
              ))}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </PdvLayout>
  );
}
