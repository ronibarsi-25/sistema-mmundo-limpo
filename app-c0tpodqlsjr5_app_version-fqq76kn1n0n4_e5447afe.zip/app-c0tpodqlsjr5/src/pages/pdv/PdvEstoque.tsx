import { useEffect, useState } from 'react';
import { Search, AlertTriangle, TrendingUp, TrendingDown, SlidersHorizontal, Plus, Minus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { PdvLayout } from '@/components/layouts/PdvLayout';
import { supabase } from '@/db/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import type { PdvProduct, StockMovement } from '@/types/types';

export default function PdvEstoque() {
  const { profile } = useAuth();
  const [products, setProducts] = useState<PdvProduct[]>([]);
  const [movements, setMovements] = useState<StockMovement[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<'all' | 'baixo' | 'zero'>('all');
  const [showAdjust, setShowAdjust] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<PdvProduct | null>(null);
  const [adjType, setAdjType] = useState<'entrada' | 'saida' | 'ajuste'>('ajuste');
  const [adjQty, setAdjQty] = useState('');
  const [adjNotes, setAdjNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => { loadAll(); }, []);

  const loadAll = async () => {
    setLoading(true);
    const [prodRes, movRes] = await Promise.all([
      supabase.from('pdv_products').select('*, pdv_categories(id,name,color)').eq('active', true).order('name'),
      supabase.from('pdv_stock_movements').select('*, pdv_products(name,unit)').order('created_at', { ascending: false }).limit(50),
    ]);
    setProducts((prodRes.data as PdvProduct[]) || []);
    setMovements((movRes.data as StockMovement[]) || []);
    setLoading(false);
  };

  const openAdjust = (p: PdvProduct) => { setSelectedProduct(p); setAdjQty(''); setAdjNotes(''); setAdjType('ajuste'); setShowAdjust(true); };

  const handleAdjust = async () => {
    if (!selectedProduct || !profile) return;
    const qty = parseFloat(adjQty);
    if (!qty || qty <= 0) { toast.error('Informe uma quantidade válida'); return; }
    setSubmitting(true);
    const prevQty = selectedProduct.stock_qty;
    let newQty = prevQty;
    if (adjType === 'entrada') newQty = prevQty + qty;
    else if (adjType === 'saida') newQty = Math.max(0, prevQty - qty);
    else newQty = qty;

    const { error: movErr } = await supabase.from('pdv_stock_movements').insert({
      product_id: selectedProduct.id, type: adjType, quantity: qty,
      previous_qty: prevQty, new_qty: newQty,
      notes: adjNotes || null, created_by: profile.id,
      reference_type: 'ajuste_manual',
    });
    if (movErr) { toast.error('Erro ao registrar movimentação'); setSubmitting(false); return; }
    const { error: updErr } = await supabase.from('pdv_products').update({ stock_qty: newQty }).eq('id', selectedProduct.id);
    setSubmitting(false);
    if (updErr) { toast.error('Erro ao atualizar estoque'); return; }
    toast.success(`Estoque ajustado: ${prevQty} → ${newQty} ${selectedProduct.unit}`);
    setShowAdjust(false);
    loadAll();
  };

  const filtered = products.filter(p => {
    const s = search.toLowerCase();
    const matchSearch = !search || 
      p.name.toLowerCase().includes(s) || 
      p.code.toLowerCase().includes(s) || 
      (p.barcode && p.barcode.toLowerCase().includes(s));
    const matchFilter = filter === 'all' || (filter === 'baixo' && p.stock_qty <= p.stock_min && p.stock_qty > 0) || (filter === 'zero' && p.stock_qty === 0);
    return matchSearch && matchFilter;
  });

  const totalValue = products.reduce((s, p) => s + p.stock_qty * p.cost_price, 0);
  const lowCount = products.filter(p => p.stock_qty <= p.stock_min).length;
  const zeroCount = products.filter(p => p.stock_qty === 0).length;

  const movTypeLabel = { entrada: 'Entrada', saida: 'Saída', ajuste: 'Ajuste' };
  const movTypeClass = { entrada: 'status-badge-success', saida: 'status-badge-destructive', ajuste: 'status-badge-info' };

  return (
    <PdvLayout title="Estoque">
      {/* Summary cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-5">
        <div className="bg-card border border-border rounded-lg p-4 flex flex-col gap-1">
          <p className="text-xs text-muted-foreground">Valor em Estoque</p>
          <p className="text-lg font-bold text-primary">R$ {totalValue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</p>
        </div>
        <div className="bg-card border border-warning/30 bg-warning/5 rounded-lg p-4 flex flex-col gap-1">
          <p className="text-xs text-muted-foreground flex items-center gap-1"><AlertTriangle className="h-3 w-3 text-warning" />Estoque Baixo</p>
          <p className="text-lg font-bold text-warning">{lowCount} produtos</p>
        </div>
        <div className="bg-card border border-destructive/30 bg-destructive/5 rounded-lg p-4 flex flex-col gap-1 col-span-2 md:col-span-1">
          <p className="text-xs text-muted-foreground flex items-center gap-1"><AlertTriangle className="h-3 w-3 text-destructive" />Sem Estoque</p>
          <p className="text-lg font-bold text-destructive">{zeroCount} produtos</p>
        </div>
      </div>

      <Tabs defaultValue="produtos">
        <TabsList className="mb-4">
          <TabsTrigger value="produtos">Produtos</TabsTrigger>
          <TabsTrigger value="movimentacoes">Movimentações</TabsTrigger>
        </TabsList>

        <TabsContent value="produtos">
          <div className="flex flex-col md:flex-row gap-3 mb-4">
            <div className="relative flex-1 min-w-0">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Buscar produto..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
            </div>
            <Select value={filter} onValueChange={v => setFilter(v as 'all' | 'baixo' | 'zero')}>
              <SelectTrigger className="w-full md:w-44 shrink-0"><SlidersHorizontal className="h-4 w-4 mr-2" /><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os produtos</SelectItem>
                <SelectItem value="baixo">Estoque baixo</SelectItem>
                <SelectItem value="zero">Sem estoque</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="bg-card border border-border rounded-lg overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border bg-muted/40">
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Produto</th>
                    <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Estoque</th>
                    <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Mínimo</th>
                    <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Custo Unitário</th>
                    <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Valor Total</th>
                    <th className="text-center px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Situação</th>
                    <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Ajustar</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {loading ? (
                    Array.from({ length: 5 }).map((_, i) => <tr key={i}><td colSpan={7} className="px-4 py-3"><Skeleton className="h-5 w-full bg-muted" /></td></tr>)
                  ) : filtered.length === 0 ? (
                    <tr><td colSpan={7} className="text-center py-10 text-muted-foreground text-pretty">Nenhum produto encontrado</td></tr>
                  ) : filtered.map(p => {
                    const situation = p.stock_qty === 0 ? 'zero' : p.stock_qty <= p.stock_min ? 'baixo' : 'ok';
                    return (
                      <tr key={p.id} className="hover:bg-muted/30 transition-colors">
                        <td className="px-4 py-3 whitespace-nowrap">
                          <p className="font-medium text-foreground">{p.name}</p>
                          <p className="text-xs text-muted-foreground">{p.code}</p>
                        </td>
                        <td className="px-4 py-3 text-right whitespace-nowrap font-semibold">
                          <span className={situation !== 'ok' ? 'text-destructive' : 'text-foreground'}>{p.stock_qty}</span>
                          <span className="text-xs text-muted-foreground ml-1">{p.unit}</span>
                        </td>
                        <td className="px-4 py-3 text-right text-muted-foreground whitespace-nowrap">{p.stock_min} {p.unit}</td>
                        <td className="px-4 py-3 text-right text-muted-foreground whitespace-nowrap">R$ {p.cost_price.toFixed(2)}</td>
                        <td className="px-4 py-3 text-right font-medium whitespace-nowrap">R$ {(p.stock_qty * p.cost_price).toFixed(2)}</td>
                        <td className="px-4 py-3 text-center whitespace-nowrap">
                          {situation === 'ok' && <span className="status-badge-success">Normal</span>}
                          {situation === 'baixo' && <span className="status-badge-warning">Baixo</span>}
                          {situation === 'zero' && <span className="status-badge-destructive">Zerado</span>}
                        </td>
                        <td className="px-4 py-3 text-right whitespace-nowrap">
                          <Button variant="outline" size="sm" className="h-7 text-xs" onClick={() => openAdjust(p)}>
                            <SlidersHorizontal className="h-3 w-3 mr-1" />Ajustar
                          </Button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="movimentacoes">
          <div className="bg-card border border-border rounded-lg overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border bg-muted/40">
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Data</th>
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Produto</th>
                    <th className="text-center px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Tipo</th>
                    <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Quantidade</th>
                    <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Anterior</th>
                    <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Novo</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {loading ? (
                    Array.from({ length: 5 }).map((_, i) => <tr key={i}><td colSpan={6} className="px-4 py-3"><Skeleton className="h-5 w-full bg-muted" /></td></tr>)
                  ) : movements.length === 0 ? (
                    <tr><td colSpan={6} className="text-center py-10 text-muted-foreground text-pretty">Nenhuma movimentação registrada</td></tr>
                  ) : movements.map(m => (
                    <tr key={m.id} className="hover:bg-muted/30 transition-colors">
                      <td className="px-4 py-3 text-xs text-muted-foreground whitespace-nowrap">{new Date(m.created_at).toLocaleDateString('pt-BR')}</td>
                      <td className="px-4 py-3 whitespace-nowrap font-medium">{m.pdv_products?.name || '—'}</td>
                      <td className="px-4 py-3 text-center whitespace-nowrap">
                        <span className={movTypeClass[m.type as keyof typeof movTypeClass] || 'status-badge-muted'}>{movTypeLabel[m.type as keyof typeof movTypeLabel] || m.type}</span>
                      </td>
                      <td className="px-4 py-3 text-right whitespace-nowrap">
                        <span className="flex items-center justify-end gap-1">
                          {m.type === 'entrada' ? <TrendingUp className="h-3.5 w-3.5 text-success" /> : m.type === 'saida' ? <TrendingDown className="h-3.5 w-3.5 text-destructive" /> : null}
                          {m.quantity}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-right text-muted-foreground whitespace-nowrap">{m.previous_qty}</td>
                      <td className="px-4 py-3 text-right font-semibold whitespace-nowrap">{m.new_qty}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </TabsContent>
      </Tabs>

      {/* Adjust dialog */}
      <Dialog open={showAdjust} onOpenChange={setShowAdjust}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-sm">
          <DialogHeader><DialogTitle className="text-balance">Ajuste de Estoque</DialogTitle></DialogHeader>
          {selectedProduct && (
            <div className="space-y-4 py-2">
              <div className="bg-muted/40 rounded-md px-3 py-2">
                <p className="text-sm font-semibold text-foreground">{selectedProduct.name}</p>
                <p className="text-xs text-muted-foreground">Estoque atual: <strong>{selectedProduct.stock_qty} {selectedProduct.unit}</strong></p>
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">Tipo de Ajuste</Label>
                <div className="grid grid-cols-3 gap-2">
                  {(['entrada', 'saida', 'ajuste'] as const).map(t => (
                    <button key={t} onClick={() => setAdjType(t)}
                      className={`py-2 px-3 rounded-md border text-xs font-medium transition-colors ${adjType === t ? 'border-primary bg-primary/10 text-primary' : 'border-border text-muted-foreground hover:bg-muted/60'}`}>
                      {t === 'entrada' ? <><Plus className="h-3 w-3 inline mr-1" />Entrada</> : t === 'saida' ? <><Minus className="h-3 w-3 inline mr-1" />Saída</> : 'Ajuste'}
                    </button>
                  ))}
                </div>
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">{adjType === 'ajuste' ? 'Novo Estoque' : 'Quantidade'} ({selectedProduct.unit})</Label>
                <Input type="number" min="0" step="0.001" value={adjQty} onChange={e => setAdjQty(e.target.value)} autoFocus />
                {adjQty && (
                  <p className="text-xs text-muted-foreground">
                    Resultado: {adjType === 'entrada' ? selectedProduct.stock_qty + (parseFloat(adjQty) || 0) : adjType === 'saida' ? Math.max(0, selectedProduct.stock_qty - (parseFloat(adjQty) || 0)) : parseFloat(adjQty) || 0} {selectedProduct.unit}
                  </p>
                )}
              </div>
              <div className="space-y-1.5"><Label className="text-sm font-normal">Motivo / Observações</Label><Textarea value={adjNotes} onChange={e => setAdjNotes(e.target.value)} rows={2} placeholder="Ex: Inventário, avaria, devolução..." /></div>
            </div>
          )}
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setShowAdjust(false)}>Cancelar</Button>
            <Button onClick={handleAdjust} disabled={submitting}>Confirmar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PdvLayout>
  );
}
