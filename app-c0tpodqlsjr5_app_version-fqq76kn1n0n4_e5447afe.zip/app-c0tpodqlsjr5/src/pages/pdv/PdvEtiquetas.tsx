import { useEffect, useRef, useState } from 'react';
import { Search, Printer, Settings2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { PdvLayout } from '@/components/layouts/PdvLayout';
import QRCodeDataUrl from '@/components/ui/qrcodedataurl';
import { supabase } from '@/db/supabase';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import type { PdvProduct, PdvCategory, LabelConfig } from '@/types/types';

const DEFAULT_CFG: Omit<LabelConfig, 'id' | 'updated_at'> = {
  width_mm: 50, height_mm: 25, preset: '50x25',
  show_name: true, show_code: true, show_price: true, show_barcode: true, show_qr: false,
  logo_url: null, logo_position: 'top', logo_size_pct: 30,
  bg_image_url: null, bg_opacity: 20,
  cols: 4, rows: 6, paper_size: 'A4',
};

const PAPER_DIMENSIONS: Record<string, { w: number; h: number }> = {
  A4: { w: 210, h: 297 }, A5: { w: 148, h: 210 },
  Carta: { w: 216, h: 279 }, Oficio: { w: 216, h: 356 }, Termico: { w: 80, h: 9999 },
};

export default function PdvEtiquetas() {
  const navigate = useNavigate();
  const [products, setProducts] = useState<PdvProduct[]>([]);
  const [categories, setCategories] = useState<PdvCategory[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [catFilter, setCatFilter] = useState('all');
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [qty, setQty] = useState<Record<string, number>>({});
  const [cfg, setCfg] = useState<Omit<LabelConfig, 'id' | 'updated_at'>>(DEFAULT_CFG);

  useEffect(() => {
    loadAll();
    loadConfig();
  }, []);

  const loadAll = async () => {
    setLoading(true);
    const [prodRes, catRes] = await Promise.all([
      supabase.from('pdv_products').select('*, pdv_categories(id,name,color)').eq('active', true).order('name'),
      supabase.from('pdv_categories').select('*').order('name'),
    ]);
    setProducts((prodRes.data as PdvProduct[]) || []);
    setCategories((catRes.data as PdvCategory[]) || []);
    setLoading(false);
  };

  const loadConfig = async () => {
    const { data } = await supabase.from('label_config').select('*').order('updated_at', { ascending: false }).limit(1).maybeSingle();
    if (data) {
      const { id, updated_at, ...rest } = data as LabelConfig;
      setCfg(rest);
    }
  };

  const toggleSelect = (id: string) => {
    setSelected(prev => {
      const s = new Set(prev);
      if (s.has(id)) s.delete(id);
      else { s.add(id); if (!qty[id]) setQty(q => ({ ...q, [id]: 1 })); }
      return s;
    });
  };

  const selectAll = () => {
    const vis = filtered.map(p => p.id);
    setSelected(new Set(vis));
    setQty(q => { const n = { ...q }; vis.forEach(id => { if (!n[id]) n[id] = 1; }); return n; });
  };

  const filtered = products.filter(p => {
    const s = search.toLowerCase();
    return (!search || p.name.toLowerCase().includes(s) || p.code.toLowerCase().includes(s) || (p.barcode || '').toLowerCase().includes(s))
      && (catFilter === 'all' || p.category_id === catFilter);
  });

  const selectedProducts = products.filter(p => selected.has(p.id));
  const labelItems = selectedProducts.flatMap(p =>
    Array.from({ length: qty[p.id] || 1 }, (_, i) => ({ ...p, _key: `${p.id}-${i}` }))
  );

  const handlePrint = () => {
    if (labelItems.length === 0) { toast.error('Selecione ao menos um produto'); return; }
    const paper = PAPER_DIMENSIONS[cfg.paper_size] || PAPER_DIMENSIONS.A4;
    const isTermico = cfg.paper_size === 'Termico';
    const labelW = cfg.width_mm;
    const labelH = cfg.height_mm;
    const mmToPx = (mm: number) => `${mm}mm`;

    const labelHTML = labelItems.map(p => {
      const barcodeVal = p.barcode || p.code;
      const rows: string[] = [];

      if (cfg.logo_url && cfg.logo_position === 'top')
        rows.push(`<div class="logo-top"><img src="${cfg.logo_url}" style="max-width:${cfg.logo_size_pct}%;max-height:30%;object-fit:contain"/></div>`);

      const inner: string[] = [];
      if (cfg.logo_url && cfg.logo_position === 'left')
        inner.push(`<img src="${cfg.logo_url}" style="max-width:${cfg.logo_size_pct}%;max-height:100%;object-fit:contain;flex-shrink:0"/>`);

      const fields: string[] = [];
      if (cfg.show_name) fields.push(`<div class="lname">${p.name}</div>`);
      if (cfg.show_barcode) fields.push(`<div class="barcode">${barcodeVal}</div>`);
      if (cfg.show_code) fields.push(`<div class="lcode">${p.code}</div>`);
      if (cfg.show_price) fields.push(`<div class="lprice">R$ ${p.sale_price.toFixed(2)}</div>`);
      if (cfg.show_qr) fields.push(`<div class="qr-placeholder">▣ QR</div>`);
      inner.push(`<div class="fields">${fields.join('')}</div>`);

      if (cfg.logo_url && cfg.logo_position === 'right')
        inner.push(`<img src="${cfg.logo_url}" style="max-width:${cfg.logo_size_pct}%;max-height:100%;object-fit:contain;flex-shrink:0"/>`);

      rows.push(`<div class="row-inner">${inner.join('')}</div>`);
      return `<div class="label"><div class="label-bg-overlay"></div><div class="label-content">${rows.join('')}</div></div>`;
    }).join('');

    const colGap = 2;
    const rowGap = 2;
    const pageW = isTermico ? labelW + 4 : paper.w;
    const pageH = isTermico ? 9999 : paper.h;

    const w = window.open('', '_blank');
    if (!w) { toast.error('Popup bloqueado. Permita popups para imprimir.'); return; }
    w.document.write(`<!DOCTYPE html><html><head><title>Etiquetas</title>
<style>
@page { size: ${isTermico ? `${labelW}mm auto` : `${pageW}mm ${pageH}mm`}; margin: ${isTermico ? '2mm' : '5mm'}; }
* { box-sizing: border-box; }
body { margin: 0; font-family: Arial, sans-serif; background: white; }
.grid {
  display: grid;
  grid-template-columns: repeat(${isTermico ? 1 : cfg.cols}, ${mmToPx(labelW)});
  gap: ${rowGap}mm ${colGap}mm;
}
.label {
  width: ${mmToPx(labelW)};
  height: ${isTermico ? 'auto' : mmToPx(labelH)};
  min-height: ${isTermico ? mmToPx(labelH) : 'unset'};
  border: 0.3mm solid #aaa;
  border-radius: 1mm;
  padding: 1mm;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  page-break-inside: avoid;
  overflow: hidden;
  position: relative;
  ${cfg.bg_image_url ? `background-image: url('${cfg.bg_image_url}'); background-size: cover; background-position: center;` : ''}
}
.label-bg-overlay {
  position: absolute; inset: 0; pointer-events: none;
  ${cfg.bg_image_url ? `background: rgba(255,255,255,${1 - cfg.bg_opacity / 100});` : ''}
}
.label-content { position: relative; z-index: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; width: 100%; height: 100%; }
.logo-top { text-align: center; width: 100%; margin-bottom: 0.5mm; }
.row-inner { display: flex; flex-direction: row; align-items: center; width: 100%; gap: 1mm; }
.fields { display: flex; flex-direction: column; align-items: center; flex: 1; min-width: 0; gap: 0.3mm; }
.lname { font-size: ${Math.max(6, Math.round(labelH * 0.18))}pt; font-weight: 700; text-align: center; line-height: 1.1; word-break: break-word; }
.lcode { font-size: ${Math.max(5, Math.round(labelH * 0.12))}pt; color: #555; font-family: monospace; text-align: center; }
.barcode { font-family: 'Libre Barcode 128', 'Free 3 of 9', monospace; font-size: ${Math.max(16, Math.round(labelH * 0.6))}pt; line-height: 1; text-align: center; letter-spacing: -0.5px; }
.lprice { font-size: ${Math.max(8, Math.round(labelH * 0.24))}pt; font-weight: 800; color: #0a5c5a; text-align: center; }
.qr-placeholder { font-size: 7pt; color: #888; border: 0.3mm solid #ccc; padding: 0.5mm; }
@media print { body { -webkit-print-color-adjust: exact; } }
</style>
</head><body>
<div class="grid">${labelHTML}</div>
<script>window.onload = function(){ window.print(); }</script>
</body></html>`);
    w.document.close();
  };

  return (
    <PdvLayout title="Etiquetas">
      <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
        <p className="text-sm text-muted-foreground">
          Configuração: <span className="font-medium text-foreground">{cfg.width_mm}×{cfg.height_mm}mm · {cfg.paper_size} · {cfg.cols}×{cfg.rows}</span>
        </p>
        <Button variant="outline" size="sm" onClick={() => navigate('/pdv/configuracao-etiquetas')}>
          <Settings2 className="h-4 w-4 mr-1.5" /> Configurar Etiqueta
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* Seleção de produtos */}
        <div className="md:col-span-2 space-y-3">
          <div className="flex flex-col md:flex-row gap-3">
            <div className="relative flex-1 min-w-0">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Buscar produto..." value={search}
                onChange={e => setSearch(e.target.value)} className="pl-9 px-9" />
            </div>
            <Select value={catFilter} onValueChange={setCatFilter}>
              <SelectTrigger className="w-full md:w-44 shrink-0"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas as categorias</SelectItem>
                {categories.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={selectAll}>Selecionar Visíveis</Button>
            <Button variant="outline" size="sm" onClick={() => setSelected(new Set())}>Limpar</Button>
            <span className="text-xs text-muted-foreground ml-auto">{selected.size} selecionado(s)</span>
          </div>

          <div className="bg-card border border-border rounded-lg overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border bg-muted/40">
                    <th className="px-3 py-2 text-left whitespace-nowrap"><span className="sr-only">Sel.</span></th>
                    <th className="px-3 py-2 text-left font-medium text-muted-foreground whitespace-nowrap">Produto</th>
                    <th className="px-3 py-2 text-right font-medium text-muted-foreground whitespace-nowrap">Preço</th>
                    <th className="px-3 py-2 text-right font-medium text-muted-foreground whitespace-nowrap">Qtd. Etiquetas</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {loading
                    ? Array.from({ length: 6 }).map((_, i) => (
                        <tr key={i}><td colSpan={4} className="px-3 py-2">
                          <Skeleton className="h-5 w-full bg-muted" /></td></tr>
                      ))
                    : filtered.map(p => (
                        <tr key={p.id}
                          className={`hover:bg-muted/30 transition-colors cursor-pointer ${selected.has(p.id) ? 'bg-primary/5' : ''}`}
                          onClick={() => toggleSelect(p.id)}
                        >
                          <td className="px-3 py-2 whitespace-nowrap" onClick={e => e.stopPropagation()}>
                            <input type="checkbox" checked={selected.has(p.id)}
                              onChange={() => toggleSelect(p.id)} className="h-4 w-4 rounded border-border" />
                          </td>
                          <td className="px-3 py-2 whitespace-nowrap">
                            <p className="font-medium text-foreground">{p.name}</p>
                            <p className="text-xs text-muted-foreground font-mono">{p.code}</p>
                          </td>
                          <td className="px-3 py-2 text-right font-semibold text-primary whitespace-nowrap">
                            R$ {p.sale_price.toFixed(2)}
                          </td>
                          <td className="px-3 py-2 text-right whitespace-nowrap" onClick={e => e.stopPropagation()}>
                            {selected.has(p.id) && (
                              <Input type="number" min="1" max="999"
                                value={qty[p.id] || 1}
                                onChange={e => setQty(q => ({ ...q, [p.id]: parseInt(e.target.value) || 1 }))}
                                className="w-16 h-7 text-right text-xs px-2 ml-auto"
                              />
                            )}
                          </td>
                        </tr>
                      ))
                  }
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Painel direito: resumo + preview */}
        <div className="space-y-4">
          {/* Resumo config */}
          <div className="bg-card border border-border rounded-lg p-4 space-y-2">
            <p className="text-sm font-semibold text-foreground mb-1">Config. ativa</p>
            <div className="space-y-1.5 text-xs">
              <Row label="Tamanho" value={`${cfg.width_mm} × ${cfg.height_mm} mm`} />
              <Row label="Folha" value={cfg.paper_size} />
              <Row label="Grade" value={`${cfg.cols} col × ${cfg.rows} lin`} />
              <Row label="Total/página" value={`${cfg.cols * cfg.rows} etiquetas`} />
            </div>
            <div className="pt-1 flex flex-wrap gap-1">
              {cfg.show_name && <Badge variant="secondary" className="text-[10px]">Nome</Badge>}
              {cfg.show_price && <Badge variant="secondary" className="text-[10px]">Preço</Badge>}
              {cfg.show_code && <Badge variant="secondary" className="text-[10px]">Código</Badge>}
              {cfg.show_barcode && <Badge variant="secondary" className="text-[10px]">Cód. Barras</Badge>}
              {cfg.show_qr && <Badge variant="secondary" className="text-[10px]">QR</Badge>}
              {cfg.logo_url && <Badge variant="secondary" className="text-[10px]">Logo</Badge>}
            </div>
          </div>

          <Button className="w-full" disabled={selected.size === 0} onClick={handlePrint}>
            <Printer className="h-4 w-4 mr-2" />
            Imprimir {labelItems.length > 0 ? `${labelItems.length} ` : ''}Etiqueta(s)
          </Button>
        </div>
      </div>

      {/* Preview etiquetas */}
      {labelItems.length > 0 && (
        <div className="mt-6">
          <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
            <p className="text-sm font-semibold text-foreground">
              Pré-visualização — {labelItems.length} etiqueta(s)
            </p>
            <Button variant="outline" size="sm" onClick={handlePrint}>
              <Printer className="h-4 w-4 mr-1.5" /> Imprimir
            </Button>
          </div>
          <div className="bg-white border border-border rounded-lg p-3 overflow-x-auto">
            <div style={{ display: 'grid', gridTemplateColumns: `repeat(${cfg.cols}, minmax(0, 1fr))`, gap: 8, width: '100%' }}>
              {labelItems.slice(0, cfg.cols * cfg.rows).map(p => (
                <LabelPreview key={(p as any)._key} p={p} cfg={cfg} />
              ))}
            </div>
            {labelItems.length > cfg.cols * cfg.rows && (
              <p className="text-xs text-muted-foreground mt-2 text-center">
                +{labelItems.length - cfg.cols * cfg.rows} etiqueta(s) na impressão
              </p>
            )}
          </div>
        </div>
      )}

      {selected.size === 0 && !loading && (
        <div className="mt-8 flex flex-col items-center justify-center text-muted-foreground py-10">
          <Printer className="h-10 w-10 mb-2 opacity-30" />
          <p className="text-sm text-pretty text-center">Selecione produtos para gerar etiquetas</p>
          <Button variant="outline" size="sm" className="mt-3" onClick={() => navigate('/pdv/configuracao-etiquetas')}>
            <Settings2 className="h-4 w-4 mr-1.5" /> Configurar layout das etiquetas
          </Button>
        </div>
      )}
    </PdvLayout>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-medium text-foreground">{value}</span>
    </div>
  );
}

function LabelPreview({ p, cfg }: { p: PdvProduct; cfg: Omit<LabelConfig, 'id' | 'updated_at'> }) {
  const aspectRatio = cfg.height_mm > 0 ? cfg.width_mm / cfg.height_mm : 2;
  return (
    <div
      className="border border-dashed border-border rounded overflow-hidden"
      style={{
        aspectRatio, minHeight: 48, position: 'relative',
        backgroundImage: cfg.bg_image_url ? `url(${cfg.bg_image_url})` : undefined,
        backgroundSize: 'cover', backgroundPosition: 'center',
      }}
    >
      {cfg.bg_image_url && (
        <div style={{ position: 'absolute', inset: 0, background: `rgba(255,255,255,${1 - cfg.bg_opacity / 100})`, pointerEvents: 'none' }} />
      )}
      <div style={{ position: 'relative', zIndex: 1 }}
        className="flex flex-col items-center justify-center p-1.5 gap-0.5 w-full h-full">
        {cfg.logo_url && cfg.logo_position === 'top' && (
          <img src={cfg.logo_url} alt="logo"
            style={{ width: `${cfg.logo_size_pct}%`, maxHeight: '25%', objectFit: 'contain' }} />
        )}
        <div className={`flex ${cfg.logo_url && cfg.logo_position !== 'top' ? 'flex-row gap-1 items-center' : 'flex-col items-center'} w-full`}>
          {cfg.logo_url && cfg.logo_position === 'left' && (
            <img src={cfg.logo_url} alt="logo"
              style={{ width: `${cfg.logo_size_pct}%`, objectFit: 'contain', flexShrink: 0 }} />
          )}
          <div className="flex flex-col items-center flex-1 min-w-0 gap-[1px]">
            {cfg.show_name && <p className="text-[7px] md:text-[8px] font-bold text-gray-800 text-center leading-tight line-clamp-2 w-full">{p.name}</p>}
            {cfg.show_barcode && (
              <p className="text-[6px] font-mono text-gray-600 tracking-tight">||| {p.barcode || p.code} |||</p>
            )}
            {cfg.show_code && <p className="text-[6px] text-gray-500 font-mono">{p.code}</p>}
            {cfg.show_price && <p className="text-[9px] font-extrabold text-emerald-700">R$ {p.sale_price.toFixed(2)}</p>}
            {cfg.show_qr && (
              <QRCodeDataUrl text={`${p.code}|${p.name}|${p.sale_price}`} width={28} />
            )}
          </div>
          {cfg.logo_url && cfg.logo_position === 'right' && (
            <img src={cfg.logo_url} alt="logo"
              style={{ width: `${cfg.logo_size_pct}%`, objectFit: 'contain', flexShrink: 0 }} />
          )}
        </div>
      </div>
    </div>
  );
}

