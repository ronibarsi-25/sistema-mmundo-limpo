import { useEffect, useState } from 'react';
import { Star, Gift, Settings, TrendingUp, Award } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { PdvLayout } from '@/components/layouts/PdvLayout';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';

interface Customer { id: string; name: string; loyalty_points: number; email: string; phone: string; }
interface LoyaltyTransaction {
  id: string; customer_id: string; type: string; points: number; balance_after: number;
  description: string | null; created_at: string;
  customers?: { name: string } | null;
}
interface LoyaltyConfig { id: string; points_per_real: number; real_per_point: number; min_redemption_points: number; active: boolean; }

const TYPE_LABEL: Record<string, { label: string; color: string }> = {
  acumulo: { label: 'Acúmulo', color: 'text-success' },
  resgate: { label: 'Resgate', color: 'text-warning' },
  expiracao: { label: 'Expiração', color: 'text-destructive' },
  bonus_indicacao: { label: 'Bônus Indicação', color: 'text-primary' },
};

export default function PdvFidelidade() {
  const [config, setConfig] = useState<LoyaltyConfig | null>(null);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [transactions, setTransactions] = useState<LoyaltyTransaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [showConfig, setShowConfig] = useState(false);
  const [showManual, setShowManual] = useState(false);
  const [configForm, setConfigForm] = useState({ points_per_real: '1', real_per_point: '0.01', min_redemption_points: '100' });
  const [manualForm, setManualForm] = useState({ customer_id: '', type: 'acumulo', points: '', description: '' });
  const [saving, setSaving] = useState(false);
  const [search, setSearch] = useState('');

  useEffect(() => { loadAll(); }, []);

  const loadAll = async () => {
    setLoading(true);
    const [cfgRes, custRes, txRes] = await Promise.all([
      supabase.from('loyalty_config').select('*').single(),
      supabase.from('customers').select('id,name,loyalty_points,email,phone').order('loyalty_points', { ascending: false }).limit(100),
      supabase.from('loyalty_transactions').select('*, customers(name)').order('created_at', { ascending: false }).limit(100),
    ]);
    if (cfgRes.data) { setConfig(cfgRes.data as LoyaltyConfig); setConfigForm({ points_per_real: String(cfgRes.data.points_per_real), real_per_point: String(cfgRes.data.real_per_point), min_redemption_points: String(cfgRes.data.min_redemption_points) }); }
    setCustomers((custRes.data as Customer[]) || []);
    setTransactions((txRes.data as LoyaltyTransaction[]) || []);
    setLoading(false);
  };

  const saveConfig = async () => {
    if (!config) return;
    setSaving(true);
    const { error } = await supabase.from('loyalty_config').update({
      points_per_real: parseFloat(configForm.points_per_real), real_per_point: parseFloat(configForm.real_per_point), min_redemption_points: parseInt(configForm.min_redemption_points), updated_at: new Date().toISOString(),
    }).eq('id', config.id);
    setSaving(false);
    if (error) { toast.error('Erro ao salvar'); return; }
    toast.success('Configurações salvas!');
    setShowConfig(false);
    loadAll();
  };

  const saveManual = async () => {
    if (!manualForm.customer_id) { toast.error('Selecione o cliente'); return; }
    const pts = parseInt(manualForm.points);
    if (!pts || pts <= 0) { toast.error('Informe a quantidade de pontos'); return; }
    setSaving(true);
    const { data: cust } = await supabase.from('customers').select('loyalty_points').eq('id', manualForm.customer_id).single();
    if (!cust) { toast.error('Cliente não encontrado'); setSaving(false); return; }
    const delta = manualForm.type === 'resgate' ? -pts : pts;
    const newBalance = Math.max(0, cust.loyalty_points + delta);
    await supabase.from('customers').update({ loyalty_points: newBalance }).eq('id', manualForm.customer_id);
    await supabase.from('loyalty_transactions').insert({ customer_id: manualForm.customer_id, type: manualForm.type, points: manualForm.type === 'resgate' ? -pts : pts, balance_after: newBalance, description: manualForm.description || null });
    setSaving(false);
    toast.success('Pontos ajustados!');
    setShowManual(false);
    setManualForm({ customer_id: '', type: 'acumulo', points: '', description: '' });
    loadAll();
  };

  const cf = (k: string, v: string) => setConfigForm(p => ({ ...p, [k]: v }));
  const mf = (k: string, v: string) => setManualForm(p => ({ ...p, [k]: v }));

  const filteredCustomers = customers.filter(c => c.name.toLowerCase().includes(search.toLowerCase()));
  const totalPoints = customers.reduce((s, c) => s + c.loyalty_points, 0);
  const totalValue = totalPoints * (config?.real_per_point || 0.01);

  return (
    <PdvLayout title="Programa de Fidelidade" actions={
      <div className="flex gap-2">
        <Button size="sm" variant="outline" onClick={() => setShowConfig(true)}><Settings className="h-4 w-4 mr-1.5" />Config</Button>
        <Button size="sm" onClick={() => setShowManual(true)}><Gift className="h-4 w-4 mr-1.5" />Ajustar Pontos</Button>
      </div>
    }>
      <div className="space-y-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { label: 'Pontos em Circulação', val: totalPoints.toLocaleString('pt-BR'), icon: Star, cls: 'text-primary' },
            { label: 'Valor em Desconto', val: `R$ ${totalValue.toFixed(2)}`, icon: TrendingUp, cls: 'text-success' },
            { label: 'Clientes com Pontos', val: customers.filter(c => c.loyalty_points > 0).length, icon: Award, cls: 'text-foreground' },
            { label: 'Pts por R$1', val: config?.points_per_real || 1, icon: Gift, cls: 'text-foreground' },
          ].map((k, i) => (
            <div key={i} className="bg-card border border-border rounded-lg p-4">
              <div className="flex items-center gap-2 mb-1">
                <k.icon className={`h-4 w-4 ${k.cls}`} />
                <p className="text-xs text-muted-foreground">{k.label}</p>
              </div>
              <p className="text-xl font-bold text-foreground">{k.val}</p>
            </div>
          ))}
        </div>

        {config && (
          <div className="bg-primary/5 border border-primary/20 rounded-lg p-4 flex flex-wrap gap-4 text-sm">
            <span>Acúmulo: <strong className="text-primary">{config.points_per_real} pts/R$1</strong></span>
            <span>Resgate: <strong className="text-primary">R$ {config.real_per_point}/ponto</strong></span>
            <span>Mín. resgate: <strong className="text-primary">{config.min_redemption_points} pts</strong></span>
            <Badge variant={config.active ? 'default' : 'secondary'}>{config.active ? 'Ativo' : 'Inativo'}</Badge>
          </div>
        )}

        <Tabs defaultValue="clientes">
          <TabsList>
            <TabsTrigger value="clientes">Clientes</TabsTrigger>
            <TabsTrigger value="historico">Histórico</TabsTrigger>
          </TabsList>
          <TabsContent value="clientes" className="mt-4 space-y-3">
            <Input className="max-w-xs" placeholder="Buscar cliente..." value={search} onChange={e => setSearch(e.target.value)} />
            <div className="bg-card border border-border rounded-lg overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead><tr className="border-b border-border bg-muted/40">
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Cliente</th>
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Contato</th>
                    <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Pontos</th>
                    <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Valor Desconto</th>
                    <th className="text-center px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Status</th>
                  </tr></thead>
                  <tbody className="divide-y divide-border">
                    {loading ? Array.from({ length: 5 }).map((_, i) => <tr key={i}><td colSpan={5} className="px-4 py-3"><Skeleton className="h-5 w-full bg-muted" /></td></tr>)
                      : filteredCustomers.length === 0 ? <tr><td colSpan={5} className="text-center py-10 text-muted-foreground"><Star className="h-8 w-8 mx-auto mb-2 opacity-40" /><p>Nenhum cliente encontrado</p></td></tr>
                      : filteredCustomers.map(c => (
                        <tr key={c.id} className="hover:bg-muted/30">
                          <td className="px-4 py-3 font-medium whitespace-nowrap">{c.name}</td>
                          <td className="px-4 py-3 text-muted-foreground whitespace-nowrap">{c.phone || c.email || '—'}</td>
                          <td className="px-4 py-3 text-right whitespace-nowrap">
                            <span className={c.loyalty_points > 0 ? 'font-bold text-primary' : 'text-muted-foreground'}>{c.loyalty_points.toLocaleString('pt-BR')}</span>
                          </td>
                          <td className="px-4 py-3 text-right whitespace-nowrap">R$ {(c.loyalty_points * (config?.real_per_point || 0.01)).toFixed(2)}</td>
                          <td className="px-4 py-3 text-center whitespace-nowrap">
                            {c.loyalty_points >= (config?.min_redemption_points || 100)
                              ? <Badge className="text-xs bg-success/10 text-success border border-success/30">Pode Resgatar</Badge>
                              : <Badge variant="secondary" className="text-xs">Acumulando</Badge>}
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>
          </TabsContent>
          <TabsContent value="historico" className="mt-4">
            <div className="bg-card border border-border rounded-lg overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead><tr className="border-b border-border bg-muted/40">
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Data</th>
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Cliente</th>
                    <th className="text-center px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Tipo</th>
                    <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Pontos</th>
                    <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Saldo</th>
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Descrição</th>
                  </tr></thead>
                  <tbody className="divide-y divide-border">
                    {loading ? Array.from({ length: 5 }).map((_, i) => <tr key={i}><td colSpan={6} className="px-4 py-3"><Skeleton className="h-5 w-full bg-muted" /></td></tr>)
                      : transactions.length === 0 ? <tr><td colSpan={6} className="text-center py-10 text-muted-foreground"><p>Nenhuma transação</p></td></tr>
                      : transactions.map(t => {
                        const tp = TYPE_LABEL[t.type] || { label: t.type, color: 'text-foreground' };
                        return (
                          <tr key={t.id} className="hover:bg-muted/30">
                            <td className="px-4 py-3 whitespace-nowrap">{new Date(t.created_at).toLocaleDateString('pt-BR')}</td>
                            <td className="px-4 py-3 whitespace-nowrap">{t.customers?.name || '—'}</td>
                            <td className="px-4 py-3 text-center whitespace-nowrap"><span className={`text-xs font-medium ${tp.color}`}>{tp.label}</span></td>
                            <td className={`px-4 py-3 text-right font-bold whitespace-nowrap ${t.points > 0 ? 'text-success' : 'text-destructive'}`}>{t.points > 0 ? '+' : ''}{t.points}</td>
                            <td className="px-4 py-3 text-right whitespace-nowrap">{t.balance_after.toLocaleString('pt-BR')}</td>
                            <td className="px-4 py-3 text-muted-foreground whitespace-nowrap">{t.description || '—'}</td>
                          </tr>
                        );
                      })}
                  </tbody>
                </table>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Config Dialog */}
      <Dialog open={showConfig} onOpenChange={setShowConfig}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-sm">
          <DialogHeader><DialogTitle className="text-balance">Configurar Fidelidade</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5"><Label className="text-sm font-normal">Pontos por R$1 gasto</Label><Input type="number" min="0.01" step="0.01" value={configForm.points_per_real} onChange={e => cf('points_per_real', e.target.value)} /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">R$ de desconto por ponto</Label><Input type="number" min="0.001" step="0.001" value={configForm.real_per_point} onChange={e => cf('real_per_point', e.target.value)} /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Mínimo para resgate (pontos)</Label><Input type="number" min="1" value={configForm.min_redemption_points} onChange={e => cf('min_redemption_points', e.target.value)} /></div>
          </div>
          <DialogFooter className="gap-2"><Button variant="outline" onClick={() => setShowConfig(false)}>Cancelar</Button><Button onClick={saveConfig} disabled={saving}>Salvar</Button></DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Manual Points Dialog */}
      <Dialog open={showManual} onOpenChange={setShowManual}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-sm">
          <DialogHeader><DialogTitle className="text-balance">Ajuste Manual de Pontos</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Cliente *</Label>
              <Select value={manualForm.customer_id || 'none'} onValueChange={v => mf('customer_id', v === 'none' ? '' : v)}>
                <SelectTrigger><SelectValue placeholder="Selecione..." /></SelectTrigger>
                <SelectContent>{customers.map(c => <SelectItem key={c.id} value={c.id}>{c.name} ({c.loyalty_points} pts)</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Tipo</Label>
              <Select value={manualForm.type} onValueChange={v => mf('type', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="acumulo">Acúmulo</SelectItem><SelectItem value="resgate">Resgate</SelectItem><SelectItem value="bonus_indicacao">Bônus Indicação</SelectItem><SelectItem value="expiracao">Expiração</SelectItem></SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Pontos</Label><Input type="number" min="1" value={manualForm.points} onChange={e => mf('points', e.target.value)} /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Descrição</Label><Input value={manualForm.description} onChange={e => mf('description', e.target.value)} /></div>
          </div>
          <DialogFooter className="gap-2"><Button variant="outline" onClick={() => setShowManual(false)}>Cancelar</Button><Button onClick={saveManual} disabled={saving}>Confirmar</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </PdvLayout>
  );
}
