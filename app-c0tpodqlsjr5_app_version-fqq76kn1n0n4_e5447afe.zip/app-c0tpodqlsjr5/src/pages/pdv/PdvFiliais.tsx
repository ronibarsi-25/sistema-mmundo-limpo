import { useEffect, useState } from 'react';
import { Plus, Building2, ArrowLeftRight, Pencil, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { PdvLayout } from '@/components/layouts/PdvLayout';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';

interface Branch {
  id: string; name: string; cnpj: string | null; phone: string | null; email: string | null;
  cidade: string | null; estado: string | null; is_main: boolean; active: boolean;
}
interface TransferItem { product_id: string; quantity: number; }
interface Product { id: string; name: string; code: string; stock_qty: number; }

const emptyBranch = () => ({ name: '', cnpj: '', phone: '', email: '', cep: '', logradouro: '', numero: '', complemento: '', bairro: '', cidade: '', estado: '', is_main: false, active: true });

export default function PdvFiliais() {
  const [branches, setBranches] = useState<Branch[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [showDialog, setShowDialog] = useState(false);
  const [showTransfer, setShowTransfer] = useState(false);
  const [editBranch, setEditBranch] = useState<Branch | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState(emptyBranch());
  const [transferForm, setTransferForm] = useState({ from_branch_id: '', to_branch_id: '', notes: '' });
  const [transferItems, setTransferItems] = useState<TransferItem[]>([{ product_id: '', quantity: 1 }]);

  useEffect(() => { loadBranches(); loadProducts(); }, []);

  const loadBranches = async () => {
    setLoading(true);
    const { data } = await supabase.from('branches').select('*').order('is_main', { ascending: false });
    setBranches((data as Branch[]) || []);
    setLoading(false);
  };
  const loadProducts = async () => { const { data } = await supabase.from('pdv_products').select('id,name,code,stock_qty').order('name').limit(200); setProducts(data || []); };

  const openNew = () => { setEditBranch(null); setForm(emptyBranch()); setShowDialog(true); };
  const openEdit = (b: Branch) => { setEditBranch(b); setForm({ ...b, cnpj: b.cnpj || '', phone: b.phone || '', email: b.email || '', cidade: b.cidade || '', estado: b.estado || '', cep: '', logradouro: '', numero: '', complemento: '', bairro: '' }); setShowDialog(true); };

  const handleSave = async () => {
    if (!form.name.trim()) { toast.error('Informe o nome da filial'); return; }
    setSaving(true);
    const payload = { name: form.name, cnpj: form.cnpj || null, phone: form.phone || null, email: form.email || null, cidade: form.cidade || null, estado: form.estado || null, is_main: form.is_main, active: form.active, updated_at: new Date().toISOString() };
    let error;
    if (editBranch) {
      ({ error } = await supabase.from('branches').update(payload).eq('id', editBranch.id));
    } else {
      ({ error } = await supabase.from('branches').insert(payload));
    }
    setSaving(false);
    if (error) { toast.error('Erro: ' + error.message); return; }
    toast.success(editBranch ? 'Filial atualizada!' : 'Filial criada!');
    setShowDialog(false);
    loadBranches();
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    const { error } = await supabase.from('branches').delete().eq('id', deleteId);
    if (error) { toast.error('Erro ao excluir'); return; }
    toast.success('Filial excluída!');
    setDeleteId(null);
    loadBranches();
  };

  const handleTransfer = async () => {
    if (!transferForm.from_branch_id || !transferForm.to_branch_id) { toast.error('Selecione as filiais'); return; }
    if (transferForm.from_branch_id === transferForm.to_branch_id) { toast.error('Filiais devem ser diferentes'); return; }
    if (transferItems.some(i => !i.product_id)) { toast.error('Selecione todos os produtos'); return; }
    setSaving(true);
    const { data: transfer, error } = await supabase.from('stock_transfers').insert({ from_branch_id: transferForm.from_branch_id, to_branch_id: transferForm.to_branch_id, notes: transferForm.notes || null, status: 'confirmado', confirmed_at: new Date().toISOString() }).select().single();
    if (error || !transfer) { toast.error('Erro ao criar transferência'); setSaving(false); return; }
    await supabase.from('stock_transfer_items').insert(transferItems.map(i => ({ transfer_id: transfer.id, product_id: i.product_id, quantity: i.quantity })));
    // Update stock (subtract from origin, add to destination - simplified without branch stock)
    toast.success('Transferência registrada com sucesso!');
    setSaving(false);
    setShowTransfer(false);
    setTransferForm({ from_branch_id: '', to_branch_id: '', notes: '' });
    setTransferItems([{ product_id: '', quantity: 1 }]);
  };

  const ff = (k: string, v: string | boolean) => setForm(p => ({ ...p, [k]: v }));
  const tf = (k: string, v: string) => setTransferForm(p => ({ ...p, [k]: v }));
  const updateTItem = (idx: number, k: keyof TransferItem, v: string | number) => setTransferItems(prev => prev.map((item, i) => i === idx ? { ...item, [k]: v } : item));

  return (
    <PdvLayout title="Controle de Filiais" actions={
      <div className="flex gap-2">
        <Button size="sm" variant="outline" onClick={() => setShowTransfer(true)}><ArrowLeftRight className="h-4 w-4 mr-1.5" />Transferir</Button>
        <Button size="sm" onClick={openNew}><Plus className="h-4 w-4 mr-1.5" />Nova Filial</Button>
      </div>
    }>
      <div className="space-y-4">
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {[
            { label: 'Total de Filiais', val: branches.length },
            { label: 'Filiais Ativas', val: branches.filter(b => b.active).length },
            { label: 'Filiais Inativas', val: branches.filter(b => !b.active).length },
          ].map((k, i) => (
            <div key={i} className="bg-card border border-border rounded-lg p-4">
              <p className="text-xs text-muted-foreground mb-1">{k.label}</p>
              <p className="text-2xl font-bold text-foreground">{k.val}</p>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {loading ? Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-40 bg-muted rounded-lg" />)
            : branches.length === 0 ? (
              <div className="col-span-3 text-center py-16 text-muted-foreground">
                <Building2 className="h-10 w-10 mx-auto mb-3 opacity-30" />
                <p className="text-pretty">Nenhuma filial cadastrada</p>
              </div>
            ) : branches.map(b => (
              <div key={b.id} className="bg-card border border-border rounded-lg p-4 h-full flex flex-col">
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="font-semibold text-foreground text-sm truncate">{b.name}</h3>
                      {b.is_main && <Badge className="text-xs shrink-0">Principal</Badge>}
                      <Badge variant={b.active ? 'secondary' : 'outline'} className="text-xs shrink-0">{b.active ? 'Ativa' : 'Inativa'}</Badge>
                    </div>
                  </div>
                  <div className="flex shrink-0">
                    <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openEdit(b)}><Pencil className="h-3.5 w-3.5" /></Button>
                    {!b.is_main && <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive hover:text-destructive" onClick={() => setDeleteId(b.id)}><Trash2 className="h-3.5 w-3.5" /></Button>}
                  </div>
                </div>
                <div className="text-xs text-muted-foreground space-y-1 flex-1">
                  {b.cnpj && <p>CNPJ: {b.cnpj}</p>}
                  {b.phone && <p>Tel: {b.phone}</p>}
                  {b.email && <p className="truncate">Email: {b.email}</p>}
                  {(b.cidade || b.estado) && <p>{[b.cidade, b.estado].filter(Boolean).join(', ')}</p>}
                </div>
              </div>
            ))}
        </div>
      </div>

      {/* Branch Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle className="text-balance">{editBranch ? 'Editar' : 'Nova'} Filial</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-4 py-2 max-h-[60vh] overflow-y-auto pr-1">
            <div className="col-span-2 space-y-1.5"><Label className="text-sm font-normal">Nome *</Label><Input value={form.name} onChange={e => ff('name', e.target.value)} /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">CNPJ</Label><Input value={form.cnpj} onChange={e => ff('cnpj', e.target.value)} placeholder="00.000.000/0000-00" /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Telefone</Label><Input value={form.phone} onChange={e => ff('phone', e.target.value)} /></div>
            <div className="col-span-2 space-y-1.5"><Label className="text-sm font-normal">E-mail</Label><Input type="email" value={form.email} onChange={e => ff('email', e.target.value)} /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Cidade</Label><Input value={form.cidade} onChange={e => ff('cidade', e.target.value)} /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Estado</Label><Input value={form.estado} onChange={e => ff('estado', e.target.value)} maxLength={2} placeholder="SP" /></div>
            <div className="col-span-2 flex items-center gap-6">
              <div className="flex items-center gap-2">
                <Switch id="main" checked={form.is_main} onCheckedChange={v => ff('is_main', v)} />
                <Label htmlFor="main" className="text-sm font-normal cursor-pointer">Filial Principal</Label>
              </div>
              <div className="flex items-center gap-2">
                <Switch id="active" checked={form.active} onCheckedChange={v => ff('active', v)} />
                <Label htmlFor="active" className="text-sm font-normal cursor-pointer">Ativa</Label>
              </div>
            </div>
          </div>
          <DialogFooter className="gap-2"><Button variant="outline" onClick={() => setShowDialog(false)}>Cancelar</Button><Button onClick={handleSave} disabled={saving}>Salvar</Button></DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Transfer Dialog */}
      <Dialog open={showTransfer} onOpenChange={setShowTransfer}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle className="text-balance">Transferência de Estoque</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2 max-h-[65vh] overflow-y-auto pr-1">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">De (Filial Origem) *</Label>
                <Select value={transferForm.from_branch_id || 'none'} onValueChange={v => tf('from_branch_id', v === 'none' ? '' : v)}>
                  <SelectTrigger><SelectValue placeholder="Origem" /></SelectTrigger>
                  <SelectContent><SelectItem value="none">Selecione</SelectItem>{branches.map(b => <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">Para (Filial Destino) *</Label>
                <Select value={transferForm.to_branch_id || 'none'} onValueChange={v => tf('to_branch_id', v === 'none' ? '' : v)}>
                  <SelectTrigger><SelectValue placeholder="Destino" /></SelectTrigger>
                  <SelectContent><SelectItem value="none">Selecione</SelectItem>{branches.map(b => <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-sm font-semibold">Produtos</Label>
                <Button size="sm" variant="outline" onClick={() => setTransferItems(prev => [...prev, { product_id: '', quantity: 1 }])}><Plus className="h-3.5 w-3.5 mr-1" />Add</Button>
              </div>
              {transferItems.map((item, idx) => (
                <div key={idx} className="flex gap-2">
                  <div className="flex-1">
                    <Select value={item.product_id || 'none'} onValueChange={v => updateTItem(idx, 'product_id', v === 'none' ? '' : v)}>
                      <SelectTrigger className="h-8 text-xs"><SelectValue placeholder="Produto..." /></SelectTrigger>
                      <SelectContent>{products.map(p => <SelectItem key={p.id} value={p.id}>{p.name} (Est: {p.stock_qty})</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                  <Input className="w-20 h-8 text-xs" type="number" min="1" value={item.quantity} onChange={e => updateTItem(idx, 'quantity', parseInt(e.target.value) || 1)} />
                </div>
              ))}
            </div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Observações</Label><Input value={transferForm.notes} onChange={e => tf('notes', e.target.value)} /></div>
          </div>
          <DialogFooter className="gap-2"><Button variant="outline" onClick={() => setShowTransfer(false)}>Cancelar</Button><Button onClick={handleTransfer} disabled={saving}><ArrowLeftRight className="h-4 w-4 mr-1.5" />Confirmar Transferência</Button></DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={o => { if (!o) setDeleteId(null); }}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-sm">
          <AlertDialogHeader><AlertDialogTitle>Excluir Filial?</AlertDialogTitle><AlertDialogDescription>Esta ação não pode ser desfeita.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancelar</AlertDialogCancel><AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={handleDelete}>Excluir</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </PdvLayout>
  );
}
