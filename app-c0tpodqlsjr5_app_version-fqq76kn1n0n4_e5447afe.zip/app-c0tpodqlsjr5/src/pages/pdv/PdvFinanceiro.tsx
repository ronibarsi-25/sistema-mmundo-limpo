import { useEffect, useState } from 'react';
import { Plus, Pencil, Trash2, TrendingUp, TrendingDown, DollarSign, BarChart3 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { PdvLayout } from '@/components/layouts/PdvLayout';
import { supabase } from '@/db/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import type { Transaction, TransactionType, PaymentMethod } from '@/types/types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const PAYMENT_LABELS: Record<PaymentMethod, string> = {
  dinheiro: 'Dinheiro', cartao_debito: 'Débito', cartao_credito: 'Crédito', pix: 'PIX', outros: 'Outros',
};

const RECEITA_CATS = ['Venda', 'Serviço', 'Devolução Fornecedor', 'Outras Receitas'];
const DESPESA_CATS = ['Compra Mercadoria', 'Aluguel', 'Salário', 'Energia/Água', 'Telefone/Internet', 'Marketing', 'Manutenção', 'Impostos', 'Outras Despesas'];

const emptyForm = { type: 'receita' as TransactionType, category: '', description: '', amount: '', payment_method: 'dinheiro' as PaymentMethod, transaction_date: new Date().toISOString().split('T')[0], notes: '' };

export default function PdvFinanceiro() {
  const { profile } = useAuth();
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [dateFrom, setDateFrom] = useState(() => { const d = new Date(); d.setDate(1); return d.toISOString().split('T')[0]; });
  const [dateTo, setDateTo] = useState(() => new Date().toISOString().split('T')[0]);
  const [showDialog, setShowDialog] = useState(false);
  const [editing, setEditing] = useState<Transaction | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [submitting, setSubmitting] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  useEffect(() => { load(); }, [dateFrom, dateTo]);

  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from('transactions').select('*').gte('transaction_date', dateFrom).lte('transaction_date', dateTo).order('transaction_date', { ascending: false }).order('created_at', { ascending: false });
    setTransactions((data as Transaction[]) || []);
    setLoading(false);
  };

  const openCreate = () => { setEditing(null); setForm(emptyForm); setShowDialog(true); };
  const openEdit = (t: Transaction) => {
    setEditing(t);
    setForm({ type: t.type, category: t.category, description: t.description, amount: String(t.amount), payment_method: t.payment_method, transaction_date: t.transaction_date, notes: t.notes || '' });
    setShowDialog(true);
  };

  const handleSave = async () => {
    if (!profile || !form.description.trim() || !form.amount || !form.category) { toast.error('Preencha todos os campos obrigatórios'); return; }
    setSubmitting(true);
    const payload = { type: form.type, category: form.category, description: form.description, amount: parseFloat(form.amount), payment_method: form.payment_method, transaction_date: form.transaction_date, notes: form.notes || null, created_by: profile.id };
    const q = editing ? supabase.from('transactions').update(payload).eq('id', editing.id) : supabase.from('transactions').insert(payload);
    const { error } = await q;
    setSubmitting(false);
    if (error) { toast.error('Erro ao salvar: ' + error.message); return; }
    toast.success(editing ? 'Lançamento atualizado!' : 'Lançamento registrado!');
    setShowDialog(false); load();
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    const { error } = await supabase.from('transactions').delete().eq('id', deleteId);
    if (error) toast.error('Erro ao excluir'); else { toast.success('Lançamento excluído'); load(); }
    setDeleteId(null);
  };

  const f = (k: string, v: string) => setForm(p => ({ ...p, [k]: v }));

  const totalReceitas = transactions.filter(t => t.type === 'receita').reduce((s, t) => s + t.amount, 0);
  const totalDespesas = transactions.filter(t => t.type === 'despesa').reduce((s, t) => s + t.amount, 0);
  const saldo = totalReceitas - totalDespesas;

  // Chart data by day
  const chartData: Record<string, { dia: string; receita: number; despesa: number }> = {};
  transactions.forEach(t => {
    const d = t.transaction_date;
    if (!chartData[d]) chartData[d] = { dia: new Date(d + 'T00:00:00').toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' }), receita: 0, despesa: 0 };
    if (t.type === 'receita') chartData[d].receita += t.amount;
    else chartData[d].despesa += t.amount;
  });
  const chart = Object.values(chartData).reverse().slice(0, 14);

  const catGroups = form.type === 'receita' ? RECEITA_CATS : DESPESA_CATS;

  return (
    <PdvLayout title="Financeiro" actions={<Button size="sm" onClick={openCreate}><Plus className="h-4 w-4 mr-1.5" />Novo Lançamento</Button>}>
      {/* Summary */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-5">
        <div className="bg-success/10 border border-success/20 rounded-lg p-4 flex items-center gap-3">
          <TrendingUp className="h-8 w-8 text-success shrink-0" />
          <div><p className="text-xs text-muted-foreground">Receitas</p><p className="text-lg font-bold text-success">R$ {totalReceitas.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</p></div>
        </div>
        <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-4 flex items-center gap-3">
          <TrendingDown className="h-8 w-8 text-destructive shrink-0" />
          <div><p className="text-xs text-muted-foreground">Despesas</p><p className="text-lg font-bold text-destructive">R$ {totalDespesas.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</p></div>
        </div>
        <div className={`border rounded-lg p-4 flex items-center gap-3 col-span-2 md:col-span-1 ${saldo >= 0 ? 'bg-primary/10 border-primary/20' : 'bg-destructive/10 border-destructive/20'}`}>
          <DollarSign className={`h-8 w-8 shrink-0 ${saldo >= 0 ? 'text-primary' : 'text-destructive'}`} />
          <div><p className="text-xs text-muted-foreground">Saldo</p><p className={`text-lg font-bold ${saldo >= 0 ? 'text-primary' : 'text-destructive'}`}>R$ {saldo.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</p></div>
        </div>
      </div>

      {/* Date filter */}
      <div className="flex flex-row items-center gap-3 mb-5 flex-wrap">
        <div className="flex items-center gap-2">
          <Label className="text-sm whitespace-nowrap">De:</Label>
          <Input type="date" value={dateFrom} onChange={e => setDateFrom(e.target.value)} className="w-36 h-8 text-sm" />
        </div>
        <div className="flex items-center gap-2">
          <Label className="text-sm whitespace-nowrap">Até:</Label>
          <Input type="date" value={dateTo} onChange={e => setDateTo(e.target.value)} className="w-36 h-8 text-sm" />
        </div>
      </div>

      <Tabs defaultValue="lancamentos">
        <TabsList className="mb-4">
          <TabsTrigger value="lancamentos">Lançamentos</TabsTrigger>
          <TabsTrigger value="grafico">Gráfico</TabsTrigger>
        </TabsList>

        <TabsContent value="lancamentos">
          <div className="bg-card border border-border rounded-lg overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border bg-muted/40">
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Data</th>
                    <th className="text-center px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Tipo</th>
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Categoria</th>
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Descrição</th>
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Pagamento</th>
                    <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Valor</th>
                    <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Ações</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {loading ? (
                    Array.from({ length: 5 }).map((_, i) => <tr key={i}><td colSpan={7} className="px-4 py-3"><Skeleton className="h-5 w-full bg-muted" /></td></tr>)
                  ) : transactions.length === 0 ? (
                    <tr><td colSpan={7} className="text-center py-12 text-muted-foreground">
                      <BarChart3 className="h-8 w-8 mx-auto mb-2 opacity-40" />
                      <p className="text-pretty">Nenhum lançamento no período</p>
                    </td></tr>
                  ) : transactions.map(t => (
                    <tr key={t.id} className="hover:bg-muted/30 transition-colors">
                      <td className="px-4 py-3 text-muted-foreground whitespace-nowrap text-xs">{new Date(t.transaction_date + 'T00:00:00').toLocaleDateString('pt-BR')}</td>
                      <td className="px-4 py-3 text-center whitespace-nowrap">
                        {t.type === 'receita'
                          ? <span className="status-badge-success">Receita</span>
                          : <span className="status-badge-destructive">Despesa</span>}
                      </td>
                      <td className="px-4 py-3 text-muted-foreground whitespace-nowrap">{t.category}</td>
                      <td className="px-4 py-3 whitespace-nowrap font-medium text-foreground max-w-[200px] truncate">{t.description}</td>
                      <td className="px-4 py-3 text-muted-foreground whitespace-nowrap">{PAYMENT_LABELS[t.payment_method]}</td>
                      <td className={`px-4 py-3 text-right font-bold whitespace-nowrap ${t.type === 'receita' ? 'text-success' : 'text-destructive'}`}>
                        {t.type === 'receita' ? '+' : '-'}R$ {t.amount.toFixed(2)}
                      </td>
                      <td className="px-4 py-3 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1">
                          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openEdit(t)}><Pencil className="h-3.5 w-3.5" /></Button>
                          <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive hover:bg-destructive/10" onClick={() => setDeleteId(t.id)}><Trash2 className="h-3.5 w-3.5" /></Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="grafico">
          <div className="bg-card border border-border rounded-lg p-4">
            {loading ? <Skeleton className="h-56 w-full bg-muted" /> : (
              <div className="w-full min-w-0 overflow-hidden">
                <ResponsiveContainer width="100%" height={240}>
                  <BarChart data={chart} margin={{ top: 4, right: 4, left: -15, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis dataKey="dia" tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} />
                    <YAxis tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} />
                    <Tooltip
                      formatter={(v: number) => `R$ ${v.toFixed(2)}`}
                      contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: 6, fontSize: 12 }}
                    />
                    <Legend layout="horizontal" wrapperStyle={{ paddingTop: 8 }} />
                    <Bar dataKey="receita" name="Receitas" fill="hsl(var(--success))" radius={[3, 3, 0, 0]} />
                    <Bar dataKey="despesa" name="Despesas" fill="hsl(var(--destructive))" radius={[3, 3, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>

      {/* Create/Edit dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg max-h-[90dvh] overflow-y-auto">
          <DialogHeader><DialogTitle className="text-balance">{editing ? 'Editar Lançamento' : 'Novo Lançamento'}</DialogTitle></DialogHeader>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-2">
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Tipo</Label>
              <Select value={form.type} onValueChange={v => f('type', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="receita">Receita</SelectItem><SelectItem value="despesa">Despesa</SelectItem></SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Data</Label>
              <Input type="date" value={form.transaction_date} onChange={e => f('transaction_date', e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Categoria *</Label>
              <Select value={form.category || 'none'} onValueChange={v => f('category', v === 'none' ? '' : v)}>
                <SelectTrigger><SelectValue placeholder="Selecionar" /></SelectTrigger>
                <SelectContent>
                  {catGroups.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Valor (R$) *</Label>
              <Input type="number" min="0" step="0.01" value={form.amount} onChange={e => f('amount', e.target.value)} placeholder="0,00" />
            </div>
            <div className="space-y-1.5 md:col-span-2">
              <Label className="text-sm font-normal">Descrição *</Label>
              <Input value={form.description} onChange={e => f('description', e.target.value)} placeholder="Ex: Venda de produtos de limpeza" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Forma de Pagamento</Label>
              <Select value={form.payment_method} onValueChange={v => f('payment_method', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{(Object.keys(PAYMENT_LABELS) as PaymentMethod[]).map(m => <SelectItem key={m} value={m}>{PAYMENT_LABELS[m]}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Observações</Label>
              <Textarea value={form.notes} onChange={e => f('notes', e.target.value)} rows={2} className="resize-none" />
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setShowDialog(false)}>Cancelar</Button>
            <Button onClick={handleSave} disabled={submitting}>Salvar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <AlertDialogHeader><AlertDialogTitle className="text-balance">Excluir lançamento?</AlertDialogTitle><AlertDialogDescription className="text-pretty">Esta ação não pode ser desfeita.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancelar</AlertDialogCancel><AlertDialogAction onClick={handleDelete} className="bg-destructive hover:bg-destructive/90">Excluir</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </PdvLayout>
  );
}
