import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/db/supabase';
import { PdvLayout } from '@/components/layouts/PdvLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { toast } from 'sonner';
import { Save, FileCheck, Lock, Shield, AlertTriangle, Check, Loader2, Trash2 } from 'lucide-react';
import type { PdvFiscalConfig, PdvCertificate } from '@/types/types';

export default function PdvFiscal() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [config, setConfig] = useState<Partial<PdvFiscalConfig>>({});
  const [certificates, setCertificates] = useState<PdvCertificate[]>([]);
  const [certForm, setCertForm] = useState({ alias: '', certificate_type: 'A1' as 'A1' | 'A3', password_hint: '', notes: '' });
  const [certFile, setCertFile] = useState<File | null>(null);
  const [certSaving, setCertSaving] = useState(false);

  const loadData = useCallback(async () => {
    setLoading(true);
    const [{ data: cfg }, { data: certs }] = await Promise.all([
      supabase.from('pdv_fiscal_config').select('*').single(),
      supabase.from('pdv_certificates').select('*').order('created_at', { ascending: false }),
    ]);
    if (cfg) setConfig(cfg);
    setCertificates(Array.isArray(certs) ? certs : []);
    setLoading(false);
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  const handleSaveConfig = async () => {
    try {
      setSaving(true);
      const { error } = await supabase.from('pdv_fiscal_config').update({
        company_name: config.company_name,
        company_fantasy_name: config.company_fantasy_name,
        cnpj: config.cnpj,
        ie: config.ie,
        im: config.im,
        cnae: config.cnae,
        crt: config.crt,
        address: config.address,
        address_number: config.address_number,
        neighborhood: config.neighborhood,
        city_code: config.city_code,
        city_name: config.city_name,
        state: config.state,
        zip_code: config.zip_code,
        phone: config.phone,
        email: config.email,
        sat_enabled: config.sat_enabled,
        sat_sign_ac: config.sat_sign_ac,
        sat_activation_code: config.sat_activation_code,
        sat_environment: config.sat_environment,
      }).eq('id', config.id!);

      if (error) {
        toast.error(`Erro ao salvar: ${error.message}`);
      } else {
        toast.success('Configurações fiscais salvas com sucesso!');
      }
    } finally {
      setSaving(false);
    }
  };

  const handleAddCertificate = async () => {
    if (!certForm.alias.trim()) {
      toast.error('Informe um nome/alias para o certificado');
      return;
    }
    if (!certFile) {
      toast.error('Selecione o arquivo do certificado (.pfx)');
      return;
    }

    try {
      setCertSaving(true);
      // Read file as base64
      const base64 = await new Promise<string>((resolve) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
        reader.readAsDataURL(certFile);
      });

      const { error } = await supabase.from('pdv_certificates').insert({
        alias: certForm.alias.trim(),
        certificate_type: certForm.certificate_type,
        certificate_data: base64,
        password_hint: certForm.password_hint.trim() || null,
        notes: certForm.notes.trim() || null,
      });

      if (error) {
        toast.error(`Erro ao salvar certificado: ${error.message}`);
      } else {
        toast.success('Certificado cadastrado com sucesso!');
        setCertForm({ alias: '', certificate_type: 'A1', password_hint: '', notes: '' });
        setCertFile(null);
        loadData();
      }
    } finally {
      setCertSaving(false);
    }
  };

  const handleDeleteCertificate = async (id: string) => {
    if (!confirm('Deseja realmente remover este certificado?')) return;
    const { error } = await supabase.from('pdv_certificates').delete().eq('id', id);
    if (error) {
      toast.error(`Erro: ${error.message}`);
    } else {
      toast.success('Certificado removido');
      setCertificates((prev) => prev.filter((c) => c.id !== id));
    }
  };

  const formatDate = (d: string | null) => d ? new Date(d).toLocaleDateString('pt-BR') : '—';

  return (
    <PdvLayout title="Fiscal & Certificado Digital">
      <div className="max-w-5xl mx-auto space-y-6">
        <Tabs defaultValue="fiscal" className="w-full">
          <TabsList className="mb-4">
            <TabsTrigger value="fiscal"><Shield className="h-4 w-4 mr-2" /> Cadastro Fiscal</TabsTrigger>
            <TabsTrigger value="certificado"><Lock className="h-4 w-4 mr-2" /> Certificado Digital</TabsTrigger>
            <TabsTrigger value="sat"><FileCheck className="h-4 w-4 mr-2" /> SAT / CF-e</TabsTrigger>
          </TabsList>

          {/* Aba Cadastro Fiscal */}
          <TabsContent value="fiscal" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-balance">Dados do Emitente</CardTitle>
                <CardDescription className="text-pretty">Informações fiscais da empresa para emissão de notas e cupons.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {loading ? (
                  <div className="flex items-center gap-2 text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" /> Carregando...</div>
                ) : (
                  <>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label>Razão Social</Label>
                        <Input value={config.company_name || ''} onChange={(e) => setConfig({ ...config, company_name: e.target.value })} />
                      </div>
                      <div>
                        <Label>Nome Fantasia</Label>
                        <Input value={config.company_fantasy_name || ''} onChange={(e) => setConfig({ ...config, company_fantasy_name: e.target.value })} />
                      </div>
                      <div>
                        <Label>CNPJ</Label>
                        <Input value={config.cnpj || ''} onChange={(e) => setConfig({ ...config, cnpj: e.target.value })} placeholder="00.000.000/0000-00" />
                      </div>
                      <div>
                        <Label>Inscrição Estadual (IE)</Label>
                        <Input value={config.ie || ''} onChange={(e) => setConfig({ ...config, ie: e.target.value })} />
                      </div>
                      <div>
                        <Label>Inscrição Municipal (IM)</Label>
                        <Input value={config.im || ''} onChange={(e) => setConfig({ ...config, im: e.target.value })} />
                      </div>
                      <div>
                        <Label>CNAE</Label>
                        <Input value={config.cnae || ''} onChange={(e) => setConfig({ ...config, cnae: e.target.value })} />
                      </div>
                      <div>
                        <Label>CRT (Regime Tributário)</Label>
                        <Select value={config.crt || '1'} onValueChange={(v) => setConfig({ ...config, crt: v as '1' | '2' | '3' })}>
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="1">1 - Simples Nacional</SelectItem>
                            <SelectItem value="2">2 - Simples Nacional - excesso de sublimite</SelectItem>
                            <SelectItem value="3">3 - Regime Normal (Lucro Presumido / Real)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="border-t pt-4 mt-4">
                      <p className="text-sm font-medium mb-3">Endereço</p>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <Label>Logradouro</Label>
                          <Input value={config.address || ''} onChange={(e) => setConfig({ ...config, address: e.target.value })} />
                        </div>
                        <div>
                          <Label>Número</Label>
                          <Input value={config.address_number || ''} onChange={(e) => setConfig({ ...config, address_number: e.target.value })} />
                        </div>
                        <div>
                          <Label>Bairro</Label>
                          <Input value={config.neighborhood || ''} onChange={(e) => setConfig({ ...config, neighborhood: e.target.value })} />
                        </div>
                        <div>
                          <Label>CEP</Label>
                          <Input value={config.zip_code || ''} onChange={(e) => setConfig({ ...config, zip_code: e.target.value })} />
                        </div>
                        <div>
                          <Label>Cidade</Label>
                          <Input value={config.city_name || ''} onChange={(e) => setConfig({ ...config, city_name: e.target.value })} />
                        </div>
                        <div>
                          <Label>Código IBGE da Cidade</Label>
                          <Input value={config.city_code || ''} onChange={(e) => setConfig({ ...config, city_code: e.target.value })} />
                        </div>
                        <div>
                          <Label>UF</Label>
                          <Input value={config.state || ''} maxLength={2} onChange={(e) => setConfig({ ...config, state: e.target.value.toUpperCase() })} />
                        </div>
                      </div>
                    </div>

                    <div className="border-t pt-4 mt-4">
                      <p className="text-sm font-medium mb-3">Contato</p>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <Label>Telefone</Label>
                          <Input value={config.phone || ''} onChange={(e) => setConfig({ ...config, phone: e.target.value })} />
                        </div>
                        <div>
                          <Label>E-mail</Label>
                          <Input type="email" value={config.email || ''} onChange={(e) => setConfig({ ...config, email: e.target.value })} />
                        </div>
                      </div>
                    </div>

                    <div className="flex justify-end pt-4">
                      <Button onClick={handleSaveConfig} disabled={saving}>
                        {saving ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Salvando...</> : <><Save className="h-4 w-4 mr-2" /> Salvar Configurações</>}
                      </Button>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Aba Certificado Digital */}
          <TabsContent value="certificado" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-balance">Certificados Digitais</CardTitle>
                <CardDescription className="text-pretty">Gerencie os certificados A1 ou A3 para emissão de notas fiscais e cupons.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Lista de certificados */}
                {certificates.length > 0 && (
                  <div className="space-y-2">
                    {certificates.map((cert) => (
                      <div key={cert.id} className="flex items-center gap-3 p-3 rounded-md border bg-card">
                        <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                          <Lock className="h-4 w-4 text-primary" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">{cert.alias}</p>
                          <p className="text-xs text-muted-foreground">Tipo {cert.certificate_type} · {cert.is_active ? 'Ativo' : 'Inativo'} · Válido até {formatDate(cert.valid_until)}</p>
                        </div>
                        <Button variant="ghost" size="icon" onClick={() => handleDeleteCertificate(cert.id)}>
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}

                {/* Form novo certificado */}
                <div className="border rounded-lg p-4 space-y-3 bg-muted/30">
                  <p className="text-sm font-medium">Adicionar Novo Certificado</p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div>
                      <Label>Alias / Nome</Label>
                      <Input value={certForm.alias} onChange={(e) => setCertForm({ ...certForm, alias: e.target.value })} placeholder="Ex: Certificado Principal" />
                    </div>
                    <div>
                      <Label>Tipo</Label>
                      <Select value={certForm.certificate_type} onValueChange={(v) => setCertForm({ ...certForm, certificate_type: v as 'A1' | 'A3' })}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="A1">A1 (Arquivo)</SelectItem>
                          <SelectItem value="A3">A3 (Cartão/Token)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div>
                    <Label>Arquivo do Certificado (.pfx)</Label>
                    <Input type="file" accept=".pfx" onChange={(e) => setCertFile(e.target.files?.[0] || null)} />
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div>
                      <Label>Lembrete de Senha</Label>
                      <Input value={certForm.password_hint} onChange={(e) => setCertForm({ ...certForm, password_hint: e.target.value })} placeholder="Dica para lembrar a senha" />
                    </div>
                    <div>
                      <Label>Observações</Label>
                      <Input value={certForm.notes} onChange={(e) => setCertForm({ ...certForm, notes: e.target.value })} placeholder="Ex: Validade, fornecedor..." />
                    </div>
                  </div>
                  <div className="flex justify-end">
                    <Button onClick={handleAddCertificate} disabled={certSaving}>
                      {certSaving ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Salvando...</> : <><Save className="h-4 w-4 mr-2" /> Adicionar Certificado</>}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Aba SAT */}
          <TabsContent value="sat" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-balance">Configuração SAT / CF-e</CardTitle>
                <CardDescription className="text-pretty">Configure o equipamento SAT para emissão de Cupom Fiscal Eletrônico.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {loading ? (
                  <div className="flex items-center gap-2 text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" /> Carregando...</div>
                ) : (
                  <>
                    <div className="flex items-center gap-3">
                      <Switch
                        checked={config.sat_enabled || false}
                        onCheckedChange={(v) => setConfig({ ...config, sat_enabled: v })}
                      />
                      <Label className="cursor-pointer">Ativar SAT / CF-e</Label>
                    </div>

                    {config.sat_enabled && (
                      <>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <Label>Código de Ativação do SAT</Label>
                            <Input value={config.sat_activation_code || ''} onChange={(e) => setConfig({ ...config, sat_activation_code: e.target.value })} />
                          </div>
                          <div>
                            <Label>Assinatura do AC (Chave de Registro)</Label>
                            <Input value={config.sat_sign_ac || ''} onChange={(e) => setConfig({ ...config, sat_sign_ac: e.target.value })} />
                          </div>
                          <div>
                            <Label>Ambiente</Label>
                            <Select value={config.sat_environment || 'homologacao'} onValueChange={(v) => setConfig({ ...config, sat_environment: v as 'homologacao' | 'producao' })}>
                              <SelectTrigger><SelectValue /></SelectTrigger>
                              <SelectContent>
                                <SelectItem value="homologacao">Homologação (Testes)</SelectItem>
                                <SelectItem value="producao">Produção (Real)</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>

                        <div className="flex items-start gap-2 p-3 rounded-md bg-amber-50 text-amber-900 text-sm">
                          <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5" />
                          <p>Emissão de CF-e SAT requer equipamento homologado e certificado digital válido. Esta configuração prepara o sistema para integração futura com o equipamento.</p>
                        </div>
                      </>
                    )}

                    <div className="flex justify-end pt-4">
                      <Button onClick={handleSaveConfig} disabled={saving}>
                        {saving ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Salvando...</> : <><Save className="h-4 w-4 mr-2" /> Salvar</>}
                      </Button>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </PdvLayout>
  );
}
