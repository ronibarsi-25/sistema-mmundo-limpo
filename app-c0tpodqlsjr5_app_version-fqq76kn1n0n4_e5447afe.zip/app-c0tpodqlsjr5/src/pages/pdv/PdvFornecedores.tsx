import { useEffect, useState } from 'react';
import { Plus, Pencil, Trash2, Search, Truck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Textarea } from '@/components/ui/textarea';
import { PdvLayout } from '@/components/layouts/PdvLayout';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import type { Supplier } from '@/types/types';

const emptyForm = {
  razao_social: '', nome_fantasia: '', cnpj: '', email: '', phone: '', contact_name: '',
  cep: '', logradouro: '', numero: '', complemento: '', bairro: '', cidade: '', estado: '', notes: '', active: true,
};

export default function PdvFornecedores() {
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showDialog, setShowDialog] = useState(false);
  const [editing, setEditing] = useState<Supplier | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [submitting, setSubmitting] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  useEffect(() => { load(); }, []);
  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from('suppliers').select('*').order('razao_social');
    setSuppliers((data as Supplier[]) || []);
    setLoading(false);
  };

  const openCreate = () => { setEditing(null); setForm(emptyForm); setShowDialog(true); };
  const openEdit = (s: Supplier) => {
    setEditing(s);
    setForm({
      razao_social: s.razao_social, nome_fantasia: s.nome_fantasia || '', cnpj: s.cnpj || '',
      email: s.email || '', phone: s.phone || '', contact_name: s.contact_name || '',
      cep: s.cep || '', logradouro: s.logradouro || '', numero: s.numero || '',
      complemento: s.complemento || '', bairro: s.bairro || '', cidade: s.cidade || '',
      estado: s.estado || '', notes: s.notes || '', active: s.active,
    });
    setShowDialog(true);
  };

  const lookupCep = async () => {
    if (form.cep.replace(/\D/g, '').length !== 8) return;
    try {
      const r = await fetch(`https://viacep.com.br/ws/${form.cep.replace(/\D/g, '')}/json/`);
      const d = await r.json();
      if (!d.erro) setForm(p => ({ ...p, logradouro: d.logradouro, bairro: d.bairro, cidade: d.localidade, estado: d.uf }));
    } catch { /* silent */ }
  };

  const handleSave = async () => {
    if (!form.razao_social.trim()) { toast.error('Informe a razão social'); return; }
    setSubmitting(true);
    const payload = { razao_social: form.razao_social.trim(), nome_fantasia: form.nome_fantasia || null, cnpj: form.cnpj || null, email: form.email || null, phone: form.phone || null, contact_name: form.contact_name || null, cep: form.cep || null, logradouro: form.logradouro || null, numero: form.numero || null, complemento: form.complemento || null, bairro: form.bairro || null, cidade: form.cidade || null, estado: form.estado || null, notes: form.notes || null, active: form.active };
    const q = editing ? supabase.from('suppliers').update(payload).eq('id', editing.id) : supabase.from('suppliers').insert(payload);
    const { error } = await q;
    setSubmitting(false);
    if (error) { toast.error('Erro ao salvar: ' + error.message); return; }
    toast.success(editing ? 'Fornecedor atualizado!' : 'Fornecedor criado!');
    setShowDialog(false); load();
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    const { error } = await supabase.from('suppliers').delete().eq('id', deleteId);
    if (error) toast.error('Não é possível excluir fornecedor com registros vinculados');
    else { toast.success('Fornecedor excluído'); load(); }
    setDeleteId(null);
  };

  const f = (k: string, v: string | boolean) => setForm(p => ({ ...p, [k]: v }));
  const filtered = suppliers.filter(s => !search || s.razao_social.toLowerCase().includes(search.toLowerCase()) || (s.nome_fantasia || '').toLowerCase().includes(search.toLowerCase()) || (s.cnpj || '').includes(search));

  return (
    <PdvLayout title="Fornecedores" actions={<Button size="sm" onClick={openCreate}><Plus className="h-4 w-4 mr-1.5" />Novo Fornecedor</Button>}>
      <div className="relative mb-5 max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input placeholder="Buscar por nome ou CNPJ..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
      </div>

      <div className="bg-card border border-border rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/40">
                <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Razão Social</th>
                <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Nome Fantasia</th>
                <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">CNPJ</th>
                <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Contato</th>
                <th className="text-center px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Status</th>
                <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {loading ? (
                Array.from({ length: 5 }).map((_, i) => <tr key={i}><td colSpan={6} className="px-4 py-3"><Skeleton className="h-5 w-full bg-muted" /></td></tr>)
              ) : filtered.length === 0 ? (
                <tr><td colSpan={6} className="text-center py-12 text-muted-foreground">
                  <Truck className="h-8 w-8 mx-auto mb-2 opacity-40" />
                  <p className="text-pretty">Nenhum fornecedor encontrado</p>
                </td></tr>
              ) : filtered.map(s => (
                <tr key={s.id} className="hover:bg-muted/30 transition-colors">
                  <td className="px-4 py-3 font-medium text-foreground whitespace-nowrap">{s.razao_social}</td>
                  <td className="px-4 py-3 text-muted-foreground whitespace-nowrap">{s.nome_fantasia || '—'}</td>
                  <td className="px-4 py-3 text-muted-foreground whitespace-nowrap font-mono text-xs">{s.cnpj || '—'}</td>
                  <td className="px-4 py-3 text-muted-foreground whitespace-nowrap">{s.contact_name || s.phone || '—'}</td>
                  <td className="px-4 py-3 text-center whitespace-nowrap"><Badge variant={s.active ? 'default' : 'secondary'} className="text-xs">{s.active ? 'Ativo' : 'Inativo'}</Badge></td>
                  <td className="px-4 py-3 text-right whitespace-nowrap">
                    <div className="flex items-center justify-end gap-1">
                      <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openEdit(s)}><Pencil className="h-3.5 w-3.5" /></Button>
                      <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive hover:bg-destructive/10" onClick={() => setDeleteId(s.id)}><Trash2 className="h-3.5 w-3.5" /></Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl max-h-[90dvh] overflow-y-auto">
          <DialogHeader><DialogTitle className="text-balance">{editing ? 'Editar Fornecedor' : 'Novo Fornecedor'}</DialogTitle></DialogHeader>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-2">
            <div className="space-y-1.5 md:col-span-2"><Label className="text-sm font-normal">Razão Social *</Label><Input value={form.razao_social} onChange={e => f('razao_social', e.target.value)} /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Nome Fantasia</Label><Input value={form.nome_fantasia} onChange={e => f('nome_fantasia', e.target.value)} /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">CNPJ</Label><Input value={form.cnpj} onChange={e => f('cnpj', e.target.value)} placeholder="00.000.000/0000-00" /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Telefone</Label><Input value={form.phone} onChange={e => f('phone', e.target.value)} /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">E-mail</Label><Input type="email" value={form.email} onChange={e => f('email', e.target.value)} /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Nome do Contato</Label><Input value={form.contact_name} onChange={e => f('contact_name', e.target.value)} /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">CEP</Label><Input value={form.cep} onChange={e => f('cep', e.target.value)} onBlur={lookupCep} placeholder="00000-000" /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Logradouro</Label><Input value={form.logradouro} onChange={e => f('logradouro', e.target.value)} /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Número</Label><Input value={form.numero} onChange={e => f('numero', e.target.value)} /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Bairro</Label><Input value={form.bairro} onChange={e => f('bairro', e.target.value)} /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Cidade</Label><Input value={form.cidade} onChange={e => f('cidade', e.target.value)} /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Estado</Label><Input value={form.estado} onChange={e => f('estado', e.target.value)} maxLength={2} /></div>
            <div className="space-y-1.5 md:col-span-2"><Label className="text-sm font-normal">Observações</Label><Textarea value={form.notes} onChange={e => f('notes', e.target.value)} rows={2} /></div>
            <div className="flex items-center gap-2 md:col-span-2">
              <input type="checkbox" id="sAtivo" checked={form.active as boolean} onChange={e => f('active', e.target.checked)} className="h-4 w-4 rounded border-border" />
              <Label htmlFor="sAtivo" className="text-sm font-normal cursor-pointer">Fornecedor ativo</Label>
            </div>
          </div>
          <DialogFooter className="gap-2"><Button variant="outline" onClick={() => setShowDialog(false)}>Cancelar</Button><Button onClick={handleSave} disabled={submitting}>Salvar</Button></DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <AlertDialogHeader><AlertDialogTitle className="text-balance">Excluir fornecedor?</AlertDialogTitle><AlertDialogDescription className="text-pretty">Esta ação não pode ser desfeita.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancelar</AlertDialogCancel><AlertDialogAction onClick={handleDelete} className="bg-destructive hover:bg-destructive/90">Excluir</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </PdvLayout>
  );
}
