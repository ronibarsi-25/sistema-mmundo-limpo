import { useEffect, useRef, useState } from 'react';
import { Plus, Shield, AlertTriangle, CheckCircle, Zap, Printer } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { PdvLayout } from '@/components/layouts/PdvLayout';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';

interface Warranty {
  id: string;
  invoice_id: string | null;
  product_id: string;
  customer_id: string | null;
  warranty_months: number;
  start_date: string;
  end_date: string;
  status: 'ativa' | 'expirada' | 'acionada';
  notes: string | null;
  created_at: string;
  product_name?: string | null;
  customer_name?: string | null;
  invoice_number?: string | null;
  pdv_products?: { name: string } | null;
  customers?: { name: string } | null;
}

const today = new Date().toISOString().split('T')[0];
const in30 = new Date(Date.now() + 30 * 86400000).toISOString().split('T')[0];

const STATUS_INFO = {
  ativa:    { label: 'Ativa',    color: 'bg-success/10 text-success border-success/30',       icon: CheckCircle },
  expirada: { label: 'Expirada', color: 'bg-muted text-muted-foreground border-border',        icon: Shield },
  acionada: { label: 'Acionada', color: 'bg-warning/10 text-warning border-warning/30',        icon: Zap },
};

/* ── Geração do HTML de impressão da garantia ── */
function buildWarrantyHtml(w: Warranty, companyName: string): string {
  const prodName  = w.product_name || w.pdv_products?.name || '—';
  const custName  = w.customer_name || w.customers?.name  || '—';
  const invNum    = w.invoice_number || '—';
  const startFmt  = new Date(w.start_date + 'T00:00:00').toLocaleDateString('pt-BR');
  const endFmt    = new Date(w.end_date   + 'T00:00:00').toLocaleDateString('pt-BR');

  return `<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8"/>
<title>Termo de Garantia</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:Arial,sans-serif;font-size:13px;color:#111;padding:32px}
  h1{font-size:20px;text-align:center;margin-bottom:4px}
  .subtitle{text-align:center;font-size:12px;color:#555;margin-bottom:24px}
  .section{margin-bottom:16px}
  .section h2{font-size:13px;font-weight:700;border-bottom:1px solid #ccc;padding-bottom:4px;margin-bottom:8px}
  .row{display:flex;gap:32px;margin-bottom:6px}
  .field label{font-size:11px;color:#555;display:block}
  .field span{font-size:13px;font-weight:600}
  .highlight{background:#f0f9f0;border:1px solid #6abf6a;border-radius:6px;padding:12px 16px;display:flex;justify-content:space-between;align-items:center;margin-bottom:20px}
  .highlight .months{font-size:28px;font-weight:700;color:#2e7d32}
  .notes{background:#fafafa;border:1px solid #ddd;border-radius:4px;padding:10px;font-size:12px;color:#444}
  .footer{margin-top:40px;border-top:1px dashed #ccc;padding-top:16px;display:flex;justify-content:space-between;font-size:11px;color:#555}
  .sig-line{border-top:1px solid #333;width:200px;text-align:center;padding-top:4px;font-size:11px}
  @media print{body{padding:16px}}
</style></head><body>
<h1>${companyName}</h1>
<p class="subtitle">TERMO DE GARANTIA</p>

<div class="highlight">
  <div>
    <div style="font-size:12px;color:#555">Garantia válida por</div>
    <div class="months">${w.warranty_months} ${w.warranty_months === 1 ? 'mês' : 'meses'}</div>
  </div>
  <div style="text-align:right">
    <div style="font-size:12px;color:#555">Vigência</div>
    <div style="font-size:15px;font-weight:600">${startFmt} → ${endFmt}</div>
  </div>
</div>

<div class="section">
  <h2>Produto</h2>
  <div class="row">
    <div class="field"><label>Nome do Produto</label><span>${prodName}</span></div>
    <div class="field"><label>Nota Fiscal</label><span>${invNum}</span></div>
  </div>
</div>

<div class="section">
  <h2>Cliente</h2>
  <div class="row">
    <div class="field"><label>Nome</label><span>${custName}</span></div>
    <div class="field"><label>Data de Início</label><span>${startFmt}</span></div>
    <div class="field"><label>Validade</label><span>${endFmt}</span></div>
  </div>
</div>

${w.notes ? `<div class="section"><h2>Observações</h2><p class="notes">${w.notes}</p></div>` : ''}

<div class="footer">
  <div>
    <div class="sig-line">Assinatura do Responsável</div>
  </div>
  <div style="text-align:right;font-size:11px;color:#999">
    Emitido em ${new Date().toLocaleString('pt-BR')}<br/>
    ID: ${w.id.slice(0, 8).toUpperCase()}
  </div>
</div>
</body></html>`;
}

export default function PdvGarantias() {
  const [warranties, setWarranties]   = useState<Warranty[]>([]);
  const [products, setProducts]       = useState<{ id: string; name: string }[]>([]);
  const [customers, setCustomers]     = useState<{ id: string; name: string }[]>([]);
  const [invoices, setInvoices]       = useState<{ id: string; number: string }[]>([]);
  const [loading, setLoading]         = useState(true);
  const [showDialog, setShowDialog]   = useState(false);
  const [saving, setSaving]           = useState(false);
  const [companyName, setCompanyName] = useState('Minha Empresa');
  const [form, setForm] = useState({
    product_id: '', customer_id: '', invoice_id: '',
    warranty_months: '12', start_date: today, notes: '',
  });

  const printFrameRef = useRef<HTMLIFrameElement | null>(null);

  useEffect(() => { load(); loadProducts(); loadCustomers(); loadInvoices(); loadCompany(); }, []);

  const loadCompany = async () => {
    const { data } = await supabase.from('store_settings').select('store_name').maybeSingle();
    if (data?.store_name) setCompanyName(data.store_name);
  };

  const load = async () => {
    setLoading(true);
    // Auto-expira garantias vencidas
    await supabase.from('warranties').update({ status: 'expirada' })
      .eq('status', 'ativa').lt('end_date', today);
    const { data, error } = await supabase
      .from('warranties')
      .select('*, pdv_products(name), customers(name)')
      .order('end_date');
    if (error) toast.error('Erro ao carregar garantias: ' + error.message);
    setWarranties((data as Warranty[]) || []);
    setLoading(false);
  };

  const loadProducts = async () => {
    const { data } = await supabase.from('pdv_products').select('id,name').order('name');
    setProducts(data || []);
  };
  const loadCustomers = async () => {
    const { data } = await supabase.from('customers').select('id,name').order('name');
    setCustomers(data || []);
  };
  const loadInvoices = async () => {
    // pdv_invoices.number (não invoice_number)
    const { data } = await supabase
      .from('pdv_invoices')
      .select('id,number')
      .eq('type', 'saida')
      .order('created_at', { ascending: false })
      .limit(100);
    setInvoices((data || []) as { id: string; number: string }[]);
  };

  const handleSave = async () => {
    if (!form.product_id) { toast.error('Selecione o produto'); return; }
    const months = parseInt(form.warranty_months);
    if (!months || months <= 0) { toast.error('Informe os meses de garantia'); return; }

    const end = new Date(form.start_date + 'T00:00:00');
    end.setMonth(end.getMonth() + months);

    // Busca nome do produto e cliente para desnormalizar
    const prodObj = products.find(p => p.id === form.product_id);
    const custObj = customers.find(c => c.id === form.customer_id);
    const invObj  = invoices.find(i => i.id === form.invoice_id);

    setSaving(true);
    const { error } = await supabase.from('warranties').insert({
      product_id:      form.product_id,
      customer_id:     form.customer_id  || null,
      invoice_id:      form.invoice_id   || null,
      warranty_months: months,
      start_date:      form.start_date,
      end_date:        end.toISOString().split('T')[0],
      status:          'ativa',
      notes:           form.notes || null,
      product_name:    prodObj?.name  || null,
      customer_name:   custObj?.name  || null,
      invoice_number:  invObj?.number || null,
    });
    setSaving(false);

    if (error) { toast.error('Erro ao registrar garantia: ' + error.message); return; }

    toast.success('Garantia registrada com sucesso!');
    setShowDialog(false);
    setForm({ product_id: '', customer_id: '', invoice_id: '', warranty_months: '12', start_date: today, notes: '' });
    load();
  };

  const acionar = async (id: string) => {
    const { error } = await supabase.from('warranties').update({ status: 'acionada' }).eq('id', id);
    if (error) { toast.error('Erro: ' + error.message); return; }
    toast.success('Garantia acionada!');
    load();
  };

  const handlePrint = (w: Warranty) => {
    const html = buildWarrantyHtml(w, companyName);
    // Usa iframe oculto para impressão sem abrir nova aba
    let frame = printFrameRef.current;
    if (!frame) {
      frame = document.createElement('iframe');
      frame.style.cssText = 'position:fixed;top:-9999px;left:-9999px;width:800px;height:600px;border:none';
      document.body.appendChild(frame);
      printFrameRef.current = frame;
    }
    const doc = frame.contentDocument || frame.contentWindow?.document;
    if (!doc) return;
    doc.open(); doc.write(html); doc.close();
    setTimeout(() => frame!.contentWindow?.print(), 400);
  };

  const ff = (k: string, v: string) => setForm(p => ({ ...p, [k]: v }));

  const expiring = warranties.filter(w =>
    w.status === 'ativa' && w.end_date <= in30 && w.end_date >= today
  );

  const getProductName = (w: Warranty) => w.product_name || w.pdv_products?.name || '—';
  const getCustomerName = (w: Warranty) => w.customer_name || w.customers?.name || '—';
  const getInvoiceNumber = (w: Warranty) => w.invoice_number || '—';

  return (
    <PdvLayout title="Controle de Garantias" actions={
      <Button size="sm" onClick={() => setShowDialog(true)}>
        <Plus className="h-4 w-4 mr-1.5" />Nova Garantia
      </Button>
    }>
      <div className="space-y-4">
        {expiring.length > 0 && (
          <div className="bg-warning/5 border border-warning/20 rounded-lg p-4 flex items-start gap-3">
            <AlertTriangle className="h-5 w-5 text-warning shrink-0 mt-0.5" />
            <div className="text-sm">
              <p className="font-medium text-warning">{expiring.length} garantia(s) vencendo em 30 dias!</p>
              <p className="text-muted-foreground mt-0.5">
                {expiring.map(w => getProductName(w)).join(', ')}
              </p>
            </div>
          </div>
        )}

        {/* Stat cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { label: 'Ativas',    val: warranties.filter(w => w.status === 'ativa').length,    cls: 'text-success' },
            { label: 'Vencendo',  val: expiring.length,                                        cls: 'text-warning' },
            { label: 'Acionadas', val: warranties.filter(w => w.status === 'acionada').length, cls: 'text-primary' },
            { label: 'Expiradas', val: warranties.filter(w => w.status === 'expirada').length, cls: 'text-muted-foreground' },
          ].map((k, i) => (
            <div key={i} className="bg-card border border-border rounded-lg p-4">
              <p className="text-xs text-muted-foreground mb-1">{k.label}</p>
              <p className={`text-2xl font-bold ${k.cls}`}>{k.val}</p>
            </div>
          ))}
        </div>

        {/* Table */}
        <div className="bg-card border border-border rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border bg-muted/40">
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Produto</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Cliente</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Nota</th>
                  <th className="text-center px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Meses</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Início</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Vencimento</th>
                  <th className="text-center px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Status</th>
                  <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {loading
                  ? Array.from({ length: 5 }).map((_, i) => (
                      <tr key={i}>
                        <td colSpan={8} className="px-4 py-3">
                          <Skeleton className="h-5 w-full bg-muted" />
                        </td>
                      </tr>
                    ))
                  : warranties.length === 0
                    ? (
                      <tr>
                        <td colSpan={8} className="text-center py-12 text-muted-foreground">
                          <Shield className="h-8 w-8 mx-auto mb-2 opacity-40" />
                          <p>Nenhuma garantia registrada</p>
                        </td>
                      </tr>
                    )
                    : warranties.map(w => {
                        const si = STATUS_INFO[w.status];
                        const isExpiring = w.status === 'ativa' && w.end_date <= in30 && w.end_date >= today;
                        return (
                          <tr key={w.id} className="hover:bg-muted/30">
                            <td className="px-4 py-3 font-medium whitespace-nowrap">{getProductName(w)}</td>
                            <td className="px-4 py-3 whitespace-nowrap">{getCustomerName(w)}</td>
                            <td className="px-4 py-3 font-mono text-xs whitespace-nowrap">{getInvoiceNumber(w)}</td>
                            <td className="px-4 py-3 text-center whitespace-nowrap">{w.warranty_months}</td>
                            <td className="px-4 py-3 whitespace-nowrap">
                              {new Date(w.start_date + 'T00:00:00').toLocaleDateString('pt-BR')}
                            </td>
                            <td className={`px-4 py-3 whitespace-nowrap ${isExpiring ? 'text-warning font-medium' : ''}`}>
                              {new Date(w.end_date + 'T00:00:00').toLocaleDateString('pt-BR')}
                              {isExpiring && <span className="ml-1 text-xs">(vencendo!)</span>}
                            </td>
                            <td className="px-4 py-3 text-center whitespace-nowrap">
                              <span className={`inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full border ${si.color}`}>
                                <si.icon className="h-3 w-3" />{si.label}
                              </span>
                            </td>
                            <td className="px-4 py-3 text-right whitespace-nowrap">
                              <div className="flex items-center justify-end gap-1">
                                <Button
                                  variant="ghost" size="sm" className="h-7 text-xs"
                                  title="Imprimir Garantia"
                                  onClick={() => handlePrint(w)}
                                >
                                  <Printer className="h-3 w-3 mr-1" />Imprimir
                                </Button>
                                {w.status === 'ativa' && (
                                  <Button
                                    variant="outline" size="sm" className="h-7 text-xs"
                                    onClick={() => acionar(w.id)}
                                  >
                                    <Zap className="h-3 w-3 mr-1" />Acionar
                                  </Button>
                                )}
                              </div>
                            </td>
                          </tr>
                        );
                      })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Dialog: Nova Garantia */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-balance">Registrar Garantia</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4 py-2">
            <div className="col-span-2 space-y-1.5">
              <Label className="text-sm font-normal">Produto *</Label>
              <Select value={form.product_id || 'none'} onValueChange={v => ff('product_id', v === 'none' ? '' : v)}>
                <SelectTrigger><SelectValue placeholder="Selecione o produto..." /></SelectTrigger>
                <SelectContent>
                  {products.map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Cliente</Label>
              <Select value={form.customer_id || 'none'} onValueChange={v => ff('customer_id', v === 'none' ? '' : v)}>
                <SelectTrigger><SelectValue placeholder="Opcional" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Nenhum</SelectItem>
                  {customers.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Nota Fiscal</Label>
              <Select value={form.invoice_id || 'none'} onValueChange={v => ff('invoice_id', v === 'none' ? '' : v)}>
                <SelectTrigger><SelectValue placeholder="Opcional" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Nenhuma</SelectItem>
                  {invoices.map(i => <SelectItem key={i.id} value={i.id}>{i.number}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Data de Início</Label>
              <Input type="date" value={form.start_date} onChange={e => ff('start_date', e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Meses de Garantia *</Label>
              <Input type="number" min="1" max="120" value={form.warranty_months} onChange={e => ff('warranty_months', e.target.value)} />
            </div>
            <div className="col-span-2 space-y-1.5">
              <Label className="text-sm font-normal">Observações</Label>
              <Textarea value={form.notes} onChange={e => ff('notes', e.target.value)} rows={2} />
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setShowDialog(false)}>Cancelar</Button>
            <Button onClick={handleSave} disabled={saving}>
              {saving ? 'Registrando...' : 'Registrar'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PdvLayout>
  );
}
