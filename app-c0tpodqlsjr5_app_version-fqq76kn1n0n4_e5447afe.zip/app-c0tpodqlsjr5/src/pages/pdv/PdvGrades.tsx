import { useEffect, useState } from 'react';
import { Plus, Pencil, Trash2, Layers, ChevronDown, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { PdvLayout } from '@/components/layouts/PdvLayout';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';

interface PdvProduct { id: string; name: string; code: string; barcode?: string | null; has_variants: boolean; sale_price: number; }
interface ProductVariant {
  id: string; product_id: string; variant_name: string; color: string | null;
  size: string | null; flavor: string | null; barcode: string | null;
  stock_qty: number; cost_price: number; sale_price: number | null; active: boolean;
}

const empty = (): Omit<ProductVariant, 'id'> => ({
  product_id: '', variant_name: '', color: '', size: '', flavor: '', barcode: '',
  stock_qty: 0, cost_price: 0, sale_price: null, active: true,
});

export default function PdvGrades() {
  const [products, setProducts] = useState<PdvProduct[]>([]);
  const [expanded, setExpanded] = useState<string | null>(null);
  const [variants, setVariants] = useState<Record<string, ProductVariant[]>>({});
  const [loading, setLoading] = useState(true);
  const [loadingVariants, setLoadingVariants] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [showDialog, setShowDialog] = useState(false);
  const [editVariant, setEditVariant] = useState<ProductVariant | null>(null);
  const [form, setForm] = useState(empty());
  const [saving, setSaving] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [deleteProductId, setDeleteProductId] = useState<string | null>(null);

  useEffect(() => { loadProducts(); }, []);

  const loadProducts = async () => {
    setLoading(true);
    const { data } = await supabase.from('pdv_products').select('id,name,code,has_variants,sale_price').order('name');
    setProducts((data as PdvProduct[]) || []);
    setLoading(false);
  };

  const toggleExpand = async (pid: string) => {
    if (expanded === pid) { setExpanded(null); return; }
    setExpanded(pid);
    if (!variants[pid]) {
      setLoadingVariants(pid);
      const { data } = await supabase.from('product_variants').select('*').eq('product_id', pid).order('variant_name');
      setVariants(v => ({ ...v, [pid]: (data as ProductVariant[]) || [] }));
      setLoadingVariants(null);
    }
  };

  const openNew = (pid: string) => {
    setEditVariant(null);
    setForm({ ...empty(), product_id: pid });
    setShowDialog(true);
  };

  const openEdit = (v: ProductVariant) => {
    setEditVariant(v);
    setForm({ product_id: v.product_id, variant_name: v.variant_name, color: v.color || '', size: v.size || '', flavor: v.flavor || '', barcode: v.barcode || '', stock_qty: v.stock_qty, cost_price: v.cost_price, sale_price: v.sale_price, active: v.active });
    setShowDialog(true);
  };

  const handleSave = async () => {
    if (!form.variant_name.trim()) { toast.error('Informe o nome da variação'); return; }
    setSaving(true);
    const payload = { ...form, color: form.color || null, size: form.size || null, flavor: form.flavor || null, barcode: form.barcode || null, sale_price: form.sale_price || null };
    let error;
    if (editVariant) {
      ({ error } = await supabase.from('product_variants').update(payload).eq('id', editVariant.id));
    } else {
      ({ error } = await supabase.from('product_variants').insert(payload));
      if (!error) await supabase.from('pdv_products').update({ has_variants: true }).eq('id', form.product_id);
    }
    setSaving(false);
    if (error) { toast.error('Erro: ' + error.message); return; }
    toast.success(editVariant ? 'Variação atualizada!' : 'Variação criada!');
    setShowDialog(false);
    setVariants(v => { const copy = { ...v }; delete copy[form.product_id]; return copy; });
    if (expanded === form.product_id) {
      setLoadingVariants(form.product_id);
      const { data } = await supabase.from('product_variants').select('*').eq('product_id', form.product_id).order('variant_name');
      setVariants(v => ({ ...v, [form.product_id]: (data as ProductVariant[]) || [] }));
      setLoadingVariants(null);
    }
  };

  const handleDelete = async () => {
    if (!deleteId || !deleteProductId) return;
    const { error } = await supabase.from('product_variants').delete().eq('id', deleteId);
    if (error) { toast.error('Erro ao excluir'); return; }
    toast.success('Variação excluída!');
    setDeleteId(null);
    setVariants(v => ({ ...v, [deleteProductId]: (v[deleteProductId] || []).filter(x => x.id !== deleteId) }));
  };

  const f = (k: keyof typeof form, v: string | number | boolean | null) => setForm(p => ({ ...p, [k]: v }));

  const filtered = products.filter(p => p.name.toLowerCase().includes(search.toLowerCase()) || p.code.includes(search) || (p.barcode && p.barcode.includes(search)));

  return (
    <PdvLayout title="Grades de Produtos">
      <div className="space-y-4">
        <div className="flex flex-col md:flex-row gap-3">
          <Input className="md:max-w-xs" placeholder="Buscar produto..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>

        <div className="space-y-2">
          {loading ? Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-14 w-full bg-muted rounded-lg" />) :
            filtered.length === 0 ? (
              <div className="text-center py-16 text-muted-foreground">
                <Layers className="h-10 w-10 mx-auto mb-3 opacity-30" />
                <p className="text-pretty">Nenhum produto encontrado</p>
              </div>
            ) : filtered.map(p => (
              <div key={p.id} className="bg-card border border-border rounded-lg overflow-hidden">
                <button
                  className="w-full flex items-center gap-3 px-4 py-3 hover:bg-muted/30 transition-colors text-left"
                  onClick={() => toggleExpand(p.id)}
                >
                  {expanded === p.id ? <ChevronDown className="h-4 w-4 shrink-0 text-muted-foreground" /> : <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />}
                  <span className="font-medium text-sm flex-1 min-w-0 truncate">{p.name}</span>
                  <span className="text-xs text-muted-foreground font-mono shrink-0">{p.code}</span>
                  {p.has_variants && <Badge variant="secondary" className="text-xs shrink-0">Com grades</Badge>}
                  <Button size="sm" variant="outline" className="h-7 text-xs shrink-0" onClick={e => { e.stopPropagation(); openNew(p.id); }}>
                    <Plus className="h-3.5 w-3.5 mr-1" />Nova Variação
                  </Button>
                </button>

                {expanded === p.id && (
                  <div className="border-t border-border">
                    {loadingVariants === p.id ? (
                      <div className="p-4 space-y-2">{Array.from({ length: 2 }).map((_, i) => <Skeleton key={i} className="h-10 w-full bg-muted" />)}</div>
                    ) : (variants[p.id] || []).length === 0 ? (
                      <p className="text-sm text-muted-foreground text-center py-6">Nenhuma variação cadastrada. Clique em "Nova Variação" para adicionar.</p>
                    ) : (
                      <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                          <thead><tr className="bg-muted/30">
                            <th className="text-left px-4 py-2 font-medium text-muted-foreground whitespace-nowrap">Variação</th>
                            <th className="text-left px-4 py-2 font-medium text-muted-foreground whitespace-nowrap">Cor</th>
                            <th className="text-left px-4 py-2 font-medium text-muted-foreground whitespace-nowrap">Tam.</th>
                            <th className="text-left px-4 py-2 font-medium text-muted-foreground whitespace-nowrap">Barcode</th>
                            <th className="text-right px-4 py-2 font-medium text-muted-foreground whitespace-nowrap">Estoque</th>
                            <th className="text-right px-4 py-2 font-medium text-muted-foreground whitespace-nowrap">Preço</th>
                            <th className="text-center px-4 py-2 font-medium text-muted-foreground whitespace-nowrap">Status</th>
                            <th className="text-right px-4 py-2 font-medium text-muted-foreground whitespace-nowrap">Ações</th>
                          </tr></thead>
                          <tbody className="divide-y divide-border">
                            {(variants[p.id] || []).map(v => (
                              <tr key={v.id} className="hover:bg-muted/20">
                                <td className="px-4 py-2 font-medium whitespace-nowrap">{v.variant_name}</td>
                                <td className="px-4 py-2 text-muted-foreground whitespace-nowrap">{v.color || '—'}</td>
                                <td className="px-4 py-2 text-muted-foreground whitespace-nowrap">{v.size || '—'}</td>
                                <td className="px-4 py-2 font-mono text-xs whitespace-nowrap">{v.barcode || '—'}</td>
                                <td className="px-4 py-2 text-right whitespace-nowrap">
                                  <span className={v.stock_qty <= 0 ? 'text-destructive font-medium' : 'text-foreground'}>{v.stock_qty}</span>
                                </td>
                                <td className="px-4 py-2 text-right whitespace-nowrap">R$ {(v.sale_price ?? p.sale_price).toFixed(2)}</td>
                                <td className="px-4 py-2 text-center whitespace-nowrap">
                                  <Badge variant={v.active ? 'default' : 'secondary'} className="text-xs">{v.active ? 'Ativo' : 'Inativo'}</Badge>
                                </td>
                                <td className="px-4 py-2 text-right whitespace-nowrap">
                                  <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openEdit(v)}><Pencil className="h-3.5 w-3.5" /></Button>
                                  <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive hover:text-destructive" onClick={() => { setDeleteId(v.id); setDeleteProductId(p.id); }}><Trash2 className="h-3.5 w-3.5" /></Button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                )}
              </div>
            ))}
        </div>
      </div>

      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle className="text-balance">{editVariant ? 'Editar Variação' : 'Nova Variação'}</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-4 py-2">
            <div className="col-span-2 space-y-1.5"><Label className="text-sm font-normal">Nome da Variação *</Label><Input value={form.variant_name} onChange={e => f('variant_name', e.target.value)} placeholder="ex: Azul - Tamanho P" /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Cor</Label><Input value={form.color || ''} onChange={e => f('color', e.target.value)} placeholder="Azul, Vermelho..." /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Tamanho</Label><Input value={form.size || ''} onChange={e => f('size', e.target.value)} placeholder="P, M, G, GG..." /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Sabor</Label><Input value={form.flavor || ''} onChange={e => f('flavor', e.target.value)} placeholder="Limão, Lavanda..." /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Código de Barras</Label><Input value={form.barcode || ''} onChange={e => f('barcode', e.target.value)} /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Estoque Atual</Label><Input type="number" min="0" value={form.stock_qty} onChange={e => f('stock_qty', parseFloat(e.target.value) || 0)} /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Preço de Custo (R$)</Label><Input type="number" min="0" step="0.01" value={form.cost_price} onChange={e => f('cost_price', parseFloat(e.target.value) || 0)} /></div>
            <div className="col-span-2 space-y-1.5"><Label className="text-sm font-normal">Preço de Venda (R$) — deixe vazio para herdar do produto</Label><Input type="number" min="0" step="0.01" value={form.sale_price ?? ''} onChange={e => f('sale_price', e.target.value ? parseFloat(e.target.value) : null)} /></div>
            <div className="col-span-2 flex items-center gap-3">
              <Switch checked={form.active} onCheckedChange={v => f('active', v)} id="active-switch" />
              <Label htmlFor="active-switch" className="text-sm font-normal cursor-pointer">Variação ativa</Label>
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setShowDialog(false)}>Cancelar</Button>
            <Button onClick={handleSave} disabled={saving}>Salvar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={o => { if (!o) { setDeleteId(null); setDeleteProductId(null); } }}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-sm">
          <AlertDialogHeader><AlertDialogTitle>Excluir Variação?</AlertDialogTitle><AlertDialogDescription>Esta ação não pode ser desfeita.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancelar</AlertDialogCancel><AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={handleDelete}>Excluir</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </PdvLayout>
  );
}
