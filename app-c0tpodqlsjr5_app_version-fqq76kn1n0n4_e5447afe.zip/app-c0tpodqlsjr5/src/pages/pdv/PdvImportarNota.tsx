import { useState, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { useDropzone } from 'react-dropzone';
import { supabase } from '@/db/supabase';
import { PdvLayout } from '@/components/layouts/PdvLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import {
  Upload, FileText, X, Loader2, Check, AlertTriangle, FileUp, Eye,
  Pencil, Trash2, Merge, Plus, Table as TableIcon, FileSpreadsheet,
  Receipt, ArrowRight
} from 'lucide-react';
import { parseNfeXmlString } from '@/utils/nfeParser';

interface ExtractedProduct {
  code: string;
  name: string;
  description?: string;
  unit?: string;
  cost_price: number;
  quantity: number;
  barcode?: string;
  sale_price?: number;
}

interface InvoiceInfo {
  numero: string;
  serie: string;
  dataEmissao: string;
  emitenteNome: string;
  emitenteCnpj: string;
  destinatarioNome: string;
  destinatarioCnpj: string;
  valorTotal: string;
}

type ImportMode = 'nota' | 'csv' | 'manual';

const UNITS = ['UN', 'KG', 'L', 'ML', 'G', 'CX', 'PC', 'PAR', 'MT'];

export default function PdvImportarNota() {
  const [mode, setMode] = useState<ImportMode>('nota');
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [products, setProducts] = useState<ExtractedProduct[]>([]);
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [editForm, setEditForm] = useState<Partial<ExtractedProduct>>({});
  const [previewText, setPreviewText] = useState<string | null>(null);
  const [invoiceInfo, setInvoiceInfo] = useState<InvoiceInfo | null>(null);
  const [saving, setSaving] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [defaultMarkup, setDefaultMarkup] = useState<number>(50); // Default 50% markup
  const [includeTaxesAndFreight, setIncludeTaxesAndFreight] = useState<boolean>(true);
  
  // Opções para gerar despesa na importação
  const [createExpense, setCreateExpense] = useState(false);
  const [expensePaymentMethod, setExpensePaymentMethod] = useState('pix');

  // Manual entry form
  const [manualForm, setManualForm] = useState<ExtractedProduct>({
    code: '', name: '', description: '', unit: 'UN', cost_price: 0, quantity: 1, barcode: '', sale_price: 0,
  });

  const isXml = (f: File) => f.type === 'text/xml' || f.name.toLowerCase().endsWith('.xml');
  const isPdf = (f: File) => f.type === 'application/pdf' || f.name.toLowerCase().endsWith('.pdf');
  const isCsv = (f: File) => f.type === 'text/csv' || f.name.toLowerCase().endsWith('.csv');

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const f = acceptedFiles[0];
    if (!f) return;
    if (mode === 'csv' && isCsv(f)) {
      setFile(f); setProducts([]); setPreviewText(null); setInvoiceInfo(null); setErrorMsg(null);
    } else if (mode === 'nota' && (isPdf(f) || isXml(f))) {
      setFile(f); setProducts([]); setPreviewText(null); setInvoiceInfo(null); setErrorMsg(null);
    } else {
      toast.error('Formato de arquivo não suportado para este modo.');
    }
  }, [mode]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: mode === 'csv'
      ? { 'text/csv': ['.csv'] }
      : { 'application/pdf': ['.pdf'], 'text/xml': ['.xml'] },
    maxFiles: 1,
    maxSize: 10 * 1024 * 1024,
  });

  // ─── Parse CSV ───
  const parseCSV = (text: string): ExtractedProduct[] => {
    const lines = text.split('\n').filter(l => l.trim());
    if (lines.length < 2) return [];
    const header = lines[0].split(',').map(h => h.trim().toLowerCase());
    const rows: ExtractedProduct[] = [];
    for (let i = 1; i < lines.length; i++) {
      const cols = lines[i].split(',');
      const get = (key: string) => {
        const idx = header.indexOf(key);
        return idx >= 0 ? cols[idx]?.trim() : undefined;
      };
      const code = get('codigo') || get('code') || get('sku') || `CSV_${i}`;
      const name = get('nome') || get('name') || get('produto') || `Produto ${i}`;
      const unit = (get('unidade') || get('unit') || 'UN').toUpperCase();
      const qty = Number(get('quantidade') || get('qty') || get('qtd') || 0);
      const cost = Number(get('custo') || get('cost_price') || get('preco_custo') || 0);
      const sale = Number(get('venda') || get('sale_price') || get('preco_venda') || cost * 1.5);
      rows.push({ code, name, description: get('descricao') || get('description') || '', unit, cost_price: cost, quantity: qty, barcode: get('barcode') || get('ean') || '', sale_price: sale });
    }
    return rows;
  };

  // ─── Process file ───
  const handleUploadAndProcess = async () => {
    if (!file) return;
    setErrorMsg(null);

    if (mode === 'csv') {
      setProcessing(true);
      try {
        const text = await file.text();
        const parsed = parseCSV(text);
        setProducts(parsed);
        if (parsed.length > 0) {
          toast.success(`${parsed.length} produto(s) importado(s) do CSV!`);
        } else {
          toast.error('Nenhum produto encontrado no CSV. Verifique o formato.');
        }
      } catch (err) {
        toast.error('Erro ao ler CSV: ' + (err instanceof Error ? err.message : 'desconhecido'));
      } finally {
        setProcessing(false);
      }
      return;
    }

    // Nota fiscal (PDF/XML)
    try {
      setUploading(true);
      const fileName = `notas/${Date.now()}_${file.name.replace(/\s+/g, '_')}`;
      const { error: uploadError } = await supabase.storage.from('invoices').upload(fileName, file, { upsert: true });
      if (uploadError) {
        setErrorMsg(`Erro no upload: ${uploadError.message}`);
        toast.error(`Erro no upload: ${uploadError.message}`);
        setUploading(false);
        return;
      }

      setUploading(false);
      setProcessing(true);

      const isXmlFile = isXml(file);

      if (isXmlFile) {
        // Leitura e extração direta e instantânea do XML da NF-e
        try {
          const xmlText = await file.text();
          const parsed = parseNfeXmlString(xmlText, defaultMarkup, includeTaxesAndFreight);
          const extracted: ExtractedProduct[] = parsed.itens.map(it => ({
            code: it.codigoFornecedor,
            name: it.descricao,
            unit: it.unidade,
            cost_price: it.custoRealUnitario,
            quantity: it.quantidade,
            barcode: it.barcode,
            sale_price: it.precoVendaSugerido,
          }));

          setProducts(extracted);
          setInvoiceInfo({
            numero: parsed.numero,
            serie: parsed.serie,
            dataEmissao: parsed.dataEmissao,
            emitenteNome: parsed.fornecedor.razaoSocial,
            emitenteCnpj: parsed.fornecedor.cnpj,
            destinatarioNome: '',
            destinatarioCnpj: '',
            valorTotal: String(parsed.totais.valorTotal),
          });
          setPreviewText(null);
          toast.success(`${extracted.length} produto(s) extraído(s) do XML com sucesso!`);
          setProcessing(false);
          return;
        } catch (xmlErr) {
          console.warn('Erro no parser local de XML, tentando fallback via Edge Function', xmlErr);
        }
      }

      const functionName = isXmlFile ? 'parse-nfe-xml' : 'extract-invoice-products';
      
      let invokeOptions: any = {};
      
      if (isXmlFile) {
        const formData = new FormData();
        formData.append('file', file);
        invokeOptions = { body: formData };
      } else {
        invokeOptions = {
          body: { 
            filePath: fileName,
            defaultMarkup,
            includeTaxesAndFreight
          } 
        };
      }

      const { data, error } = await supabase.functions.invoke(functionName, invokeOptions);

      if (error) {
        console.error("Invoke error: ", error);
        let errMsg = 'Erro desconhecido no processamento.';
        try {
          const errText = await error.context?.text?.();
          if (errText) {
            try {
              const parsed = JSON.parse(errText);
              errMsg = parsed?.message || errText;
            } catch {
              errMsg = errText;
            }
          } else {
            errMsg = error.message || errMsg;
          }
        } catch (_e) {
          errMsg = error.message || errMsg;
        }
        // Mensagem amigável específica para rate limit
        if (error.context?.status === 429 || errMsg.toLowerCase().includes('limite') || errMsg.toLowerCase().includes('rate')) {
          errMsg = '⏱️ Limite de requisições da IA atingido. Aguarde alguns segundos e clique em "Processar" novamente.';
        }
        setErrorMsg(errMsg);
        toast.error(errMsg, { duration: 8000 });
        setProcessing(false);
        return;
      }

      console.log("Invoke response data:", data);

      if (data?.code === 'SUCCESS' && Array.isArray(data.data?.products)) {
        let extracted = data.data.products as ExtractedProduct[];
        
        // Apply default markup to imported XML/PDF products if sale_price is missing or 0
        extracted = extracted.map(p => {
          const cost = Number(p.cost_price) || 0;
          let sale = Number(p.sale_price) || 0;
          if (sale === 0 && cost > 0) {
            sale = cost + (cost * (defaultMarkup / 100));
          }
          return { ...p, sale_price: Number(sale.toFixed(2)) };
        });

        setProducts(extracted);
        if (isXmlFile) {
          setInvoiceInfo(data.data.invoiceInfo as InvoiceInfo || null);
          setPreviewText(null);
        } else {
          setPreviewText(data.data.extractedTextPreview || null);
          setInvoiceInfo(null);
        }
        toast.success(`${extracted.length} produto(s) extraído(s) com sucesso!`);
      } else {
        const msg = data?.message || 'Nenhum produto encontrado no arquivo.';
        setErrorMsg(msg);
        toast.error(msg);
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Erro inesperado';
      setErrorMsg(msg);
      toast.error(msg);
    } finally {
      setUploading(false);
      setProcessing(false);
    }
  };

  // ─── Save all ───
  const handleSaveAll = async () => {
    if (products.length === 0) return;
    setErrorMsg(null);

    try {
      setSaving(true);

      // Check for existing codes
      const codes = products.map(p => p.code?.trim()).filter(Boolean) as string[];
      if (codes.length) {
        const { data: existing } = await supabase.from('pdv_products').select('code,name').in('code', codes);
        const existingMap = new Map((existing || []).map(e => [e.code, e.name]));
        if (existingMap.size > 0) {
          const dups = Array.from(existingMap.entries()).map(([c, n]) => `"${c}" (${n})`).join(', ');
          setErrorMsg(`Código(s) já existente(s): ${dups}. Edite os códigos ou use a opção de mesclar.`);
          toast.error(`Código(s) já existente(s): ${dups}`);
          setSaving(false);
          return;
        }
      }

      const inserts = products.map((p) => {
        const cost = Number(p.cost_price) || 0;
        let sale = Number(p.sale_price) || 0;
        if (sale === 0 && cost > 0) {
          sale = cost + (cost * (defaultMarkup / 100));
        }

        return {
          code: p.code?.trim() || `AUTO_${Math.random().toString(36).slice(2, 8).toUpperCase()}`,
          name: p.name?.trim() || 'Produto sem nome',
          description: p.description?.trim() || null,
          unit: (p.unit?.trim() || 'UN').toUpperCase(),
          cost_price: cost,
          sale_price: sale,
          stock_qty: Number(p.quantity) || 0,
          barcode: p.barcode?.trim() || null,
          active: true,
        };
      });

      const { error } = await supabase.from('pdv_products').insert(inserts);

      if (error) {
        if (error.message?.includes('duplicate key') || error.code === '23505') {
          setErrorMsg('Código duplicado detectado. Verifique os códigos dos produtos e tente novamente.');
          toast.error('Código duplicado detectado. Verifique os códigos dos produtos.');
        } else {
          setErrorMsg(`Erro ao salvar: ${error.message}`);
          toast.error(`Erro ao salvar: ${error.message}`);
        }
        setSaving(false);
        return;
      }

      // Se a opção de gerar despesa estiver ativa
      let fallbackAmount = 0;
      if (products.length > 0) {
        fallbackAmount = products.reduce((acc, p) => acc + ((Number(p.cost_price) || 0) * (Number(p.quantity) || 1)), 0);
      }
      const totalDespesa = invoiceInfo && Number(invoiceInfo.valorTotal) > 0 ? Number(invoiceInfo.valorTotal) : fallbackAmount;
      
      if (createExpense && totalDespesa > 0) {
        const { data: userData } = await supabase.auth.getUser();
        if (userData?.user) {
          const { error: expError } = await supabase.from('transactions').insert({
            type: 'despesa',
            category: 'Fornecedor',
            description: `Nota Fiscal Nº ${invoiceInfo?.numero || 'S/N'} - ${invoiceInfo?.emitenteNome || 'Fornecedor'} (Via Produtos)`,
            amount: totalDespesa,
            payment_method: expensePaymentMethod,
            installments: 1,
            transaction_date: new Date().toISOString().split('T')[0],
            created_by: userData.user.id
          });
          if (expError) {
            toast.error(`Aviso: Erro ao gerar despesa: ${expError.message}`);
          } else {
            toast.success('Despesa financeira gerada com sucesso.');
          }
        }
      }

      toast.success(`${inserts.length} produto(s) cadastrado(s) com sucesso!`);
      setProducts([]);
      setFile(null);
      setInvoiceInfo(null);
      setPreviewText(null);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Erro ao salvar';
      setErrorMsg(msg);
      toast.error(msg);
    } finally {
      setSaving(false);
    }
  };

  // ─── Merge duplicates: add stock to existing ───
  const handleMergeDuplicates = async () => {
    if (products.length === 0) return;
    setErrorMsg(null);

    try {
      setSaving(true);
      const codes = products.map(p => p.code?.trim()).filter(Boolean) as string[];
      if (!codes.length) { toast.error('Nenhum código válido para mesclar'); setSaving(false); return; }

      const { data: existing } = await supabase.from('pdv_products').select('id,code,name,stock_qty').in('code', codes);
      const existingMap = new Map((existing || []).map(e => [e.code, e]));

      let merged = 0;
      let inserted = 0;

      for (const p of products) {
        const code = p.code?.trim();
        if (!code) continue;
        const existingProd = existingMap.get(code);
        if (existingProd) {
          // Add stock to existing
          const newQty = (existingProd.stock_qty || 0) + (Number(p.quantity) || 0);
          await supabase.from('pdv_products').update({ stock_qty: newQty, updated_at: new Date().toISOString() }).eq('id', existingProd.id);
          merged++;
        } else {
          // Insert new
          await supabase.from('pdv_products').insert({
            code, name: p.name?.trim() || 'Produto sem nome',
            description: p.description?.trim() || null,
            unit: (p.unit?.trim() || 'UN').toUpperCase(),
            cost_price: Number(p.cost_price) || 0,
            sale_price: Number(p.sale_price) || Number(p.cost_price) * 1.5 || 0,
            stock_qty: Number(p.quantity) || 0,
            barcode: p.barcode?.trim() || null,
            active: true,
          });
          inserted++;
        }
      }

      // Se a opção de gerar despesa estiver ativa
      let fallbackAmount = 0;
      if (products.length > 0) {
        fallbackAmount = products.reduce((acc, p) => acc + ((Number(p.cost_price) || 0) * (Number(p.quantity) || 1)), 0);
      }
      const totalDespesa = invoiceInfo && Number(invoiceInfo.valorTotal) > 0 ? Number(invoiceInfo.valorTotal) : fallbackAmount;

      if (createExpense && totalDespesa > 0) {
        const { data: userData } = await supabase.auth.getUser();
        if (userData?.user) {
          const { error: expError } = await supabase.from('transactions').insert({
            type: 'despesa',
            category: 'Fornecedor',
            description: `Nota Fiscal Nº ${invoiceInfo?.numero || 'S/N'} - ${invoiceInfo?.emitenteNome || 'Fornecedor'} (Mescla)`,
            amount: totalDespesa,
            payment_method: expensePaymentMethod,
            installments: 1,
            transaction_date: new Date().toISOString().split('T')[0],
            created_by: userData.user.id
          });
          if (expError) {
            toast.error(`Aviso: Erro ao gerar despesa: ${expError.message}`);
          }
        }
      }

      toast.success(`${inserted} novo(s) + ${merged} mesclado(s) com sucesso!`);
      setProducts([]);
      setFile(null);
      setInvoiceInfo(null);
      setPreviewText(null);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Erro ao mesclar';
      setErrorMsg(msg);
      toast.error(msg);
    } finally {
      setSaving(false);
    }
  };

  // ─── Manual add ───
  const handleManualAdd = () => {
    if (!manualForm.code.trim() || !manualForm.name.trim()) {
      toast.error('Preencha código e nome'); return;
    }
    setProducts(prev => [...prev, { ...manualForm }]);
    setManualForm({ code: '', name: '', description: '', unit: 'UN', cost_price: 0, quantity: 1, barcode: '', sale_price: 0 });
    toast.success('Produto adicionado à lista');
  };

  const openEdit = (index: number) => {
    setEditingIndex(index);
    setEditForm({ ...products[index] });
  };

  const saveEdit = () => {
    if (editingIndex === null) return;
    setProducts((prev) => {
      const next = [...prev];
      next[editingIndex] = { ...next[editingIndex], ...editForm } as ExtractedProduct;
      return next;
    });
    setEditingIndex(null);
    toast.success('Produto atualizado');
  };

  const removeProduct = (index: number) => {
    setProducts((prev) => prev.filter((_, i) => i !== index));
  };

  const formatCurrency = (val: number) =>
    new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val || 0);

  const hasDuplicates = products.length > new Set(products.map(p => p.code?.trim())).size;

  return (
    <PdvLayout title="Importar Produtos">
      <div className="space-y-6 max-w-6xl mx-auto">
        {/* Banner de Direcionamento para Entrada de Mercadorias */}
        <div className="bg-primary/10 border border-primary/20 rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-primary text-primary-foreground rounded-lg shrink-0">
              <Receipt className="h-5 w-5" />
            </div>
            <div>
              <p className="text-sm font-semibold text-foreground">
                Deseja dar entrada no estoque e atualizar custos existentes por NF-e?
              </p>
              <p className="text-xs text-muted-foreground">
                Utilize o módulo de Entrada de Mercadorias com conferência de itens, cálculo de markup e geração de contas a pagar.
              </p>
            </div>
          </div>
          <Button asChild size="sm" variant="default" className="shrink-0 w-full sm:w-auto">
            <Link to="/pdv/entrada-mercadorias">
              Ir para Entrada de Mercadorias
              <ArrowRight className="h-4 w-4 ml-1.5" />
            </Link>
          </Button>
        </div>

        {/* Mode selector */}
        <Card>
          <CardHeader>
            <CardTitle className="text-balance">Importar Produtos</CardTitle>
            <CardDescription className="text-pretty">
              Escolha como deseja importar os produtos para o sistema.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <button
                type="button"
                onClick={() => { setMode('nota'); setFile(null); setProducts([]); setErrorMsg(null); }}
                className={`flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-colors ${mode === 'nota' ? 'border-primary bg-primary/5 text-primary' : 'border-border hover:border-primary/30'}`}
              >
                <FileText className="h-6 w-6" />
                <span className="text-sm font-semibold">Nota Fiscal (PDF/XML)</span>
                <span className="text-xs text-muted-foreground text-center">Extrai automaticamente</span>
              </button>
              <button
                type="button"
                onClick={() => { setMode('csv'); setFile(null); setProducts([]); setErrorMsg(null); }}
                className={`flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-colors ${mode === 'csv' ? 'border-primary bg-primary/5 text-primary' : 'border-border hover:border-primary/30'}`}
              >
                <TableIcon className="h-6 w-6" />
                <span className="text-sm font-semibold">Planilha CSV</span>
                <span className="text-xs text-muted-foreground text-center">Importe de arquivo CSV</span>
              </button>
              <button
                type="button"
                onClick={() => { setMode('manual'); setFile(null); setProducts([]); setErrorMsg(null); }}
                className={`flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-colors ${mode === 'manual' ? 'border-primary bg-primary/5 text-primary' : 'border-border hover:border-primary/30'}`}
              >
                <Plus className="h-6 w-6" />
                <span className="text-sm font-semibold">Cadastro Manual</span>
                <span className="text-xs text-muted-foreground text-center">Adicione um por um</span>
              </button>
            </div>
          </CardContent>
        </Card>

        {/* Error banner */}
        {errorMsg && (
          <div className="flex items-start gap-2 p-4 rounded-xl bg-destructive/10 border border-destructive/20 text-destructive text-sm">
            <AlertTriangle className="h-5 w-5 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold">Erro na importação</p>
              <p className="text-pretty">{errorMsg}</p>
            </div>
            <Button variant="ghost" size="icon" className="h-6 w-6 ml-auto shrink-0" onClick={() => setErrorMsg(null)}>
              <X className="h-3 w-3" />
            </Button>
          </div>
        )}

        {/* Upload / Manual area */}
        {mode !== 'manual' ? (
          <Card>
            <CardHeader>
              <CardTitle className="text-balance text-lg">
                {mode === 'nota' ? 'Importar via Nota Fiscal' : 'Importar via CSV'}
              </CardTitle>
              <CardDescription className="text-pretty">
                {mode === 'nota'
                  ? 'Faça upload do PDF (processado com IA) ou do XML da nota fiscal para extrair os produtos automaticamente.'
                  : 'Colunas esperadas: codigo, nome, unidade, quantidade, custo, venda, barcode (opcional).'}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div
                {...getRootProps()}
                className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-colors ${
                  isDragActive ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/50'
                }`}
              >
                <input {...getInputProps()} />
                <FileUp className="h-10 w-10 mx-auto mb-3 text-muted-foreground" />
                <p className="text-sm font-medium text-foreground">
                  {isDragActive ? 'Solte o arquivo aqui' : mode === 'nota' ? 'Arraste e solte o PDF ou XML da nota fiscal aqui' : 'Arraste e solte o arquivo CSV aqui'}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  Ou clique para selecionar · {mode === 'nota' ? 'PDF (IA) ou XML (direto)' : 'CSV'} · Máx. 10MB
                </p>
              </div>

              {file && (
                <div className="flex items-center gap-3 p-3 rounded-lg bg-muted">
                  <FileText className="h-5 w-5 text-primary shrink-0" />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-medium truncate">{file.name}</p>
                      <Badge variant="secondary" className="text-[10px] shrink-0">
                        {isXml(file) ? 'XML' : isCsv(file) ? 'CSV' : 'PDF'}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">{(file.size / 1024 / 1024).toFixed(2)} MB</p>
                  </div>
                  <Button variant="ghost" size="icon" onClick={() => { setFile(null); setProducts([]); setInvoiceInfo(null); setPreviewText(null); setErrorMsg(null); }}>
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              )}

              {mode === 'nota' && file && (
                <div className="flex flex-col md:flex-row gap-4">
                  <div className="flex-1 p-3 rounded-lg border border-border flex items-center justify-between gap-4">
                    <div className="flex-1">
                      <Label className="text-sm font-medium">Incluir Frete e Impostos no Custo</Label>
                      <p className="text-xs text-muted-foreground leading-tight mt-0.5">Rateia frete, IPI, ICMS-ST e abate descontos do custo final do produto</p>
                    </div>
                    <Switch 
                      checked={includeTaxesAndFreight} 
                      onCheckedChange={setIncludeTaxesAndFreight} 
                    />
                  </div>
                  <div className="p-3 rounded-lg border border-border flex items-center gap-4 md:w-64">
                    <div className="flex-1">
                      <Label className="text-sm font-medium">Markup Padrão</Label>
                      <p className="text-xs text-muted-foreground">Margem de lucro</p>
                    </div>
                    <div className="w-20 relative">
                      <Input 
                        type="number" 
                        min="0"
                        value={defaultMarkup} 
                        onChange={e => setDefaultMarkup(Number(e.target.value))} 
                        className="pr-6 text-right h-8"
                      />
                      <span className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground text-xs">%</span>
                    </div>
                  </div>
                </div>
              )}

              <Button
                onClick={handleUploadAndProcess}
                disabled={!file || uploading || processing}
                className="w-full md:w-auto"
              >
                {uploading ? (
                  <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Enviando...</>
                ) : processing ? (
                  <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Processando...</>
                ) : (
                  <><Upload className="h-4 w-4 mr-2" /> {mode === 'nota' ? 'Extrair Produtos' : 'Importar CSV'}</>
                )}
              </Button>

              {previewText && (
                <div className="p-3 rounded-lg bg-muted text-xs text-muted-foreground">
                  <p className="font-medium mb-1 flex items-center gap-1"><Eye className="h-3 w-3" /> Prévia do texto extraído:</p>
                  <p className="line-clamp-3">{previewText}...</p>
                </div>
              )}

              {invoiceInfo && (
                <div className="p-4 rounded-lg bg-muted space-y-1 text-sm">
                  <p className="font-medium text-foreground flex items-center gap-1"><FileText className="h-3 w-3" /> Dados da Nota Fiscal</p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-2 text-muted-foreground text-xs mt-2">
                    <p><span className="font-medium text-foreground">Nº:</span> {invoiceInfo.numero} · Série: {invoiceInfo.serie}</p>
                    <p><span className="font-medium text-foreground">Emissão:</span> {invoiceInfo.dataEmissao ? new Date(invoiceInfo.dataEmissao).toLocaleString('pt-BR') : '—'}</p>
                    <p className="truncate" title={invoiceInfo.emitenteNome}><span className="font-medium text-foreground">Emitente:</span> {invoiceInfo.emitenteNome || '—'} {invoiceInfo.emitenteCnpj ? `(${invoiceInfo.emitenteCnpj})` : ''}</p>
                    <p className="truncate" title={invoiceInfo.destinatarioNome}><span className="font-medium text-foreground">Destinatário:</span> {invoiceInfo.destinatarioNome || '—'} {invoiceInfo.destinatarioCnpj ? `(${invoiceInfo.destinatarioCnpj})` : ''}</p>
                    <p className="sm:col-span-2"><span className="font-medium text-foreground">Valor Total:</span> {invoiceInfo.valorTotal ? new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(Number(invoiceInfo.valorTotal)) : '—'}</p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        ) : (
          /* Manual entry */
          <Card>
            <CardHeader>
              <CardTitle className="text-balance text-lg">Cadastro Manual</CardTitle>
              <CardDescription className="text-pretty">Adicione produtos individualmente à lista de importação.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                <div>
                  <Label className="text-sm font-normal">Código *</Label>
                  <Input value={manualForm.code} onChange={e => setManualForm(p => ({ ...p, code: e.target.value }))} placeholder="Ex: PROD001" />
                </div>
                <div className="sm:col-span-2 md:col-span-2">
                  <Label className="text-sm font-normal">Nome *</Label>
                  <Input value={manualForm.name} onChange={e => setManualForm(p => ({ ...p, name: e.target.value }))} placeholder="Nome do produto" />
                </div>
                <div className="sm:col-span-2 md:col-span-3">
                  <Label className="text-sm font-normal">Descrição</Label>
                  <Input value={manualForm.description} onChange={e => setManualForm(p => ({ ...p, description: e.target.value }))} placeholder="Descrição opcional" />
                </div>
                <div>
                  <Label className="text-sm font-normal">Unidade</Label>
                  <select value={manualForm.unit} onChange={e => setManualForm(p => ({ ...p, unit: e.target.value }))} className="w-full h-9 rounded-md border border-input bg-background px-3 py-1 text-sm">
                    {UNITS.map(u => <option key={u} value={u}>{u}</option>)}
                  </select>
                </div>
                <div>
                  <Label className="text-sm font-normal">Quantidade</Label>
                  <Input type="number" min="0" value={manualForm.quantity} onChange={e => setManualForm(p => ({ ...p, quantity: Number(e.target.value) }))} />
                </div>
                <div>
                  <Label className="text-sm font-normal">Preço de Custo (R$)</Label>
                  <Input type="number" step="0.01" min="0" value={manualForm.cost_price} onChange={e => setManualForm(p => ({ ...p, cost_price: Number(e.target.value) }))} />
                </div>
                <div>
                  <Label className="text-sm font-normal">Preço de Venda (R$)</Label>
                  <Input type="number" step="0.01" min="0" value={manualForm.sale_price} onChange={e => setManualForm(p => ({ ...p, sale_price: Number(e.target.value) }))} />
                </div>
                <div className="sm:col-span-2 md:col-span-2">
                  <Label className="text-sm font-normal">Código de Barras</Label>
                  <Input value={manualForm.barcode} onChange={e => setManualForm(p => ({ ...p, barcode: e.target.value }))} placeholder="EAN / Código de barras" />
                </div>
              </div>
              <Button onClick={handleManualAdd} className="w-full md:w-auto">
                <Plus className="h-4 w-4 mr-2" /> Adicionar à Lista
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Products Review Table */}
        {products.length > 0 && (
          <Card>
            <CardHeader className="flex flex-col md:flex-row md:items-center md:justify-between gap-2">
              <div>
                <CardTitle className="text-balance">Produtos para Importar</CardTitle>
                <CardDescription className="text-pretty">
                  Revise e edite os produtos antes de cadastrar no sistema.
                </CardDescription>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs text-muted-foreground">{products.length} produto(s)</span>
                {hasDuplicates && <Badge variant="destructive" className="text-[10px]">Códigos duplicados na lista</Badge>}
              </div>
            </CardHeader>
            <CardContent>
              <div className="w-full max-w-full overflow-x-auto bg-card">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="whitespace-nowrap">Código</TableHead>
                      <TableHead className="whitespace-nowrap">Nome</TableHead>
                      <TableHead className="whitespace-nowrap">UN</TableHead>
                      <TableHead className="whitespace-nowrap">Qtd</TableHead>
                      <TableHead className="whitespace-nowrap">Custo</TableHead>
                      <TableHead className="whitespace-nowrap">Venda Sug.</TableHead>
                      <TableHead className="whitespace-nowrap">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {products.map((p, idx) => (
                      <TableRow key={idx}>
                        <TableCell className="whitespace-nowrap font-mono text-xs">{p.code}</TableCell>
                        <TableCell className="whitespace-nowrap max-w-[200px] truncate" title={p.name}>{p.name}</TableCell>
                        <TableCell className="whitespace-nowrap">{p.unit || 'UN'}</TableCell>
                        <TableCell className="whitespace-nowrap">{p.quantity}</TableCell>
                        <TableCell className="whitespace-nowrap">{formatCurrency(p.cost_price)}</TableCell>
                        <TableCell className="whitespace-nowrap">{formatCurrency(p.sale_price || p.cost_price * 1.5)}</TableCell>
                        <TableCell className="whitespace-nowrap">
                          <div className="flex items-center gap-1">
                            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(idx)} title="Editar">
                              <Pencil className="h-3.5 w-3.5" />
                            </Button>
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive" onClick={() => removeProduct(idx)} title="Excluir lançamento">
                              <Trash2 className="h-3.5 w-3.5" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              <div className="mt-6 border border-border rounded-lg p-4 bg-muted/30">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <h3 className="text-sm font-semibold text-foreground">Lançar no Financeiro</h3>
                    <p className="text-xs text-muted-foreground mt-1">
                      Gerar uma despesa no valor de {formatCurrency(invoiceInfo && Number(invoiceInfo.valorTotal) > 0 ? Number(invoiceInfo.valorTotal) : products.reduce((acc, p) => acc + ((Number(p.cost_price) || 0) * (Number(p.quantity) || 1)), 0))} automaticamente.
                    </p>
                  </div>
                  <div className="flex sm:shrink-0 justify-start sm:justify-end">
                    <Switch
                      checked={createExpense}
                      onCheckedChange={setCreateExpense}
                    />
                  </div>
                </div>

                {createExpense && (
                  <div className="mt-4 pt-4 border-t border-border">
                    <Label className="text-sm font-normal text-muted-foreground mb-2 block">Forma de Pagamento da Despesa</Label>
                    <Select value={expensePaymentMethod} onValueChange={setExpensePaymentMethod}>
                      <SelectTrigger className="w-full sm:w-[250px] bg-background">
                        <SelectValue placeholder="Forma de Pagamento" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pix">PIX</SelectItem>
                        <SelectItem value="dinheiro">Dinheiro</SelectItem>
                        <SelectItem value="cartao_credito">Cartão de Crédito</SelectItem>
                        <SelectItem value="cartao_debito">Cartão de Débito</SelectItem>
                        <SelectItem value="boleto">Boleto Bancário</SelectItem>
                        <SelectItem value="transferencia">Transferência Bancária</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </div>

              <div className="flex flex-col md:flex-row items-stretch md:items-center gap-3 mt-4">
                <Button
                  variant="default"
                  onClick={handleSaveAll}
                  disabled={saving}
                  className="w-full flex-1 md:w-auto"
                >
                  {saving ? (
                    <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Salvando...</>
                  ) : (
                    <><Check className="h-4 w-4 mr-2" /> Cadastrar {products.length} Produto(s)</>
                  )}
                </Button>
                <Button
                  variant="outline"
                  onClick={handleMergeDuplicates}
                  disabled={saving}
                  className="w-full flex-1 md:w-auto"
                  title="Novos são inseridos; existentes têm estoque somado"
                >
                  <Merge className="h-4 w-4 mr-2 shrink-0" /> Mesclar (somar estoque)
                </Button>
                <Button variant="outline" onClick={() => { setProducts([]); setFile(null); setInvoiceInfo(null); setPreviewText(null); setErrorMsg(null); }} className="w-full md:w-auto">
                  Limpar
                </Button>
              </div>

              {products.some((p) => !p.name || !p.code) && (
                <div className="mt-3 flex items-start gap-2 p-3 rounded-lg bg-warning/10 text-warning text-sm border border-warning/20">
                  <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5" />
                  <p>Alguns produtos estão com campos incompletos. Revise antes de salvar.</p>
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>

      {/* Edit Dialog */}
      <Dialog open={editingIndex !== null} onOpenChange={(open) => !open && setEditingIndex(null)}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-balance">Editar Produto</DialogTitle>
            <DialogDescription className="text-pretty">Ajuste os dados do produto antes de cadastrar.</DialogDescription>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div>
              <Label className="text-sm font-normal">Código</Label>
              <Input value={editForm.code || ''} onChange={(e) => setEditForm({ ...editForm, code: e.target.value })} />
            </div>
            <div>
              <Label className="text-sm font-normal">Nome</Label>
              <Input value={editForm.name || ''} onChange={(e) => setEditForm({ ...editForm, name: e.target.value })} />
            </div>
            <div>
              <Label className="text-sm font-normal">Descrição</Label>
              <Input value={editForm.description || ''} onChange={(e) => setEditForm({ ...editForm, description: e.target.value })} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-sm font-normal">Unidade</Label>
                <Input value={editForm.unit || 'UN'} onChange={(e) => setEditForm({ ...editForm, unit: e.target.value })} />
              </div>
              <div>
                <Label className="text-sm font-normal">Quantidade</Label>
                <Input type="number" value={editForm.quantity || 0} onChange={(e) => setEditForm({ ...editForm, quantity: Number(e.target.value) })} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-sm font-normal">Preço de Custo</Label>
                <Input type="number" step="0.01" value={editForm.cost_price || 0} onChange={(e) => setEditForm({ ...editForm, cost_price: Number(e.target.value) })} />
              </div>
              <div>
                <Label className="text-sm font-normal">Preço de Venda</Label>
                <Input type="number" step="0.01" value={editForm.sale_price || 0} onChange={(e) => setEditForm({ ...editForm, sale_price: Number(e.target.value) })} />
              </div>
            </div>
            <div>
              <Label className="text-sm font-normal">Código de Barras</Label>
              <Input value={editForm.barcode || ''} onChange={(e) => setEditForm({ ...editForm, barcode: e.target.value })} />
            </div>
          </div>
          <div className="flex justify-end gap-2 mt-2">
            <Button variant="outline" onClick={() => setEditingIndex(null)}>Cancelar</Button>
            <Button onClick={saveEdit}>Salvar</Button>
          </div>
        </DialogContent>
      </Dialog>
    </PdvLayout>
  );
}
