import { useEffect, useState } from 'react';
import { Plus, Users, Gift, CheckCircle, Clock, XCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { PdvLayout } from '@/components/layouts/PdvLayout';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';

interface Referral {
  id: string; referrer_id: string; referred_id: string;
  bonus_type: string; bonus_value: number;
  status: 'pendente' | 'confirmado' | 'cancelado'; created_at: string;
  referrer?: { name: string } | null;
  referred?: { name: string } | null;
}

const STATUS_INFO = {
  pendente: { label: 'Pendente', icon: Clock, cls: 'text-warning bg-warning/10 border-warning/30' },
  confirmado: { label: 'Confirmado', icon: CheckCircle, cls: 'text-success bg-success/10 border-success/30' },
  cancelado: { label: 'Cancelado', icon: XCircle, cls: 'text-muted-foreground bg-muted/40 border-border' },
};

const BONUS_LABELS: Record<string, string> = { pontos: 'Pontos', desconto: 'Desconto (R$)', credito: 'Crédito (R$)' };

export default function PdvIndicacoes() {
  const [referrals, setReferrals] = useState<Referral[]>([]);
  const [customers, setCustomers] = useState<{ id: string; name: string }[]>([]);
  const [loading, setLoading] = useState(true);
  const [showDialog, setShowDialog] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ referrer_id: '', referred_id: '', bonus_type: 'pontos', bonus_value: '50' });

  useEffect(() => { load(); loadCustomers(); }, []);

  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from('referrals')
      .select('*, referrer:referrer_id(name), referred:referred_id(name)')
      .order('created_at', { ascending: false });
    setReferrals((data as Referral[]) || []);
    setLoading(false);
  };

  const loadCustomers = async () => {
    const { data } = await supabase.from('customers').select('id,name').order('name');
    setCustomers(data || []);
  };

  const handleSave = async () => {
    if (!form.referrer_id || !form.referred_id) { toast.error('Selecione os dois clientes'); return; }
    if (form.referrer_id === form.referred_id) { toast.error('O indicador e indicado devem ser diferentes'); return; }
    const val = parseFloat(form.bonus_value);
    if (!val || val <= 0) { toast.error('Informe o valor do bônus'); return; }
    setSaving(true);
    const { error } = await supabase.from('referrals').insert({
      referrer_id: form.referrer_id, referred_id: form.referred_id,
      bonus_type: form.bonus_type, bonus_value: val, status: 'pendente',
    });
    setSaving(false);
    if (error) { toast.error('Erro: ' + error.message); return; }
    toast.success('Indicação registrada!');
    setShowDialog(false);
    setForm({ referrer_id: '', referred_id: '', bonus_type: 'pontos', bonus_value: '50' });
    load();
  };

  const updateStatus = async (id: string, status: string) => {
    const { error } = await supabase.from('referrals').update({ status }).eq('id', id);
    if (error) { toast.error('Erro ao atualizar'); return; }
    if (status === 'confirmado') {
      // Award bonus
      const ref = referrals.find(r => r.id === id);
      if (ref && ref.bonus_type === 'pontos') {
        const { data: cust } = await supabase.from('customers').select('loyalty_points').eq('id', ref.referrer_id).single();
        if (cust) {
          const newPts = cust.loyalty_points + ref.bonus_value;
          await supabase.from('customers').update({ loyalty_points: newPts }).eq('id', ref.referrer_id);
          await supabase.from('loyalty_transactions').insert({ customer_id: ref.referrer_id, type: 'bonus_indicacao', points: ref.bonus_value, balance_after: newPts, description: 'Bônus por indicação' });
        }
      }
      toast.success('Indicação confirmada e bônus concedido!');
    } else {
      toast.success('Status atualizado!');
    }
    load();
  };

  const ff = (k: string, v: string) => setForm(p => ({ ...p, [k]: v }));

  const totalConfirmed = referrals.filter(r => r.status === 'confirmado').length;
  const totalPending = referrals.filter(r => r.status === 'pendente').length;
  const totalBonus = referrals.filter(r => r.status === 'confirmado').reduce((s, r) => s + r.bonus_value, 0);

  return (
    <PdvLayout title="Programa de Indicação" actions={
      <Button size="sm" onClick={() => setShowDialog(true)}>
        <Plus className="h-4 w-4 mr-1.5" />Registrar Indicação
      </Button>
    }>
      <div className="space-y-4">
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {[
            { label: 'Confirmadas', val: totalConfirmed, cls: 'text-success', icon: CheckCircle },
            { label: 'Pendentes', val: totalPending, cls: 'text-warning', icon: Clock },
            { label: 'Bônus Concedidos', val: totalBonus, cls: 'text-primary', icon: Gift },
          ].map((k, i) => (
            <div key={i} className="bg-card border border-border rounded-lg p-4">
              <div className="flex items-center gap-2 mb-1"><k.icon className={`h-4 w-4 ${k.cls}`} /><p className="text-xs text-muted-foreground">{k.label}</p></div>
              <p className="text-xl font-bold text-foreground">{typeof k.val === 'number' && k.val > 999 ? `R$ ${k.val.toFixed(0)}` : k.val}</p>
            </div>
          ))}
        </div>

        <div className="bg-card border border-border rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead><tr className="border-b border-border bg-muted/40">
                <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Data</th>
                <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Indicador</th>
                <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Indicado</th>
                <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Tipo Bônus</th>
                <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Valor</th>
                <th className="text-center px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Status</th>
                <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Ação</th>
              </tr></thead>
              <tbody className="divide-y divide-border">
                {loading ? Array.from({ length: 4 }).map((_, i) => <tr key={i}><td colSpan={7} className="px-4 py-3"><Skeleton className="h-5 w-full bg-muted" /></td></tr>)
                  : referrals.length === 0 ? (
                    <tr><td colSpan={7} className="text-center py-12 text-muted-foreground">
                      <Users className="h-8 w-8 mx-auto mb-2 opacity-40" />
                      <p className="text-pretty">Nenhuma indicação registrada</p>
                    </td></tr>
                  ) : referrals.map(r => {
                    const si = STATUS_INFO[r.status];
                    return (
                      <tr key={r.id} className="hover:bg-muted/30">
                        <td className="px-4 py-3 whitespace-nowrap text-muted-foreground">{new Date(r.created_at).toLocaleDateString('pt-BR')}</td>
                        <td className="px-4 py-3 font-medium whitespace-nowrap">{(r.referrer as { name: string } | null)?.name || '—'}</td>
                        <td className="px-4 py-3 whitespace-nowrap">{(r.referred as { name: string } | null)?.name || '—'}</td>
                        <td className="px-4 py-3 text-muted-foreground whitespace-nowrap">{BONUS_LABELS[r.bonus_type] || r.bonus_type}</td>
                        <td className="px-4 py-3 text-right font-medium whitespace-nowrap">{r.bonus_type === 'pontos' ? `${r.bonus_value} pts` : `R$ ${r.bonus_value.toFixed(2)}`}</td>
                        <td className="px-4 py-3 text-center whitespace-nowrap">
                          <span className={`inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full border ${si.cls}`}>
                            <si.icon className="h-3 w-3" />{si.label}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-right whitespace-nowrap">
                          {r.status === 'pendente' && (
                            <div className="flex justify-end gap-1">
                              <Button size="sm" variant="outline" className="h-7 text-xs bg-success/10 text-success border-success/30 hover:bg-success/20" onClick={() => updateStatus(r.id, 'confirmado')}>Confirmar</Button>
                              <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => updateStatus(r.id, 'cancelado')}>Cancelar</Button>
                            </div>
                          )}
                        </td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-sm">
          <DialogHeader><DialogTitle className="text-balance">Registrar Indicação</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Indicador (quem indicou) *</Label>
              <Select value={form.referrer_id || 'none'} onValueChange={v => ff('referrer_id', v === 'none' ? '' : v)}>
                <SelectTrigger><SelectValue placeholder="Selecione..." /></SelectTrigger>
                <SelectContent>{customers.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Indicado (novo cliente) *</Label>
              <Select value={form.referred_id || 'none'} onValueChange={v => ff('referred_id', v === 'none' ? '' : v)}>
                <SelectTrigger><SelectValue placeholder="Selecione..." /></SelectTrigger>
                <SelectContent>{customers.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">Tipo de Bônus</Label>
                <Select value={form.bonus_type} onValueChange={v => ff('bonus_type', v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="pontos">Pontos</SelectItem><SelectItem value="desconto">Desconto R$</SelectItem><SelectItem value="credito">Crédito R$</SelectItem></SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">Valor do Bônus</Label>
                <Input type="number" min="1" value={form.bonus_value} onChange={e => ff('bonus_value', e.target.value)} />
              </div>
            </div>
          </div>
          <DialogFooter className="gap-2"><Button variant="outline" onClick={() => setShowDialog(false)}>Cancelar</Button><Button onClick={handleSave} disabled={saving}>Registrar</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </PdvLayout>
  );
}
