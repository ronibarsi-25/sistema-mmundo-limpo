import { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Droplets, Eye, EyeOff, Loader2, Lock, User, ShieldAlert, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useAuth } from '@/contexts/AuthContext';
import { useLoginRateLimit } from '@/hooks/useLoginRateLimit';
import { toast } from 'sonner';

export default function PdvLoginPage() {
  const { signInWithUsername } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const from = (location.state as { from?: string })?.from || '/pdv';
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);

  const {
    isLocked, lockoutLabel, attemptsLeft, maxAttempts,
    recordFailure, recordSuccess,
  } = useLoginRateLimit(username.trim() || 'pdv');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isLocked) return;
    if (!username.trim() || !password) {
      toast.error('Preencha todos os campos');
      return;
    }
    setLoading(true);
    const { error } = await signInWithUsername(username.trim(), password);
    setLoading(false);
    if (error) {
      const left = recordFailure();
      if (left >= maxAttempts) {
        toast.error('Conta bloqueada por 5 minutos após múltiplas tentativas.');
      } else {
        toast.error(`Usuário ou senha incorretos. ${maxAttempts - left} tentativa(s) restante(s).`);
      }
      return;
    }
    recordSuccess();
    toast.success('Login realizado com sucesso!');
    navigate(from, { replace: true });
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4 py-10">
      <div className="w-full max-w-sm">
        {/* Logo */}
        <div className="flex flex-col items-center gap-3 mb-8">
          <div className="h-14 w-14 rounded-2xl bg-primary flex items-center justify-center shadow-md">
            <Droplets className="h-7 w-7 text-primary-foreground" />
          </div>
          <div className="text-center">
            <h1 className="text-2xl font-bold text-foreground text-balance">Mundo Limpo</h1>
            <p className="text-sm text-muted-foreground">Sistema de Ponto de Venda</p>
          </div>
        </div>

        <div className="bg-card border border-border rounded-xl shadow-sm p-6 md:p-8">
          <h2 className="text-base font-semibold text-foreground mb-5">Acesso ao PDV</h2>

          {/* Alerta de bloqueio */}
          {isLocked && (
            <Alert variant="destructive" className="mb-4 py-3">
              <ShieldAlert className="h-4 w-4" />
              <AlertDescription className="text-xs">
                Acesso temporariamente bloqueado. Tente novamente em <strong>{lockoutLabel}</strong>.
              </AlertDescription>
            </Alert>
          )}

          {/* Aviso de tentativas restantes */}
          {!isLocked && attemptsLeft < maxAttempts && attemptsLeft > 0 && (
            <Alert className="mb-4 py-3 border-warning/40 bg-warning/10">
              <AlertTriangle className="h-4 w-4 text-warning" />
              <AlertDescription className="text-xs text-warning">
                {attemptsLeft} tentativa(s) restante(s) antes do bloqueio.
              </AlertDescription>
            </Alert>
          )}

          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="username" className="text-sm font-normal">Usuário</Label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  id="username"
                  type="text"
                  placeholder="Digite seu usuário"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="pl-9"
                  autoComplete="username"
                  disabled={isLocked}
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="password" className="text-sm font-normal">Senha</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  id="password"
                  type={showPass ? 'text' : 'password'}
                  placeholder="Digite sua senha"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="pl-9 pr-10"
                  autoComplete="current-password"
                  disabled={isLocked}
                />
                <button
                  type="button"
                  onClick={() => setShowPass(!showPass)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  disabled={isLocked}
                >
                  {showPass ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>
            <Button type="submit" className="w-full" disabled={loading || isLocked}>
              {loading
                ? <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                : isLocked
                  ? <ShieldAlert className="h-4 w-4 mr-2" />
                  : null}
              {isLocked ? `Bloqueado por ${lockoutLabel}` : 'Entrar'}
            </Button>
          </form>
        </div>

        <p className="text-center text-xs text-muted-foreground mt-6">
          © {new Date().getFullYear()} Mundo Limpo — Sistema PDV
        </p>
      </div>
    </div>
  );
}
