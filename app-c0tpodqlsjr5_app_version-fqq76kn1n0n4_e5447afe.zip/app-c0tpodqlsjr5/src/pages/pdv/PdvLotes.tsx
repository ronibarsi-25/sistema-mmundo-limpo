import { useEffect, useState } from 'react';
import { Plus, Trash2, Package, AlertTriangle, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { PdvLayout } from '@/components/layouts/PdvLayout';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';

interface ProductBatch {
  id: string; product_id: string; batch_number: string;
  manufacturing_date: string | null; expiry_date: string | null;
  initial_qty: number; current_qty: number; cost_price: number; notes: string | null;
  pdv_products?: { name: string; code: string } | null;
}

const empty = () => ({
  product_id: '', batch_number: '', manufacturing_date: '', expiry_date: '',
  initial_qty: 0, current_qty: 0, cost_price: 0, notes: '',
});

const today = new Date().toISOString().split('T')[0];
const in30 = new Date(Date.now() + 30 * 86400000).toISOString().split('T')[0];

function expiryStatus(d: string | null) {
  if (!d) return null;
  if (d < today) return 'vencido';
  if (d <= in30) return 'vencendo';
  return 'ok';
}

export default function PdvLotes() {
  const [batches, setBatches] = useState<ProductBatch[]>([]);
  const [products, setProducts] = useState<{ id: string; name: string; code: string }[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showDialog, setShowDialog] = useState(false);
  const [form, setForm] = useState(empty());
  const [saving, setSaving] = useState(false);
  const [activeTab, setActiveTab] = useState('todos');

  useEffect(() => { load(); loadProducts(); }, []);

  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from('product_batches')
      .select('*, pdv_products(name,code)')
      .order('expiry_date', { ascending: true });
    setBatches((data as ProductBatch[]) || []);
    setLoading(false);
  };

  const loadProducts = async () => {
    const { data } = await supabase.from('pdv_products').select('id,name,code').order('name');
    setProducts(data || []);
  };

  const handleSave = async () => {
    if (!form.product_id) { toast.error('Selecione o produto'); return; }
    if (!form.batch_number.trim()) { toast.error('Informe o número do lote'); return; }
    setSaving(true);
    const payload = {
      product_id: form.product_id, batch_number: form.batch_number.trim(),
      manufacturing_date: form.manufacturing_date || null, expiry_date: form.expiry_date || null,
      initial_qty: form.initial_qty, current_qty: form.current_qty,
      cost_price: form.cost_price, notes: form.notes || null,
    };
    const { error } = await supabase.from('product_batches').insert(payload);
    setSaving(false);
    if (error) { toast.error('Erro: ' + error.message); return; }
    toast.success('Lote cadastrado!');
    setShowDialog(false);
    setForm(empty());
    load();
  };

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from('product_batches').delete().eq('id', id);
    if (error) { toast.error('Erro ao excluir'); return; }
    toast.success('Lote excluído!');
    setBatches(b => b.filter(x => x.id !== id));
  };

  const f = (k: string, v: string | number) => setForm(p => ({ ...p, [k]: v }));

  const filtered = batches.filter(b => {
    const term = search.toLowerCase();
    const matchSearch = b.batch_number.toLowerCase().includes(term) || (b.pdv_products?.name || '').toLowerCase().includes(term);
    if (!matchSearch) return false;
    if (activeTab === 'vencidos') return expiryStatus(b.expiry_date) === 'vencido';
    if (activeTab === 'vencendo') return expiryStatus(b.expiry_date) === 'vencendo';
    if (activeTab === 'sem_validade') return !b.expiry_date;
    return true;
  });

  const vencidosCount = batches.filter(b => expiryStatus(b.expiry_date) === 'vencido').length;
  const vencendoCount = batches.filter(b => expiryStatus(b.expiry_date) === 'vencendo').length;

  return (
    <PdvLayout title="Controle de Lotes e Validade" actions={
      <Button size="sm" onClick={() => { setForm(empty()); setShowDialog(true); }}>
        <Plus className="h-4 w-4 mr-1.5" />Novo Lote
      </Button>
    }>
      <div className="space-y-4">
        {(vencidosCount > 0 || vencendoCount > 0) && (
          <div className={`flex items-start gap-3 rounded-lg border p-4 ${vencidosCount > 0 ? 'border-destructive/30 bg-destructive/5' : 'border-warning/30 bg-warning/5'}`}>
            <AlertTriangle className={`h-5 w-5 shrink-0 mt-0.5 ${vencidosCount > 0 ? 'text-destructive' : 'text-warning'}`} />
            <div className="text-sm">
              {vencidosCount > 0 && <p className="font-medium text-destructive">{vencidosCount} lote(s) vencido(s)!</p>}
              {vencendoCount > 0 && <p className="text-warning font-medium">{vencendoCount} lote(s) vencendo em 30 dias.</p>}
            </div>
          </div>
        )}

        <div className="flex flex-col md:flex-row gap-3">
          <div className="relative md:max-w-xs w-full">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
            <Input className="pl-9" placeholder="Buscar lote ou produto..." value={search} onChange={e => setSearch(e.target.value)} />
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList>
            <TabsTrigger value="todos">Todos ({batches.length})</TabsTrigger>
            <TabsTrigger value="vencendo" className={vencendoCount > 0 ? 'text-warning' : ''}>Vencendo ({vencendoCount})</TabsTrigger>
            <TabsTrigger value="vencidos" className={vencidosCount > 0 ? 'text-destructive' : ''}>Vencidos ({vencidosCount})</TabsTrigger>
            <TabsTrigger value="sem_validade">Sem Validade</TabsTrigger>
          </TabsList>
          <TabsContent value={activeTab} className="mt-4">
            <div className="bg-card border border-border rounded-lg overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead><tr className="border-b border-border bg-muted/40">
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Produto</th>
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Lote</th>
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Fabricação</th>
                    <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Validade</th>
                    <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Qtd. Inicial</th>
                    <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Qtd. Atual</th>
                    <th className="text-center px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Status</th>
                    <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Ações</th>
                  </tr></thead>
                  <tbody className="divide-y divide-border">
                    {loading ? Array.from({ length: 5 }).map((_, i) => (
                      <tr key={i}><td colSpan={8} className="px-4 py-3"><Skeleton className="h-5 w-full bg-muted" /></td></tr>
                    )) : filtered.length === 0 ? (
                      <tr><td colSpan={8} className="text-center py-12 text-muted-foreground">
                        <Package className="h-8 w-8 mx-auto mb-2 opacity-40" />
                        <p className="text-pretty">Nenhum lote encontrado</p>
                      </td></tr>
                    ) : filtered.map(b => {
                      const status = expiryStatus(b.expiry_date);
                      return (
                        <tr key={b.id} className="hover:bg-muted/30 transition-colors">
                          <td className="px-4 py-3 whitespace-nowrap">
                            <p className="font-medium">{b.pdv_products?.name || '—'}</p>
                            <p className="text-xs text-muted-foreground font-mono">{b.pdv_products?.code}</p>
                          </td>
                          <td className="px-4 py-3 font-mono text-xs whitespace-nowrap">{b.batch_number}</td>
                          <td className="px-4 py-3 text-muted-foreground whitespace-nowrap">{b.manufacturing_date ? new Date(b.manufacturing_date + 'T00:00:00').toLocaleDateString('pt-BR') : '—'}</td>
                          <td className="px-4 py-3 whitespace-nowrap">{b.expiry_date ? new Date(b.expiry_date + 'T00:00:00').toLocaleDateString('pt-BR') : '—'}</td>
                          <td className="px-4 py-3 text-right whitespace-nowrap">{b.initial_qty}</td>
                          <td className="px-4 py-3 text-right whitespace-nowrap font-medium">{b.current_qty}</td>
                          <td className="px-4 py-3 text-center whitespace-nowrap">
                            {!b.expiry_date ? <Badge variant="secondary" className="text-xs">Sem validade</Badge>
                              : status === 'vencido' ? <Badge className="text-xs bg-destructive text-destructive-foreground">Vencido</Badge>
                              : status === 'vencendo' ? <Badge className="text-xs bg-warning/10 text-warning border border-warning/30">Vencendo</Badge>
                              : <Badge variant="outline" className="text-xs text-success border-success/40">Válido</Badge>}
                          </td>
                          <td className="px-4 py-3 text-right whitespace-nowrap">
                            <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive hover:text-destructive" onClick={() => handleDelete(b.id)}><Trash2 className="h-3.5 w-3.5" /></Button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle className="text-balance">Cadastrar Lote</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-4 py-2">
            <div className="col-span-2 space-y-1.5">
              <Label className="text-sm font-normal">Produto *</Label>
              <Select value={form.product_id} onValueChange={v => f('product_id', v)}>
                <SelectTrigger><SelectValue placeholder="Selecione..." /></SelectTrigger>
                <SelectContent>{products.map(p => <SelectItem key={p.id} value={p.id}>{p.name} ({p.code})</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Número do Lote *</Label><Input value={form.batch_number} onChange={e => f('batch_number', e.target.value)} placeholder="LOT-001" /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Data de Fabricação</Label><Input type="date" value={form.manufacturing_date} onChange={e => f('manufacturing_date', e.target.value)} /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Data de Validade</Label><Input type="date" value={form.expiry_date} onChange={e => f('expiry_date', e.target.value)} /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Qtd. Inicial</Label><Input type="number" min="0" value={form.initial_qty} onChange={e => f('initial_qty', parseFloat(e.target.value) || 0)} /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Qtd. Atual</Label><Input type="number" min="0" value={form.current_qty} onChange={e => f('current_qty', parseFloat(e.target.value) || 0)} /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Custo (R$)</Label><Input type="number" min="0" step="0.01" value={form.cost_price} onChange={e => f('cost_price', parseFloat(e.target.value) || 0)} /></div>
            <div className="col-span-2 space-y-1.5"><Label className="text-sm font-normal">Observações</Label><Input value={form.notes} onChange={e => f('notes', e.target.value)} /></div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setShowDialog(false)}>Cancelar</Button>
            <Button onClick={handleSave} disabled={saving}>Salvar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PdvLayout>
  );
}
