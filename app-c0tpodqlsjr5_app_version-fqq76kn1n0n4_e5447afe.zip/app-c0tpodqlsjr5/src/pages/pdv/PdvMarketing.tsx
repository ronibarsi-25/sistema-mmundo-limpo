import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { PdvLayout } from '@/components/layouts/PdvLayout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { toast } from 'sonner';
import {
  Share2, CheckCircle2, XCircle, AlertCircle, Play, Save, Loader2,
  ExternalLink, Sparkles, Activity, ShieldCheck, Eye, ShoppingCart,
  CreditCard, CheckCheck, RefreshCw, HelpCircle, Code, Rss, ArrowUpRight
} from 'lucide-react';
import { metaPixel, type MetaPixelEventLog } from '@/utils/metaPixel';

export default function PdvMarketing() {
  const [pixelId, setPixelId] = useState('');
  const [isActive, setIsActive] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [recentLogs, setRecentLogs] = useState<MetaPixelEventLog[]>([]);

  useEffect(() => {
    loadSettings();
    const unsubscribe = metaPixel.subscribeLogs((logs) => {
      setRecentLogs([...logs]);
    });
    return () => unsubscribe();
  }, []);

  const loadSettings = async () => {
    setLoading(true);
    try {
      const cfg = await metaPixel.loadFromSupabase();
      setPixelId(cfg.pixelId);
      setIsActive(cfg.active);
    } catch (err) {
      console.error(err);
      toast.error('Erro ao carregar configurações do Meta Pixel.');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const cleanId = pixelId.trim();

    if (isActive && !cleanId) {
      toast.error('Para ativar a integração, informe um Meta Pixel ID válido.');
      return;
    }

    if (cleanId && !/^\d{12,18}$/.test(cleanId)) {
      toast.warning('O Meta Pixel ID costuma ser numérico com 15 a 16 dígitos. Verifique se copiou corretamente.');
    }

    setSaving(true);
    try {
      await metaPixel.saveToSupabase(cleanId, isActive);
      toast.success('Configurações do Meta Pixel salvas com sucesso!');
    } catch (err: any) {
      console.error(err);
      toast.error(err?.message || 'Falha ao salvar configurações do Meta Pixel.');
    } finally {
      setSaving(false);
    }
  };

  const handleTestEvent = () => {
    handleTriggerEvent('test');
  };

  const handleTriggerEvent = (type: 'test' | 'pageview' | 'viewcontent' | 'addtocart' | 'initiatecheckout' | 'purchase') => {
    setTesting(true);
    setTimeout(() => {
      try {
        switch (type) {
          case 'test': {
            const res = metaPixel.sendTestEvent();
            if (res.success) toast.success(res.message);
            else toast.error(res.message);
            break;
          }
          case 'pageview': {
            metaPixel.trackPageView('/pdv/marketing?teste=sim');
            toast.success('Evento PageView disparado com sucesso!');
            break;
          }
          case 'viewcontent': {
            metaPixel.trackViewContent({
              id: 'PROD-TESTE-01',
              name: 'Detergente Neutro 5L (Demonstração)',
              price: 24.90,
              category: 'Limpeza Geral',
            });
            toast.success('Evento ViewContent (Visualização de Produto) disparado!');
            break;
          }
          case 'addtocart': {
            metaPixel.trackAddToCart({
              id: 'PROD-TESTE-01',
              name: 'Detergente Neutro 5L (Demonstração)',
              price: 24.90,
              quantity: 2,
              category: 'Limpeza Geral',
            });
            toast.success('Evento AddToCart (Adição ao Carrinho) disparado!');
            break;
          }
          case 'initiatecheckout': {
            metaPixel.trackInitiateCheckout({
              itemsCount: 2,
              totalValue: 49.80,
              items: [{ id: 'PROD-TESTE-01', name: 'Detergente Neutro 5L', price: 24.90, quantity: 2 }],
            });
            toast.success('Evento InitiateCheckout (Início de Pagamento) disparado!');
            break;
          }
          case 'purchase': {
            const num = `TESTE-${Date.now().toString().slice(-6)}`;
            metaPixel.trackPurchase({
              orderId: num,
              totalValue: 49.80,
              itemsCount: 2,
              items: [{ id: 'PROD-TESTE-01', quantity: 2 }],
            });
            toast.success(`Evento Purchase (Compra #${num} - R$ 49,80) disparado!`);
            break;
          }
        }
      } catch (err: any) {
        toast.error(`Falha ao disparar evento: ${err?.message || 'Erro'}`);
      } finally {
        setTesting(false);
      }
    }, 250);
  };

  const statusBadge = () => {
    if (!pixelId.trim()) {
      return (
        <Badge variant="outline" className="bg-muted/50 text-muted-foreground gap-1 border-muted">
          <AlertCircle className="h-3 w-3" /> Não Configurado
        </Badge>
      );
    }
    if (isActive) {
      return (
        <Badge variant="outline" className="bg-emerald-500/10 text-emerald-600 border-emerald-500/20 gap-1 font-semibold">
          <CheckCircle2 className="h-3 w-3" /> Conectado & Ativo
        </Badge>
      );
    }
    return (
      <Badge variant="outline" className="bg-amber-500/10 text-amber-600 border-amber-500/20 gap-1 font-semibold">
        <XCircle className="h-3 w-3" /> Pausado / Desativado
      </Badge>
    );
  };

  const supportedEvents: Array<{
    id: 'pageview' | 'viewcontent' | 'addtocart' | 'initiatecheckout' | 'purchase';
    name: string;
    tag: string;
    desc: string;
    icon: React.ComponentType<{ className?: string }>;
    status: string;
  }> = [
    {
      id: 'pageview',
      name: 'PageView',
      tag: 'fbq("track", "PageView")',
      desc: 'Disparado automaticamente ao acessar ou trocar qualquer página do sistema e PDV.',
      icon: Eye,
      status: 'Automático',
    },
    {
      id: 'viewcontent',
      name: 'ViewContent',
      tag: 'fbq("track", "ViewContent", {...})',
      desc: 'Disparado ao abrir os detalhes de qualquer produto no catálogo ou no estoque.',
      icon: Sparkles,
      status: 'Automático',
    },
    {
      id: 'addtocart',
      name: 'AddToCart',
      tag: 'fbq("track", "AddToCart", {...})',
      desc: 'Disparado ao adicionar um produto ao carrinho na tela do PDV ou na loja.',
      icon: ShoppingCart,
      status: 'Automático',
    },
    {
      id: 'initiatecheckout',
      name: 'InitiateCheckout',
      tag: 'fbq("track", "InitiateCheckout", {...})',
      desc: 'Disparado quando o operador ou cliente abre a tela de finalização/pagamento da compra.',
      icon: CreditCard,
      status: 'Automático',
    },
    {
      id: 'purchase',
      name: 'Purchase',
      tag: 'fbq("track", "Purchase", {...})',
      desc: 'Disparado ao concluir a venda no PDV com valor total em BRL, itens e ID da venda.',
      icon: CheckCheck,
      status: 'Automático',
    },
  ];

  return (
    <PdvLayout
      title="Integração com Meta Pixel"
      actions={
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={loadSettings} disabled={loading} className="gap-1.5">
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
            <span className="hidden sm:inline">Recarregar</span>
          </Button>
          <Button
            size="sm"
            onClick={() => handleSave()}
            disabled={saving || loading}
            className="gap-1.5 shadow-sm"
          >
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
            <span>Salvar Alterações</span>
          </Button>
        </div>
      }
    >
      <div className="space-y-6 max-w-6xl mx-auto pb-12">
        {/* Banner de Atalho para Feed de Catálogo Facebook & Instagram */}
        <div className="rounded-xl border border-primary/20 bg-primary/5 p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0">
              <Rss className="h-5 w-5" />
            </div>
            <div>
              <p className="font-semibold text-sm text-foreground">Catálogo & Feed de Produtos (Facebook & Instagram Shopping)</p>
              <p className="text-xs text-muted-foreground">Sincronize seus produtos com o Meta Commerce Manager via feed dinâmico XML/CSV ou gere posts para Feed e Stories.</p>
            </div>
          </div>
          <Button asChild size="sm" className="bg-primary text-primary-foreground gap-1.5 shrink-0 text-xs">
            <Link to="/pdv/feed-meta">
              <span>Acessar Feed & Criativos</span>
              <ArrowUpRight className="h-3.5 w-3.5" />
            </Link>
          </Button>
        </div>

        {/* Banner Superior de Status */}
        <div className="rounded-xl border border-border bg-gradient-to-r from-blue-600/10 via-primary/5 to-transparent p-5 md:p-6 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-start gap-4">
            <div className="h-12 w-12 rounded-xl bg-primary text-primary-foreground flex items-center justify-center shrink-0 shadow-sm">
              <Share2 className="h-6 w-6" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-lg md:text-xl font-bold text-foreground">Meta Pixel (Facebook Ads)</h2>
                {statusBadge()}
              </div>
              <p className="text-xs md:text-sm text-muted-foreground mt-1 max-w-2xl text-pretty">
                Rastreie visitantes, visualizações de produtos, adições ao carrinho e conversões de compras do seu PDV e catálogo para otimizar anúncios e criar públicos personalizados na Meta.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <Button
              variant="outline"
              size="sm"
              onClick={handleTestEvent}
              disabled={testing || !pixelId || !isActive}
              className="gap-1.5 h-9 bg-card"
            >
              {testing ? <Loader2 className="h-4 w-4 animate-spin text-primary" /> : <Play className="h-4 w-4 text-primary fill-primary" />}
              <span>Testar Disparo</span>
            </Button>
            <Button
              asChild
              variant="ghost"
              size="sm"
              className="h-9 gap-1 text-xs text-muted-foreground hover:text-foreground"
            >
              <a href="https://adsmanager.facebook.com/events_manager" target="_blank" rel="noopener noreferrer">
                <span>Gerenciador de Eventos</span>
                <ExternalLink className="h-3.5 w-3.5" />
              </a>
            </Button>
          </div>
        </div>

        {/* Grid Principal: Configuração + Diagnóstico */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Coluna Esquerda: Formulário de Configuração */}
          <Card className="lg:col-span-2 shadow-sm border-border bg-card">
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <ShieldCheck className="h-4 w-4 text-primary" />
                Configuração da Conexão
              </CardTitle>
              <CardDescription>
                Informe o Identificador do Pixel (Pixel ID) gerado no Gerenciador de Negócios da Meta.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSave} className="space-y-5">
                <div className="space-y-2">
                  <Label htmlFor="pixel-id" className="text-sm font-semibold flex items-center justify-between">
                    <span>Meta Pixel ID *</span>
                    <span className="text-xs font-normal text-muted-foreground">Ex: 123456789012345</span>
                  </Label>
                  <Input
                    id="pixel-id"
                    type="text"
                    placeholder="Cole seu Meta Pixel ID (apenas números)"
                    value={pixelId}
                    onChange={(e) => setPixelId(e.target.value.replace(/\D/g, ''))}
                    className="font-mono text-base tracking-wider"
                    maxLength={20}
                  />
                  <p className="text-xs text-muted-foreground">
                    Você pode encontrar este ID no menu <em>Gerenciador de Eventos &gt; Fontes de Dados</em> da sua conta da Meta.
                  </p>
                </div>

                <div className="rounded-lg border border-border p-4 bg-muted/30 flex items-center justify-between gap-4">
                  <div className="space-y-0.5">
                    <Label htmlFor="pixel-active" className="text-sm font-medium cursor-pointer">
                      Ativar Rastreamento do Pixel
                    </Label>
                    <p className="text-xs text-muted-foreground text-pretty">
                      Quando ativado, o script oficial da Meta é carregado e os eventos de navegação e vendas passam a ser monitorados.
                    </p>
                  </div>
                  <Switch
                    id="pixel-active"
                    checked={isActive}
                    onCheckedChange={setIsActive}
                    disabled={loading || saving}
                  />
                </div>

                <div className="pt-2 flex justify-end gap-3">
                  <Button
                    type="submit"
                    disabled={saving || loading}
                    className="gap-2 px-6"
                  >
                    {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                    <span>Salvar Configuração</span>
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>

          {/* Coluna Direita: Guia de Validação Rápida */}
          <Card className="shadow-sm border-border bg-card">
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <HelpCircle className="h-4 w-4 text-primary" />
                Como Validar a Conexão?
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-xs text-muted-foreground">
              <div className="p-3 rounded-lg border border-border bg-muted/40 space-y-1.5">
                <p className="font-semibold text-foreground flex items-center gap-1.5">
                  <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary font-bold text-[11px]">1</span>
                  Meta Pixel Helper
                </p>
                <p className="text-pretty">
                  Instale a extensão gratuita <strong>Meta Pixel Helper</strong> no Chrome ou Edge para inspecionar em tempo real os eventos disparados na sua tela.
                </p>
              </div>

              <div className="p-3 rounded-lg border border-border bg-muted/40 space-y-1.5">
                <p className="font-semibold text-foreground flex items-center gap-1.5">
                  <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary font-bold text-[11px]">2</span>
                  Disparo de Teste
                </p>
                <p className="text-pretty">
                  Clique no botão <strong>Testar Disparo</strong> acima. O sistema enviará um evento de diagnóstico instantâneo para verificar a integridade da comunicação.
                </p>
              </div>

              <div className="p-3 rounded-lg border border-border bg-muted/40 space-y-1.5">
                <p className="font-semibold text-foreground flex items-center gap-1.5">
                  <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary font-bold text-[11px]">3</span>
                  Aba de Testes no Facebook
                </p>
                <p className="text-pretty">
                  Abra a aba <em>Testar Eventos</em> no Gerenciador de Eventos da Meta para conferir a chegada das compras e conversões em tempo real.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Tabela de Eventos Padrão Mapeados */}
        <Card className="shadow-sm border-border bg-card">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Code className="h-4 w-4 text-primary" />
              Eventos Automáticos de Conversão Suportados
            </CardTitle>
            <CardDescription>
              Todos os principais eventos do funil de e-commerce e varejo já estão implementados e prontos para uso.
            </CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table className="[&>div]:max-w-full">
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[180px] whitespace-nowrap">Evento Padrão</TableHead>
                    <TableHead className="whitespace-nowrap">Código Executado</TableHead>
                    <TableHead>Descrição e Gatilho</TableHead>
                    <TableHead className="w-[110px] text-center whitespace-nowrap">Status</TableHead>
                    <TableHead className="w-[120px] text-right whitespace-nowrap">Ação de Teste</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {supportedEvents.map((evt, idx) => {
                    const Icon = evt.icon;
                    return (
                      <TableRow key={idx}>
                        <TableCell className="font-medium whitespace-nowrap">
                          <div className="flex items-center gap-2">
                            <div className="p-1.5 rounded-md bg-primary/10 text-primary">
                              <Icon className="h-4 w-4" />
                            </div>
                            <span className="font-semibold text-foreground">{evt.name}</span>
                          </div>
                        </TableCell>
                        <TableCell className="font-mono text-xs text-muted-foreground whitespace-nowrap">
                          <code>{evt.tag}</code>
                        </TableCell>
                        <TableCell className="text-xs text-muted-foreground">{evt.desc}</TableCell>
                        <TableCell className="text-center whitespace-nowrap">
                          <Badge variant="outline" className="bg-emerald-500/10 text-emerald-600 border-emerald-500/20 text-xs">
                            {evt.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right whitespace-nowrap">
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-8 text-xs gap-1.5"
                            disabled={testing || !pixelId || !isActive}
                            onClick={() => handleTriggerEvent(evt.id)}
                          >
                            <Play className="h-3 w-3 text-primary fill-primary" />
                            <span>Testar</span>
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        {/* Console de Eventos Recentes Disparados na Sessão */}
        <Card className="shadow-sm border-border bg-card">
          <CardHeader className="flex flex-row items-center justify-between pb-3">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <Activity className="h-4 w-4 text-primary" />
                Monitor de Eventos em Tempo Real (Sessão Atual)
              </CardTitle>
              <CardDescription>
                Audite os últimos disparos enviados pelo sistema durante o uso do PDV e catálogo.
              </CardDescription>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={handleTestEvent}
              disabled={testing || !pixelId || !isActive}
              className="gap-1.5 text-xs h-8"
            >
              <Play className="h-3 w-3 text-primary" /> Testar Sinal
            </Button>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table className="[&>div]:max-w-full">
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[110px] whitespace-nowrap">Horário</TableHead>
                    <TableHead className="w-[180px] whitespace-nowrap">Evento</TableHead>
                    <TableHead className="w-[120px] whitespace-nowrap">Status</TableHead>
                    <TableHead>Parâmetros Transmitidos</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentLogs.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={4} className="h-24 text-center text-muted-foreground text-xs">
                        Nenhum evento registrado ainda nesta sessão. Navegue pelas páginas ou clique em &quot;Testar Disparo&quot;.
                      </TableCell>
                    </TableRow>
                  ) : (
                    recentLogs.map((log) => (
                      <TableRow key={log.id}>
                        <TableCell className="font-mono text-xs text-muted-foreground whitespace-nowrap">
                          {log.timestamp}
                        </TableCell>
                        <TableCell className="font-medium text-foreground whitespace-nowrap">
                          {log.eventName}
                        </TableCell>
                        <TableCell className="whitespace-nowrap">
                          {log.status === 'sent' ? (
                            <Badge variant="outline" className="bg-emerald-500/10 text-emerald-600 border-emerald-500/20 text-xs">
                              Transmitido
                            </Badge>
                          ) : log.status === 'disabled' ? (
                            <Badge variant="outline" className="bg-amber-500/10 text-amber-600 border-amber-500/20 text-xs">
                              Desativado
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="bg-destructive/10 text-destructive border-destructive/20 text-xs">
                              Bloqueado
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell className="font-mono text-[11px] text-muted-foreground">
                          {log.parameters ? JSON.stringify(log.parameters) : '-'}
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
    </PdvLayout>
  );
}
