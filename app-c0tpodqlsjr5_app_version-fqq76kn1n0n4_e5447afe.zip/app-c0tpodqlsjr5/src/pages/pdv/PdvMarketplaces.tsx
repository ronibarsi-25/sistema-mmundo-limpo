import { useEffect, useState } from 'react';
import { Plus, ExternalLink, RefreshCw, Pencil, Trash2, ShoppingBag } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { PdvLayout } from '@/components/layouts/PdvLayout';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';

interface Listing {
  id: string; product_id: string; marketplace: string; listing_id: string | null;
  title: string; listed_price: number; status: string; url: string | null;
  last_sync_at: string | null; created_at: string;
  pdv_products?: { name: string; code: string; stock_qty: number } | null;
}

const MP_LABELS: Record<string, string> = { mercado_livre: 'Mercado Livre', shopee: 'Shopee', amazon: 'Amazon', americanas: 'Americanas', outro: 'Outro' };
const STATUS_INFO: Record<string, { label: string; cls: string }> = {
  ativo: { label: 'Ativo', cls: 'bg-success/10 text-success border-success/30' },
  pausado: { label: 'Pausado', cls: 'bg-warning/10 text-warning border-warning/30' },
  encerrado: { label: 'Encerrado', cls: 'bg-muted text-muted-foreground border-border' },
  pendente: { label: 'Pendente', cls: 'bg-primary/10 text-primary border-primary/30' },
};

const emptyForm = () => ({ product_id: '', marketplace: 'mercado_livre', listing_id: '', title: '', listed_price: '', status: 'pendente', url: '' });

export default function PdvMarketplaces() {
  const [listings, setListings] = useState<Listing[]>([]);
  const [products, setProducts] = useState<{ id: string; name: string; code: string }[]>([]);
  const [loading, setLoading] = useState(true);
  const [showDialog, setShowDialog] = useState(false);
  const [editListing, setEditListing] = useState<Listing | null>(null);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState(emptyForm());
  const [filterMp, setFilterMp] = useState('all');

  useEffect(() => { load(); loadProducts(); }, []);

  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from('marketplace_listings').select('*, pdv_products(name,code,stock_qty)').order('created_at', { ascending: false });
    setListings((data as Listing[]) || []);
    setLoading(false);
  };
  const loadProducts = async () => { const { data } = await supabase.from('pdv_products').select('id,name,code').order('name'); setProducts(data || []); };

  const openNew = () => { setEditListing(null); setForm(emptyForm()); setShowDialog(true); };
  const openEdit = (l: Listing) => {
    setEditListing(l);
    setForm({ product_id: l.product_id, marketplace: l.marketplace, listing_id: l.listing_id || '', title: l.title, listed_price: String(l.listed_price), status: l.status, url: l.url || '' });
    setShowDialog(true);
  };

  const handleSave = async () => {
    if (!form.product_id) { toast.error('Selecione o produto'); return; }
    if (!form.title.trim()) { toast.error('Informe o título do anúncio'); return; }
    const price = parseFloat(form.listed_price);
    if (!price || price <= 0) { toast.error('Informe o preço'); return; }
    setSaving(true);
    const payload = { product_id: form.product_id, marketplace: form.marketplace, listing_id: form.listing_id || null, title: form.title, listed_price: price, status: form.status, url: form.url || null, updated_at: new Date().toISOString() };
    let error;
    if (editListing) {
      ({ error } = await supabase.from('marketplace_listings').update(payload).eq('id', editListing.id));
    } else {
      ({ error } = await supabase.from('marketplace_listings').insert(payload));
    }
    setSaving(false);
    if (error) { toast.error('Erro: ' + error.message); return; }
    toast.success(editListing ? 'Anúncio atualizado!' : 'Anúncio criado!');
    setShowDialog(false);
    load();
  };

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from('marketplace_listings').delete().eq('id', id);
    if (error) { toast.error('Erro ao excluir'); return; }
    toast.success('Anúncio excluído!');
    setListings(l => l.filter(x => x.id !== id));
  };

  const syncAll = async () => {
    const now = new Date().toISOString();
    await supabase.from('marketplace_listings').update({ last_sync_at: now }).in('status', ['ativo', 'pausado']);
    toast.success('Sincronização simulada com sucesso!');
    load();
  };

  const ff = (k: string, v: string) => setForm(p => ({ ...p, [k]: v }));

  const filtered = listings.filter(l => filterMp === 'all' || l.marketplace === filterMp);
  const byMarketplace = Object.entries(MP_LABELS).map(([k, label]) => ({
    key: k, label, count: listings.filter(l => l.marketplace === k).length, active: listings.filter(l => l.marketplace === k && l.status === 'ativo').length,
  })).filter(m => m.count > 0);

  return (
    <PdvLayout title="Integração com Marketplaces" actions={
      <div className="flex gap-2">
        <Button size="sm" variant="outline" onClick={syncAll}><RefreshCw className="h-4 w-4 mr-1.5" />Sincronizar</Button>
        <Button size="sm" onClick={openNew}><Plus className="h-4 w-4 mr-1.5" />Novo Anúncio</Button>
      </div>
    }>
      <div className="space-y-4">
        {byMarketplace.length > 0 && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {byMarketplace.map(m => (
              <div key={m.key} className="bg-card border border-border rounded-lg p-4">
                <p className="text-xs text-muted-foreground mb-1">{m.label}</p>
                <p className="text-xl font-bold text-foreground">{m.count} anúncio{m.count !== 1 ? 's' : ''}</p>
                <p className="text-xs text-success mt-0.5">{m.active} ativo{m.active !== 1 ? 's' : ''}</p>
              </div>
            ))}
          </div>
        )}

        <div className="flex gap-3">
          <Select value={filterMp} onValueChange={setFilterMp}>
            <SelectTrigger className="w-48"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os marketplaces</SelectItem>
              {Object.entries(MP_LABELS).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>

        <div className="bg-card border border-border rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead><tr className="border-b border-border bg-muted/40">
                <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Produto</th>
                <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Marketplace</th>
                <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Título</th>
                <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Preço</th>
                <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Estoque</th>
                <th className="text-center px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Status</th>
                <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Ações</th>
              </tr></thead>
              <tbody className="divide-y divide-border">
                {loading ? Array.from({ length: 4 }).map((_, i) => <tr key={i}><td colSpan={7} className="px-4 py-3"><Skeleton className="h-5 w-full bg-muted" /></td></tr>)
                  : filtered.length === 0 ? <tr><td colSpan={7} className="text-center py-12 text-muted-foreground"><ShoppingBag className="h-8 w-8 mx-auto mb-2 opacity-40" /><p>Nenhum anúncio cadastrado</p></td></tr>
                  : filtered.map(l => {
                    const si = STATUS_INFO[l.status] || STATUS_INFO['pendente'];
                    return (
                      <tr key={l.id} className="hover:bg-muted/30">
                        <td className="px-4 py-3 whitespace-nowrap">
                          <p className="font-medium">{l.pdv_products?.name || '—'}</p>
                          <p className="text-xs text-muted-foreground font-mono">{l.pdv_products?.code}</p>
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap"><Badge variant="outline" className="text-xs">{MP_LABELS[l.marketplace] || l.marketplace}</Badge></td>
                        <td className="px-4 py-3 max-w-[200px] truncate">{l.title}</td>
                        <td className="px-4 py-3 text-right font-medium whitespace-nowrap">R$ {l.listed_price.toFixed(2)}</td>
                        <td className="px-4 py-3 text-right whitespace-nowrap">{l.pdv_products?.stock_qty ?? '—'}</td>
                        <td className="px-4 py-3 text-center whitespace-nowrap">
                          <span className={`inline-flex text-xs px-2 py-0.5 rounded-full border ${si.cls}`}>{si.label}</span>
                        </td>
                        <td className="px-4 py-3 text-right whitespace-nowrap">
                          {l.url && <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => window.open(l.url!, '_blank')}><ExternalLink className="h-3.5 w-3.5" /></Button>}
                          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openEdit(l)}><Pencil className="h-3.5 w-3.5" /></Button>
                          <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive hover:text-destructive" onClick={() => handleDelete(l.id)}><Trash2 className="h-3.5 w-3.5" /></Button>
                        </td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader><DialogTitle className="text-balance">{editListing ? 'Editar' : 'Novo'} Anúncio</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-4 py-2">
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Produto *</Label>
              <Select value={form.product_id || 'none'} onValueChange={v => { ff('product_id', v === 'none' ? '' : v); const p = products.find(x => x.id === v); if (p && !form.title) ff('title', p.name); }}>
                <SelectTrigger><SelectValue placeholder="Selecione..." /></SelectTrigger>
                <SelectContent>{products.map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Marketplace</Label>
              <Select value={form.marketplace} onValueChange={v => ff('marketplace', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{Object.entries(MP_LABELS).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="col-span-2 space-y-1.5"><Label className="text-sm font-normal">Título do Anúncio *</Label><Input value={form.title} onChange={e => ff('title', e.target.value)} /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Preço (R$) *</Label><Input type="number" min="0" step="0.01" value={form.listed_price} onChange={e => ff('listed_price', e.target.value)} /></div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Status</Label>
              <Select value={form.status} onValueChange={v => ff('status', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{Object.entries(STATUS_INFO).map(([k, v]) => <SelectItem key={k} value={k}>{v.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">ID do Anúncio (externo)</Label><Input value={form.listing_id} onChange={e => ff('listing_id', e.target.value)} placeholder="MLB12345..." /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">URL do Anúncio</Label><Input value={form.url} onChange={e => ff('url', e.target.value)} placeholder="https://..." /></div>
          </div>
          <DialogFooter className="gap-2"><Button variant="outline" onClick={() => setShowDialog(false)}>Cancelar</Button><Button onClick={handleSave} disabled={saving}>Salvar</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </PdvLayout>
  );
}
