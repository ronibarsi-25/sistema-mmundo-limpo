import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/db/supabase';
import { PdvLayout } from '@/components/layouts/PdvLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { toast } from 'sonner';
import { Plus, Pencil, Trash2, Loader2, Save, CreditCard, Banknote, QrCode, Wallet, FileText, Receipt, DollarSign } from 'lucide-react';
import type { PdvPaymentMethod } from '@/types/types';

const TYPE_LABELS: Record<string, string> = {
  dinheiro: 'Dinheiro',
  cartao_debito: 'Cartão Débito',
  cartao_credito: 'Cartão Crédito',
  pix: 'PIX',
  boleto: 'Boleto',
  vale: 'Vale / Ticket',
  crediario: 'Crediário',
  outro: 'Outro',
};

const ICON_MAP: Record<string, typeof CreditCard> = {
  CreditCard, Banknote, QrCode, Wallet, FileText, Receipt, DollarSign,
};

const DEFAULT_ICONS = ['CreditCard', 'Banknote', 'QrCode', 'Wallet', 'FileText', 'Receipt', 'DollarSign'];

const emptyForm = {
  name: '', code: '', type: 'outro' as PdvPaymentMethod['type'],
  provider: '', icon: 'CreditCard', fee_percent: '', fee_fixed: '', terminal_id: '', notes: '', is_active: true,
};

export default function PdvMetodosPagamento() {
  const [methods, setMethods] = useState<PdvPaymentMethod[]>([]);
  const [loading, setLoading] = useState(true);
  const [showDialog, setShowDialog] = useState(false);
  const [editing, setEditing] = useState<PdvPaymentMethod | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [submitting, setSubmitting] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase.from('pdv_payment_methods').select('*').order('name');
    setMethods(Array.isArray(data) ? data : []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const openNew = () => {
    setEditing(null);
    setForm(emptyForm);
    setShowDialog(true);
  };

  const openEdit = (m: PdvPaymentMethod) => {
    setEditing(m);
    setForm({
      name: m.name, code: m.code, type: m.type,
      provider: m.provider || '', icon: m.icon || 'CreditCard',
      fee_percent: String(m.fee_percent), fee_fixed: String(m.fee_fixed),
      terminal_id: m.terminal_id || '', notes: m.notes || '', is_active: m.is_active,
    });
    setShowDialog(true);
  };

  const handleSave = async () => {
    if (!form.name.trim() || !form.code.trim()) { toast.error('Preencha nome e código'); return; }
    setSubmitting(true);
    const payload = {
      name: form.name.trim(), code: form.code.trim().toLowerCase().replace(/\s+/g, '_'),
      type: form.type, provider: form.provider?.trim() || null,
      icon: form.icon, is_active: form.is_active,
      fee_percent: parseFloat(form.fee_percent) || 0,
      fee_fixed: parseFloat(form.fee_fixed) || 0,
      terminal_id: form.terminal_id?.trim() || null,
      notes: form.notes?.trim() || null,
    };
    const query = editing
      ? supabase.from('pdv_payment_methods').update(payload).eq('id', editing.id)
      : supabase.from('pdv_payment_methods').insert(payload);
    const { error } = await query;
    setSubmitting(false);
    if (error) { toast.error(`Erro: ${error.message}`); return; }
    toast.success(editing ? 'Método atualizado!' : 'Método cadastrado!');
    setShowDialog(false);
    load();
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    const { error } = await supabase.from('pdv_payment_methods').delete().eq('id', deleteId);
    if (error) { toast.error(`Erro: ${error.message}`); }
    else { toast.success('Método removido'); load(); }
    setDeleteId(null);
  };

  const f = (k: string, v: string | boolean) => setForm(prev => ({ ...prev, [k]: v }));

  const formatCurrency = (val: number) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val || 0);

  return (
    <PdvLayout title="Métodos de Pagamento">
      <div className="max-w-5xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold text-balance">Formas de Pagamento</h2>
            <p className="text-sm text-muted-foreground text-pretty">Cadastre e gerencie as formas de pagamento aceitas na loja (Stone, Cielo, PIX, etc.).</p>
          </div>
          <Button onClick={openNew}><Plus className="h-4 w-4 mr-2" /> Novo</Button>
        </div>

        <Card>
          <CardContent className="p-0">
            <div className="w-full max-w-full overflow-x-auto bg-card">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="whitespace-nowrap">Nome</TableHead>
                    <TableHead className="whitespace-nowrap">Tipo</TableHead>
                    <TableHead className="whitespace-nowrap">Provedor</TableHead>
                    <TableHead className="whitespace-nowrap">Taxa</TableHead>
                    <TableHead className="whitespace-nowrap">Status</TableHead>
                    <TableHead className="whitespace-nowrap">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loading ? (
                    <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground"><Loader2 className="h-5 w-5 mx-auto animate-spin" /></TableCell></TableRow>
                  ) : methods.length === 0 ? (
                    <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">Nenhum método cadastrado.</TableCell></TableRow>
                  ) : (
                    methods.map((m) => {
                      const IconComp = ICON_MAP[m.icon || 'CreditCard'] || CreditCard;
                      return (
                        <TableRow key={m.id}>
                          <TableCell className="whitespace-nowrap">
                            <div className="flex items-center gap-2">
                              <IconComp className="h-4 w-4 text-muted-foreground shrink-0" />
                              <span className="font-medium">{m.name}</span>
                            </div>
                          </TableCell>
                          <TableCell className="whitespace-nowrap">{TYPE_LABELS[m.type] || m.type}</TableCell>
                          <TableCell className="whitespace-nowrap">{m.provider || '—'}</TableCell>
                          <TableCell className="whitespace-nowrap">
                            {m.fee_percent > 0 && <span className="text-xs">{m.fee_percent}%</span>}
                            {m.fee_fixed > 0 && <span className="text-xs ml-1">+ {formatCurrency(m.fee_fixed)}</span>}
                            {m.fee_percent === 0 && m.fee_fixed === 0 && <span className="text-xs text-muted-foreground">Sem taxa</span>}
                          </TableCell>
                          <TableCell className="whitespace-nowrap"><Badge variant={m.is_active ? 'default' : 'secondary'}>{m.is_active ? 'Ativo' : 'Inativo'}</Badge></TableCell>
                          <TableCell className="whitespace-nowrap">
                            <div className="flex items-center gap-1">
                              <Button variant="ghost" size="icon" onClick={() => openEdit(m)}><Pencil className="h-4 w-4" /></Button>
                              <Button variant="ghost" size="icon" onClick={() => setDeleteId(m.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg max-h-[90dvh] overflow-y-auto">
          <DialogHeader><DialogTitle className="text-balance">{editing ? 'Editar Método' : 'Novo Método de Pagamento'}</DialogTitle></DialogHeader>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-2">
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Nome *</Label>
              <Input value={form.name} onChange={e => f('name', e.target.value)} placeholder="Ex: Stone Débito" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Código (ID interno) *</Label>
              <Input value={form.code} onChange={e => f('code', e.target.value)} placeholder="Ex: stone_debito" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Tipo</Label>
              <Select value={form.type} onValueChange={v => f('type', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(TYPE_LABELS).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Provedor</Label>
              <Input value={form.provider} onChange={e => f('provider', e.target.value)} placeholder="Ex: Stone, Cielo, Rede..." />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Taxa (%)</Label>
              <Input type="number" min="0" step="0.01" value={form.fee_percent} onChange={e => f('fee_percent', e.target.value)} placeholder="0,00" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Taxa Fixa (R$)</Label>
              <Input type="number" min="0" step="0.01" value={form.fee_fixed} onChange={e => f('fee_fixed', e.target.value)} placeholder="0,00" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">ID do Terminal / Pinpad</Label>
              <Input value={form.terminal_id} onChange={e => f('terminal_id', e.target.value)} placeholder="Opcional" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Ícone</Label>
              <Select value={form.icon} onValueChange={v => f('icon', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {DEFAULT_ICONS.map(i => {
                    const I = ICON_MAP[i] || CreditCard;
                    return <SelectItem key={i} value={i}><div className="flex items-center gap-2"><I className="h-4 w-4" />{i}</div></SelectItem>;
                  })}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5 md:col-span-2">
              <Label className="text-sm font-normal">Observações</Label>
              <Input value={form.notes} onChange={e => f('notes', e.target.value)} placeholder="Ex: Configuração do equipamento, chave API..." />
            </div>
            <div className="flex items-center gap-2 md:col-span-2">
              <Switch checked={form.is_active} onCheckedChange={v => f('is_active', v)} />
              <Label className="text-sm font-normal cursor-pointer">Ativo</Label>
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setShowDialog(false)}>Cancelar</Button>
            <Button onClick={handleSave} disabled={submitting}>
              {submitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              <Save className="h-4 w-4 mr-2" /> Salvar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete confirm */}
      <Dialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-balance">Remover Método</DialogTitle>
            <CardDescription className="text-pretty">Deseja realmente excluir este método de pagamento?</CardDescription>
          </DialogHeader>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setDeleteId(null)}>Cancelar</Button>
            <Button variant="destructive" onClick={handleDelete}><Trash2 className="h-4 w-4 mr-2" /> Remover</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PdvLayout>
  );
}
