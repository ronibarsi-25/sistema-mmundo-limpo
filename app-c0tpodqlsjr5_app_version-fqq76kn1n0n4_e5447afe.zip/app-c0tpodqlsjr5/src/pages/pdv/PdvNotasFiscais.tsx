import { useEffect, useState } from 'react';
import { Plus, Search, Eye, FileText, X, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Separator } from '@/components/ui/separator';
import { PdvLayout } from '@/components/layouts/PdvLayout';
import { supabase } from '@/db/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import type { PdvInvoice, PdvProduct, Customer, Supplier, PaymentMethod, InvoiceType } from '@/types/types';

const PAYMENT_LABELS: Record<PaymentMethod, string> = {
  dinheiro: 'Dinheiro', cartao_debito: 'Cartão Débito', cartao_credito: 'Cartão Crédito', pix: 'PIX', outros: 'Outros',
};

const STATUS_CLASS: Record<string, string> = {
  pendente: 'status-badge-warning',
  emitida: 'status-badge-success',
  cancelada: 'status-badge-destructive',
};

interface InvoiceWithDetail extends PdvInvoice {
  pdv_invoice_items: Array<{ quantity: number; unit_price: number; total_price: number; pdv_products: { name: string; unit: string } | null }>;
}

interface CartItem { product: PdvProduct; qty: number; unit_price: string; }

export default function PdvNotasFiscais() {
  const { profile } = useAuth();
  const [invoices, setInvoices] = useState<InvoiceWithDetail[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [products, setProducts] = useState<PdvProduct[]>([]);
  const [loading, setLoading] = useState(true);
  const [typeFilter, setTypeFilter] = useState<'all' | 'entrada' | 'saida'>('all');
  const [search, setSearch] = useState('');
  const [showCreate, setShowCreate] = useState(false);
  const [showDetail, setShowDetail] = useState<InvoiceWithDetail | null>(null);
  const [submitting, setSubmitting] = useState(false);

  // Form state
  const [formType, setFormType] = useState<InvoiceType>('saida');
  const [formCustomer, setFormCustomer] = useState('');
  const [formSupplier, setFormSupplier] = useState('');
  const [formPayment, setFormPayment] = useState<PaymentMethod>('pix');
  const [formDiscount, setFormDiscount] = useState('0');
  const [formNotes, setFormNotes] = useState('');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [prodSearch, setProdSearch] = useState('');
  const [prodResults, setProdResults] = useState<PdvProduct[]>([]);

  useEffect(() => { loadAll(); }, []);

  const loadAll = async () => {
    setLoading(true);
    const [invRes, cusRes, supRes, prodRes] = await Promise.all([
      supabase.from('pdv_invoices').select('*, customers(name), suppliers(razao_social, nome_fantasia), pdv_invoice_items(quantity, unit_price, total_price, pdv_products(name, unit))').order('issued_at', { ascending: false }).limit(100),
      supabase.from('customers').select('*').eq('active', true).order('name'),
      supabase.from('suppliers').select('*').eq('active', true).order('razao_social'),
      supabase.from('pdv_products').select('*').eq('active', true).order('name'),
    ]);
    setInvoices((invRes.data as InvoiceWithDetail[]) || []);
    setCustomers((cusRes.data as Customer[]) || []);
    setSuppliers((supRes.data as Supplier[]) || []);
    setProducts((prodRes.data as PdvProduct[]) || []);
    setLoading(false);
  };

  const searchProds = (q: string) => {
    setProdSearch(q);
    if (q.trim().length < 1) { setProdResults([]); return; }
    setProdResults(products.filter(p => p.name.toLowerCase().includes(q.toLowerCase()) || p.code.toLowerCase().includes(q.toLowerCase()) || (p.barcode && p.barcode.toLowerCase().includes(q.toLowerCase()))).slice(0, 6));
  };

  const addToCart = (p: PdvProduct) => {
    if (cart.find(i => i.product.id === p.id)) { toast.warning('Produto já adicionado'); return; }
    setCart(prev => [...prev, { product: p, qty: 1, unit_price: String(p.sale_price) }]);
    setProdSearch(''); setProdResults([]);
  };

  const updateCartItem = (id: string, field: 'qty' | 'unit_price', val: string) => {
    setCart(prev => prev.map(i => i.product.id === id ? { ...i, [field]: field === 'qty' ? Number(val) : val } : i));
  };

  const subtotal = cart.reduce((s, i) => s + (typeof i.qty === 'number' ? i.qty : 1) * (parseFloat(i.unit_price) || 0), 0);
  const discountVal = Math.min(parseFloat(formDiscount) || 0, subtotal);
  const total = subtotal - discountVal;

  const handleCreate = async () => {
    if (!profile) return;
    if (cart.length === 0) { toast.error('Adicione produtos'); return; }
    setSubmitting(true);
    try {
      const num = `${formType === 'saida' ? 'V' : 'E'}${Date.now()}`;
      const { data: inv, error: invErr } = await supabase.from('pdv_invoices').insert({
        number: num, type: formType, status: 'emitida',
        customer_id: formCustomer || null, supplier_id: formSupplier || null,
        subtotal, discount: discountVal, total, payment_method: formPayment,
        notes: formNotes || null, created_by: profile.id,
      }).select().maybeSingle();
      if (invErr || !inv) throw invErr;
      const items = cart.map(i => ({
        invoice_id: inv.id, product_id: i.product.id,
        quantity: typeof i.qty === 'number' ? i.qty : 1,
        unit_price: parseFloat(i.unit_price), total_price: (typeof i.qty === 'number' ? i.qty : 1) * parseFloat(i.unit_price),
      }));
      await supabase.from('pdv_invoice_items').insert(items);
      toast.success(`Nota ${num} emitida!`);
      setShowCreate(false); setCart([]); setFormCustomer(''); setFormSupplier(''); setFormDiscount('0'); setFormNotes('');
      loadAll();
    } catch (err) { console.error(err); toast.error('Erro ao emitir nota'); }
    finally { setSubmitting(false); }
  };

  const cancelInvoice = async (id: string) => {
    const { error } = await supabase.from('pdv_invoices').update({ status: 'cancelada' }).eq('id', id);
    if (error) toast.error('Erro ao cancelar nota');
    else { toast.success('Nota cancelada'); loadAll(); }
  };

  const filtered = invoices.filter(inv => {
    const matchType = typeFilter === 'all' || inv.type === typeFilter;
    const matchSearch = !search || inv.number.toLowerCase().includes(search.toLowerCase()) || ((inv.customers as any)?.name || '').toLowerCase().includes(search.toLowerCase());
    return matchType && matchSearch;
  });

  return (
    <PdvLayout title="Notas Fiscais" actions={<Button size="sm" onClick={() => setShowCreate(true)}><Plus className="h-4 w-4 mr-1.5" />Nova Nota</Button>}>
      <div className="flex flex-col md:flex-row gap-3 mb-5">
        <div className="relative flex-1 min-w-0">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Buscar por número ou cliente..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
        </div>
        <Select value={typeFilter} onValueChange={v => setTypeFilter(v as 'all' | 'entrada' | 'saida')}>
          <SelectTrigger className="w-full md:w-40 shrink-0"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos os tipos</SelectItem>
            <SelectItem value="saida">Saída (Venda)</SelectItem>
            <SelectItem value="entrada">Entrada (Compra)</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="bg-card border border-border rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/40">
                <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Número</th>
                <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Data</th>
                <th className="text-center px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Tipo</th>
                <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Cliente / Fornecedor</th>
                <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Pagamento</th>
                <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Total</th>
                <th className="text-center px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Status</th>
                <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {loading ? (
                Array.from({ length: 5 }).map((_, i) => <tr key={i}><td colSpan={8} className="px-4 py-3"><Skeleton className="h-5 w-full bg-muted" /></td></tr>)
              ) : filtered.length === 0 ? (
                <tr><td colSpan={8} className="text-center py-12 text-muted-foreground">
                  <FileText className="h-8 w-8 mx-auto mb-2 opacity-40" />
                  <p className="text-pretty">Nenhuma nota fiscal encontrada</p>
                </td></tr>
              ) : filtered.map(inv => (
                <tr key={inv.id} className="hover:bg-muted/30 transition-colors">
                  <td className="px-4 py-3 font-mono text-xs font-bold whitespace-nowrap">{inv.number}</td>
                  <td className="px-4 py-3 text-muted-foreground whitespace-nowrap">{new Date(inv.issued_at).toLocaleDateString('pt-BR')}</td>
                  <td className="px-4 py-3 text-center whitespace-nowrap">
                    <Badge variant={inv.type === 'saida' ? 'default' : 'secondary'} className="text-xs">{inv.type === 'saida' ? 'Saída' : 'Entrada'}</Badge>
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap text-muted-foreground">
                    {(inv.customers as any)?.name || (inv.suppliers as any)?.nome_fantasia || (inv.suppliers as any)?.razao_social || '—'}
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap text-muted-foreground">{PAYMENT_LABELS[inv.payment_method]}</td>
                  <td className="px-4 py-3 text-right font-bold whitespace-nowrap text-foreground">R$ {inv.total.toFixed(2)}</td>
                  <td className="px-4 py-3 text-center whitespace-nowrap">
                    <span className={STATUS_CLASS[inv.status] || 'status-badge-muted'}>{inv.status}</span>
                  </td>
                  <td className="px-4 py-3 text-right whitespace-nowrap">
                    <div className="flex items-center justify-end gap-1">
                      <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setShowDetail(inv)}><Eye className="h-3.5 w-3.5" /></Button>
                      {inv.status === 'emitida' && (
                        <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive hover:bg-destructive/10" onClick={() => cancelInvoice(inv.id)}><X className="h-3.5 w-3.5" /></Button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create dialog */}
      <Dialog open={showCreate} onOpenChange={setShowCreate}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl max-h-[90dvh] overflow-y-auto">
          <DialogHeader><DialogTitle className="text-balance">Nova Nota Fiscal</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">Tipo</Label>
                <Select value={formType} onValueChange={v => setFormType(v as InvoiceType)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="saida">Saída (Venda)</SelectItem>
                    <SelectItem value="entrada">Entrada (Compra)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-normal">Pagamento</Label>
                <Select value={formPayment} onValueChange={v => setFormPayment(v as PaymentMethod)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {(Object.keys(PAYMENT_LABELS) as PaymentMethod[]).map(m => <SelectItem key={m} value={m}>{PAYMENT_LABELS[m]}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              {formType === 'saida' && (
                <div className="space-y-1.5 col-span-2">
                  <Label className="text-sm font-normal">Cliente</Label>
                  <Select value={formCustomer || 'none'} onValueChange={v => setFormCustomer(v === 'none' ? '' : v)}>
                    <SelectTrigger><SelectValue placeholder="Selecionar cliente" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">Consumidor final</SelectItem>
                      {customers.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              )}
              {formType === 'entrada' && (
                <div className="space-y-1.5 col-span-2">
                  <Label className="text-sm font-normal">Fornecedor</Label>
                  <Select value={formSupplier || 'none'} onValueChange={v => setFormSupplier(v === 'none' ? '' : v)}>
                    <SelectTrigger><SelectValue placeholder="Selecionar fornecedor" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">Nenhum</SelectItem>
                      {suppliers.map(s => <SelectItem key={s.id} value={s.id}>{s.nome_fantasia || s.razao_social}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>

            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Adicionar Produto</Label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input placeholder="Buscar produto..." value={prodSearch} onChange={e => searchProds(e.target.value)} className="pl-9" />
              </div>
              {prodResults.length > 0 && (
                <div className="border border-border rounded-md overflow-hidden bg-card shadow-sm">
                  {prodResults.map(p => (
                    <button key={p.id} onClick={() => addToCart(p)} className="w-full flex items-center justify-between px-3 py-2 text-sm hover:bg-muted/60 transition-colors border-b border-border/50 last:border-0 text-left">
                      <span className="font-medium truncate">{p.name}</span>
                      <span className="text-xs font-bold text-primary shrink-0 ml-2">R$ {p.sale_price.toFixed(2)}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {cart.length > 0 && (
              <div className="border border-border rounded-lg overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead><tr className="border-b border-border bg-muted/40"><th className="text-left px-3 py-2 font-medium text-muted-foreground whitespace-nowrap">Produto</th><th className="text-right px-3 py-2 font-medium text-muted-foreground whitespace-nowrap">Qtd</th><th className="text-right px-3 py-2 font-medium text-muted-foreground whitespace-nowrap">Preço</th><th className="text-right px-3 py-2 font-medium text-muted-foreground whitespace-nowrap">Total</th><th className="px-3 py-2"></th></tr></thead>
                    <tbody className="divide-y divide-border">
                      {cart.map(item => (
                        <tr key={item.product.id}>
                          <td className="px-3 py-2 whitespace-nowrap font-medium max-w-[140px] truncate">{item.product.name}</td>
                          <td className="px-3 py-2 text-right whitespace-nowrap"><Input type="number" min="1" value={item.qty} onChange={e => updateCartItem(item.product.id, 'qty', e.target.value)} className="w-16 h-7 text-right text-xs px-2 ml-auto" /></td>
                          <td className="px-3 py-2 text-right whitespace-nowrap"><Input type="number" min="0" step="0.01" value={item.unit_price} onChange={e => updateCartItem(item.product.id, 'unit_price', e.target.value)} className="w-24 h-7 text-right text-xs px-2 ml-auto" /></td>
                          <td className="px-3 py-2 text-right font-semibold whitespace-nowrap">R$ {((typeof item.qty === 'number' ? item.qty : 1) * (parseFloat(item.unit_price) || 0)).toFixed(2)}</td>
                          <td className="px-3 py-2 whitespace-nowrap"><Button variant="ghost" size="icon" className="h-6 w-6 text-destructive" onClick={() => setCart(c => c.filter(i => i.product.id !== item.product.id))}><X className="h-3 w-3" /></Button></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <div className="px-3 py-2 border-t border-border bg-muted/30 flex items-center justify-between gap-3 flex-wrap">
                  <div className="flex items-center gap-2">
                    <Label className="text-xs text-muted-foreground whitespace-nowrap">Desconto (R$)</Label>
                    <Input type="number" min="0" step="0.01" value={formDiscount} onChange={e => setFormDiscount(e.target.value)} className="w-24 h-7 text-xs px-2" />
                  </div>
                  <p className="text-sm font-bold text-primary">Total: R$ {total.toFixed(2)}</p>
                </div>
              </div>
            )}

            <div className="space-y-1.5"><Label className="text-sm font-normal">Observações</Label><Textarea value={formNotes} onChange={e => setFormNotes(e.target.value)} rows={2} /></div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setShowCreate(false)}>Cancelar</Button>
            <Button onClick={handleCreate} disabled={submitting || cart.length === 0}>
              {submitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />} Emitir Nota
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Detail dialog */}
      {showDetail && (
        <Dialog open={!!showDetail} onOpenChange={() => setShowDetail(null)}>
          <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg max-h-[90dvh] overflow-y-auto">
            <DialogHeader><DialogTitle className="text-balance">Nota {showDetail.number}</DialogTitle></DialogHeader>
            <div className="space-y-3 py-2 text-sm">
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div><span className="text-muted-foreground">Tipo: </span><strong>{showDetail.type === 'saida' ? 'Saída' : 'Entrada'}</strong></div>
                <div><span className="text-muted-foreground">Status: </span><span className={STATUS_CLASS[showDetail.status]}>{showDetail.status}</span></div>
                <div><span className="text-muted-foreground">Data: </span>{new Date(showDetail.issued_at).toLocaleDateString('pt-BR')}</div>
                <div><span className="text-muted-foreground">Pagamento: </span>{PAYMENT_LABELS[showDetail.payment_method]}</div>
                {(showDetail.customers as any)?.name && <div className="col-span-2"><span className="text-muted-foreground">Cliente: </span><strong>{(showDetail.customers as any)?.name}</strong></div>}
                {(showDetail.suppliers as any)?.razao_social && <div className="col-span-2"><span className="text-muted-foreground">Fornecedor: </span><strong>{(showDetail.suppliers as any)?.nome_fantasia || (showDetail.suppliers as any)?.razao_social}</strong></div>}
              </div>
              <Separator />
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead><tr className="text-muted-foreground border-b border-border"><th className="text-left py-1.5 whitespace-nowrap">Produto</th><th className="text-right py-1.5 whitespace-nowrap">Qtd</th><th className="text-right py-1.5 whitespace-nowrap">Preço</th><th className="text-right py-1.5 whitespace-nowrap">Total</th></tr></thead>
                  <tbody className="divide-y divide-border/50">
                    {(showDetail.pdv_invoice_items || []).map((it, i) => (
                      <tr key={i}><td className="py-1.5 pr-3 whitespace-nowrap">{it.pdv_products?.name || '—'}</td><td className="py-1.5 text-right whitespace-nowrap">{it.quantity} {it.pdv_products?.unit}</td><td className="py-1.5 text-right whitespace-nowrap">R$ {it.unit_price.toFixed(2)}</td><td className="py-1.5 text-right font-medium whitespace-nowrap">R$ {it.total_price.toFixed(2)}</td></tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <Separator />
              <div className="space-y-1 text-xs">
                <div className="flex justify-between"><span className="text-muted-foreground">Subtotal</span><span>R$ {showDetail.subtotal.toFixed(2)}</span></div>
                {showDetail.discount > 0 && <div className="flex justify-between text-destructive"><span>Desconto</span><span>-R$ {showDetail.discount.toFixed(2)}</span></div>}
                <div className="flex justify-between font-bold text-base"><span>Total</span><span className="text-primary">R$ {showDetail.total.toFixed(2)}</span></div>
              </div>
              {showDetail.notes && <p className="text-xs text-muted-foreground italic">Obs: {showDetail.notes}</p>}
            </div>
          </DialogContent>
        </Dialog>
      )}
    </PdvLayout>
  );
}
