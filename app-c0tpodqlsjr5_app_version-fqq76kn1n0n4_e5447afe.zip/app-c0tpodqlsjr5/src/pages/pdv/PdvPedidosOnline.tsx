import { useEffect, useState } from 'react';
import { Eye, ShoppingCart, CheckCircle, Clock, XCircle, Package } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { PdvLayout } from '@/components/layouts/PdvLayout';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';

interface OnlineOrder {
  id: string; customer_id: string | null; channel: string; status: string;
  subtotal: number; discount: number; total: number; notes: string | null;
  created_at: string; updated_at: string;
  customers?: { name: string; phone: string; email: string } | null;
}

interface OrderItem {
  id: string; product_id: string; quantity: number; unit_price: number; total_price: number;
  pdv_products?: { name: string; code: string } | null;
}

const STATUS_INFO: Record<string, { label: string; cls: string; icon: React.ElementType }> = {
  pendente: { label: 'Pendente', cls: 'bg-warning/10 text-warning border-warning/30', icon: Clock },
  confirmado: { label: 'Confirmado', cls: 'bg-primary/10 text-primary border-primary/30', icon: CheckCircle },
  em_preparacao: { label: 'Em Preparo', cls: 'bg-primary/10 text-primary border-primary/30', icon: Package },
  pronto: { label: 'Pronto', cls: 'bg-success/10 text-success border-success/30', icon: CheckCircle },
  entregue: { label: 'Entregue', cls: 'bg-success/10 text-success border-success/30', icon: CheckCircle },
  cancelado: { label: 'Cancelado', cls: 'bg-destructive/10 text-destructive border-destructive/30', icon: XCircle },
};

const STATUS_FLOW: Record<string, string> = {
  pendente: 'confirmado', confirmado: 'em_preparacao', em_preparacao: 'pronto', pronto: 'entregue',
};

const CHANNEL_LABELS: Record<string, string> = { whatsapp: 'WhatsApp', site: 'Site', app: 'App', instagram: 'Instagram', ifood: 'iFood', outro: 'Outro' };

export default function PdvPedidosOnline() {
  const [orders, setOrders] = useState<OnlineOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [showDetail, setShowDetail] = useState<OnlineOrder | null>(null);
  const [orderItems, setOrderItems] = useState<OrderItem[]>([]);
  const [loadingItems, setLoadingItems] = useState(false);
  const [filterStatus, setFilterStatus] = useState('all');

  useEffect(() => { load(); }, [filterStatus]);
  useEffect(() => { if (showDetail) loadItems(showDetail.id); }, [showDetail]);

  const load = async () => {
    setLoading(true);
    let q = supabase.from('online_orders').select('*, customers(name,phone,email)').order('created_at', { ascending: false }).limit(100);
    if (filterStatus !== 'all') q = q.eq('status', filterStatus);
    const { data } = await q;
    setOrders((data as OnlineOrder[]) || []);
    setLoading(false);
  };

  const loadItems = async (orderId: string) => {
    setLoadingItems(true);
    const { data } = await supabase.from('online_order_items').select('*, pdv_products(name,code)').eq('order_id', orderId);
    setOrderItems((data as OrderItem[]) || []);
    setLoadingItems(false);
  };

  const advanceStatus = async (order: OnlineOrder) => {
    const next = STATUS_FLOW[order.status];
    if (!next) { toast.error('Pedido já no status final'); return; }
    const { error } = await supabase.from('online_orders').update({ status: next, updated_at: new Date().toISOString() }).eq('id', order.id);
    if (error) { toast.error('Erro ao atualizar status'); return; }
    toast.success(`Pedido atualizado para: ${STATUS_INFO[next].label}`);
    if (showDetail?.id === order.id) setShowDetail({ ...order, status: next });
    load();
  };

  const cancelOrder = async (id: string) => {
    await supabase.from('online_orders').update({ status: 'cancelado', updated_at: new Date().toISOString() }).eq('id', id);
    toast.success('Pedido cancelado!');
    setShowDetail(null);
    load();
  };

  const pending = orders.filter(o => o.status === 'pendente').length;
  const totalRevenue = orders.filter(o => o.status !== 'cancelado').reduce((s, o) => s + o.total, 0);

  return (
    <PdvLayout title="Pedidos Online">
      <div className="space-y-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { label: 'Total de Pedidos', val: orders.length, cls: 'text-foreground', icon: ShoppingCart },
            { label: 'Pendentes', val: pending, cls: pending > 0 ? 'text-warning' : 'text-muted-foreground', icon: Clock },
            { label: 'Entregues', val: orders.filter(o => o.status === 'entregue').length, cls: 'text-success', icon: CheckCircle },
            { label: 'Receita (visível)', val: `R$ ${totalRevenue.toFixed(2)}`, cls: 'text-primary', icon: Package },
          ].map((k, i) => (
            <div key={i} className="bg-card border border-border rounded-lg p-4">
              <div className="flex items-center gap-2 mb-1"><k.icon className={`h-4 w-4 ${k.cls}`} /><p className="text-xs text-muted-foreground">{k.label}</p></div>
              <p className={`text-xl font-bold ${k.cls}`}>{k.val}</p>
            </div>
          ))}
        </div>

        {pending > 0 && (
          <div className="bg-warning/5 border border-warning/20 rounded-lg p-4 flex items-start gap-3">
            <Clock className="h-5 w-5 text-warning shrink-0 mt-0.5" />
            <div className="text-sm">
              <p className="font-medium text-warning">{pending} pedido(s) aguardando confirmação!</p>
              <p className="text-muted-foreground mt-0.5">Revise e confirme os pedidos pendentes.</p>
            </div>
          </div>
        )}

        <div className="flex gap-3">
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-48"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os status</SelectItem>
              {Object.entries(STATUS_INFO).map(([k, v]) => <SelectItem key={k} value={k}>{v.label}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>

        <div className="bg-card border border-border rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead><tr className="border-b border-border bg-muted/40">
                <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Data/Hora</th>
                <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Cliente</th>
                <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Canal</th>
                <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Total</th>
                <th className="text-center px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Status</th>
                <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Ações</th>
              </tr></thead>
              <tbody className="divide-y divide-border">
                {loading ? Array.from({ length: 5 }).map((_, i) => <tr key={i}><td colSpan={6} className="px-4 py-3"><Skeleton className="h-5 w-full bg-muted" /></td></tr>)
                  : orders.length === 0 ? <tr><td colSpan={6} className="text-center py-12 text-muted-foreground"><ShoppingCart className="h-8 w-8 mx-auto mb-2 opacity-40" /><p>Nenhum pedido encontrado</p></td></tr>
                  : orders.map(o => {
                    const si = STATUS_INFO[o.status] || STATUS_INFO['pendente'];
                    const nextStatus = STATUS_FLOW[o.status];
                    return (
                      <tr key={o.id} className="hover:bg-muted/30">
                        <td className="px-4 py-3 whitespace-nowrap text-muted-foreground text-xs">
                          <p>{new Date(o.created_at).toLocaleDateString('pt-BR')}</p>
                          <p>{new Date(o.created_at).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</p>
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap"><p className="font-medium">{o.customers?.name || '—'}</p><p className="text-xs text-muted-foreground">{o.customers?.phone}</p></td>
                        <td className="px-4 py-3 whitespace-nowrap"><Badge variant="outline" className="text-xs">{CHANNEL_LABELS[o.channel] || o.channel}</Badge></td>
                        <td className="px-4 py-3 text-right font-bold whitespace-nowrap">R$ {o.total.toFixed(2)}</td>
                        <td className="px-4 py-3 text-center whitespace-nowrap">
                          <span className={`inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full border ${si.cls}`}>
                            <si.icon className="h-3 w-3" />{si.label}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-right whitespace-nowrap">
                          <div className="flex items-center justify-end gap-1">
                            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setShowDetail(o)}><Eye className="h-3.5 w-3.5" /></Button>
                            {nextStatus && (
                              <Button size="sm" variant="default" className="h-7 text-xs" onClick={() => advanceStatus(o)}>{STATUS_INFO[nextStatus].label}</Button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <Dialog open={!!showDetail} onOpenChange={o => { if (!o) setShowDetail(null); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-balance">Pedido — {showDetail?.customers?.name || 'Cliente'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="flex flex-wrap gap-3 text-sm">
              <span>Canal: <strong className="text-foreground">{CHANNEL_LABELS[showDetail?.channel || ''] || showDetail?.channel}</strong></span>
              <span>•</span>
              <span>Data: <strong className="text-foreground">{showDetail && new Date(showDetail.created_at).toLocaleString('pt-BR')}</strong></span>
            </div>
            {showDetail?.customers && (
              <div className="bg-muted/40 rounded-lg p-3 text-sm space-y-1">
                <p className="font-medium">{showDetail.customers.name}</p>
                {showDetail.customers.phone && <p className="text-muted-foreground">{showDetail.customers.phone}</p>}
                {showDetail.customers.email && <p className="text-muted-foreground">{showDetail.customers.email}</p>}
              </div>
            )}
            <div className="overflow-x-auto rounded-lg border border-border">
              <table className="w-full text-sm">
                <thead><tr className="border-b border-border bg-muted/40">
                  <th className="text-left px-3 py-2 font-medium text-muted-foreground whitespace-nowrap">Produto</th>
                  <th className="text-right px-3 py-2 font-medium text-muted-foreground whitespace-nowrap">Qtd</th>
                  <th className="text-right px-3 py-2 font-medium text-muted-foreground whitespace-nowrap">Unit.</th>
                  <th className="text-right px-3 py-2 font-medium text-muted-foreground whitespace-nowrap">Total</th>
                </tr></thead>
                <tbody className="divide-y divide-border">
                  {loadingItems ? <tr><td colSpan={4} className="px-3 py-2"><Skeleton className="h-4 w-full bg-muted" /></td></tr>
                    : orderItems.length === 0 ? <tr><td colSpan={4} className="text-center py-4 text-muted-foreground text-xs">Sem itens</td></tr>
                    : orderItems.map(item => (
                      <tr key={item.id}>
                        <td className="px-3 py-2 whitespace-nowrap">{item.pdv_products?.name || '—'}</td>
                        <td className="px-3 py-2 text-right whitespace-nowrap">{item.quantity}</td>
                        <td className="px-3 py-2 text-right whitespace-nowrap">R$ {item.unit_price.toFixed(2)}</td>
                        <td className="px-3 py-2 text-right font-medium whitespace-nowrap">R$ {item.total_price.toFixed(2)}</td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
            <div className="text-right space-y-1 text-sm">
              {showDetail?.discount != null && showDetail.discount > 0 && <p className="text-muted-foreground">Desconto: <span className="text-destructive">-R$ {showDetail.discount.toFixed(2)}</span></p>}
              <p className="font-bold text-lg">Total: R$ {showDetail?.total?.toFixed(2)}</p>
            </div>
            {showDetail && showDetail.status !== 'cancelado' && showDetail.status !== 'entregue' && (
              <div className="flex justify-between gap-2 pt-2 border-t border-border">
                <Button variant="outline" className="text-destructive border-destructive/30 hover:bg-destructive/10" onClick={() => cancelOrder(showDetail.id)}>
                  <XCircle className="h-4 w-4 mr-1.5" />Cancelar Pedido
                </Button>
                {STATUS_FLOW[showDetail.status] && (
                  <Button onClick={() => advanceStatus(showDetail)}>
                    <CheckCircle className="h-4 w-4 mr-1.5" />{STATUS_INFO[STATUS_FLOW[showDetail.status]].label}
                  </Button>
                )}
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </PdvLayout>
  );
}
