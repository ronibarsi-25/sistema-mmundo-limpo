import { useEffect, useState } from 'react';
import { Plus, Pencil, Trash2, Search, Loader2, Package, Globe, GlobeOff, RefreshCw, Merge, AlertTriangle, CheckCircle2, ArrowUpRight, Sparkles, Barcode } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { PdvLayout } from '@/components/layouts/PdvLayout';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import { generateUniqueEan13List } from '@/utils/barcodeGenerator';
import type { PdvProduct, PdvCategory } from '@/types/types';
import type { Category } from '@/types/types';

const UNITS = ['UN', 'KG', 'L', 'ML', 'G', 'CX', 'PC', 'PAR', 'MT'];
const FRACTION_UNITS = ['KG', 'G', 'L', 'ML', 'MT'];

const emptyProduct = {
  code: '', barcode: '', name: '', description: '', category_id: '',
  unit: 'UN', cost_price: '', sale_price: '', margin_percent: '', markup_percent: '',
  stock_qty: '', stock_min: '5', active: true,
  is_fraction: false, fraction_unit: 'KG', wholesale_price: '', retail_price: '', ncm: '', cest: '',
};

export default function PdvProdutos() {
  const [products, setProducts] = useState<PdvProduct[]>([]);
  const [categories, setCategories] = useState<PdvCategory[]>([]);
  const [siteCategories, setSiteCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [catFilter, setCatFilter] = useState('all');
  const [showDialog, setShowDialog] = useState(false);
  const [editing, setEditing] = useState<PdvProduct | null>(null);
  const [form, setForm] = useState(emptyProduct);
  const [submitting, setSubmitting] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  // Publicar no site
  const [publishProduct, setPublishProduct] = useState<PdvProduct | null>(null);
  const [publishForm, setPublishForm] = useState({
    site_category_id: 'none',
    image_url: '',
    is_featured: false,
  });
  const [publishing, setPublishing] = useState(false);
  const [unpublishId, setUnpublishId] = useState<string | null>(null);
  const [siteFilter, setSiteFilter] = useState<'all' | 'on_site' | 'off_site'>('all');
  const [batchPublishing, setBatchPublishing] = useState(false);
  const [generatingBarcodes, setGeneratingBarcodes] = useState(false);

  // Merge produtos duplicados
  const [mergeDialog, setMergeDialog] = useState<{
    open: boolean;
    existingId: string;
    existingName: string;
    code: string;
    barcode?: string;
    reason: 'barcode' | 'code' | 'both';
  }>({ open: false, existingId: '', existingName: '', code: '', reason: 'code' });

  // Modal avançado de consolidação de produtos duplicados (por código de barras e código interno)
  const [duplicateModal, setDuplicateModal] = useState<{
    open: boolean;
    clusters: Array<{
      key: string;
      reason: 'barcode' | 'code' | 'both';
      identifier: string;
      items: PdvProduct[];
      totalStock: number;
      keepProduct: PdvProduct;
    }>;
  }>({ open: false, clusters: [] });

  const [onlyDuplicatesFilter, setOnlyDuplicatesFilter] = useState(false);

  useEffect(() => { loadAll(); }, []);

  const loadAll = async () => {
    setLoading(true);
    const [prodRes, catRes, siteCatRes] = await Promise.all([
      supabase.from('pdv_products').select('*, pdv_categories(id,name,color)').order('name'),
      supabase.from('pdv_categories').select('*').order('name'),
      supabase.from('categories').select('id,name').eq('is_active', true).order('name'),
    ]);
    setProducts((prodRes.data as PdvProduct[]) || []);
    setCategories((catRes.data as PdvCategory[]) || []);
    setSiteCategories((siteCatRes.data as Category[]) || []);
    setLoading(false);
  };

  const openCreate = () => {
    setEditing(null);
    setForm(emptyProduct);
    setShowDialog(true);
  };

  /**
   * Gera códigos de barras EAN-13 para todos os produtos (PDV e site)
   * que ainda estão sem código, garantindo unicidade global.
   */
  const handleGenerateMissingBarcodes = async () => {
    setGeneratingBarcodes(true);
    try {
      const [{ data: pdvAll }, { data: siteAll }] = await Promise.all([
        supabase.from('pdv_products').select('id, barcode'),
        supabase.from('products').select('id, barcode'),
      ]);

      const pdvMissing = (pdvAll || []).filter(p => !p.barcode || !p.barcode.trim());
      const siteMissing = (siteAll || []).filter(p => !p.barcode || !p.barcode.trim());
      const total = pdvMissing.length + siteMissing.length;

      if (total === 0) {
        toast.info('Todos os produtos já possuem código de barras.');
        return;
      }

      const existing = [
        ...(pdvAll || []).map(p => p.barcode || ''),
        ...(siteAll || []).map(p => p.barcode || ''),
      ].filter(Boolean);

      const codes = generateUniqueEan13List(total, existing);
      let idx = 0;
      let updated = 0;

      for (const p of pdvMissing) {
        const { error } = await supabase.from('pdv_products').update({ barcode: codes[idx++] }).eq('id', p.id);
        if (!error) updated++;
      }
      for (const p of siteMissing) {
        const { error } = await supabase.from('products').update({ barcode: codes[idx++] }).eq('id', p.id);
        if (!error) updated++;
      }

      toast.success(`${updated} código(s) de barras gerado(s) com sucesso!`);
      await loadAll();
    } catch (err: any) {
      toast.error('Erro ao gerar códigos de barras: ' + (err?.message || 'erro desconhecido'));
    } finally {
      setGeneratingBarcodes(false);
    }
  };

  const openEdit = (p: PdvProduct) => {
    setEditing(p);
    setForm({
      code: p.code, barcode: p.barcode || '', name: p.name, description: p.description || '',
      category_id: p.category_id || '', unit: p.unit,
      cost_price: String(p.cost_price), sale_price: String(p.sale_price),
      margin_percent: String(p.margin_percent || ''), markup_percent: String(p.markup_percent || ''),
      stock_qty: String(p.stock_qty), stock_min: String(p.stock_min), active: p.active,
      is_fraction: p.is_fraction, fraction_unit: p.fraction_unit || 'KG',
      wholesale_price: String(p.wholesale_price || ''), retail_price: String(p.retail_price || ''),
      ncm: p.ncm || '', cest: p.cest || '',
    });
    setShowDialog(true);
  };

  const generateUniqueCode = (base: string): string => {
    const slug = base
      .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-zA-Z0-9]+/g, '-')
      .replace(/^-|-$/g, '')
      .toUpperCase()
      .slice(0, 15) || 'PROD';
    const existing = products.map(p => p.code);
    let code = slug;
    let counter = 1;
    while (existing.includes(code)) {
      code = `${slug}-${counter}`;
      counter++;
    }
    return code;
  };

  const handleSave = async () => {
    if (!form.name.trim() || !form.sale_price) {
      toast.error('Preencha nome e preço de venda'); return;
    }

    // Auto-generate code if empty (new products only)
    let code = form.code.trim();
    if (!code && !editing) {
      code = generateUniqueCode(form.name);
    }
    if (!code) {
      toast.error('Código do produto é obrigatório'); return;
    }

    // 1. Verificar duplicidade de CÓDIGO INTERNO
    let dupCodeQuery = supabase.from('pdv_products').select('id,name,code,barcode').eq('code', code);
    if (editing) { dupCodeQuery = dupCodeQuery.neq('id', editing.id); }
    const { data: dupCode } = await dupCodeQuery.maybeSingle();

    // 2. Verificar duplicidade de CÓDIGO DE BARRAS (se informado)
    let dupBarcode: { id: string; name: string; code: string; barcode: string | null } | null = null;
    const barcodeTrimmed = form.barcode ? form.barcode.trim() : '';
    if (barcodeTrimmed) {
      let dupBarQuery = supabase.from('pdv_products').select('id,name,code,barcode').eq('barcode', barcodeTrimmed);
      if (editing) { dupBarQuery = dupBarQuery.neq('id', editing.id); }
      const { data } = await dupBarQuery.maybeSingle();
      dupBarcode = data;
    }

    if (dupCode || dupBarcode) {
      const target = dupBarcode || dupCode!;
      const isBoth = Boolean(dupCode && dupBarcode);
      const reason: 'barcode' | 'code' | 'both' = isBoth ? 'both' : (dupBarcode ? 'barcode' : 'code');

      if (!editing) {
        setMergeDialog({
          open: true,
          existingId: target.id,
          existingName: target.name,
          code: target.code,
          barcode: barcodeTrimmed || target.barcode || '',
          reason,
        });
        return;
      } else {
        const msg = reason === 'barcode'
          ? `O código de barras "${barcodeTrimmed}" já está em uso pelo produto "${target.name}" (Código: ${target.code}).`
          : reason === 'both'
          ? `O código "${code}" e o código de barras "${barcodeTrimmed}" já pertencem ao produto "${target.name}".`
          : `O código "${code}" já está em uso pelo produto "${target.name}".`;
        toast.error(msg);
        return;
      }
    }

    await doSave(code);
  };

  const doSave = async (code: string) => {
    setSubmitting(true);
    const payload = {
      code, barcode: form.barcode || null, name: form.name.trim(),
      description: form.description || null, category_id: form.category_id || null,
      unit: form.unit, cost_price: parseFloat(form.cost_price) || 0,
      sale_price: parseFloat(form.sale_price), stock_qty: parseFloat(form.stock_qty) || 0,
      stock_min: parseFloat(form.stock_min) || 0, active: form.active,
      margin_percent: parseFloat(form.margin_percent) || 0,
      markup_percent: parseFloat(form.markup_percent) || 0,
      is_fraction: form.is_fraction, fraction_unit: form.fraction_unit || 'KG',
      wholesale_price: parseFloat(form.wholesale_price) || 0,
      retail_price: parseFloat(form.retail_price) || 0,
      ncm: form.ncm?.trim() || null, cest: form.cest?.trim() || null,
    };
    const query = editing
      ? supabase.from('pdv_products').update(payload).eq('id', editing.id)
      : supabase.from('pdv_products').insert(payload);
    const { error } = await query;
    setSubmitting(false);

    // Second-line defense: if duplicate-key still slips through, show merge dialog
    if (error) {
      if (error.message?.includes('duplicate key') || error.code === '23505') {
        if (!editing) {
          const { data: dup } = await supabase.from('pdv_products').select('id,name,code,barcode').or(`code.eq.${code},barcode.eq.${form.barcode || ''}`).maybeSingle();
          if (dup) {
            setMergeDialog({
              open: true,
              existingId: dup.id,
              existingName: dup.name,
              code: dup.code,
              barcode: form.barcode || dup.barcode || '',
              reason: dup.barcode === form.barcode ? 'barcode' : 'code',
            });
            return;
          }
        }
      }
      toast.error('Erro ao salvar produto: ' + error.message); return;
    }

    toast.success(editing ? 'Produto atualizado!' : 'Produto criado!');
    setShowDialog(false);
    loadAll();
  };

  // Merge: overwrite existing product with new data
  const handleMergeOverwrite = async () => {
    if (!mergeDialog.existingId) return;
    setSubmitting(true);
    const { error } = await supabase.from('pdv_products').update({
      name: form.name.trim(), barcode: form.barcode || null,
      description: form.description || null, category_id: form.category_id || null,
      unit: form.unit, cost_price: parseFloat(form.cost_price) || 0,
      sale_price: parseFloat(form.sale_price), stock_qty: parseFloat(form.stock_qty) || 0,
      stock_min: parseFloat(form.stock_min) || 0, active: form.active,
      margin_percent: parseFloat(form.margin_percent) || 0,
      markup_percent: parseFloat(form.markup_percent) || 0,
      is_fraction: form.is_fraction, fraction_unit: form.fraction_unit || 'KG',
      wholesale_price: parseFloat(form.wholesale_price) || 0,
      retail_price: parseFloat(form.retail_price) || 0,
      ncm: form.ncm?.trim() || null, cest: form.cest?.trim() || null,
      updated_at: new Date().toISOString(),
    }).eq('id', mergeDialog.existingId);
    setSubmitting(false);
    setMergeDialog(m => ({ ...m, open: false }));
    if (error) { toast.error('Erro ao atualizar: ' + error.message); return; }
    toast.success(`Produto "${mergeDialog.existingName}" sobrescrito com sucesso!`);
    setShowDialog(false);
    loadAll();
  };

  // Merge: add stock to existing product
  const handleMergeAddStock = async () => {
    if (!mergeDialog.existingId) return;
    setSubmitting(true);
    const addStock = parseFloat(form.stock_qty) || 0;
    const { data: existing } = await supabase.from('pdv_products').select('stock_qty').eq('id', mergeDialog.existingId).single();
    const newStock = (existing?.stock_qty || 0) + addStock;
    const { error } = await supabase.from('pdv_products').update({
      stock_qty: newStock,
      barcode: form.barcode || undefined,
      updated_at: new Date().toISOString(),
    }).eq('id', mergeDialog.existingId);
    setSubmitting(false);
    setMergeDialog(m => ({ ...m, open: false }));
    if (error) { toast.error('Erro ao somar estoque: ' + error.message); return; }
    toast.success(`Estoque somado! "${mergeDialog.existingName}" agora tem ${newStock} unidades.`);
    setShowDialog(false);
    loadAll();
  };

  // ── Identificação e consolidação de produtos duplicados ─────────────────────
  // Considera duplicados tanto pelo MESMO CÓDIGO DE BARRAS quanto pelo MESMO CÓDIGO INTERNO
  const findDuplicateClusters = () => {
    const barcodeMap = new Map<string, PdvProduct[]>();
    const codeMap = new Map<string, PdvProduct[]>();

    products.forEach(p => {
      const b = p.barcode?.trim();
      if (b) {
        const list = barcodeMap.get(b) || [];
        list.push(p);
        barcodeMap.set(b, list);
      }
      const c = p.code?.trim();
      if (c) {
        const list = codeMap.get(c) || [];
        list.push(p);
        codeMap.set(c, list);
      }
    });

    const processedProductIds = new Set<string>();
    const clusters: Array<{
      key: string;
      reason: 'barcode' | 'code' | 'both';
      identifier: string;
      items: PdvProduct[];
      totalStock: number;
      keepProduct: PdvProduct;
    }> = [];

    // 1. Grupos pelo MESMO CÓDIGO DE BARRAS (EAN)
    barcodeMap.forEach((list, barcode) => {
      if (list.length > 1) {
        const sorted = [...list].sort((a, b) => {
          if (a.publish_to_site && !b.publish_to_site) return -1;
          if (!a.publish_to_site && b.publish_to_site) return 1;
          return new Date(b.created_at || '').getTime() - new Date(a.created_at || '').getTime();
        });
        const totalStock = sorted.reduce((s, x) => s + (Number(x.stock_qty) || 0), 0);
        sorted.forEach(p => processedProductIds.add(p.id));

        const hasCodeConflict = new Set(sorted.map(x => x.code)).size < sorted.length;
        clusters.push({
          key: `barcode-${barcode}`,
          reason: hasCodeConflict ? 'both' : 'barcode',
          identifier: `Cód. de Barras: ${barcode}`,
          items: sorted,
          totalStock,
          keepProduct: sorted[0],
        });
      }
    });

    // 2. Grupos pelo MESMO CÓDIGO INTERNO (que não tenham sido agrupados integralmente por barcode)
    codeMap.forEach((list, code) => {
      if (list.length > 1) {
        const unhandled = list.filter(p => !processedProductIds.has(p.id));
        if (unhandled.length > 1) {
          const sorted = [...unhandled].sort((a, b) => {
            if (a.publish_to_site && !b.publish_to_site) return -1;
            if (!a.publish_to_site && b.publish_to_site) return 1;
            return new Date(b.created_at || '').getTime() - new Date(a.created_at || '').getTime();
          });
          const totalStock = sorted.reduce((s, x) => s + (Number(x.stock_qty) || 0), 0);
          sorted.forEach(p => processedProductIds.add(p.id));
          clusters.push({
            key: `code-${code}`,
            reason: 'code',
            identifier: `Código Interno: ${code}`,
            items: sorted,
            totalStock,
            keepProduct: sorted[0],
          });
        }
      }
    });

    return clusters;
  };

  const handleOpenConsolidateModal = () => {
    const clusters = findDuplicateClusters();
    if (clusters.length === 0) {
      toast.info('Nenhum produto duplicado por código de barras ou código interno foi encontrado.');
      return;
    }
    setDuplicateModal({ open: true, clusters });
  };

  const handleExecuteConsolidation = async () => {
    if (!duplicateModal.clusters.length) return;
    setSubmitting(true);
    let totalMerged = 0;
    try {
      for (const cluster of duplicateModal.clusters) {
        const keep = cluster.keepProduct;
        const others = cluster.items.filter(item => item.id !== keep.id);
        const totalStock = cluster.totalStock;

        // Manter o melhor código de barras e atualizar estoque total
        const bestBarcode = keep.barcode?.trim() || others.find(o => o.barcode?.trim())?.barcode?.trim() || null;
        await supabase.from('pdv_products').update({
          stock_qty: totalStock,
          barcode: bestBarcode,
          updated_at: new Date().toISOString(),
        }).eq('id', keep.id);

        const idsToDelete = others.map(o => o.id);
        if (idsToDelete.length) {
          await supabase.from('pdv_products').delete().in('id', idsToDelete);
        }
        totalMerged += others.length;
      }
      toast.success(`${totalMerged} produto(s) duplicado(s) por código de barras/código interno foram unificados com sucesso!`);
      setDuplicateModal({ open: false, clusters: [] });
      loadAll();
    } catch (err: any) {
      toast.error('Erro ao consolidar duplicados: ' + (err?.message || 'Erro'));
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    const { error } = await supabase.from('pdv_products').delete().eq('id', deleteId);
    if (error) { toast.error('Não é possível excluir produto com movimentações'); }
    else { toast.success('Produto excluído'); loadAll(); }
    setDeleteId(null);
  };

  // ── Publicar no site ──────────────────────────────────────────────────────
  const openPublish = (p: PdvProduct) => {
    setPublishProduct(p);
    setPublishForm({ site_category_id: 'none', image_url: '', is_featured: false });
    setPublishing(false);
  };

  const handlePublish = async () => {
    if (!publishProduct) return;
    setPublishing(true);
    const slug = publishProduct.name.toLowerCase()
      .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') + '-' + Date.now();
    const images = publishForm.image_url ? [{ url: publishForm.image_url, alt: publishProduct.name }] : [];
    const catId = publishForm.site_category_id === 'none' ? null : publishForm.site_category_id;

    let siteProductId = publishProduct.site_product_id;

    if (siteProductId) {
      // Atualizar produto existente no site
      const { error } = await supabase.from('products').update({
        name: publishProduct.name,
        description: publishProduct.description,
        price: publishProduct.sale_price,
        stock_quantity: publishProduct.stock_qty,
        category_id: catId,
        is_featured: publishForm.is_featured,
        is_available: publishProduct.active,
        ...(images.length ? { images } : {}),
        updated_at: new Date().toISOString(),
      }).eq('id', siteProductId);
      if (error) { toast.error('Erro ao atualizar no site: ' + error.message); setPublishing(false); return; }
    } else {
      // Criar novo produto no site
      const { data: newProd, error } = await supabase.from('products').insert({
        name: publishProduct.name,
        slug,
        description: publishProduct.description,
        price: publishProduct.sale_price,
        stock_quantity: publishProduct.stock_qty,
        category_id: catId,
        is_available: publishProduct.active,
        is_featured: publishForm.is_featured,
        images,
        attributes: {},
      }).select('id').maybeSingle();
      if (error || !newProd) { toast.error('Erro ao publicar no site: ' + (error?.message || '')); setPublishing(false); return; }
      siteProductId = newProd.id;
    }

    // Vincular produto PDV ao produto do site
    await supabase.from('pdv_products').update({
      publish_to_site: true,
      site_product_id: siteProductId,
    }).eq('id', publishProduct.id);

    toast.success('Produto publicado no site com sucesso!');
    setPublishProduct(null);
    setPublishing(false);
    loadAll();
  };

  const handleUnpublish = async () => {
    if (!unpublishId) return;
    const p = products.find(x => x.id === unpublishId);
    if (!p) { setUnpublishId(null); return; }
    if (p.site_product_id) {
      await supabase.from('products').update({ is_available: false }).eq('id', p.site_product_id);
    }
    await supabase.from('pdv_products').update({ publish_to_site: false, site_product_id: null }).eq('id', p.id);
    toast.success('Produto removido do site.');
    setUnpublishId(null);
    loadAll();
  };

  // Publicação rápida (1 clique) para produtos fora do site
  const handleQuickPublish = async (p: PdvProduct) => {
    try {
      const slug = p.name.toLowerCase()
        .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
        .replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') + '-' + Date.now();
      
      let siteProductId = p.site_product_id;
      if (siteProductId) {
        await supabase.from('products').update({
          name: p.name,
          description: p.description,
          price: p.sale_price,
          stock_quantity: p.stock_qty,
          is_available: true,
          updated_at: new Date().toISOString(),
        }).eq('id', siteProductId);
      } else {
        const { data: newProd, error } = await supabase.from('products').insert({
          name: p.name,
          slug,
          description: p.description,
          price: p.sale_price,
          stock_quantity: p.stock_qty,
          is_available: true,
          is_featured: false,
          images: [],
          attributes: {},
        }).select('id').maybeSingle();
        if (error || !newProd) throw new Error(error?.message || 'Falha ao criar produto');
        siteProductId = newProd.id;
      }

      await supabase.from('pdv_products').update({
        publish_to_site: true,
        site_product_id: siteProductId,
      }).eq('id', p.id);

      toast.success(`"${p.name}" publicado no site!`);
      loadAll();
    } catch (err: any) {
      toast.error(`Erro ao publicar: ${err?.message || 'Erro'}`);
    }
  };

  // Publicar todos os itens que estão fora do site em lote
  const handleBatchPublishOffSite = async () => {
    const offSiteProducts = products.filter(p => !p.publish_to_site);
    if (!offSiteProducts.length) {
      toast.info('Não há produtos fora do site para publicar.');
      return;
    }
    setBatchPublishing(true);
    let successCount = 0;
    try {
      for (const p of offSiteProducts) {
        const slug = p.name.toLowerCase()
          .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
          .replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') + '-' + Date.now();
        let siteProductId = p.site_product_id;
        if (siteProductId) {
          await supabase.from('products').update({
            name: p.name,
            description: p.description,
            price: p.sale_price,
            stock_quantity: p.stock_qty,
            is_available: true,
            updated_at: new Date().toISOString(),
          }).eq('id', siteProductId);
        } else {
          const { data: newProd } = await supabase.from('products').insert({
            name: p.name,
            slug,
            description: p.description,
            price: p.sale_price,
            stock_quantity: p.stock_qty,
            is_available: true,
            is_featured: false,
            images: [],
            attributes: {},
          }).select('id').maybeSingle();
          if (newProd) siteProductId = newProd.id;
        }
        if (siteProductId) {
          await supabase.from('pdv_products').update({
            publish_to_site: true,
            site_product_id: siteProductId,
          }).eq('id', p.id);
          successCount++;
        }
      }
      toast.success(`${successCount} produto(s) publicados no site com sucesso!`);
      loadAll();
    } catch (err: any) {
      toast.error('Erro ao processar lote: ' + err.message);
    } finally {
      setBatchPublishing(false);
    }
  };

  const totalCount = products.length;
  const onSiteCount = products.filter(p => p.publish_to_site).length;
  const offSiteCount = products.filter(p => !p.publish_to_site).length;

  // ── Identificação de Duplicidades na Lista Atual (por Barcode ou Code) ─────
  const duplicateBarcodeSet = new Set<string>();
  const duplicateCodeSet = new Set<string>();

  const bCounts = new Map<string, number>();
  const cCounts = new Map<string, number>();
  products.forEach(p => {
    const b = p.barcode?.trim();
    if (b) bCounts.set(b, (bCounts.get(b) || 0) + 1);
    const c = p.code?.trim();
    if (c) cCounts.set(c, (cCounts.get(c) || 0) + 1);
  });
  bCounts.forEach((count, b) => { if (count > 1) duplicateBarcodeSet.add(b); });
  cCounts.forEach((count, c) => { if (count > 1) duplicateCodeSet.add(c); });

  const getProductDuplicateStatus = (p: PdvProduct) => {
    const hasBarDup = p.barcode?.trim() ? duplicateBarcodeSet.has(p.barcode.trim()) : false;
    const hasCodeDup = p.code?.trim() ? duplicateCodeSet.has(p.code.trim()) : false;
    if (hasBarDup && hasCodeDup) return { isDup: true, label: 'Código e Cód. Barras Duplicados', type: 'both' as const };
    if (hasBarDup) return { isDup: true, label: 'Mesmo Código de Barras', type: 'barcode' as const };
    if (hasCodeDup) return { isDup: true, label: 'Mesmo Código Interno', type: 'code' as const };
    return { isDup: false, label: '', type: null };
  };

  const duplicateProductsCount = products.filter(p => getProductDuplicateStatus(p).isDup).length;

  const filtered = products.filter(p => {
    const s = search.toLowerCase();
    const matchSearch = !search || 
      p.name.toLowerCase().includes(s) || 
      p.code.toLowerCase().includes(s) || 
      (p.barcode && p.barcode.toLowerCase().includes(s));
    const matchCat = catFilter === 'all' || p.category_id === catFilter;
    const matchSite = 
      siteFilter === 'all' ||
      (siteFilter === 'on_site' && p.publish_to_site) ||
      (siteFilter === 'off_site' && !p.publish_to_site);
    const matchDups = !onlyDuplicatesFilter || getProductDuplicateStatus(p).isDup;
    return matchSearch && matchCat && matchSite && matchDups;
  });

  const setFormField = (k: string, v: string | boolean) => {
    setForm(prev => {
      const next = { ...prev, [k]: v };
      if (k === 'cost_price' || k === 'sale_price') {
        const cost = parseFloat(String(next.cost_price)) || 0;
        const sale = parseFloat(String(next.sale_price)) || 0;
        if (cost > 0 && sale > 0) {
          next.markup_percent = String(Math.round(((sale - cost) / cost) * 100 * 100) / 100);
          next.margin_percent = String(Math.round(((sale - cost) / sale) * 100 * 100) / 100);
        }
      }
      if (k === 'markup_percent') {
        const cost = parseFloat(String(next.cost_price)) || 0;
        const mk = parseFloat(String(next.markup_percent)) || 0;
        if (cost > 0) {
          const sale = cost * (1 + mk / 100);
          next.sale_price = String(Math.round(sale * 100) / 100);
          next.margin_percent = String(Math.round(((sale - cost) / sale) * 100 * 100) / 100);
        }
      }
      if (k === 'margin_percent') {
        const cost = parseFloat(String(next.cost_price)) || 0;
        const mg = parseFloat(String(next.margin_percent)) || 0;
        if (cost > 0 && mg < 100) {
          const sale = cost / (1 - mg / 100);
          next.sale_price = String(Math.round(sale * 100) / 100);
          next.markup_percent = String(Math.round(((sale - cost) / cost) * 100 * 100) / 100);
        }
      }
      return next;
    });
  };

  const f = (k: string, v: string | boolean) => setFormField(k, v);

  return (
    <PdvLayout title="Produtos" actions={<Button size="sm" onClick={openCreate}><Plus className="h-4 w-4 mr-1.5" />Novo Produto</Button>}>
      {/* Cards de Status de Visibilidade no Site */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-5">
        <button
          type="button"
          onClick={() => setSiteFilter('all')}
          className={`flex items-center justify-between p-3.5 rounded-lg border text-left transition-all ${
            siteFilter === 'all'
              ? 'bg-primary/10 border-primary shadow-sm ring-1 ring-primary/30'
              : 'bg-card border-border hover:bg-muted/40'
          }`}
        >
          <div className="space-y-0.5">
            <span className="text-xs font-medium text-muted-foreground">Total de Produtos</span>
            <p className="text-xl font-bold text-foreground">{totalCount}</p>
          </div>
          <div className="p-2 rounded-md bg-muted text-muted-foreground">
            <Package className="h-4 w-4" />
          </div>
        </button>

        <button
          type="button"
          onClick={() => setSiteFilter('on_site')}
          className={`flex items-center justify-between p-3.5 rounded-lg border text-left transition-all ${
            siteFilter === 'on_site'
              ? 'bg-emerald-500/10 border-emerald-500 shadow-sm ring-1 ring-emerald-500/30'
              : 'bg-card border-border hover:bg-muted/40'
          }`}
        >
          <div className="space-y-0.5">
            <span className="text-xs font-medium text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
              <Globe className="h-3.5 w-3.5" /> No Site (Publicados)
            </span>
            <p className="text-xl font-bold text-emerald-700 dark:text-emerald-400">{onSiteCount}</p>
          </div>
          <Badge className="bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border-0 text-xs">
            {totalCount > 0 ? Math.round((onSiteCount / totalCount) * 100) : 0}%
          </Badge>
        </button>

        <button
          type="button"
          onClick={() => setSiteFilter('off_site')}
          className={`flex items-center justify-between p-3.5 rounded-lg border text-left transition-all ${
            siteFilter === 'off_site'
              ? 'bg-amber-500/15 border-amber-500 shadow-sm ring-1 ring-amber-500/40'
              : 'bg-card border-border hover:bg-amber-500/5'
          }`}
        >
          <div className="space-y-0.5">
            <span className="text-xs font-semibold text-amber-700 dark:text-amber-400 flex items-center gap-1">
              <GlobeOff className="h-3.5 w-3.5 text-amber-600" /> Fora do Site (Pendentes)
            </span>
            <p className="text-xl font-bold text-amber-700 dark:text-amber-400">{offSiteCount}</p>
          </div>
          {offSiteCount > 0 ? (
            <Badge variant="outline" className="bg-amber-500/20 text-amber-800 dark:text-amber-300 border-amber-500/40 font-bold text-xs">
              Atenção: {offSiteCount}
            </Badge>
          ) : (
            <Badge variant="outline" className="bg-muted text-muted-foreground text-xs">0</Badge>
          )}
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-2 mb-4">
        <div className="relative flex-1 min-w-[180px]">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Buscar por nome ou código..." value={search} onChange={e => setSearch(e.target.value)} className="pl-8 h-9 text-xs" />
        </div>

        <Select value={siteFilter} onValueChange={(v: 'all' | 'on_site' | 'off_site') => setSiteFilter(v)}>
          <SelectTrigger className="w-full sm:w-44 md:w-48 h-9 text-xs shrink-0">
            <SelectValue placeholder="Status no Site" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos ({totalCount})</SelectItem>
            <SelectItem value="on_site">No Site ({onSiteCount})</SelectItem>
            <SelectItem value="off_site">Fora do Site ({offSiteCount})</SelectItem>
          </SelectContent>
        </Select>

        <Select value={catFilter} onValueChange={setCatFilter}>
          <SelectTrigger className="w-full sm:w-36 md:w-40 h-9 text-xs shrink-0"><SelectValue placeholder="Categoria" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todas as categorias</SelectItem>
            {categories.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
          </SelectContent>
        </Select>

        {duplicateProductsCount > 0 && (
          <Button
            variant={onlyDuplicatesFilter ? 'destructive' : 'outline'}
            size="sm"
            onClick={() => setOnlyDuplicatesFilter(!onlyDuplicatesFilter)}
            className="h-9 text-xs shrink-0 gap-1.5 px-2.5"
            title="Filtrar apenas produtos que possuem código de barras ou código interno duplicados"
          >
            <AlertTriangle className="h-3.5 w-3.5 text-amber-500" />
            Duplicados ({duplicateProductsCount})
          </Button>
        )}

        <Button
          variant="outline"
          size="sm"
          onClick={handleGenerateMissingBarcodes}
          disabled={generatingBarcodes}
          className="h-9 text-xs shrink-0 gap-1.5 px-2.5"
          title="Gera códigos de barras EAN-13 para todos os produtos do PDV e do site que ainda estão sem código"
        >
          {generatingBarcodes ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Barcode className="h-3.5 w-3.5" />}
          Gerar Códigos de Barras
        </Button>

        <Button
          variant="outline"
          size="sm"
          onClick={handleOpenConsolidateModal}
          disabled={submitting}
          className="h-9 text-xs shrink-0 gap-1.5 px-2.5 border-amber-500/40 hover:bg-amber-500/10 text-amber-700 dark:text-amber-400 font-medium"
          title="Detectar e unificar produtos duplicados com mesmo código de barras ou mesmo código interno"
        >
          <Merge className="h-3.5 w-3.5 text-amber-600" />
          Consolidar {duplicateProductsCount > 0 && `(${duplicateProductsCount})`}
        </Button>
      </div>

      {/* Aviso contextual quando filtrado por "Fora do Site" */}
      {siteFilter === 'off_site' && (
        <div className="mb-4 rounded-lg border border-amber-500/30 bg-amber-500/10 p-3 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-sm">
          <div className="flex items-center gap-2 text-amber-800 dark:text-amber-300">
            <AlertTriangle className="h-4 w-4 shrink-0 text-amber-600" />
            <p className="text-xs sm:text-sm font-medium">
              Exibindo <strong>{filtered.length} produto(s)</strong> do estoque/PDV que <strong>NÃO estão publicados</strong> no site/catálogo online.
            </p>
          </div>
          {filtered.length > 0 && (
            <Button
              size="sm"
              onClick={handleBatchPublishOffSite}
              disabled={batchPublishing}
              className="bg-amber-600 hover:bg-amber-700 text-white shrink-0 gap-1.5 text-xs h-8"
            >
              {batchPublishing ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Sparkles className="h-3.5 w-3.5" />}
              Publicar Todos no Site ({filtered.length})
            </Button>
          )}
        </div>
      )}

      {/* Table */}
      <div className="bg-card border border-border rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-border bg-muted/40">
                <th className="text-left px-2.5 py-2 font-medium text-muted-foreground whitespace-nowrap">Código</th>
                <th className="text-left px-2.5 py-2 font-medium text-muted-foreground whitespace-nowrap">Nome</th>
                <th className="text-left px-2 py-2 font-medium text-muted-foreground whitespace-nowrap" title="Categoria do Produto">Cat.</th>
                <th className="text-right px-2 py-2 font-medium text-muted-foreground whitespace-nowrap">Custo</th>
                <th className="text-right px-2 py-2 font-medium text-muted-foreground whitespace-nowrap">Venda</th>
                <th className="text-right px-2 py-2 font-medium text-muted-foreground whitespace-nowrap">Markup</th>
                <th className="text-right px-2 py-2 font-medium text-muted-foreground whitespace-nowrap">Margem</th>
                <th className="text-right px-2 py-2 font-medium text-muted-foreground whitespace-nowrap">Estoque</th>
                <th className="text-center px-1.5 py-2 font-medium text-muted-foreground whitespace-nowrap">Status</th>
                <th className="text-center px-1.5 py-2 font-medium text-muted-foreground whitespace-nowrap">No Site</th>
                <th className="text-right px-2.5 py-2 font-medium text-muted-foreground whitespace-nowrap">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {loading ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <tr key={i}><td colSpan={11} className="px-2.5 py-2"><Skeleton className="h-5 w-full bg-muted" /></td></tr>
                ))
              ) : filtered.length === 0 ? (
                <tr><td colSpan={11} className="text-center py-10 text-muted-foreground">
                  <Package className="h-7 w-7 mx-auto mb-1.5 opacity-40" />
                  <p className="text-pretty text-xs">Nenhum produto encontrado</p>
                </td></tr>
              ) : filtered.map(p => {
                const dupStatus = getProductDuplicateStatus(p);
                return (
                  <tr key={p.id} className="hover:bg-muted/30 transition-colors">
                    <td className="px-2.5 py-1.5 font-mono text-[11px] whitespace-nowrap">
                      <div>
                        <span className="font-semibold text-foreground/90">{p.code}</span>
                        {dupStatus.isDup && (
                          <div className="mt-0.5">
                            <Badge
                              variant="outline"
                              className="text-[8px] px-1 py-0 bg-amber-500/15 text-amber-700 dark:text-amber-300 border-amber-500/40 font-semibold gap-0.5 inline-flex items-center leading-tight"
                              title={dupStatus.label}
                            >
                              <AlertTriangle className="h-2 w-2 text-amber-600 shrink-0" />
                              {dupStatus.type === 'barcode' ? 'Barras Dupl.' : dupStatus.type === 'both' ? 'Barras+Cód' : 'Cód. Dupl.'}
                            </Badge>
                          </div>
                        )}
                      </div>
                    </td>
                    <td className="px-2.5 py-1.5 whitespace-nowrap max-w-[160px] md:max-w-[200px]">
                      <p className="font-medium text-foreground truncate text-xs" title={p.name}>{p.name}</p>
                      {p.barcode && (
                        <p className="text-[10px] text-muted-foreground flex items-center gap-1 font-mono leading-tight">
                          <span className="truncate">{p.barcode}</span>
                          {duplicateBarcodeSet.has(p.barcode.trim()) && (
                            <span className="text-[9px] text-amber-600 font-semibold shrink-0">(Duplicado)</span>
                          )}
                        </p>
                      )}
                    </td>
                    <td className="px-2 py-1.5 whitespace-nowrap">
                      {p.pdv_categories ? (
                        <span
                          className="inline-block max-w-[85px] sm:max-w-[95px] truncate text-[10px] font-medium px-1.5 py-0.5 rounded border leading-tight"
                          style={{ borderColor: p.pdv_categories.color + '40', color: p.pdv_categories.color, background: p.pdv_categories.color + '15' }}
                          title={p.pdv_categories.name}
                        >
                          {p.pdv_categories.name}
                        </span>
                      ) : <span className="text-muted-foreground text-[11px]">—</span>}
                    </td>
                    <td className="px-2 py-1.5 text-right whitespace-nowrap text-muted-foreground text-[11px]">R$ {p.cost_price.toFixed(2)}</td>
                    <td className="px-2 py-1.5 text-right whitespace-nowrap font-semibold text-foreground text-xs">R$ {p.sale_price.toFixed(2)}</td>
                    <td className="px-2 py-1.5 text-right whitespace-nowrap text-muted-foreground text-[11px]">{p.markup_percent.toFixed(1)}%</td>
                    <td className="px-2 py-1.5 text-right whitespace-nowrap text-muted-foreground text-[11px]">{p.margin_percent.toFixed(1)}%</td>
                    <td className="px-2 py-1.5 text-right whitespace-nowrap text-xs">
                      <span className={p.stock_qty <= p.stock_min ? 'text-destructive font-semibold' : 'text-foreground'}>
                        {p.stock_qty} {p.unit}
                      </span>
                    </td>
                    <td className="px-1.5 py-1.5 text-center whitespace-nowrap">
                      <Badge variant={p.active ? 'default' : 'secondary'} className="text-[9px] px-1.5 py-0 h-4 leading-none font-medium">
                        {p.active ? 'Ativo' : 'Inativo'}
                      </Badge>
                    </td>
                    <td className="px-1.5 py-1.5 text-center whitespace-nowrap">
                      {p.publish_to_site ? (
                        <Badge
                          className="text-[9px] px-1.5 py-0 h-4 bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border border-emerald-500/30 gap-0.5 font-medium cursor-pointer hover:bg-emerald-500/25 transition-colors leading-none"
                          onClick={() => setUnpublishId(p.id)}
                          title="Clique para remover do catálogo online"
                        >
                          <Globe className="h-2.5 w-2.5" /> No Site
                        </Badge>
                      ) : (
                        <div className="flex items-center justify-center gap-1">
                          <Badge
                            variant="outline"
                            className="text-[9px] px-1.5 py-0 h-4 bg-amber-500/10 text-amber-700 dark:text-amber-400 border-amber-500/30 gap-0.5 font-medium leading-none"
                          >
                            <GlobeOff className="h-2.5 w-2.5 text-amber-600" /> Fora
                          </Badge>
                          <Button
                            variant="outline"
                            size="sm"
                            className="h-4 text-[9px] text-primary border-primary/30 hover:bg-primary/10 px-1 py-0 font-medium leading-none"
                            onClick={() => handleQuickPublish(p)}
                            title="Publicar agora no catálogo online com 1 clique"
                          >
                            Publicar
                          </Button>
                        </div>
                      )}
                    </td>
                    <td className="px-2.5 py-1.5 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-0.5">
                        {p.publish_to_site && (
                          <Button variant="ghost" size="icon" className="h-6 w-6 text-primary hover:bg-primary/10" title="Atualizar no site" onClick={() => openPublish(p)}>
                            <Globe className="h-3 w-3" />
                          </Button>
                        )}
                        <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => openEdit(p)} title="Editar produto"><Pencil className="h-3 w-3" /></Button>
                        <Button variant="ghost" size="icon" className="h-6 w-6 text-destructive hover:bg-destructive/10" onClick={() => setDeleteId(p.id)} title="Excluir produto"><Trash2 className="h-3 w-3" /></Button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Product Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl max-h-[90dvh] overflow-y-auto">
          <DialogHeader><DialogTitle className="text-balance">{editing ? 'Editar Produto' : 'Novo Produto'}</DialogTitle></DialogHeader>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-2">
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Código {editing ? '*' : '(auto se vazio)'}</Label>
              <div className="flex gap-2">
                <Input value={form.code} onChange={e => f('code', e.target.value)} placeholder={editing ? 'Ex: DET001' : 'Deixe vazio para gerar automaticamente'} className="flex-1 min-w-0" />
                <Button type="button" variant="outline" size="icon" className="shrink-0 h-9 w-9" title="Gerar código automático a partir do nome"
                  onClick={() => {
                    if (!form.name.trim()) { return; }
                    f('code', generateUniqueCode(form.name));
                  }}>
                  <RefreshCw className="h-4 w-4" />
                </Button>
              </div>
              {!form.name.trim() && <p className="text-[10px] text-muted-foreground">Preencha o nome primeiro para gerar o código</p>}
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Código de Barras</Label>
              <Input value={form.barcode} onChange={e => f('barcode', e.target.value)} placeholder="EAN-13" />
            </div>
            <div className="space-y-1.5 md:col-span-2">
              <Label className="text-sm font-normal">Nome *</Label>
              <Input value={form.name} onChange={e => f('name', e.target.value)} placeholder="Nome do produto" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Categoria</Label>
              <Select value={form.category_id || 'none'} onValueChange={v => f('category_id', v === 'none' ? '' : v)}>
                <SelectTrigger><SelectValue placeholder="Selecionar" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Sem categoria</SelectItem>
                  {categories.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Unidade</Label>
              <Select value={form.unit} onValueChange={v => f('unit', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{UNITS.map(u => <SelectItem key={u} value={u}>{u}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Preço de Custo (R$)</Label>
              <Input type="number" min="0" step="0.01" value={form.cost_price} onChange={e => f('cost_price', e.target.value)} placeholder="0,00" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Preço de Venda (R$) *</Label>
              <Input type="number" min="0" step="0.01" value={form.sale_price} onChange={e => f('sale_price', e.target.value)} placeholder="0,00" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Markup (%)</Label>
              <Input type="number" min="-999" step="0.01" value={form.markup_percent} onChange={e => f('markup_percent', e.target.value)} placeholder="0,00" />
              <p className="text-[10px] text-muted-foreground">Sobre o custo</p>
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Margem (%)</Label>
              <Input type="number" min="-999" max="99.99" step="0.01" value={form.margin_percent} onChange={e => f('margin_percent', e.target.value)} placeholder="0,00" />
              <p className="text-[10px] text-muted-foreground">Sobre o preço de venda</p>
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Estoque Atual</Label>
              <Input type="number" min="0" step="0.001" value={form.stock_qty} onChange={e => f('stock_qty', e.target.value)} placeholder="0" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Estoque Mínimo</Label>
              <Input type="number" min="0" step="0.001" value={form.stock_min} onChange={e => f('stock_min', e.target.value)} placeholder="5" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">NCM</Label>
              <Input value={form.ncm} onChange={e => f('ncm', e.target.value)} placeholder="Ex: 34022000" maxLength={8} />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">CEST</Label>
              <Input value={form.cest} onChange={e => f('cest', e.target.value)} placeholder="Ex: 2806300" maxLength={7} />
            </div>

            {/* Preços Atacado / Varejo */}
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Preço Atacado (R$)</Label>
              <Input type="number" min="0" step="0.01" value={form.wholesale_price} onChange={e => f('wholesale_price', e.target.value)} placeholder="0,00" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Preço Varejo (R$)</Label>
              <Input type="number" min="0" step="0.01" value={form.retail_price} onChange={e => f('retail_price', e.target.value)} placeholder="0,00" />
            </div>

            {/* Fração */}
            <div className="flex items-center gap-2 md:col-span-2">
              <input type="checkbox" id="is_fraction" checked={form.is_fraction as boolean} onChange={e => f('is_fraction', e.target.checked)} className="h-4 w-4 rounded border-border" />
              <Label htmlFor="is_fraction" className="text-sm font-normal cursor-pointer">Produto vendido por fração (peso, medida)</Label>
            </div>
            {form.is_fraction && (
              <div className="space-y-1.5 md:col-span-2">
                <Label className="text-sm font-normal">Unidade de Fração</Label>
                <Select value={form.fraction_unit} onValueChange={v => f('fraction_unit', v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{FRACTION_UNITS.map(u => <SelectItem key={u} value={u}>{u}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            )}

            <div className="space-y-1.5 md:col-span-2">
              <Label className="text-sm font-normal">Descrição</Label>
              <Textarea value={form.description} onChange={e => f('description', e.target.value)} placeholder="Descrição opcional do produto" rows={2} />
            </div>
            <div className="flex items-center gap-2 md:col-span-2">
              <input type="checkbox" id="active" checked={form.active as boolean} onChange={e => f('active', e.target.checked)} className="h-4 w-4 rounded border-border" />
              <Label htmlFor="active" className="text-sm font-normal cursor-pointer">Produto ativo</Label>
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setShowDialog(false)}>Cancelar</Button>
            <Button onClick={handleSave} disabled={submitting}>
              {submitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />} Salvar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete confirm */}
      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-balance">Excluir produto?</AlertDialogTitle>
            <AlertDialogDescription className="text-pretty">Produtos com movimentações de estoque não podem ser excluídos.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive hover:bg-destructive/90">Excluir</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Publicar no Site Dialog */}
      <Dialog open={!!publishProduct} onOpenChange={open => { if (!open) setPublishProduct(null); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-balance flex items-center gap-2">
              <Globe className="h-4 w-4 text-primary" />
              {publishProduct?.publish_to_site ? 'Atualizar no Site' : 'Publicar no Site'}
            </DialogTitle>
          </DialogHeader>
          {publishProduct && (
            <div className="space-y-4 py-1">
              <div className="rounded-lg bg-muted/40 border border-border px-4 py-3 space-y-0.5">
                <p className="text-sm font-semibold text-foreground">{publishProduct.name}</p>
                <p className="text-xs text-muted-foreground">Código: {publishProduct.code} · Preço: R$ {publishProduct.sale_price.toFixed(2)}</p>
              </div>

              <div className="space-y-1.5">
                <Label className="text-sm font-normal">Categoria do site</Label>
                <Select value={publishForm.site_category_id} onValueChange={v => setPublishForm(f => ({ ...f, site_category_id: v }))}>
                  <SelectTrigger><SelectValue placeholder="Selecionar categoria" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Sem categoria</SelectItem>
                    {siteCategories.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-1.5">
                <Label className="text-sm font-normal">URL da imagem (opcional)</Label>
                <Input
                  value={publishForm.image_url}
                  onChange={e => setPublishForm(f => ({ ...f, image_url: e.target.value }))}
                  placeholder="https://exemplo.com/imagem.jpg"
                />
              </div>

              <div className="flex items-center gap-3">
                <Switch
                  checked={publishForm.is_featured}
                  onCheckedChange={v => setPublishForm(f => ({ ...f, is_featured: v }))}
                  id="is_featured_pub"
                />
                <Label htmlFor="is_featured_pub" className="text-sm font-normal cursor-pointer">Destacar na loja</Label>
              </div>
            </div>
          )}
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setPublishProduct(null)}>Cancelar</Button>
            <Button onClick={handlePublish} disabled={publishing} className="bg-primary text-primary-foreground hover:bg-primary/90">
              {publishing && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              {publishProduct?.publish_to_site ? 'Atualizar no Site' : 'Publicar no Site'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Merge duplicate dialog */}
      <Dialog open={mergeDialog.open} onOpenChange={open => setMergeDialog(m => ({ ...m, open }))}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-balance flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-amber-500 shrink-0" />
              {mergeDialog.reason === 'barcode'
                ? 'Código de Barras Já Existe'
                : mergeDialog.reason === 'both'
                ? 'Código e Código de Barras Já Existem'
                : 'Código Interno Já Existe'}
            </DialogTitle>
          </DialogHeader>
          <div className="text-sm text-muted-foreground text-pretty space-y-1">
            {mergeDialog.reason === 'barcode' && (
              <p>
                O código de barras (EAN) <strong className="font-mono text-foreground font-semibold">"{mergeDialog.barcode}"</strong> já está cadastrado no produto <strong className="text-foreground">"{mergeDialog.existingName}"</strong> (Código: {mergeDialog.code}).
              </p>
            )}
            {mergeDialog.reason === 'both' && (
              <p>
                Tanto o código <strong className="font-mono text-foreground font-semibold">"{mergeDialog.code}"</strong> quanto o código de barras <strong className="font-mono text-foreground font-semibold">"{mergeDialog.barcode}"</strong> já pertencem ao produto <strong className="text-foreground">"{mergeDialog.existingName}"</strong>.
              </p>
            )}
            {mergeDialog.reason === 'code' && (
              <p>
                O código <strong className="font-mono text-foreground font-semibold">"{mergeDialog.code}"</strong> já pertence ao produto <strong className="text-foreground">"{mergeDialog.existingName}"</strong>.
              </p>
            )}
            <p className="text-xs pt-1">Escolha como deseja prosseguir com este item:</p>
          </div>
          <div className="space-y-2 py-2">
            <button
              type="button"
              onClick={handleMergeOverwrite}
              disabled={submitting}
              className="w-full text-left p-3 rounded-lg border border-border hover:bg-muted/60 transition-colors flex items-start gap-3"
            >
              <Pencil className="h-5 w-5 text-primary shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-sm">Sobrescrever existente</p>
                <p className="text-xs text-muted-foreground">Atualiza todos os dados do produto "{mergeDialog.existingName}" com as informações deste formulário.</p>
              </div>
            </button>
            <button
              type="button"
              onClick={handleMergeAddStock}
              disabled={submitting}
              className="w-full text-left p-3 rounded-lg border border-border hover:bg-muted/60 transition-colors flex items-start gap-3"
            >
              <Plus className="h-5 w-5 text-success shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-sm">Somar estoque</p>
                <p className="text-xs text-muted-foreground">Adiciona o estoque deste formulário ao produto "{mergeDialog.existingName}". Mantém os dados atuais.</p>
              </div>
            </button>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setMergeDialog(m => ({ ...m, open: false }))}>Cancelar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal avançado de Consolidação de Produtos Duplicados */}
      <Dialog open={duplicateModal.open} onOpenChange={open => setDuplicateModal(m => ({ ...m, open }))}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-balance flex items-center gap-2">
              <Merge className="h-5 w-5 text-amber-600" />
              Consolidação de Produtos Duplicados
            </DialogTitle>
          </DialogHeader>

          <p className="text-xs sm:text-sm text-muted-foreground text-pretty">
            Foram encontrados <strong>{duplicateModal.clusters.length} grupo(s)</strong> de produtos com o <strong>mesmo código de barras</strong> ou <strong>mesmo código interno</strong>. Ao unificar, o estoque total será somado no produto principal e os itens duplicados serão integrados.
          </p>

          <div className="space-y-4 my-2">
            {duplicateModal.clusters.map((cluster, idx) => (
              <div key={cluster.key} className="rounded-lg border border-border p-3.5 bg-card/60 space-y-2.5">
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-border pb-2">
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="bg-amber-500/15 text-amber-700 dark:text-amber-300 border-amber-500/30 text-xs font-semibold gap-1">
                      <AlertTriangle className="h-3 w-3 text-amber-600" />
                      {cluster.reason === 'barcode' ? 'Mesmo Código de Barras' : cluster.reason === 'both' ? 'Barras e Código Conflitantes' : 'Mesmo Código Interno'}
                    </Badge>
                    <span className="font-mono text-xs font-medium text-foreground">{cluster.identifier}</span>
                  </div>
                  <span className="text-xs text-muted-foreground">
                    Grupo #{idx + 1} ({cluster.items.length} itens)
                  </span>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="text-muted-foreground border-b border-border/50 text-left">
                        <th className="pb-1.5 font-medium">Papel</th>
                        <th className="pb-1.5 font-medium">Produto</th>
                        <th className="pb-1.5 font-medium">Código</th>
                        <th className="pb-1.5 font-medium">Cód. Barras</th>
                        <th className="pb-1.5 font-medium text-right">Estoque</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border/30">
                      {cluster.items.map(item => {
                        const isPrincipal = item.id === cluster.keepProduct.id;
                        return (
                          <tr key={item.id} className={isPrincipal ? 'bg-primary/5 font-medium' : 'text-muted-foreground'}>
                            <td className="py-1.5 whitespace-nowrap">
                              {isPrincipal ? (
                                <Badge className="text-[10px] bg-primary/20 text-primary border-0 font-semibold">Principal (Manter)</Badge>
                              ) : (
                                <Badge variant="outline" className="text-[10px] bg-muted text-muted-foreground">Unificar e Remover</Badge>
                              )}
                            </td>
                            <td className="py-1.5 whitespace-nowrap text-foreground">{item.name}</td>
                            <td className="py-1.5 whitespace-nowrap font-mono">{item.code}</td>
                            <td className="py-1.5 whitespace-nowrap font-mono">{item.barcode || '—'}</td>
                            <td className="py-1.5 whitespace-nowrap text-right font-semibold text-foreground">
                              {item.stock_qty} {item.unit}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>

                <div className="flex items-center justify-between text-xs pt-1 border-t border-border/40 text-muted-foreground">
                  <span>Estoque unificado resultante:</span>
                  <span className="font-bold text-foreground text-sm">
                    {cluster.totalStock} {cluster.keepProduct.unit}
                  </span>
                </div>
              </div>
            ))}
          </div>

          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="outline" onClick={() => setDuplicateModal(m => ({ ...m, open: false }))}>
              Cancelar
            </Button>
            <Button
              onClick={handleExecuteConsolidation}
              disabled={submitting}
              className="bg-amber-600 hover:bg-amber-700 text-white gap-1.5"
            >
              {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Merge className="h-4 w-4" />}
              Confirmar e Unificar Todos os Duplicados
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Despublicar confirm */}
      <AlertDialog open={!!unpublishId} onOpenChange={open => { if (!open) setUnpublishId(null); }}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-balance flex items-center gap-2">
              <GlobeOff className="h-4 w-4 text-destructive" /> Remover do site?
            </AlertDialogTitle>
            <AlertDialogDescription className="text-pretty">
              O produto será ocultado da loja online. Você pode publicá-lo novamente a qualquer momento.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleUnpublish} className="bg-destructive hover:bg-destructive/90">Remover do Site</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </PdvLayout>
  );
}
