import { useEffect, useState } from 'react';
import { Search, ArrowUp, ArrowDown, RotateCcw, Shuffle } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Skeleton } from '@/components/ui/skeleton';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { PdvLayout } from '@/components/layouts/PdvLayout';
import { supabase } from '@/db/supabase';

interface Movement {
  id: string; product_id: string; type: string; quantity: number;
  previous_qty: number; new_qty: number; notes: string | null;
  reference_type: string | null; created_at: string;
  pdv_products?: { name: string; code: string; barcode?: string | null; } | null;
}

const TYPE_INFO: Record<string, { label: string; icon: React.ElementType; color: string }> = {
  entrada: { label: 'Entrada', icon: ArrowUp, color: 'text-success' },
  saida: { label: 'Saída', icon: ArrowDown, color: 'text-destructive' },
  ajuste: { label: 'Ajuste', icon: Shuffle, color: 'text-primary' },
  venda: { label: 'Venda', icon: ArrowDown, color: 'text-warning' },
  devolucao: { label: 'Devolução', icon: RotateCcw, color: 'text-info-foreground' },
  return: { label: 'Devolução', icon: RotateCcw, color: 'text-info-foreground' },
};

export default function PdvRastreabilidade() {
  const [movements, setMovements] = useState<Movement[]>([]);
  const [products, setProducts] = useState<{ id: string; name: string; code: string; barcode?: string | null; }[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState('all');
  const [search, setSearch] = useState('');

  useEffect(() => { loadProducts(); }, []);
  useEffect(() => { loadMovements(); }, [selectedProduct]);

  const loadProducts = async () => {
    const { data } = await supabase.from('pdv_products').select('id,name,code').order('name').limit(200);
    setProducts(data || []);
  };

  const loadMovements = async () => {
    setLoading(true);
    let q = supabase.from('pdv_stock_movements').select('*, pdv_products(name,code)').order('created_at', { ascending: false }).limit(200);
    if (selectedProduct !== 'all') q = q.eq('product_id', selectedProduct);
    const { data } = await q;
    setMovements((data as Movement[]) || []);
    setLoading(false);
  };

  const filtered = movements.filter(m => {
    if (!search) return true;
    const s = search.toLowerCase();
    return (m.pdv_products?.name || '').toLowerCase().includes(s) || (m.pdv_products?.code || '').includes(s) || (m.pdv_products?.barcode || '').includes(s) || (m.notes || '').toLowerCase().includes(s);
  });

  return (
    <PdvLayout title="Rastreabilidade de Produtos">
      <div className="space-y-4">
        <div className="flex flex-col md:flex-row gap-3">
          <div className="relative flex-1 md:max-w-xs">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
            <Input className="pl-9" placeholder="Buscar produto ou código..." value={search} onChange={e => setSearch(e.target.value)} />
          </div>
          <div className="md:w-64">
            <Select value={selectedProduct} onValueChange={setSelectedProduct}>
              <SelectTrigger><SelectValue placeholder="Filtrar produto" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os produtos</SelectItem>
                {products.map(p => <SelectItem key={p.id} value={p.id}>{p.name} ({p.code})</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="bg-muted/40 border border-border rounded-lg p-3 text-sm text-muted-foreground">
          <strong className="text-foreground">{filtered.length}</strong> movimentações encontradas
        </div>

        <div className="bg-card border border-border rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead><tr className="border-b border-border bg-muted/40">
                <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Data/Hora</th>
                <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Produto</th>
                <th className="text-center px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Tipo</th>
                <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Qtd</th>
                <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Ant.</th>
                <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Novo</th>
                <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Ref.</th>
                <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Observação</th>
              </tr></thead>
              <tbody className="divide-y divide-border">
                {loading ? Array.from({ length: 8 }).map((_, i) => (
                  <tr key={i}><td colSpan={8} className="px-4 py-3"><Skeleton className="h-5 w-full bg-muted" /></td></tr>
                )) : filtered.length === 0 ? (
                  <tr><td colSpan={8} className="text-center py-12 text-muted-foreground">
                    <Search className="h-8 w-8 mx-auto mb-2 opacity-40" />
                    <p className="text-pretty">Nenhuma movimentação encontrada</p>
                  </td></tr>
                ) : filtered.map(m => {
                  const ti = TYPE_INFO[m.type] || { label: m.type, icon: Shuffle, color: 'text-foreground' };
                  const isPositive = m.new_qty > m.previous_qty;
                  return (
                    <tr key={m.id} className="hover:bg-muted/30">
                      <td className="px-4 py-3 whitespace-nowrap text-muted-foreground text-xs">
                        <p>{new Date(m.created_at).toLocaleDateString('pt-BR')}</p>
                        <p>{new Date(m.created_at).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</p>
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <p className="font-medium">{m.pdv_products?.name || '—'}</p>
                        <p className="text-xs text-muted-foreground font-mono">{m.pdv_products?.code}</p>
                      </td>
                      <td className="px-4 py-3 text-center whitespace-nowrap">
                        <span className={`inline-flex items-center gap-1 text-xs font-medium ${ti.color}`}>
                          <ti.icon className="h-3.5 w-3.5" />{ti.label}
                        </span>
                      </td>
                      <td className={`px-4 py-3 text-right font-bold whitespace-nowrap ${isPositive ? 'text-success' : 'text-destructive'}`}>
                        {isPositive ? '+' : '-'}{Math.abs(m.quantity)}
                      </td>
                      <td className="px-4 py-3 text-right text-muted-foreground whitespace-nowrap">{m.previous_qty}</td>
                      <td className="px-4 py-3 text-right font-medium whitespace-nowrap">{m.new_qty}</td>
                      <td className="px-4 py-3 text-muted-foreground text-xs whitespace-nowrap">{m.reference_type || '—'}</td>
                      <td className="px-4 py-3 text-muted-foreground max-w-[180px] truncate">{m.notes || '—'}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </PdvLayout>
  );
}
