import { useState, useEffect, useCallback, useMemo } from 'react';
import {
  TrendingUp, TrendingDown, ShoppingCart, DollarSign, Download, AlertCircle, CheckCircle,
  Coins, BarChart2, CalendarDays, FileText, ArrowUpRight, ArrowDownRight,
  Layers, Award, Percent, Search, Filter, HelpCircle, Package, ArrowRight
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { PdvLayout } from '@/components/layouts/PdvLayout';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  LineChart, Line, Legend, AreaChart, Area, ComposedChart
} from 'recharts';
import { supabase } from '@/db/supabase';

const MONTH_NAMES = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
const cur = new Date();
const fmtBRL = (v: number) => (v || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
const fmtNum = (v: number, dec = 0) => (v || 0).toLocaleString('pt-BR', { minimumFractionDigits: dec, maximumFractionDigits: dec });
const years = Array.from({ length: 5 }, (_, i) => cur.getFullYear() - i);

// Helper CSV export
function downloadCsv(filename: string, headers: string[], rows: (string | number)[][]) {
  const escapeCsv = (v: any) => {
    const s = String(v ?? '').replace(/"/g, '""');
    return `"${s}"`;
  };
  const content = '\uFEFF' + [
    headers.map(escapeCsv).join(';'),
    ...rows.map(r => r.map(escapeCsv).join(';'))
  ].join('\r\n');

  const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', `${filename}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

interface SaleItemDetail {
  id: string;
  code?: string;
  name: string;
  quantity: number;
  price: number;
  cost: number;
}

interface UnifiedSale {
  id: string;
  source: 'online' | 'pdv';
  number?: string;
  created_at: string;
  total_amount: number;
  total_cost: number;
  payment_method?: string;
  items: SaleItemDetail[];
}

interface BillRow {
  id: string;
  type: 'pagar' | 'receber';
  description: string;
  installment_number: number;
  total_installments: number;
  amount: number;
  due_date: string;
  paid_date: string | null;
  paid_amount: number | null;
  partial_paid_amount: number | null;
  remaining_amount: number | null;
  status: string;
  category: string;
  supplier?: string | null;
  customer?: string | null;
}

// Hook de busca unificada de vendas no período
type PeriodPreset = 'hoje' | '7dias' | 'mes' | 'ano' | 'custom';

function useSalesData() {
  const [preset, setPreset] = useState<PeriodPreset>('mes');
  const [customFrom, setCustomFrom] = useState(cur.toISOString().split('T')[0].slice(0, 7) + '-01');
  const [customTo, setCustomTo] = useState(cur.toISOString().split('T')[0]);
  const [selMonth, setSelMonth] = useState(String(cur.getMonth() + 1));
  const [selYear, setSelYear] = useState(String(cur.getFullYear()));
  const [sales, setSales] = useState<UnifiedSale[]>([]);
  const [loading, setLoading] = useState(true);

  const getDateRange = useCallback(() => {
    const today = new Date();
    const todayStr = today.toISOString().split('T')[0];

    if (preset === 'hoje') {
      return { from: `${todayStr}T00:00:00`, to: `${todayStr}T23:59:59`, label: 'Hoje' };
    }
    if (preset === '7dias') {
      const d7 = new Date();
      d7.setDate(d7.getDate() - 6);
      return { from: `${d7.toISOString().split('T')[0]}T00:00:00`, to: `${todayStr}T23:59:59`, label: 'Últimos 7 dias' };
    }
    if (preset === 'mes') {
      const y = parseInt(selYear), m = parseInt(selMonth);
      const last = new Date(y, m, 0).getDate();
      return {
        from: `${y}-${String(m).padStart(2, '0')}-01T00:00:00`,
        to: `${y}-${String(m).padStart(2, '0')}-${last}T23:59:59`,
        label: `${MONTH_NAMES[m - 1]}/${y}`
      };
    }
    if (preset === 'ano') {
      const y = parseInt(selYear);
      return {
        from: `${y}-01-01T00:00:00`,
        to: `${y}-12-31T23:59:59`,
        label: `Ano ${y}`
      };
    }
    // custom
    return {
      from: `${customFrom}T00:00:00`,
      to: `${customTo}T23:59:59`,
      label: `${new Date(customFrom + 'T00:00:00').toLocaleDateString('pt-BR')} a ${new Date(customTo + 'T00:00:00').toLocaleDateString('pt-BR')}`
    };
  }, [preset, customFrom, customTo, selMonth, selYear]);

  const load = useCallback(async () => {
    setLoading(true);
    const { from, to } = getDateRange();

    try {
      const [ordersRes, pdvRes, prodRes] = await Promise.all([
        supabase.from('orders')
          .select('*')
          .gte('created_at', from)
          .lte('created_at', to)
          .in('status', ['completed', 'delivered']),
        supabase.from('pdv_invoices')
          .select('id,number,created_at,total,payment_method,pdv_invoice_items(product_id,quantity,unit_price,pdv_products(name,code))')
          .gte('created_at', from)
          .lte('created_at', to)
          .eq('type', 'saida')
          .eq('status', 'emitida'),
        supabase.from('pdv_products').select('id,code,name,site_product_id,cost_price,sale_price'),
      ]);

      const costById: Record<string, number> = {};
      const codeById: Record<string, string> = {};
      const costBySiteId: Record<string, number> = {};
      (prodRes.data || []).forEach((p: any) => {
        costById[p.id] = p.cost_price || 0;
        codeById[p.id] = p.code || '';
        if (p.site_product_id) costBySiteId[p.site_product_id] = p.cost_price || 0;
      });

      const unified: UnifiedSale[] = [];

      (ordersRes.data || []).forEach((o: any) => {
        let cost = 0;
        const items: SaleItemDetail[] = (o.items || []).map((i: any) => {
          const c = costBySiteId[i.id] || 0;
          cost += c * (i.quantity || 1);
          return {
            id: i.id,
            code: i.sku || '',
            name: i.name,
            quantity: i.quantity || 1,
            price: i.price || 0,
            cost: c,
          };
        });
        unified.push({
          id: o.id,
          source: 'online',
          number: o.order_number || String(o.id).slice(0, 8),
          created_at: o.created_at,
          total_amount: o.total_amount || 0,
          total_cost: cost,
          payment_method: o.payment_method,
          items,
        });
      });

      (pdvRes.data || []).forEach((p: any) => {
        let cost = 0;
        const items: SaleItemDetail[] = (p.pdv_invoice_items || []).map((i: any) => {
          const c = costById[i.product_id] || 0;
          cost += c * (i.quantity || 1);
          return {
            id: i.product_id,
            code: i.pdv_products?.code || codeById[i.product_id] || '',
            name: i.pdv_products?.name || 'Produto PDV',
            quantity: i.quantity || 1,
            price: i.unit_price || 0,
            cost: c,
          };
        });
        unified.push({
          id: p.id,
          source: 'pdv',
          number: p.number,
          created_at: p.created_at,
          total_amount: p.total || 0,
          total_cost: cost,
          payment_method: p.payment_method,
          items,
        });
      });

      unified.sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
      setSales(unified);
    } catch (err) {
      console.error('Erro ao carregar vendas do relatório:', err);
    } finally {
      setLoading(false);
    }
  }, [getDateRange]);

  useEffect(() => {
    load();
  }, [load]);

  return {
    preset, setPreset,
    customFrom, setCustomFrom,
    customTo, setCustomTo,
    selMonth, setSelMonth,
    selYear, setSelYear,
    sales, loading, refresh: load,
    dateRangeLabel: getDateRange().label,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// COMPONENTE: Filtro de Período Padrão
// ─────────────────────────────────────────────────────────────────────────────
function PeriodFilterBar({
  preset, setPreset,
  selMonth, setSelMonth,
  selYear, setSelYear,
  customFrom, setCustomFrom,
  customTo, setCustomTo,
  dateRangeLabel,
  onRefresh,
}: {
  preset: PeriodPreset;
  setPreset: (p: PeriodPreset) => void;
  selMonth: string;
  setSelMonth: (m: string) => void;
  selYear: string;
  setSelYear: (y: string) => void;
  customFrom: string;
  setCustomFrom: (d: string) => void;
  customTo: string;
  setCustomTo: (d: string) => void;
  dateRangeLabel: string;
  onRefresh?: () => void;
}) {
  return (
    <div className="bg-card border border-border rounded-lg p-4 space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mr-1">Período:</span>
          {(['hoje', '7dias', 'mes', 'ano', 'custom'] as const).map(p => (
            <Button
              key={p}
              size="sm"
              variant={preset === p ? 'default' : 'outline'}
              className="text-xs h-8"
              onClick={() => setPreset(p)}
            >
              {p === 'hoje' ? 'Hoje' : p === '7dias' ? 'Últimos 7 dias' : p === 'mes' ? 'Mês Selecionado' : p === 'ano' ? 'Ano' : 'Personalizado'}
            </Button>
          ))}
        </div>
        <div className="text-xs text-muted-foreground bg-muted/50 px-2.5 py-1 rounded-md border border-border/50">
          Período ativo: <span className="font-semibold text-foreground">{dateRangeLabel}</span>
        </div>
      </div>

      {preset === 'mes' && (
        <div className="flex items-center gap-2 flex-wrap pt-1 border-t border-border/40">
          <Label className="text-xs shrink-0 text-muted-foreground">Mês/Ano:</Label>
          <Select value={selMonth} onValueChange={setSelMonth}>
            <SelectTrigger className="w-36 h-8 text-xs"><SelectValue /></SelectTrigger>
            <SelectContent>{MONTH_NAMES.map((m, i) => <SelectItem key={i+1} value={String(i+1)}>{m}</SelectItem>)}</SelectContent>
          </Select>
          <Select value={selYear} onValueChange={setSelYear}>
            <SelectTrigger className="w-24 h-8 text-xs"><SelectValue /></SelectTrigger>
            <SelectContent>{years.map(y => <SelectItem key={y} value={String(y)}>{y}</SelectItem>)}</SelectContent>
          </Select>
        </div>
      )}

      {preset === 'ano' && (
        <div className="flex items-center gap-2 flex-wrap pt-1 border-t border-border/40">
          <Label className="text-xs shrink-0 text-muted-foreground">Ano:</Label>
          <Select value={selYear} onValueChange={setSelYear}>
            <SelectTrigger className="w-28 h-8 text-xs"><SelectValue /></SelectTrigger>
            <SelectContent>{years.map(y => <SelectItem key={y} value={String(y)}>{y}</SelectItem>)}</SelectContent>
          </Select>
        </div>
      )}

      {preset === 'custom' && (
        <div className="flex items-center gap-2 flex-wrap pt-1 border-t border-border/40">
          <Label className="text-xs shrink-0 text-muted-foreground">De:</Label>
          <Input type="date" value={customFrom} onChange={e => setCustomFrom(e.target.value)} className="w-36 h-8 text-xs" />
          <Label className="text-xs shrink-0 text-muted-foreground">Até:</Label>
          <Input type="date" value={customTo} onChange={e => setCustomTo(e.target.value)} className="w-36 h-8 text-xs" />
        </div>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// 1. ABA DE LUCRATIVIDADE POR PERÍODO
// ─────────────────────────────────────────────────────────────────────────────
function ProfitabilityReport() {
  const data = useSalesData();
  const { sales, loading, dateRangeLabel } = data;
  const [searchTerm, setSearchTerm] = useState('');

  // Indicadores consolidados
  const totalRevenue = sales.reduce((s, o) => s + o.total_amount, 0);
  const totalCpv = sales.reduce((s, o) => s + o.total_cost, 0); // Custo dos Produtos Vendidos
  const grossProfit = totalRevenue - totalCpv;
  const profitMargin = totalRevenue > 0 ? (grossProfit / totalRevenue) * 100 : 0;
  const totalOrders = sales.length;
  const avgTicket = totalOrders > 0 ? totalRevenue / totalOrders : 0;
  const totalItemsSold = sales.reduce((s, o) => s + o.items.reduce((acc, it) => acc + it.quantity, 0), 0);

  // Evolução temporal (por dia ou por mês caso o período seja amplo)
  const timelineData = useMemo(() => {
    const map: Record<string, { label: string; receita: number; cpv: number; lucro: number }> = {};
    sales.forEach(sale => {
      const d = new Date(sale.created_at);
      const isLargePeriod = data.preset === 'ano';
      const key = isLargePeriod
        ? `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`
        : `${String(d.getDate()).padStart(2,'0')}/${String(d.getMonth()+1).padStart(2,'0')}`;

      const label = isLargePeriod
        ? `${MONTH_NAMES[d.getMonth()].slice(0, 3)}/${d.getFullYear()}`
        : `${String(d.getDate()).padStart(2,'0')}/${String(d.getMonth()+1).padStart(2,'0')}`;

      if (!map[key]) {
        map[key] = { label, receita: 0, cpv: 0, lucro: 0 };
      }
      map[key].receita += sale.total_amount;
      map[key].cpv += sale.total_cost;
      map[key].lucro += (sale.total_amount - sale.total_cost);
    });

    return Object.values(map);
  }, [sales, data.preset]);

  // Lista filtrada para a tabela detalhada
  const filteredSales = useMemo(() => {
    if (!searchTerm.trim()) return sales;
    const term = searchTerm.toLowerCase();
    return sales.filter(s =>
      (s.number && s.number.toLowerCase().includes(term)) ||
      s.items.some(it => it.name.toLowerCase().includes(term) || (it.code && it.code.toLowerCase().includes(term)))
    );
  }, [sales, searchTerm]);

  const handleExportCsv = () => {
    const headers = ['Data/Hora', 'Número', 'Canal', 'Forma Pagamento', 'Receita (R$)', 'CPV - Custo (R$)', 'Lucro Bruto (R$)', 'Margem (%)'];
    const rows = filteredSales.map(s => {
      const lucro = s.total_amount - s.total_cost;
      const marg = s.total_amount > 0 ? ((lucro / s.total_amount) * 100).toFixed(2) : '0.00';
      return [
        new Date(s.created_at).toLocaleString('pt-BR'),
        s.number || s.id,
        s.source === 'pdv' ? 'PDV Caixa' : 'Loja Online',
        s.payment_method || '—',
        s.total_amount.toFixed(2),
        s.total_cost.toFixed(2),
        lucro.toFixed(2),
        `${marg}%`
      ];
    });
    downloadCsv(`relatorio_lucratividade_${new Date().toISOString().slice(0,10)}`, headers, rows);
  };

  return (
    <div className="space-y-4">
      <PeriodFilterBar {...data} />

      {/* Cards de KPIs de Lucratividade */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="bg-card border border-border rounded-lg p-4">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg bg-success/10 flex items-center justify-center shrink-0 text-success">
              <DollarSign className="h-5 w-5" />
            </div>
            <div className="min-w-0">
              <p className="text-xs text-muted-foreground">Receita Bruta</p>
              {loading ? <Skeleton className="h-6 w-24 bg-muted mt-1" /> : (
                <p className="text-base md:text-lg font-bold text-foreground truncate">{fmtBRL(totalRevenue)}</p>
              )}
            </div>
          </div>
        </div>

        <div className="bg-card border border-border rounded-lg p-4">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg bg-warning/10 flex items-center justify-center shrink-0 text-warning">
              <ArrowDownRight className="h-5 w-5" />
            </div>
            <div className="min-w-0">
              <p className="text-xs text-muted-foreground">CPV (Custo Mercadoria)</p>
              {loading ? <Skeleton className="h-6 w-24 bg-muted mt-1" /> : (
                <p className="text-base md:text-lg font-bold text-foreground truncate">{fmtBRL(totalCpv)}</p>
              )}
            </div>
          </div>
        </div>

        <div className="bg-card border border-border rounded-lg p-4">
          <div className="flex items-center gap-3">
            <div className={`h-10 w-10 rounded-lg flex items-center justify-center shrink-0 ${grossProfit >= 0 ? 'bg-primary/10 text-primary' : 'bg-destructive/10 text-destructive'}`}>
              <TrendingUp className="h-5 w-5" />
            </div>
            <div className="min-w-0">
              <p className="text-xs text-muted-foreground">Lucro Bruto</p>
              {loading ? <Skeleton className="h-6 w-24 bg-muted mt-1" /> : (
                <p className={`text-base md:text-lg font-bold truncate ${grossProfit >= 0 ? 'text-primary' : 'text-destructive'}`}>
                  {fmtBRL(grossProfit)}
                </p>
              )}
            </div>
          </div>
        </div>

        <div className="bg-card border border-border rounded-lg p-4">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg bg-accent/15 flex items-center justify-center shrink-0 text-accent">
              <Percent className="h-5 w-5" />
            </div>
            <div className="min-w-0">
              <p className="text-xs text-muted-foreground">Margem de Lucro</p>
              {loading ? <Skeleton className="h-6 w-24 bg-muted mt-1" /> : (
                <p className="text-base md:text-lg font-bold text-foreground truncate">{profitMargin.toFixed(1)}%</p>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Sub-cards de apoio */}
      <div className="grid grid-cols-3 gap-3">
        <div className="bg-card border border-border rounded-lg p-3 text-center">
          <p className="text-xs text-muted-foreground">Ticket Médio</p>
          <p className="text-sm md:text-base font-semibold text-foreground mt-0.5">{fmtBRL(avgTicket)}</p>
        </div>
        <div className="bg-card border border-border rounded-lg p-3 text-center">
          <p className="text-xs text-muted-foreground">Vendas Realizadas</p>
          <p className="text-sm md:text-base font-semibold text-foreground mt-0.5">{totalOrders} pedidos</p>
        </div>
        <div className="bg-card border border-border rounded-lg p-3 text-center">
          <p className="text-xs text-muted-foreground">Itens Faturados</p>
          <p className="text-sm md:text-base font-semibold text-foreground mt-0.5">{totalItemsSold} un.</p>
        </div>
      </div>

      {/* Gráfico de Evolução de Receita x CPV x Lucro */}
      <Card>
        <CardHeader className="pb-2">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <CardTitle className="text-sm font-semibold">Evolução de Lucratividade</CardTitle>
              <CardDescription className="text-xs">Comparativo de Receita Bruta, Custo (CPV) e Lucro Bruto ao longo do período</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <Skeleton className="h-64 w-full bg-muted" />
          ) : timelineData.length === 0 ? (
            <div className="h-64 flex items-center justify-center text-muted-foreground text-sm">
              Sem movimentações no período selecionado
            </div>
          ) : (
            <div className="w-full min-w-0 overflow-hidden">
              <ResponsiveContainer width="100%" height={260}>
                <AreaChart data={timelineData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorReceita" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                    </linearGradient>
                    <linearGradient id="colorLucro" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(142.1 76.2% 36.3%)" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="hsl(142.1 76.2% 36.3%)" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="label" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} />
                  <Tooltip formatter={(val: number) => [fmtBRL(val)]} />
                  <Legend layout="horizontal" wrapperStyle={{ paddingTop: 8 }} />
                  <Area type="monotone" dataKey="receita" stroke="hsl(var(--primary))" fillOpacity={1} fill="url(#colorReceita)" name="Receita Bruta" />
                  <Area type="monotone" dataKey="cpv" stroke="hsl(38 92% 50%)" fill="hsl(38 92% 50% / 0.1)" name="Custo (CPV)" />
                  <Area type="monotone" dataKey="lucro" stroke="hsl(142.1 76.2% 36.3%)" fillOpacity={1} fill="url(#colorLucro)" name="Lucro Bruto" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Tabela de Vendas Detalhadas com Lucro */}
      <Card>
        <CardHeader className="pb-2">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div>
              <CardTitle className="text-sm font-semibold">Detalhamento de Vendas e Margens</CardTitle>
              <CardDescription className="text-xs">Registro de vendas com cálculo unitário de custo e lucratividade</CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <div className="relative w-48 md:w-64">
                <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-muted-foreground" />
                <Input
                  placeholder="Buscar venda ou produto..."
                  value={searchTerm}
                  onChange={e => setSearchTerm(e.target.value)}
                  className="pl-8 h-8 text-xs"
                />
              </div>
              <Button size="sm" variant="outline" className="h-8 gap-1.5 text-xs shrink-0" onClick={handleExportCsv}>
                <Download className="h-3.5 w-3.5" /> Exportar CSV
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {loading ? (
            <div className="p-4 space-y-2">{[...Array(5)].map((_, i) => <Skeleton key={i} className="h-8 bg-muted" />)}</div>
          ) : filteredSales.length === 0 ? (
            <div className="py-10 text-center text-muted-foreground text-sm">Nenhuma venda encontrada no período</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-max text-sm">
                <thead>
                  <tr className="border-b border-border bg-muted/40 text-xs font-semibold text-muted-foreground">
                    <th className="text-left px-4 py-2 whitespace-nowrap">Data</th>
                    <th className="text-left px-4 py-2 whitespace-nowrap">Doc / Ref</th>
                    <th className="text-left px-4 py-2 whitespace-nowrap">Canal</th>
                    <th className="text-left px-4 py-2 whitespace-nowrap">Itens</th>
                    <th className="text-right px-4 py-2 whitespace-nowrap">Receita</th>
                    <th className="text-right px-4 py-2 whitespace-nowrap">Custo (CPV)</th>
                    <th className="text-right px-4 py-2 whitespace-nowrap">Lucro Bruto</th>
                    <th className="text-right px-4 py-2 whitespace-nowrap">Margem</th>
                  </tr>
                </thead>
                <tbody>
                  {[...filteredSales].reverse().map(sale => {
                    const lucro = sale.total_amount - sale.total_cost;
                    const margem = sale.total_amount > 0 ? (lucro / sale.total_amount) * 100 : 0;
                    return (
                      <tr key={sale.id} className="border-b border-border last:border-0 hover:bg-muted/20 text-xs">
                        <td className="px-4 py-2 whitespace-nowrap text-muted-foreground">
                          {new Date(sale.created_at).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}
                        </td>
                        <td className="px-4 py-2 whitespace-nowrap font-medium text-foreground">
                          {sale.number || sale.id.slice(0, 8)}
                        </td>
                        <td className="px-4 py-2 whitespace-nowrap">
                          <Badge variant="outline" className="text-[10px] py-0">
                            {sale.source === 'pdv' ? 'PDV' : 'Online'}
                          </Badge>
                        </td>
                        <td className="px-4 py-2 whitespace-nowrap text-muted-foreground max-w-44 truncate">
                          {sale.items.map(it => `${it.quantity}x ${it.name}`).join(', ') || '—'}
                        </td>
                        <td className="px-4 py-2 whitespace-nowrap text-right font-medium text-foreground">
                          {fmtBRL(sale.total_amount)}
                        </td>
                        <td className="px-4 py-2 whitespace-nowrap text-right text-muted-foreground">
                          {fmtBRL(sale.total_cost)}
                        </td>
                        <td className={`px-4 py-2 whitespace-nowrap text-right font-semibold ${lucro >= 0 ? 'text-success' : 'text-destructive'}`}>
                          {fmtBRL(lucro)}
                        </td>
                        <td className="px-4 py-2 whitespace-nowrap text-right">
                          <span className={`px-1.5 py-0.5 rounded text-[11px] font-medium ${margem >= 30 ? 'bg-success/10 text-success' : margem >= 15 ? 'bg-primary/10 text-primary' : 'bg-destructive/10 text-destructive'}`}>
                            {margem.toFixed(1)}%
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// 2. ABA DE PRODUTOS MAIS VENDIDOS
// ─────────────────────────────────────────────────────────────────────────────
type BestSellerSort = 'qty' | 'revenue' | 'profit';

interface ProductStats {
  id: string;
  code: string;
  name: string;
  quantity: number;
  revenue: number;
  cost: number;
  profit: number;
  margin: number;
  avgPrice: number;
}

function BestSellersReport() {
  const data = useSalesData();
  const { sales, loading, dateRangeLabel } = data;
  const [sortBy, setSortBy] = useState<BestSellerSort>('qty');
  const [searchTerm, setSearchTerm] = useState('');

  // Agrupa estatísticas por produto
  const productStats = useMemo(() => {
    const map: Record<string, ProductStats> = {};

    sales.forEach(sale => {
      sale.items.forEach(it => {
        const pid = it.id || it.name;
        if (!map[pid]) {
          map[pid] = {
            id: pid,
            code: it.code || '',
            name: it.name || 'Produto sem nome',
            quantity: 0,
            revenue: 0,
            cost: 0,
            profit: 0,
            margin: 0,
            avgPrice: 0,
          };
        }
        const itemRevenue = it.price * it.quantity;
        const itemCost = it.cost * it.quantity;

        map[pid].quantity += it.quantity;
        map[pid].revenue += itemRevenue;
        map[pid].cost += itemCost;
        if (!map[pid].code && it.code) map[pid].code = it.code;
      });
    });

    const list = Object.values(map).map(p => {
      const profit = p.revenue - p.cost;
      const margin = p.revenue > 0 ? (profit / p.revenue) * 100 : 0;
      const avgPrice = p.quantity > 0 ? p.revenue / p.quantity : 0;
      return { ...p, profit, margin, avgPrice };
    });

    return list;
  }, [sales]);

  // Lista ordenada e filtrada
  const sortedList = useMemo(() => {
    let list = [...productStats];
    if (searchTerm.trim()) {
      const term = searchTerm.toLowerCase();
      list = list.filter(p => p.name.toLowerCase().includes(term) || p.code.toLowerCase().includes(term));
    }

    if (sortBy === 'qty') {
      list.sort((a, b) => b.quantity - a.quantity);
    } else if (sortBy === 'revenue') {
      list.sort((a, b) => b.revenue - a.revenue);
    } else {
      list.sort((a, b) => b.profit - a.profit);
    }
    return list;
  }, [productStats, sortBy, searchTerm]);

  // Dados para o Gráfico Top 10
  const chartData = useMemo(() => {
    return sortedList.slice(0, 10).map(p => ({
      name: p.name.length > 18 ? p.name.slice(0, 18) + '...' : p.name,
      fullName: p.name,
      quantidade: p.quantity,
      receita: p.revenue,
      lucro: p.profit,
    }));
  }, [sortedList]);

  // KPIs
  const topProductByQty = [...productStats].sort((a, b) => b.quantity - a.quantity)[0];
  const topProductByRev = [...productStats].sort((a, b) => b.revenue - a.revenue)[0];
  const topProductByProf = [...productStats].sort((a, b) => b.profit - a.profit)[0];

  const handleExportCsv = () => {
    const headers = ['Posição', 'Código/SKU', 'Produto', 'Qtd Vendida', 'Preço Médio (R$)', 'Faturamento Total (R$)', 'Custo Total (R$)', 'Lucro Bruto (R$)', 'Margem (%)'];
    const rows = sortedList.map((p, idx) => [
      idx + 1,
      p.code || '—',
      p.name,
      p.quantity,
      p.avgPrice.toFixed(2),
      p.revenue.toFixed(2),
      p.cost.toFixed(2),
      p.profit.toFixed(2),
      `${p.margin.toFixed(1)}%`
    ]);
    downloadCsv(`ranking_produtos_mais_vendidos_${new Date().toISOString().slice(0,10)}`, headers, rows);
  };

  return (
    <div className="space-y-4">
      <PeriodFilterBar {...data} />

      {/* Destaques do Ranking */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <Card className="bg-card">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg bg-amber-500/10 flex items-center justify-center shrink-0 text-amber-500">
              <Award className="h-5 w-5" />
            </div>
            <div className="min-w-0">
              <span className="text-[11px] uppercase tracking-wider text-muted-foreground font-semibold">Líder em Volume</span>
              <p className="text-sm font-bold text-foreground truncate mt-0.5">{topProductByQty?.name || '—'}</p>
              <p className="text-xs text-muted-foreground">{topProductByQty ? `${topProductByQty.quantity} unidades vendidas` : 'Nenhum'}</p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg bg-success/10 flex items-center justify-center shrink-0 text-success">
              <DollarSign className="h-5 w-5" />
            </div>
            <div className="min-w-0">
              <span className="text-[11px] uppercase tracking-wider text-muted-foreground font-semibold">Líder em Faturamento</span>
              <p className="text-sm font-bold text-foreground truncate mt-0.5">{topProductByRev?.name || '—'}</p>
              <p className="text-xs text-muted-foreground">{topProductByRev ? `${fmtBRL(topProductByRev.revenue)} gerados` : 'Nenhum'}</p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0 text-primary">
              <TrendingUp className="h-5 w-5" />
            </div>
            <div className="min-w-0">
              <span className="text-[11px] uppercase tracking-wider text-muted-foreground font-semibold">Líder em Lucro Bruto</span>
              <p className="text-sm font-bold text-foreground truncate mt-0.5">{topProductByProf?.name || '—'}</p>
              <p className="text-xs text-muted-foreground">{topProductByProf ? `${fmtBRL(topProductByProf.profit)} de lucro` : 'Nenhum'}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Gráfico Top 10 com Alternador de Métrica */}
      <Card>
        <CardHeader className="pb-2">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div>
              <CardTitle className="text-sm font-semibold">Top 10 Produtos Mais Vendidos</CardTitle>
              <CardDescription className="text-xs">Visualização gráfica dos itens de maior desempenho no período</CardDescription>
            </div>
            <div className="flex items-center gap-1.5 bg-muted/60 p-1 rounded-lg border border-border">
              <span className="text-xs text-muted-foreground px-2">Ordenar por:</span>
              <Button
                size="sm"
                variant={sortBy === 'qty' ? 'default' : 'ghost'}
                className="h-7 text-xs px-2.5"
                onClick={() => setSortBy('qty')}
              >
                Quantidade
              </Button>
              <Button
                size="sm"
                variant={sortBy === 'revenue' ? 'default' : 'ghost'}
                className="h-7 text-xs px-2.5"
                onClick={() => setSortBy('revenue')}
              >
                Faturamento
              </Button>
              <Button
                size="sm"
                variant={sortBy === 'profit' ? 'default' : 'ghost'}
                className="h-7 text-xs px-2.5"
                onClick={() => setSortBy('profit')}
              >
                Lucro
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <Skeleton className="h-64 w-full bg-muted" />
          ) : chartData.length === 0 ? (
            <div className="h-64 flex items-center justify-center text-muted-foreground text-sm">
              Sem dados para exibir no gráfico
            </div>
          ) : (
            <div className="w-full min-w-0 overflow-hidden">
              <ResponsiveContainer width="100%" height={260}>
                <BarChart data={chartData} margin={{ top: 10, right: 10, left: -5, bottom: 25 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="name" angle={-15} textAnchor="end" tick={{ fontSize: 11 }} interval={0} />
                  <YAxis tick={{ fontSize: 11 }} />
                  <Tooltip
                    formatter={(val: number) => [
                      sortBy === 'qty' ? `${val} un.` : fmtBRL(val),
                      sortBy === 'qty' ? 'Quantidade' : sortBy === 'revenue' ? 'Faturamento' : 'Lucro'
                    ]}
                  />
                  <Bar
                    dataKey={sortBy === 'qty' ? 'quantidade' : sortBy === 'revenue' ? 'receita' : 'lucro'}
                    fill={sortBy === 'qty' ? 'hsl(var(--primary))' : sortBy === 'revenue' ? 'hsl(142.1 76.2% 36.3%)' : 'hsl(var(--accent))'}
                    radius={[4, 4, 0, 0]}
                    name={sortBy === 'qty' ? 'Quantidade Vendida' : sortBy === 'revenue' ? 'Faturamento Total' : 'Lucro Bruto'}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Tabela de Ranking */}
      <Card>
        <CardHeader className="pb-2">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div>
              <CardTitle className="text-sm font-semibold">Tabela de Ranking Completa ({sortedList.length} itens)</CardTitle>
              <CardDescription className="text-xs">Lista completa de todos os itens com vendas no período</CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <div className="relative w-48 md:w-64">
                <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-muted-foreground" />
                <Input
                  placeholder="Filtrar por nome ou código..."
                  value={searchTerm}
                  onChange={e => setSearchTerm(e.target.value)}
                  className="pl-8 h-8 text-xs"
                />
              </div>
              <Button size="sm" variant="outline" className="h-8 gap-1.5 text-xs shrink-0" onClick={handleExportCsv}>
                <Download className="h-3.5 w-3.5" /> Exportar CSV
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {loading ? (
            <div className="p-4 space-y-2">{[...Array(6)].map((_, i) => <Skeleton key={i} className="h-8 bg-muted" />)}</div>
          ) : sortedList.length === 0 ? (
            <div className="py-10 text-center text-muted-foreground text-sm">Nenhum produto vendido no período</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-max text-sm">
                <thead>
                  <tr className="border-b border-border bg-muted/40 text-xs font-semibold text-muted-foreground">
                    <th className="text-left px-4 py-2 whitespace-nowrap w-12">#</th>
                    <th className="text-left px-4 py-2 whitespace-nowrap">Código</th>
                    <th className="text-left px-4 py-2 whitespace-nowrap">Produto</th>
                    <th className="text-right px-4 py-2 whitespace-nowrap">Qtd. Vendida</th>
                    <th className="text-right px-4 py-2 whitespace-nowrap">Preço Médio</th>
                    <th className="text-right px-4 py-2 whitespace-nowrap">Faturamento</th>
                    <th className="text-right px-4 py-2 whitespace-nowrap">Custo Total</th>
                    <th className="text-right px-4 py-2 whitespace-nowrap">Lucro Bruto</th>
                    <th className="text-right px-4 py-2 whitespace-nowrap">Margem</th>
                  </tr>
                </thead>
                <tbody>
                  {sortedList.map((p, idx) => (
                    <tr key={p.id} className="border-b border-border last:border-0 hover:bg-muted/20 text-xs">
                      <td className="px-4 py-2 whitespace-nowrap font-bold">
                        {idx === 0 ? (
                          <span className="inline-flex items-center justify-center h-5 w-5 rounded-full bg-amber-500 text-white text-[10px]">1</span>
                        ) : idx === 1 ? (
                          <span className="inline-flex items-center justify-center h-5 w-5 rounded-full bg-slate-400 text-white text-[10px]">2</span>
                        ) : idx === 2 ? (
                          <span className="inline-flex items-center justify-center h-5 w-5 rounded-full bg-amber-700 text-white text-[10px]">3</span>
                        ) : (
                          <span className="text-muted-foreground">#{idx + 1}</span>
                        )}
                      </td>
                      <td className="px-4 py-2 whitespace-nowrap font-mono text-[11px] text-muted-foreground">
                        {p.code || '—'}
                      </td>
                      <td className="px-4 py-2 whitespace-nowrap font-medium text-foreground max-w-56 truncate">
                        {p.name}
                      </td>
                      <td className="px-4 py-2 whitespace-nowrap text-right font-semibold text-foreground">
                        {fmtNum(p.quantity)} un.
                      </td>
                      <td className="px-4 py-2 whitespace-nowrap text-right text-muted-foreground">
                        {fmtBRL(p.avgPrice)}
                      </td>
                      <td className="px-4 py-2 whitespace-nowrap text-right font-semibold text-success">
                        {fmtBRL(p.revenue)}
                      </td>
                      <td className="px-4 py-2 whitespace-nowrap text-right text-muted-foreground">
                        {fmtBRL(p.cost)}
                      </td>
                      <td className={`px-4 py-2 whitespace-nowrap text-right font-semibold ${p.profit >= 0 ? 'text-primary' : 'text-destructive'}`}>
                        {fmtBRL(p.profit)}
                      </td>
                      <td className="px-4 py-2 whitespace-nowrap text-right">
                        <span className={`px-1.5 py-0.5 rounded text-[11px] font-medium ${p.margin >= 30 ? 'bg-success/10 text-success' : p.margin >= 15 ? 'bg-primary/10 text-primary' : 'bg-destructive/10 text-destructive'}`}>
                          {p.margin.toFixed(1)}%
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// 3. ABA DE CURVA ABC DE PRODUTOS
// ─────────────────────────────────────────────────────────────────────────────
interface AbcProduct {
  id: string;
  code: string;
  name: string;
  quantity: number;
  revenue: number;
  cost: number;
  profit: number;
  individualPercent: number; // % do total
  accumulatedPercent: number; // % acumulado
  classe: 'A' | 'B' | 'C';
}

function CurvaAbcReport() {
  const data = useSalesData();
  const { sales, loading, dateRangeLabel } = data;
  const [classeFilter, setClasseFilter] = useState<'todas' | 'A' | 'B' | 'C'>('todas');
  const [searchTerm, setSearchTerm] = useState('');

  // Cálculo da Curva ABC baseada em Faturamento (Receita)
  const { abcList, totalRevenue, summaryA, summaryB, summaryC } = useMemo(() => {
    const map: Record<string, { id: string; code: string; name: string; quantity: number; revenue: number; cost: number }> = {};

    sales.forEach(sale => {
      sale.items.forEach(it => {
        const pid = it.id || it.name;
        if (!map[pid]) {
          map[pid] = {
            id: pid,
            code: it.code || '',
            name: it.name || 'Produto sem nome',
            quantity: 0,
            revenue: 0,
            cost: 0,
          };
        }
        map[pid].quantity += it.quantity;
        map[pid].revenue += (it.price * it.quantity);
        map[pid].cost += (it.cost * it.quantity);
        if (!map[pid].code && it.code) map[pid].code = it.code;
      });
    });

    const revenueTotal = Object.values(map).reduce((sum, item) => sum + item.revenue, 0);

    // Ordenar de forma decrescente pelo faturamento
    const sorted = Object.values(map).sort((a, b) => b.revenue - a.revenue);

    let accumulatedRevenue = 0;
    const classified: AbcProduct[] = sorted.map(item => {
      accumulatedRevenue += item.revenue;
      const individualPercent = revenueTotal > 0 ? (item.revenue / revenueTotal) * 100 : 0;
      const accumulatedPercent = revenueTotal > 0 ? (accumulatedRevenue / revenueTotal) * 100 : 0;

      // Classificação Clássica de Pareto:
      // Classe A: até 80%
      // Classe B: 80.01% a 95%
      // Classe C: 95.01% a 100%
      let classe: 'A' | 'B' | 'C' = 'C';
      if (accumulatedPercent <= 80 || (sorted.indexOf(item) === 0 && accumulatedPercent > 80)) {
        classe = 'A';
      } else if (accumulatedPercent <= 95) {
        classe = 'B';
      } else {
        classe = 'C';
      }

      return {
        id: item.id,
        code: item.code,
        name: item.name,
        quantity: item.quantity,
        revenue: item.revenue,
        cost: item.cost,
        profit: item.revenue - item.cost,
        individualPercent,
        accumulatedPercent,
        classe,
      };
    });

    const getSummary = (cls: 'A' | 'B' | 'C') => {
      const items = classified.filter(i => i.classe === cls);
      const rev = items.reduce((s, i) => s + i.revenue, 0);
      const qtd = items.reduce((s, i) => s + i.quantity, 0);
      const percent = revenueTotal > 0 ? (rev / revenueTotal) * 100 : 0;
      const mixPercent = classified.length > 0 ? (items.length / classified.length) * 100 : 0;
      return { count: items.length, revenue: rev, quantity: qtd, percent, mixPercent };
    };

    return {
      abcList: classified,
      totalRevenue: revenueTotal,
      summaryA: getSummary('A'),
      summaryB: getSummary('B'),
      summaryC: getSummary('C'),
    };
  }, [sales]);

  // Lista filtrada para a tabela
  const visibleList = useMemo(() => {
    let list = abcList;
    if (classeFilter !== 'todas') {
      list = list.filter(i => i.classe === classeFilter);
    }
    if (searchTerm.trim()) {
      const term = searchTerm.toLowerCase();
      list = list.filter(i => i.name.toLowerCase().includes(term) || i.code.toLowerCase().includes(term));
    }
    return list;
  }, [abcList, classeFilter, searchTerm]);

  // Gráfico de Pareto (Top 15 produtos com barras de faturamento e linha de % acumulado)
  const paretoChartData = useMemo(() => {
    return abcList.slice(0, 15).map(item => ({
      name: item.name.length > 15 ? item.name.slice(0, 15) + '...' : item.name,
      faturamento: item.revenue,
      acumulado: Math.round(item.accumulatedPercent * 10) / 10,
      classe: item.classe,
    }));
  }, [abcList]);

  const handleExportCsv = () => {
    const headers = ['Classe', 'Código/SKU', 'Produto', 'Qtd Vendida', 'Faturamento (R$)', 'Part. Individual (%)', 'Part. Acumulada (%)'];
    const rows = visibleList.map(item => [
      `Classe ${item.classe}`,
      item.code || '—',
      item.name,
      item.quantity,
      item.revenue.toFixed(2),
      `${item.individualPercent.toFixed(2)}%`,
      `${item.accumulatedPercent.toFixed(2)}%`
    ]);
    downloadCsv(`curva_abc_produtos_${new Date().toISOString().slice(0,10)}`, headers, rows);
  };

  return (
    <div className="space-y-4">
      <PeriodFilterBar {...data} />

      {/* Cards de Resumo das Classes A, B e C */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {/* Classe A */}
        <Card className="border-l-4 border-l-emerald-500 bg-card">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600 border border-emerald-500/30">
                Classe A · Alto Impacto (~80%)
              </span>
              <span className="text-xs font-semibold text-emerald-600">{summaryA.percent.toFixed(1)}% do total</span>
            </div>
          </CardHeader>
          <CardContent className="space-y-2 text-xs">
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Faturamento:</span>
              <span className="font-bold text-sm text-foreground">{fmtBRL(summaryA.revenue)}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Produtos no Mix:</span>
              <span className="font-medium text-foreground">{summaryA.count} itens ({summaryA.mixPercent.toFixed(1)}%)</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Volume Vendido:</span>
              <span className="font-medium text-foreground">{fmtNum(summaryA.quantity)} un.</span>
            </div>
            <p className="text-[11px] text-muted-foreground pt-1 border-t border-border/40">
              💡 <strong>Prioridade Máxima:</strong> Itens mais cruciais para o caixa. Jamais permita ruptura de estoque!
            </p>
          </CardContent>
        </Card>

        {/* Classe B */}
        <Card className="border-l-4 border-l-sky-500 bg-card">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-sky-500/10 text-sky-600 border border-sky-500/30">
                Classe B · Impacto Intermediário (~15%)
              </span>
              <span className="text-xs font-semibold text-sky-600">{summaryB.percent.toFixed(1)}% do total</span>
            </div>
          </CardHeader>
          <CardContent className="space-y-2 text-xs">
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Faturamento:</span>
              <span className="font-bold text-sm text-foreground">{fmtBRL(summaryB.revenue)}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Produtos no Mix:</span>
              <span className="font-medium text-foreground">{summaryB.count} itens ({summaryB.mixPercent.toFixed(1)}%)</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Volume Vendido:</span>
              <span className="font-medium text-foreground">{fmtNum(summaryB.quantity)} un.</span>
            </div>
            <p className="text-[11px] text-muted-foreground pt-1 border-t border-border/40">
              💡 <strong>Controle Regular:</strong> Demanda consistente. Monitore periodicamente o ponto de reposição.
            </p>
          </CardContent>
        </Card>

        {/* Classe C */}
        <Card className="border-l-4 border-l-amber-500 bg-card">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-600 border border-amber-500/30">
                Classe C · Cauda Longa (~5%)
              </span>
              <span className="text-xs font-semibold text-amber-600">{summaryC.percent.toFixed(1)}% do total</span>
            </div>
          </CardHeader>
          <CardContent className="space-y-2 text-xs">
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Faturamento:</span>
              <span className="font-bold text-sm text-foreground">{fmtBRL(summaryC.revenue)}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Produtos no Mix:</span>
              <span className="font-medium text-foreground">{summaryC.count} itens ({summaryC.mixPercent.toFixed(1)}%)</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Volume Vendido:</span>
              <span className="font-medium text-foreground">{fmtNum(summaryC.quantity)} un.</span>
            </div>
            <p className="text-[11px] text-muted-foreground pt-1 border-t border-border/40">
              💡 <strong>Atenção a Excesso:</strong> Geralmente muitos itens de baixo giro. Evite estoque parado excessivo.
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Gráfico da Curva de Pareto */}
      <Card>
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-sm font-semibold">Gráfico de Pareto (Faturamento x % Acumulado)</CardTitle>
              <CardDescription className="text-xs">
                Barras representam o faturamento de cada produto e a linha traça o percentual acumulado
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <Skeleton className="h-64 w-full bg-muted" />
          ) : paretoChartData.length === 0 ? (
            <div className="h-64 flex items-center justify-center text-muted-foreground text-sm">
              Sem dados suficientes para gerar a Curva ABC
            </div>
          ) : (
            <div className="w-full min-w-0 overflow-hidden">
              <ResponsiveContainer width="100%" height={260}>
                <ComposedChart data={paretoChartData} margin={{ top: 10, right: 20, left: 0, bottom: 25 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="name" angle={-15} textAnchor="end" tick={{ fontSize: 11 }} interval={0} />
                  <YAxis yAxisId="left" tick={{ fontSize: 11 }} />
                  <YAxis yAxisId="right" orientation="right" domain={[0, 100]} unit="%" tick={{ fontSize: 11 }} />
                  <Tooltip
                    formatter={(val: number, name: string) => [
                      name === 'Faturamento' ? fmtBRL(val) : `${val}%`,
                      name
                    ]}
                  />
                  <Legend layout="horizontal" wrapperStyle={{ paddingTop: 8 }} />
                  <Bar yAxisId="left" dataKey="faturamento" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} name="Faturamento" />
                  <Line yAxisId="right" type="monotone" dataKey="acumulado" stroke="hsl(var(--destructive))" strokeWidth={2.5} dot={{ r: 4 }} name="% Acumulado" />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Tabela de Classificação ABC */}
      <Card>
        <CardHeader className="pb-2">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div>
              <CardTitle className="text-sm font-semibold">Detalhamento da Curva ABC ({visibleList.length} itens)</CardTitle>
              <CardDescription className="text-xs">Classificação individual dos produtos no período selecionado</CardDescription>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <div className="flex items-center gap-1 bg-muted/60 p-1 rounded-lg border border-border">
                {(['todas', 'A', 'B', 'C'] as const).map(c => (
                  <Button
                    key={c}
                    size="sm"
                    variant={classeFilter === c ? 'default' : 'ghost'}
                    className="h-7 text-xs px-2.5"
                    onClick={() => setClasseFilter(c)}
                  >
                    {c === 'todas' ? 'Todas' : `Classe ${c}`}
                  </Button>
                ))}
              </div>

              <div className="relative w-44 md:w-56">
                <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-muted-foreground" />
                <Input
                  placeholder="Buscar produto..."
                  value={searchTerm}
                  onChange={e => setSearchTerm(e.target.value)}
                  className="pl-8 h-8 text-xs"
                />
              </div>

              <Button size="sm" variant="outline" className="h-8 gap-1.5 text-xs shrink-0" onClick={handleExportCsv}>
                <Download className="h-3.5 w-3.5" /> CSV
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {loading ? (
            <div className="p-4 space-y-2">{[...Array(6)].map((_, i) => <Skeleton key={i} className="h-8 bg-muted" />)}</div>
          ) : visibleList.length === 0 ? (
            <div className="py-10 text-center text-muted-foreground text-sm">Nenhum produto encontrado nesta classe</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-max text-sm">
                <thead>
                  <tr className="border-b border-border bg-muted/40 text-xs font-semibold text-muted-foreground">
                    <th className="text-center px-3 py-2 whitespace-nowrap w-16">Classe</th>
                    <th className="text-left px-4 py-2 whitespace-nowrap">Código</th>
                    <th className="text-left px-4 py-2 whitespace-nowrap">Produto</th>
                    <th className="text-right px-4 py-2 whitespace-nowrap">Qtd. Vendida</th>
                    <th className="text-right px-4 py-2 whitespace-nowrap">Faturamento</th>
                    <th className="text-right px-4 py-2 whitespace-nowrap">Part. Individual</th>
                    <th className="text-right px-4 py-2 whitespace-nowrap">Part. Acumulada</th>
                  </tr>
                </thead>
                <tbody>
                  {visibleList.map(item => (
                    <tr key={item.id} className="border-b border-border last:border-0 hover:bg-muted/20 text-xs">
                      <td className="px-3 py-2 whitespace-nowrap text-center">
                        <span className={`inline-flex items-center justify-center font-bold px-2 py-0.5 rounded text-[11px] ${
                          item.classe === 'A'
                            ? 'bg-emerald-500/15 text-emerald-600 border border-emerald-500/30'
                            : item.classe === 'B'
                            ? 'bg-sky-500/15 text-sky-600 border border-sky-500/30'
                            : 'bg-amber-500/15 text-amber-600 border border-amber-500/30'
                        }`}>
                          Classe {item.classe}
                        </span>
                      </td>
                      <td className="px-4 py-2 whitespace-nowrap font-mono text-[11px] text-muted-foreground">
                        {item.code || '—'}
                      </td>
                      <td className="px-4 py-2 whitespace-nowrap font-medium text-foreground max-w-56 truncate">
                        {item.name}
                      </td>
                      <td className="px-4 py-2 whitespace-nowrap text-right text-foreground">
                        {fmtNum(item.quantity)} un.
                      </td>
                      <td className="px-4 py-2 whitespace-nowrap text-right font-semibold text-success">
                        {fmtBRL(item.revenue)}
                      </td>
                      <td className="px-4 py-2 whitespace-nowrap text-right font-medium text-foreground">
                        {item.individualPercent.toFixed(2)}%
                      </td>
                      <td className="px-4 py-2 whitespace-nowrap text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <span className="font-semibold text-foreground">{item.accumulatedPercent.toFixed(1)}%</span>
                          <div className="w-14 h-1.5 rounded-full bg-muted overflow-hidden">
                            <div
                              className={`h-full ${item.classe === 'A' ? 'bg-emerald-500' : item.classe === 'B' ? 'bg-sky-500' : 'bg-amber-500'}`}
                              style={{ width: `${Math.min(100, item.accumulatedPercent)}%` }}
                            />
                          </div>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// 4. ABA DE VENDAS GERAIS (EXISTENTE, PRESERVADA)
// ─────────────────────────────────────────────────────────────────────────────
function SalesReport() {
  const [tab, setTab] = useState('resumo');
  const [filterType, setFilterType] = useState<'dia' | 'mes' | 'periodo'>('mes');
  const [selDate, setSelDate] = useState(cur.toISOString().split('T')[0]);
  const [selMonth, setSelMonth] = useState(String(cur.getMonth() + 1));
  const [selYear, setSelYear] = useState(String(cur.getFullYear()));
  const [periodoFrom, setPeriodoFrom] = useState(cur.toISOString().split('T')[0].slice(0, 7) + '-01');
  const [periodoTo, setPeriodoTo] = useState(cur.toISOString().split('T')[0]);
  const [sales, setSales] = useState<UnifiedSale[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    let from: string, to: string;
    if (filterType === 'dia') {
      from = selDate + 'T00:00:00';
      to = selDate + 'T23:59:59';
    } else if (filterType === 'mes') {
      const y = parseInt(selYear), m = parseInt(selMonth);
      const last = new Date(y, m, 0).getDate();
      from = `${y}-${String(m).padStart(2,'0')}-01T00:00:00`;
      to = `${y}-${String(m).padStart(2,'0')}-${last}T23:59:59`;
    } else {
      from = periodoFrom + 'T00:00:00';
      to = periodoTo + 'T23:59:59';
    }

    try {
      const [ordersRes, pdvRes, prodRes] = await Promise.all([
        supabase.from('orders').select('*').gte('created_at', from).lte('created_at', to).in('status', ['completed', 'delivered']),
        supabase.from('pdv_invoices').select('id,number,created_at,total,payment_method,pdv_invoice_items(product_id,quantity,unit_price,pdv_products(name,code))')
          .gte('created_at', from).lte('created_at', to).eq('type', 'saida').eq('status', 'emitida'),
        supabase.from('pdv_products').select('id,code,site_product_id,cost_price'),
      ]);
      const costById: Record<string, number> = {};
      const costBySiteId: Record<string, number> = {};
      (prodRes.data || []).forEach((p: any) => {
        costById[p.id] = p.cost_price || 0;
        if (p.site_product_id) costBySiteId[p.site_product_id] = p.cost_price || 0;
      });
      const unified: UnifiedSale[] = [];
      (ordersRes.data || []).forEach((o: any) => {
        let cost = 0;
        const items = (o.items || []).map((i: any) => {
          const c = costBySiteId[i.id] || 0;
          cost += c * i.quantity;
          return { id: i.id, name: i.name, quantity: i.quantity, price: i.price, cost: c };
        });
        unified.push({ id: o.id, number: o.order_number, source: 'online', created_at: o.created_at, total_amount: o.total_amount || 0, total_cost: cost, items });
      });
      (pdvRes.data || []).forEach((p: any) => {
        let cost = 0;
        const items = (p.pdv_invoice_items || []).map((i: any) => {
          const c = costById[i.product_id] || 0;
          cost += c * i.quantity;
          return { id: i.product_id, code: i.pdv_products?.code, name: i.pdv_products?.name || 'Produto PDV', quantity: i.quantity, price: i.unit_price, cost: c };
        });
        unified.push({ id: p.id, number: p.number, source: 'pdv', created_at: p.created_at, total_amount: p.total || 0, total_cost: cost, payment_method: p.payment_method, items });
      });
      unified.sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
      setSales(unified);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [filterType, selDate, selMonth, selYear, periodoFrom, periodoTo]);

  useEffect(() => { load(); }, [load]);

  const revenue = sales.reduce((s, o) => s + o.total_amount, 0);
  const totalCost = sales.reduce((s, o) => s + o.total_cost, 0);
  const profit = revenue - totalCost;
  const margin = revenue > 0 ? (profit / revenue) * 100 : 0;
  const avgTicket = sales.length > 0 ? revenue / sales.length : 0;
  const totalQty = sales.reduce((s, o) => s + o.items.reduce((si, i) => si + i.quantity, 0), 0);

  const byDay = (() => {
    const map: Record<string, { date: string; receita: number; vendas: number }> = {};
    sales.forEach(o => {
      const d = new Date(o.created_at).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
      if (!map[d]) map[d] = { date: d, receita: 0, vendas: 0 };
      map[d].receita += o.total_amount; map[d].vendas++;
    });
    return Object.values(map);
  })();

  const byMonth = (() => {
    const map: Record<string, { mes: string; receita: number; vendas: number }> = {};
    sales.forEach(o => {
      const d = new Date(o.created_at);
      const k = `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`;
      const label = `${MONTH_NAMES[d.getMonth()].slice(0,3)}/${d.getFullYear()}`;
      if (!map[k]) map[k] = { mes: label, receita: 0, vendas: 0 };
      map[k].receita += o.total_amount; map[k].vendas++;
    });
    return Object.values(map);
  })();

  const prodMap: Record<string, { name: string; qty: number; revenue: number }> = {};
  sales.forEach(o => o.items.forEach(i => {
    if (!prodMap[i.id]) prodMap[i.id] = { name: i.name, qty: 0, revenue: 0 };
    prodMap[i.id].qty += i.quantity;
    prodMap[i.id].revenue += i.price * i.quantity;
  }));
  const topProducts = Object.values(prodMap).sort((a, b) => b.qty - a.qty).slice(0, 10);

  return (
    <div className="space-y-4">
      {/* Filtros */}
      <div className="bg-card border border-border rounded-lg p-4 space-y-3">
        <div className="flex items-center gap-2 flex-wrap">
          {(['dia','mes','periodo'] as const).map(t => (
            <Button key={t} size="sm" variant={filterType === t ? 'default' : 'outline'}
              onClick={() => setFilterType(t)}>
              {t === 'dia' ? 'Por Dia' : t === 'mes' ? 'Por Mês' : 'Período'}
            </Button>
          ))}
        </div>
        {filterType === 'dia' && (
          <div className="flex items-center gap-2">
            <Label className="text-sm shrink-0">Data:</Label>
            <Input type="date" value={selDate} onChange={e => setSelDate(e.target.value)} className="w-40 h-8" />
          </div>
        )}
        {filterType === 'mes' && (
          <div className="flex items-center gap-2 flex-wrap">
            <Label className="text-sm shrink-0">Mês/Ano:</Label>
            <Select value={selMonth} onValueChange={setSelMonth}>
              <SelectTrigger className="w-36 h-8"><SelectValue /></SelectTrigger>
              <SelectContent>{MONTH_NAMES.map((m, i) => <SelectItem key={i+1} value={String(i+1)}>{m}</SelectItem>)}</SelectContent>
            </Select>
            <Select value={selYear} onValueChange={setSelYear}>
              <SelectTrigger className="w-24 h-8"><SelectValue /></SelectTrigger>
              <SelectContent>{years.map(y => <SelectItem key={y} value={String(y)}>{y}</SelectItem>)}</SelectContent>
            </Select>
          </div>
        )}
        {filterType === 'periodo' && (
          <div className="flex items-center gap-2 flex-wrap">
            <Label className="text-sm shrink-0">De:</Label>
            <Input type="date" value={periodoFrom} onChange={e => setPeriodoFrom(e.target.value)} className="w-36 h-8" />
            <Label className="text-sm shrink-0">Até:</Label>
            <Input type="date" value={periodoTo} onChange={e => setPeriodoTo(e.target.value)} className="w-36 h-8" />
          </div>
        )}
      </div>

      {/* Abas */}
      <Tabs value={tab} onValueChange={setTab}>
        <TabsList>
          <TabsTrigger value="resumo" className="gap-1.5"><BarChart2 className="h-3.5 w-3.5" />Resumo</TabsTrigger>
          <TabsTrigger value="dia" className="gap-1.5"><CalendarDays className="h-3.5 w-3.5" />Por Dia</TabsTrigger>
          <TabsTrigger value="mes" className="gap-1.5"><TrendingUp className="h-3.5 w-3.5" />Por Mês</TabsTrigger>
          <TabsTrigger value="lista" className="gap-1.5"><FileText className="h-3.5 w-3.5" />Lista</TabsTrigger>
        </TabsList>

        {/* ── RESUMO ── */}
        <TabsContent value="resumo" className="mt-4 space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { label: 'Receita Total', val: fmtBRL(revenue), icon: DollarSign, cls: 'text-success' },
              { label: 'Lucro Bruto', val: fmtBRL(profit), icon: TrendingUp, cls: profit >= 0 ? 'text-success' : 'text-destructive' },
              { label: 'Margem', val: `${margin.toFixed(1)}%`, icon: BarChart2, cls: 'text-primary' },
              { label: 'Qtd. Vendas', val: sales.length, icon: ShoppingCart, cls: 'text-info' },
              { label: 'Ticket Médio', val: fmtBRL(avgTicket), icon: ArrowUpRight, cls: 'text-accent' },
              { label: 'Itens Vendidos', val: totalQty, icon: Coins, cls: 'text-foreground' },
              { label: 'Custo Total', val: fmtBRL(totalCost), icon: ArrowDownRight, cls: 'text-warning' },
              { label: 'Vendas Online', val: sales.filter(s => s.source === 'online').length, icon: ShoppingCart, cls: 'text-muted-foreground' },
            ].map((k, i) => (
              <div key={i} className="bg-card border border-border rounded-lg p-4">
                {loading ? <Skeleton className="h-10 bg-muted" /> : (
                  <div className="flex items-center gap-3">
                    <div className="h-9 w-9 rounded-lg bg-muted flex items-center justify-center shrink-0">
                      <k.icon className={`h-4 w-4 ${k.cls}`} />
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm md:text-base font-bold text-foreground truncate">{k.val}</p>
                      <p className="text-xs text-muted-foreground">{k.label}</p>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Top produtos */}
          <Card>
            <CardHeader className="pb-2"><CardTitle className="text-sm font-semibold">Produtos Mais Vendidos (Visão Rápida)</CardTitle></CardHeader>
            <CardContent className="p-0">
              {loading ? <div className="p-4 space-y-2">{[...Array(5)].map((_,i) => <Skeleton key={i} className="h-8 bg-muted" />)}</div>
                : topProducts.length === 0 ? <div className="py-10 text-center text-muted-foreground text-sm">Sem dados para o período</div>
                : (
                  <div className="overflow-x-auto">
                    <table className="w-full min-w-max text-sm">
                      <thead><tr className="border-b border-border bg-muted/40">
                        {['#','Produto','Qtd.','Receita'].map(h => <th key={h} className="text-left px-5 py-2 text-xs font-semibold text-muted-foreground whitespace-nowrap">{h}</th>)}
                      </tr></thead>
                      <tbody>
                        {topProducts.map((p, i) => (
                          <tr key={p.name} className="border-b border-border last:border-0 hover:bg-muted/20">
                            <td className="px-5 py-2 font-bold text-muted-foreground whitespace-nowrap">#{i+1}</td>
                            <td className="px-5 py-2 font-medium max-w-48 truncate whitespace-nowrap">{p.name}</td>
                            <td className="px-5 py-2 whitespace-nowrap">{p.qty} un.</td>
                            <td className="px-5 py-2 font-medium whitespace-nowrap">{fmtBRL(p.revenue)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ── POR DIA ── */}
        <TabsContent value="dia" className="mt-4 space-y-4">
          <Card>
            <CardHeader className="pb-2"><CardTitle className="text-sm font-semibold">Receita por Dia</CardTitle></CardHeader>
            <CardContent>
              {loading ? <Skeleton className="h-52 bg-muted" /> : byDay.length === 0
                ? <div className="h-52 flex items-center justify-center text-muted-foreground text-sm">Sem dados para o período</div>
                : (
                  <div className="w-full min-w-0 overflow-hidden">
                    <ResponsiveContainer width="100%" height={220}>
                      <BarChart data={byDay} margin={{ top: 4, right: 8, left: -10, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                        <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                        <YAxis tick={{ fontSize: 11 }} />
                        <Tooltip formatter={(v: number) => fmtBRL(v)} />
                        <Bar dataKey="receita" fill="hsl(var(--primary))" radius={[3,3,0,0]} name="Receita" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                )}
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2"><CardTitle className="text-sm font-semibold">Nº de Vendas por Dia</CardTitle></CardHeader>
            <CardContent>
              {loading ? <Skeleton className="h-44 bg-muted" /> : byDay.length === 0
                ? <div className="h-44 flex items-center justify-center text-muted-foreground text-sm">Sem dados</div>
                : (
                  <div className="w-full min-w-0 overflow-hidden">
                    <ResponsiveContainer width="100%" height={160}>
                      <LineChart data={byDay} margin={{ top: 4, right: 8, left: -10, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                        <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                        <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                        <Tooltip />
                        <Line type="monotone" dataKey="vendas" stroke="hsl(var(--accent))" strokeWidth={2} dot={{ r: 3 }} name="Vendas" />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ── POR MÊS ── */}
        <TabsContent value="mes" className="mt-4 space-y-4">
          <Card>
            <CardHeader className="pb-2"><CardTitle className="text-sm font-semibold">Receita por Mês</CardTitle></CardHeader>
            <CardContent>
              {loading ? <Skeleton className="h-64 bg-muted" /> : byMonth.length === 0
                ? <div className="h-64 flex items-center justify-center text-muted-foreground text-sm">Sem dados — use filtro Período</div>
                : (
                  <div className="w-full min-w-0 overflow-hidden">
                    <ResponsiveContainer width="100%" height={240}>
                      <BarChart data={byMonth} margin={{ top: 4, right: 8, left: -10, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                        <XAxis dataKey="mes" tick={{ fontSize: 11 }} />
                        <YAxis tick={{ fontSize: 11 }} />
                        <Tooltip formatter={(v: number) => fmtBRL(v)} />
                        <Legend layout="horizontal" wrapperStyle={{ paddingTop: 8 }} />
                        <Bar dataKey="receita" fill="hsl(var(--primary))" radius={[3,3,0,0]} name="Receita" />
                        <Bar dataKey="vendas" fill="hsl(var(--accent))" radius={[3,3,0,0]} name="Vendas" yAxisId={0} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ── LISTA ── */}
        <TabsContent value="lista" className="mt-4">
          <Card>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-semibold">Lista de Vendas ({sales.length})</CardTitle>
                <span className="text-xs text-muted-foreground">Total: {fmtBRL(revenue)}</span>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              {loading ? <div className="p-4 space-y-2">{[...Array(6)].map((_,i) => <Skeleton key={i} className="h-8 bg-muted" />)}</div>
                : sales.length === 0 ? <div className="py-10 text-center text-muted-foreground text-sm">Sem vendas no período</div>
                : (
                  <div className="overflow-x-auto">
                    <table className="w-full min-w-max text-sm">
                      <thead><tr className="border-b border-border bg-muted/40">
                        {['Data/Hora','Doc','Canal','Forma Pgto','Total','Custo','Lucro'].map(h => <th key={h} className="text-left px-4 py-2 text-xs font-semibold text-muted-foreground whitespace-nowrap">{h}</th>)}
                      </tr></thead>
                      <tbody>
                        {[...sales].reverse().map(s => {
                          const lucro = s.total_amount - s.total_cost;
                          return (
                            <tr key={s.id} className="border-b border-border last:border-0 hover:bg-muted/20">
                              <td className="px-4 py-2 whitespace-nowrap text-xs">{new Date(s.created_at).toLocaleString('pt-BR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'})}</td>
                              <td className="px-4 py-2 whitespace-nowrap text-xs font-medium">{s.number || s.id.slice(0, 8)}</td>
                              <td className="px-4 py-2 whitespace-nowrap">
                                <Badge variant="outline" className="text-xs">{s.source === 'pdv' ? 'PDV' : 'Online'}</Badge>
                              </td>
                              <td className="px-4 py-2 whitespace-nowrap text-muted-foreground text-xs">{s.payment_method || '—'}</td>
                              <td className="px-4 py-2 whitespace-nowrap font-medium text-success">{fmtBRL(s.total_amount)}</td>
                              <td className="px-4 py-2 whitespace-nowrap text-muted-foreground">{fmtBRL(s.total_cost)}</td>
                              <td className={`px-4 py-2 whitespace-nowrap font-medium ${lucro >= 0 ? 'text-success' : 'text-destructive'}`}>{fmtBRL(lucro)}</td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// 5. ABA DE CONTAS A PAGAR/RECEBER (EXISTENTE, PRESERVADA)
// ─────────────────────────────────────────────────────────────────────────────
const BILL_STATUS_MAP: Record<string, { label: string; cls: string }> = {
  pendente:  { label: 'Pendente',  cls: 'text-warning bg-warning/10 border-warning/30' },
  pago:      { label: 'Pago',      cls: 'text-success bg-success/10 border-success/30' },
  vencido:   { label: 'Vencido',   cls: 'text-destructive bg-destructive/10 border-destructive/30' },
  cancelado: { label: 'Cancelado', cls: 'text-muted-foreground bg-muted/40 border-border' },
  parcial:   { label: 'Parcial',   cls: 'text-primary bg-primary/10 border-primary/30' },
};

function BillsReport() {
  const [selMonth, setSelMonth] = useState(String(cur.getMonth() + 1));
  const [selYear, setSelYear] = useState(String(cur.getFullYear()));
  const [rows, setRows] = useState<BillRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [typeFilter, setTypeFilter] = useState<'todos'|'pagar'|'receber'>('todos');

  const load = useCallback(async () => {
    setLoading(true);
    const y = parseInt(selYear), m = parseInt(selMonth);
    const last = new Date(y, m, 0).getDate();
    const from = `${y}-${String(m).padStart(2,'0')}-01`;
    const to = `${y}-${String(m).padStart(2,'0')}-${last}`;

    const { data } = await supabase
      .from('bill_installments')
      .select('*, bills(type, description, installments, category, suppliers(razao_social), customers(name))')
      .gte('due_date', from).lte('due_date', to)
      .order('due_date');

    const mapped: BillRow[] = (data || []).map((i: any) => ({
      id: i.id,
      type: i.bills?.type,
      description: i.bills?.description || '—',
      installment_number: i.installment_number,
      total_installments: i.bills?.installments || 1,
      amount: i.amount,
      due_date: i.due_date,
      paid_date: i.paid_date,
      paid_amount: i.paid_amount,
      partial_paid_amount: i.partial_paid_amount,
      remaining_amount: i.remaining_amount,
      status: i.status,
      category: i.bills?.category || '—',
      supplier: i.bills?.suppliers?.razao_social,
      customer: i.bills?.customers?.name,
    }));
    setRows(mapped);
    setLoading(false);
  }, [selMonth, selYear]);

  useEffect(() => { load(); }, [load]);

  const safeNum = (v: number | null | undefined, fb = 0) => v != null && !isNaN(Number(v)) ? Number(v) : fb;

  const visible = rows.filter(r => typeFilter === 'todos' || r.type === typeFilter);
  const totalPagar = rows.filter(r => r.type === 'pagar').reduce((s, r) => s + safeNum(r.remaining_amount, safeNum(r.amount)), 0);
  const totalPago = rows.filter(r => r.type === 'pagar' && r.status === 'pago').reduce((s, r) => s + safeNum(r.paid_amount, safeNum(r.amount)), 0);
  const totalReceber = rows.filter(r => r.type === 'receber').reduce((s, r) => s + safeNum(r.remaining_amount, safeNum(r.amount)), 0);
  const totalRecebido = rows.filter(r => r.type === 'receber' && r.status === 'pago').reduce((s, r) => s + safeNum(r.paid_amount, safeNum(r.amount)), 0);
  const saldo = totalReceber - totalPagar;

  return (
    <div className="space-y-4">
      {/* Filtro mês/ano */}
      <div className="bg-card border border-border rounded-lg p-4 flex flex-wrap items-center gap-3">
        <Label className="text-sm shrink-0">Mês/Ano:</Label>
        <Select value={selMonth} onValueChange={setSelMonth}>
          <SelectTrigger className="w-36 h-8"><SelectValue /></SelectTrigger>
          <SelectContent>{MONTH_NAMES.map((m, i) => <SelectItem key={i+1} value={String(i+1)}>{m}</SelectItem>)}</SelectContent>
        </Select>
        <Select value={selYear} onValueChange={setSelYear}>
          <SelectTrigger className="w-24 h-8"><SelectValue /></SelectTrigger>
          <SelectContent>{years.map(y => <SelectItem key={y} value={String(y)}>{y}</SelectItem>)}</SelectContent>
        </Select>
        <Separator orientation="vertical" className="h-6 hidden md:block" />
        {(['todos','pagar','receber'] as const).map(t => (
          <Button key={t} size="sm" variant={typeFilter === t ? 'default' : 'outline'} onClick={() => setTypeFilter(t)}>
            {t === 'todos' ? 'Todos' : t === 'pagar' ? 'A Pagar' : 'A Receber'}
          </Button>
        ))}
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        {[
          { label: 'Total a Pagar', val: fmtBRL(totalPagar), icon: TrendingDown, cls: 'text-destructive' },
          { label: 'Pago no Mês', val: fmtBRL(totalPago), icon: CheckCircle, cls: 'text-success' },
          { label: 'Total a Receber', val: fmtBRL(totalReceber), icon: TrendingUp, cls: 'text-success' },
          { label: 'Recebido no Mês', val: fmtBRL(totalRecebido), icon: CheckCircle, cls: 'text-success' },
          { label: 'Saldo (Rec-Pag)', val: fmtBRL(saldo), icon: DollarSign, cls: saldo >= 0 ? 'text-success' : 'text-destructive' },
          { label: 'Vencidas', val: rows.filter(r => r.status === 'vencido').length, icon: AlertCircle, cls: 'text-warning' },
        ].map((k, i) => (
          <div key={i} className="bg-card border border-border rounded-lg p-4">
            {loading ? <Skeleton className="h-10 bg-muted" /> : (
              <div className="flex items-center gap-3">
                <div className="h-9 w-9 rounded-lg bg-muted flex items-center justify-center shrink-0">
                  <k.icon className={`h-4 w-4 ${k.cls}`} />
                </div>
                <div className="min-w-0">
                  <p className="text-sm md:text-base font-bold text-foreground truncate">{k.val}</p>
                  <p className="text-xs text-muted-foreground">{k.label}</p>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Tabela */}
      <Card>
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm font-semibold">Detalhamento — {MONTH_NAMES[parseInt(selMonth)-1]}/{selYear}</CardTitle>
            <span className="text-xs text-muted-foreground">{visible.length} parcela(s)</span>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {loading ? <div className="p-4 space-y-2">{[...Array(5)].map((_,i) => <Skeleton key={i} className="h-8 bg-muted" />)}</div>
            : visible.length === 0 ? <div className="py-10 text-center text-muted-foreground text-sm">Nenhuma parcela no período</div>
            : (
              <div className="overflow-x-auto">
                <table className="w-full min-w-max text-sm">
                  <thead><tr className="border-b border-border bg-muted/40">
                    {['Tipo','Descrição','Categoria','Forn./Cliente','Venc.','Valor','Pago','Restante','Status'].map(h =>
                      <th key={h} className="text-left px-4 py-2 text-xs font-semibold text-muted-foreground whitespace-nowrap">{h}</th>)}
                  </tr></thead>
                  <tbody>
                    {visible.map(r => {
                      const st = BILL_STATUS_MAP[r.status] || BILL_STATUS_MAP.pendente;
                      const paidAmt = safeNum(r.partial_paid_amount);
                      const remaining = safeNum(r.remaining_amount, safeNum(r.amount));
                      return (
                        <tr key={r.id} className="border-b border-border last:border-0 hover:bg-muted/20">
                          <td className="px-4 py-2 whitespace-nowrap">
                            <Badge variant="outline" className={`text-xs ${r.type === 'pagar' ? 'text-destructive border-destructive/40' : 'text-success border-success/40'}`}>
                              {r.type === 'pagar' ? 'Pagar' : 'Receber'}
                            </Badge>
                          </td>
                          <td className="px-4 py-2 font-medium max-w-40 truncate whitespace-nowrap">{r.description} <span className="text-muted-foreground font-normal">({r.installment_number}/{r.total_installments})</span></td>
                          <td className="px-4 py-2 text-muted-foreground whitespace-nowrap">{r.category}</td>
                          <td className="px-4 py-2 text-muted-foreground whitespace-nowrap max-w-36 truncate">{r.supplier || r.customer || '—'}</td>
                          <td className="px-4 py-2 whitespace-nowrap">{new Date(r.due_date + 'T00:00:00').toLocaleDateString('pt-BR')}</td>
                          <td className="px-4 py-2 whitespace-nowrap font-medium">{fmtBRL(safeNum(r.amount))}</td>
                          <td className="px-4 py-2 whitespace-nowrap text-success">{paidAmt > 0 ? fmtBRL(paidAmt) : '—'}</td>
                          <td className="px-4 py-2 whitespace-nowrap font-medium">{remaining > 0 ? fmtBRL(remaining) : '—'}</td>
                          <td className="px-4 py-2 whitespace-nowrap">
                            <span className={`inline-flex items-center text-xs px-2 py-0.5 rounded-full border ${st.cls}`}>{st.label}</span>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
        </CardContent>
      </Card>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// COMPONENTE PRINCIPAL: PdvRelatorios
// ─────────────────────────────────────────────────────────────────────────────
export default function PdvRelatorios() {
  const [mainTab, setMainTab] = useState('lucratividade');

  return (
    <PdvLayout
      title="Relatórios Analíticos"
      actions={
        <Button variant="outline" size="sm" onClick={() => window.print()} className="gap-1.5 print:hidden">
          <Download className="h-4 w-4" /> Imprimir Relatório
        </Button>
      }
    >
      <Tabs value={mainTab} onValueChange={setMainTab} className="space-y-4">
        <TabsList className="print:hidden flex-wrap h-auto gap-1 bg-muted/60 p-1">
          <TabsTrigger value="lucratividade" className="gap-1.5 text-xs py-1.5 px-3">
            <TrendingUp className="h-3.5 w-3.5 text-primary" /> Lucratividade
          </TabsTrigger>
          <TabsTrigger value="mais_vendidos" className="gap-1.5 text-xs py-1.5 px-3">
            <Award className="h-3.5 w-3.5 text-amber-500" /> Mais Vendidos
          </TabsTrigger>
          <TabsTrigger value="curva_abc" className="gap-1.5 text-xs py-1.5 px-3">
            <Layers className="h-3.5 w-3.5 text-emerald-500" /> Curva ABC
          </TabsTrigger>
          <TabsTrigger value="vendas" className="gap-1.5 text-xs py-1.5 px-3">
            <ShoppingCart className="h-3.5 w-3.5" /> Vendas Gerais
          </TabsTrigger>
          <TabsTrigger value="contas" className="gap-1.5 text-xs py-1.5 px-3">
            <FileText className="h-3.5 w-3.5" /> Contas a Pagar/Receber
          </TabsTrigger>
        </TabsList>

        <TabsContent value="lucratividade">
          <ProfitabilityReport />
        </TabsContent>

        <TabsContent value="mais_vendidos">
          <BestSellersReport />
        </TabsContent>

        <TabsContent value="curva_abc">
          <CurvaAbcReport />
        </TabsContent>

        <TabsContent value="vendas">
          <SalesReport />
        </TabsContent>

        <TabsContent value="contas">
          <BillsReport />
        </TabsContent>
      </Tabs>
    </PdvLayout>
  );
}
