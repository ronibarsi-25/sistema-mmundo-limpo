import { useEffect, useState } from 'react';
import { Plus, Pencil, Trash2, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { PdvLayout } from '@/components/layouts/PdvLayout';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import type { Profile, UserRole } from '@/types/types';

const ROLE_LABELS: Record<UserRole, string> = {
  admin: 'Administrador',
  gestor: 'Gerente',
  operador: 'Operador',
  vendedor: 'Vendedor',
  user: 'Cliente',
};

export default function PdvUsuarios() {
  const [users, setUsers] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [showDialog, setShowDialog] = useState(false);
  const [editUser, setEditUser] = useState<Profile | null>(null);
  const [fullName, setFullName] = useState('');
  const [role, setRole] = useState<UserRole>('operador');
  const [submitting, setSubmitting] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  // New user form
  const [showCreate, setShowCreate] = useState(false);
  const [newUsername, setNewUsername] = useState('');
  const [newFullName, setNewFullName] = useState('');
  const [newRole, setNewRole] = useState<UserRole>('operador');
  const [newPassword, setNewPassword] = useState('');

  useEffect(() => { load(); }, []);

  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from('profiles').select('*').in('role', ['admin', 'gestor', 'operador', 'vendedor']).order('full_name');
    setUsers((data as Profile[]) || []);
    setLoading(false);
  };

  const openEdit = (u: Profile) => { setEditUser(u); setFullName(u.full_name || ''); setRole(u.role); setShowDialog(true); };

  const handleSaveEdit = async () => {
    if (!editUser) return;
    setSubmitting(true);
    const { error } = await supabase.from('profiles').update({ full_name: fullName, role }).eq('id', editUser.id);
    setSubmitting(false);
    if (error) { toast.error('Erro ao atualizar'); return; }
    toast.success('Usuário atualizado!'); setShowDialog(false); load();
  };

  const handleCreate = async () => {
    if (!newUsername.trim() || !newPassword || !newFullName.trim()) { toast.error('Preencha todos os campos'); return; }
    setSubmitting(true);
    const email = `${newUsername.trim()}@miaoda.com`;
    const { data: authData, error: authErr } = await supabase.auth.admin ? 
      // Use service role if available — otherwise fallback to signUp (edge function recommended for production)
      { data: null, error: new Error('admin API not available on client') } :
      await supabase.auth.signUp({ email, password: newPassword, options: { data: { full_name: newFullName, username: newUsername.trim(), role: newRole } } });
    
    if (authErr) {
      // Fallback: create directly using signUp API
      const { data: su, error: suErr } = await supabase.auth.signUp({ email, password: newPassword });
      if (suErr) { toast.error('Erro ao criar: ' + suErr.message); setSubmitting(false); return; }
      if (su.user) {
        await supabase.from('profiles').update({ full_name: newFullName, username: newUsername.trim(), role: newRole }).eq('id', su.user.id);
      }
    }

    setSubmitting(false);
    toast.success(`Usuário ${newUsername} criado! Login: ${newUsername} / ${newPassword}`);
    setShowCreate(false); setNewUsername(''); setNewFullName(''); setNewPassword(''); setNewRole('operador');
    load();
  };

  return (
    <PdvLayout title="Usuários" actions={<Button size="sm" onClick={() => setShowCreate(true)}><Plus className="h-4 w-4 mr-1.5" />Novo Usuário</Button>}>
      <div className="bg-card border border-border rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/40">
                <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Nome</th>
                <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Usuário</th>
                <th className="text-left px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">E-mail</th>
                <th className="text-center px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Perfil</th>
                <th className="text-center px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Status</th>
                <th className="text-right px-4 py-3 font-medium text-muted-foreground whitespace-nowrap">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {loading ? (
                Array.from({ length: 3 }).map((_, i) => <tr key={i}><td colSpan={6} className="px-4 py-3"><Skeleton className="h-5 w-full bg-muted" /></td></tr>)
              ) : users.length === 0 ? (
                <tr><td colSpan={6} className="text-center py-12 text-muted-foreground">
                  <Users className="h-8 w-8 mx-auto mb-2 opacity-40" />
                  <p className="text-pretty">Nenhum usuário encontrado</p>
                </td></tr>
              ) : users.map(u => (
                <tr key={u.id} className="hover:bg-muted/30 transition-colors">
                  <td className="px-4 py-3 font-medium whitespace-nowrap">{u.full_name || '—'}</td>
                  <td className="px-4 py-3 font-mono text-xs whitespace-nowrap">{u.username || '—'}</td>
                  <td className="px-4 py-3 text-muted-foreground whitespace-nowrap text-xs">{u.email || '—'}</td>
                  <td className="px-4 py-3 text-center whitespace-nowrap">
                    <Badge variant={u.role === 'admin' ? 'default' : 'secondary'} className="text-xs">{ROLE_LABELS[u.role]}</Badge>
                  </td>
                  <td className="px-4 py-3 text-center whitespace-nowrap">
                    <Badge variant={u.active ? 'default' : 'secondary'} className="text-xs">{u.active ? 'Ativo' : 'Inativo'}</Badge>
                  </td>
                  <td className="px-4 py-3 text-right whitespace-nowrap">
                    <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openEdit(u)}><Pencil className="h-3.5 w-3.5" /></Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Edit dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-sm">
          <DialogHeader><DialogTitle className="text-balance">Editar Usuário</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5"><Label className="text-sm font-normal">Nome Completo</Label><Input value={fullName} onChange={e => setFullName(e.target.value)} /></div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Perfil</Label>
              <Select value={role} onValueChange={v => setRole(v as UserRole)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{(Object.keys(ROLE_LABELS) as UserRole[]).filter(r => r !== 'user').map(r => <SelectItem key={r} value={r}>{ROLE_LABELS[r]}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter className="gap-2"><Button variant="outline" onClick={() => setShowDialog(false)}>Cancelar</Button><Button onClick={handleSaveEdit} disabled={submitting}>Salvar</Button></DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Create dialog */}
      <Dialog open={showCreate} onOpenChange={setShowCreate}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-sm">
          <DialogHeader><DialogTitle className="text-balance">Novo Usuário</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5"><Label className="text-sm font-normal">Nome Completo *</Label><Input value={newFullName} onChange={e => setNewFullName(e.target.value)} /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Usuário (login) *</Label><Input value={newUsername} onChange={e => setNewUsername(e.target.value.toLowerCase().replace(/\s/g, ''))} placeholder="ex: joao.silva" /></div>
            <div className="space-y-1.5"><Label className="text-sm font-normal">Senha *</Label><Input type="password" value={newPassword} onChange={e => setNewPassword(e.target.value)} /></div>
            <div className="space-y-1.5">
              <Label className="text-sm font-normal">Perfil</Label>
              <Select value={newRole} onValueChange={v => setNewRole(v as UserRole)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{(Object.keys(ROLE_LABELS) as UserRole[]).filter(r => r !== 'user').map(r => <SelectItem key={r} value={r}>{ROLE_LABELS[r]}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="bg-muted/40 rounded-md p-3 text-xs text-muted-foreground">
              O usuário fará login com: <strong>{newUsername || 'username'}</strong> / senha definida acima
            </div>
          </div>
          <DialogFooter className="gap-2"><Button variant="outline" onClick={() => setShowCreate(false)}>Cancelar</Button><Button onClick={handleCreate} disabled={submitting}>Criar Usuário</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </PdvLayout>
  );
}
