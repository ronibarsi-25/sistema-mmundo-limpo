import { useState, useEffect, useMemo, useCallback } from 'react';
import { PdvLayout } from '@/components/layouts/PdvLayout';
import { supabase } from '@/db/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import {
  Search, Calendar, Filter, XCircle, Printer, Eye, Loader2,
  AlertTriangle, RotateCcw, CreditCard, Banknote, QrCode,
  DollarSign, CheckCircle2, TrendingUp, RefreshCw, ShoppingCart,
  ArrowUpDown, Download, Layers, FileText
} from 'lucide-react';
import { printCupomFiscal, type CupomData, type CupomItem } from '@/utils/printCupom';
import { cancelPdvSale } from '@/utils/saleCancellation';
import { generateCancellationReportPdf, type CancelledSaleReportItem } from '@/utils/cancellationReportPdf';

interface SaleItem {
  id: string;
  product_id: string;
  quantity: number;
  unit_price: number;
  total_price: number;
  pdv_products?: {
    name: string;
    unit: string;
    code: string;
  } | null;
}

interface SaleRecord {
  id: string;
  number: string;
  status: 'emitida' | 'cancelada' | 'pendente';
  total: number;
  subtotal: number;
  discount: number;
  payment_method: string;
  installments?: number;
  notes?: string;
  cancellation_reason?: string;
  cancelled_at?: string;
  cancelled_by?: string;
  created_at: string;
  customer_id?: string;
  customers?: {
    name: string;
    phone?: string;
    cpf_cnpj?: string;
  } | null;
  profiles?: {
    full_name?: string;
    username?: string;
  } | null;
  pdv_invoice_items?: SaleItem[];
}

const PAYMENT_LABELS: Record<string, string> = {
  dinheiro: 'Dinheiro',
  cartao_debito: 'Cartão Débito',
  cartao_credito: 'Cartão Crédito',
  pix: 'PIX',
  multiplo: 'Combinado',
  outros: 'Outros',
};

export default function PdvVendas() {
  const { profile } = useAuth();

  const [sales, setSales] = useState<SaleRecord[]>([]);
  const [loading, setLoading] = useState(true);

  // Filtros
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'emitida' | 'cancelada'>('all');
  const [paymentFilter, setPaymentFilter] = useState<string>('all');
  const [dateFilterMode, setDateFilterMode] = useState<'hoje' | 'ontem' | '7dias' | 'mes' | 'todos' | 'custom'>('hoje');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');

  // Modais
  const [selectedSale, setSelectedSale] = useState<SaleRecord | null>(null);
  const [showDetailDialog, setShowDetailDialog] = useState(false);

  const [saleToCancel, setSaleToCancel] = useState<SaleRecord | null>(null);
  const [cancelReason, setCancelReason] = useState('');
  const [cancelling, setCancelling] = useState(false);

  // Inicializar datas com base no modo
  useEffect(() => {
    const today = new Date();
    const todayStr = today.toISOString().split('T')[0];

    if (dateFilterMode === 'hoje') {
      setDateFrom(todayStr);
      setDateTo(todayStr);
    } else if (dateFilterMode === 'ontem') {
      const yesterday = new Date(Date.now() - 86400000);
      const yStr = yesterday.toISOString().split('T')[0];
      setDateFrom(yStr);
      setDateTo(yStr);
    } else if (dateFilterMode === '7dias') {
      const past7 = new Date(Date.now() - 7 * 86400000);
      setDateFrom(past7.toISOString().split('T')[0]);
      setDateTo(todayStr);
    } else if (dateFilterMode === 'mes') {
      const firstDay = new Date(today.getFullYear(), today.getMonth(), 1);
      setDateFrom(firstDay.toISOString().split('T')[0]);
      setDateTo(todayStr);
    } else if (dateFilterMode === 'todos') {
      setDateFrom('');
      setDateTo('');
    }
  }, [dateFilterMode]);

  const fetchSales = useCallback(async () => {
    setLoading(true);
    try {
      let query = supabase
        .from('pdv_invoices')
        .select(`
          id, number, status, total, subtotal, discount, payment_method,
          installments, notes, cancellation_reason, cancelled_at, cancelled_by,
          created_at, customer_id,
          customers ( name, phone, cpf_cnpj ),
          profiles:created_by ( full_name, username ),
          pdv_invoice_items (
            id, product_id, quantity, unit_price, total_price,
            pdv_products ( name, unit, code )
          )
        `)
        .eq('type', 'saida')
        .order('created_at', { ascending: false });

      if (dateFrom) {
        query = query.gte('created_at', `${dateFrom}T00:00:00.000Z`);
      }
      if (dateTo) {
        query = query.lte('created_at', `${dateTo}T23:59:59.999Z`);
      }

      const { data, error } = await query.limit(200);

      if (error) {
        throw error;
      }

      setSales((data as unknown as SaleRecord[]) || []);
    } catch (err: unknown) {
      console.error('Erro ao carregar vendas:', err);
      toast.error('Erro ao carregar lista de vendas.');
    } finally {
      setLoading(false);
    }
  }, [dateFrom, dateTo]);

  useEffect(() => {
    fetchSales();
  }, [fetchSales]);

  // Vendas filtradas client-side
  const filteredSales = useMemo(() => {
    return sales.filter(s => {
      // Filtro status
      if (statusFilter !== 'all' && s.status !== statusFilter) return false;

      // Filtro pagamento
      if (paymentFilter !== 'all' && s.payment_method !== paymentFilter) return false;

      // Busca por texto (número, cliente, observações)
      if (search.trim()) {
        const q = search.toLowerCase().trim();
        const numMatch = s.number?.toLowerCase().includes(q);
        const custMatch = s.customers?.name?.toLowerCase().includes(q) || s.customers?.cpf_cnpj?.includes(q);
        const itemMatch = s.pdv_invoice_items?.some(it => it.pdv_products?.name?.toLowerCase().includes(q));
        const noteMatch = s.notes?.toLowerCase().includes(q) || s.cancellation_reason?.toLowerCase().includes(q);

        if (!numMatch && !custMatch && !itemMatch && !noteMatch) return false;
      }

      return true;
    });
  }, [sales, statusFilter, paymentFilter, search]);

  // Totais analíticos
  const stats = useMemo(() => {
    let totalEmitidas = 0;
    let valorEmitidas = 0;
    let totalCanceladas = 0;
    let valorCancelado = 0;

    filteredSales.forEach(s => {
      const v = Number(s.total) || 0;
      if (s.status === 'cancelada') {
        totalCanceladas += 1;
        valorCancelado += v;
      } else {
        totalEmitidas += 1;
        valorEmitidas += v;
      }
    });

    const ticketMedio = totalEmitidas > 0 ? valorEmitidas / totalEmitidas : 0;

    return { totalEmitidas, valorEmitidas, totalCanceladas, valorCancelado, ticketMedio };
  }, [filteredSales]);

  // Executar cancelamento
  const handleConfirmCancel = async () => {
    if (!saleToCancel) return;
    if (!cancelReason.trim()) {
      toast.error('Por favor, informe a justificativa do cancelamento.');
      return;
    }

    setCancelling(true);
    try {
      const res = await cancelPdvSale(saleToCancel.id, cancelReason.trim(), profile?.id);

      if (!res.success) {
        toast.error(res.error || 'Erro ao cancelar a venda.');
        return;
      }

      toast.success(res.message || 'Venda cancelada com sucesso!');
      setSaleToCancel(null);
      setCancelReason('');
      setShowDetailDialog(false);
      // Recarregar vendas
      await fetchSales();
    } catch (err: unknown) {
      console.error(err);
      toast.error('Ocorreu um erro ao processar o cancelamento.');
    } finally {
      setCancelling(false);
    }
  };

  // Reimprimir Cupom da Venda
  const handleReprint = async (sale: SaleRecord) => {
    try {
      const { data: company } = await supabase.from('company').select('*').limit(1).maybeSingle();

      const items: CupomItem[] = (sale.pdv_invoice_items || []).map(it => ({
        name: it.pdv_products?.name || 'Item',
        qty: Number(it.quantity) || 1,
        unit: it.pdv_products?.unit || 'un',
        unit_price: Number(it.unit_price) || 0,
        total_price: Number(it.total_price) || 0,
        discount: 0,
      }));

      const cupom: CupomData = {
        number: sale.number,
        issued_at: sale.created_at,
        store_name: company?.nome_fantasia || company?.razao_social || 'Loja',
        cnpj: company?.cnpj,
        logradouro: company?.logradouro,
        numero: company?.numero,
        bairro: company?.bairro,
        cidade: company?.cidade,
        estado: company?.estado,
        telefone: company?.telefone,
        items,
        subtotal: Number(sale.subtotal) || Number(sale.total) || 0,
        discount: Number(sale.discount) || 0,
        total: Number(sale.total) || 0,
        payment_method: PAYMENT_LABELS[sale.payment_method] || sale.payment_method || 'Outros',
        amount_paid: Number(sale.total) || 0,
        change: 0,
        customer_name: sale.customers?.name,
        operator_name: sale.profiles?.full_name || sale.profiles?.username || undefined,
      };

      printCupomFiscal(cupom);
      toast.success(`Cupom ${sale.number} enviado para impressão.`);
    } catch (err: unknown) {
      console.error(err);
      toast.error('Erro ao preparar impressão do cupom.');
    }
  };

  // Exportar lista atual para CSV
  const exportCsv = () => {
    if (filteredSales.length === 0) {
      toast.error('Nenhuma venda para exportar');
      return;
    }

    const headers = ['Número', 'Data', 'Status', 'Cliente', 'Forma Pagamento', 'Subtotal', 'Desconto', 'Total', 'Justificativa'];
    const rows = filteredSales.map(s => [
      s.number,
      new Date(s.created_at).toLocaleString('pt-BR'),
      s.status,
      s.customers?.name || 'Consumidor Final',
      PAYMENT_LABELS[s.payment_method] || s.payment_method,
      Number(s.subtotal || s.total).toFixed(2),
      Number(s.discount || 0).toFixed(2),
      Number(s.total).toFixed(2),
      s.cancellation_reason || s.notes || '',
    ]);

    const csvContent = [headers.join(','), ...rows.map(r => r.map(c => `"${String(c).replace(/"/g, '""')}"`).join(','))].join('\n');
    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `vendas_pdv_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast.success('Arquivo CSV baixado com sucesso!');
  };

  // Exportar relatório em PDF com todas as vendas canceladas e suas justificativas
  const [exportingPdf, setExportingPdf] = useState(false);

  const handleExportCancelledPdf = async (customFilterSales?: SaleRecord[]) => {
    setExportingPdf(true);
    try {
      let targetCancelled: SaleRecord[] = [];
      if (customFilterSales) {
        targetCancelled = customFilterSales.filter(s => s.status === 'cancelada');
      } else {
        // Vendas canceladas filtradas na listagem atual
        targetCancelled = sales.filter(s => {
          if (s.status !== 'cancelada') return false;
          if (dateFilterMode !== 'todos') {
            const createdAt = new Date(s.created_at);
            if (dateFrom && createdAt < new Date(dateFrom + 'T00:00:00')) return false;
            if (dateTo && createdAt > new Date(dateTo + 'T23:59:59')) return false;
          }
          return true;
        });
      }

      // Se não encontrou nenhuma cancelada no filtro ativo, busca as mais recentes canceladas no banco
      if (targetCancelled.length === 0) {
        const { data: allCancelled, error: fetchErr } = await supabase
          .from('pdv_invoices')
          .select(`
            id, number, status, total, subtotal, discount, payment_method, notes,
            cancellation_reason, cancelled_at, cancelled_by, created_at,
            customers ( name, phone, cpf_cnpj ),
            pdv_invoice_items ( id, quantity )
          `)
          .eq('status', 'cancelada')
          .order('cancelled_at', { ascending: false })
          .limit(100);

        if (fetchErr) throw fetchErr;

        if (!allCancelled || allCancelled.length === 0) {
          toast.info('Nenhuma venda cancelada foi encontrada no sistema para gerar o relatório.');
          setExportingPdf(false);
          return;
        }
        targetCancelled = allCancelled as unknown as SaleRecord[];
      }

      // Mapear responsáveis pelos cancelamentos
      const userIds = [...new Set(targetCancelled.map(s => s.cancelled_by).filter(Boolean))];
      const userMap: Record<string, string> = {};
      if (userIds.length > 0) {
        const { data: profiles } = await supabase
          .from('profiles')
          .select('id, full_name, username')
          .in('id', userIds);
        profiles?.forEach(p => {
          userMap[p.id] = p.full_name || p.username || 'Operador';
        });
      }

      const reportItems: CancelledSaleReportItem[] = targetCancelled.map(s => ({
        id: s.id,
        number: s.number,
        created_at: s.created_at,
        cancelled_at: s.cancelled_at,
        cancelled_by_name: s.cancelled_by ? (userMap[s.cancelled_by] || 'Operador') : (profile?.full_name || 'Operador'),
        cancellation_reason: s.cancellation_reason || 'Desistência / Devolução',
        total: Number(s.total) || 0,
        payment_method: s.payment_method,
        customer_name: s.customers?.name || 'Consumidor Final',
        items_count: s.pdv_invoice_items?.reduce((acc: number, it: any) => acc + (Number(it.quantity) || 1), 0) || 1,
      }));

      const periodLabelMap: Record<string, string> = {
        hoje: 'Hoje',
        ontem: 'Ontem',
        '7dias': 'Últimos 7 dias',
        mes: 'Mês Atual',
        todos: 'Histórico Completo',
        custom: `${dateFrom ? new Date(dateFrom + 'T00:00:00').toLocaleDateString('pt-BR') : ''} até ${dateTo ? new Date(dateTo + 'T23:59:59').toLocaleDateString('pt-BR') : ''}`,
      };

      const periodLabel = periodLabelMap[dateFilterMode] || 'Período Selecionado';

      await generateCancellationReportPdf({
        periodLabel,
        startDate: dateFrom,
        endDate: dateTo,
        operatorName: profile?.full_name || profile?.username || undefined,
        sales: reportItems,
      });

      toast.success('Relatório em PDF de vendas canceladas gerado com sucesso!');
    } catch (err: unknown) {
      console.error(err);
      toast.error('Erro ao gerar relatório em PDF das vendas canceladas.');
    } finally {
      setExportingPdf(false);
    }
  };

  return (
    <PdvLayout
      title="Histórico e Cancelamento de Vendas"
      actions={
        <div className="flex items-center gap-2 flex-wrap">
          <Button variant="outline" size="sm" onClick={fetchSales} disabled={loading} className="gap-1.5">
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
            <span className="hidden sm:inline">Atualizar</span>
          </Button>
          <Button variant="outline" size="sm" onClick={exportCsv} disabled={filteredSales.length === 0} className="gap-1.5">
            <Download className="h-4 w-4" />
            <span className="hidden sm:inline">Exportar CSV</span>
          </Button>
          <Button
            variant="default"
            size="sm"
            onClick={() => handleExportCancelledPdf()}
            disabled={exportingPdf}
            className="gap-1.5 bg-destructive text-destructive-foreground hover:bg-destructive/90 shadow-sm"
          >
            {exportingPdf ? <Loader2 className="h-4 w-4 animate-spin" /> : <FileText className="h-4 w-4" />}
            <span>PDF Canceladas</span>
          </Button>
        </div>
      }
    >
      <div className="space-y-5 max-w-7xl mx-auto pb-12">
        {/* Cards de Resumo */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
          <Card className="shadow-sm border-border bg-card">
            <CardContent className="p-4 flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground font-medium uppercase tracking-wider">Vendas Concluídas</p>
                <p className="text-xl md:text-2xl font-bold text-foreground mt-1">{stats.totalEmitidas}</p>
                <p className="text-xs text-muted-foreground mt-0.5">Ticket médio: R$ {stats.ticketMedio.toFixed(2)}</p>
              </div>
              <div className="p-2.5 rounded-xl bg-success/10 text-success">
                <CheckCircle2 className="h-5 w-5" />
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-sm border-border bg-card">
            <CardContent className="p-4 flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground font-medium uppercase tracking-wider">Faturamento Líquido</p>
                <p className="text-xl md:text-2xl font-bold text-primary mt-1">
                  R$ {stats.valorEmitidas.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </p>
                <p className="text-xs text-muted-foreground mt-0.5">Vendas válidas</p>
              </div>
              <div className="p-2.5 rounded-xl bg-primary/10 text-primary">
                <TrendingUp className="h-5 w-5" />
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-sm border-border bg-card">
            <CardContent className="p-4 flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground font-medium uppercase tracking-wider">Vendas Canceladas</p>
                <div className="flex items-baseline gap-2 mt-1">
                  <p className="text-xl md:text-2xl font-bold text-destructive">{stats.totalCanceladas}</p>
                  {stats.totalCanceladas > 0 && (
                    <button
                      type="button"
                      onClick={() => handleExportCancelledPdf()}
                      disabled={exportingPdf}
                      className="text-[11px] text-destructive hover:underline font-semibold flex items-center gap-1 cursor-pointer"
                      title="Gerar PDF com todas as justificativas"
                    >
                      <FileText className="h-3 w-3" />
                      <span>Gerar PDF</span>
                    </button>
                  )}
                </div>
                <p className="text-xs text-muted-foreground mt-0.5">Itens devolvidos</p>
              </div>
              <div className="p-2.5 rounded-xl bg-destructive/10 text-destructive">
                <XCircle className="h-5 w-5" />
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-sm border-border bg-card">
            <CardContent className="p-4 flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground font-medium uppercase tracking-wider">Total Estornado</p>
                <p className="text-xl md:text-2xl font-bold text-destructive mt-1">
                  R$ {stats.valorCancelado.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </p>
                <p className="text-xs text-muted-foreground mt-0.5">Expurgado do caixa</p>
              </div>
              <div className="p-2.5 rounded-xl bg-destructive/10 text-destructive">
                <RotateCcw className="h-5 w-5" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Barra de Filtros */}
        <Card className="shadow-sm border-border">
          <CardContent className="p-4 space-y-3">
            {/* Linha 1: Período Rápido */}
            <div className="flex flex-wrap items-center gap-1.5 border-b border-border pb-3">
              <span className="text-xs font-semibold text-muted-foreground uppercase mr-2 flex items-center gap-1">
                <Calendar className="h-3.5 w-3.5" /> Período:
              </span>
              {(['hoje', 'ontem', '7dias', 'mes', 'todos', 'custom'] as const).map(mode => {
                const labels: Record<string, string> = {
                  hoje: 'Hoje',
                  ontem: 'Ontem',
                  '7dias': 'Últimos 7 dias',
                  mes: 'Este Mês',
                  todos: 'Todas as Datas',
                  custom: 'Personalizado',
                };
                return (
                  <Button
                    key={mode}
                    variant={dateFilterMode === mode ? 'default' : 'outline'}
                    size="sm"
                    className="h-7 text-xs px-2.5 rounded-md"
                    onClick={() => setDateFilterMode(mode)}
                  >
                    {labels[mode]}
                  </Button>
                );
              })}
            </div>

            {/* Linha 2: Campos de Busca, Datas Customizadas e Status */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-3 pt-1">
              {/* Campo de Busca textual */}
              <div className="md:col-span-4 relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar por número (ex: V17...), cliente ou produto..."
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  className="pl-9 text-sm h-9"
                />
                {search && (
                  <button
                    onClick={() => setSearch('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    <XCircle className="h-4 w-4" />
                  </button>
                )}
              </div>

              {/* Data Inicial e Final (caso customizado ou exibição) */}
              <div className="md:col-span-4 flex items-center gap-2">
                <div className="flex-1">
                  <Input
                    type="date"
                    value={dateFrom}
                    onChange={e => {
                      setDateFrom(e.target.value);
                      setDateFilterMode('custom');
                    }}
                    className="text-xs h-9"
                  />
                </div>
                <span className="text-xs text-muted-foreground">até</span>
                <div className="flex-1">
                  <Input
                    type="date"
                    value={dateTo}
                    onChange={e => {
                      setDateTo(e.target.value);
                      setDateFilterMode('custom');
                    }}
                    className="text-xs h-9"
                  />
                </div>
              </div>

              {/* Status */}
              <div className="md:col-span-2">
                <Select value={statusFilter} onValueChange={(v: any) => setStatusFilter(v)}>
                  <SelectTrigger className="h-9 text-xs">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos os Status</SelectItem>
                    <SelectItem value="emitida">Concluídas</SelectItem>
                    <SelectItem value="cancelada">Canceladas</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Pagamento */}
              <div className="md:col-span-2">
                <Select value={paymentFilter} onValueChange={setPaymentFilter}>
                  <SelectTrigger className="h-9 text-xs">
                    <SelectValue placeholder="Pagamento" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas as Formas</SelectItem>
                    <SelectItem value="dinheiro">Dinheiro</SelectItem>
                    <SelectItem value="cartao_debito">Cartão Débito</SelectItem>
                    <SelectItem value="cartao_credito">Cartão Crédito</SelectItem>
                    <SelectItem value="pix">PIX</SelectItem>
                    <SelectItem value="multiplo">Combinado</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Tabela de Vendas */}
        <Card className="shadow-sm border-border overflow-hidden">
          <CardHeader className="py-3.5 px-4 bg-muted/30 border-b border-border flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-sm font-semibold text-foreground">
                Lista de Vendas ({filteredSales.length})
              </CardTitle>
              <CardDescription className="text-xs">
                Localize vendas por número, data ou cliente e realize o cancelamento com estorno imediato.
              </CardDescription>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            {loading ? (
              <div className="py-16 flex flex-col items-center justify-center text-muted-foreground">
                <Loader2 className="h-8 w-8 animate-spin mb-3 text-primary" />
                <p className="text-sm">Carregando histórico de vendas...</p>
              </div>
            ) : filteredSales.length === 0 ? (
              <div className="py-16 text-center text-muted-foreground space-y-2">
                <ShoppingCart className="h-10 w-10 mx-auto opacity-30" />
                <p className="text-sm font-medium">Nenhuma venda encontrada com os filtros selecionados.</p>
                <p className="text-xs">Tente alterar o período de datas ou limpar a busca.</p>
              </div>
            ) : (
              <div className="w-full max-w-full overflow-x-auto bg-card">
                <Table className="[&>div]:max-w-full">
                  <TableHeader>
                    <TableRow className="bg-muted/40 hover:bg-muted/40">
                      <TableHead className="whitespace-nowrap text-xs font-semibold">Número</TableHead>
                      <TableHead className="whitespace-nowrap text-xs font-semibold">Data / Hora</TableHead>
                      <TableHead className="whitespace-nowrap text-xs font-semibold">Status</TableHead>
                      <TableHead className="whitespace-nowrap text-xs font-semibold">Cliente</TableHead>
                      <TableHead className="whitespace-nowrap text-xs font-semibold">Itens</TableHead>
                      <TableHead className="whitespace-nowrap text-xs font-semibold">Pagamento</TableHead>
                      <TableHead className="whitespace-nowrap text-xs font-semibold text-right">Valor Total</TableHead>
                      <TableHead className="whitespace-nowrap text-xs font-semibold text-center">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredSales.map(sale => {
                      const isCancelled = sale.status === 'cancelada';
                      const itemsCount = sale.pdv_invoice_items?.reduce((s, it) => s + (Number(it.quantity) || 1), 0) || 0;

                      return (
                        <TableRow
                          key={sale.id}
                          className={`hover:bg-muted/40 transition-colors ${isCancelled ? 'bg-destructive/5' : ''}`}
                        >
                          {/* Número */}
                          <TableCell className="whitespace-nowrap font-mono text-xs font-semibold">
                            <span className={isCancelled ? 'line-through text-muted-foreground' : 'text-foreground'}>
                              {sale.number}
                            </span>
                          </TableCell>

                          {/* Data/Hora */}
                          <TableCell className="whitespace-nowrap text-xs text-muted-foreground">
                            {new Date(sale.created_at).toLocaleString('pt-BR', {
                              day: '2-digit', month: '2-digit', year: '2-digit',
                              hour: '2-digit', minute: '2-digit'
                            })}
                          </TableCell>

                          {/* Status */}
                          <TableCell className="whitespace-nowrap text-xs">
                            {isCancelled ? (
                              <Badge variant="destructive" className="text-[10px] uppercase font-semibold">
                                Cancelada
                              </Badge>
                            ) : (
                              <Badge className="bg-success text-success-foreground hover:bg-success text-[10px] uppercase font-semibold">
                                Concluída
                              </Badge>
                            )}
                          </TableCell>

                          {/* Cliente */}
                          <TableCell className="whitespace-nowrap text-xs">
                            <span className="font-medium text-foreground">
                              {sale.customers?.name || 'Consumidor Final'}
                            </span>
                            {sale.customers?.phone && (
                              <span className="block text-[11px] text-muted-foreground">
                                {sale.customers.phone}
                              </span>
                            )}
                          </TableCell>

                          {/* Itens */}
                          <TableCell className="whitespace-nowrap text-xs text-muted-foreground">
                            <span className="font-medium text-foreground">{itemsCount}</span> unid.
                            {sale.pdv_invoice_items && sale.pdv_invoice_items.length > 0 && (
                              <span className="block text-[10px] text-muted-foreground truncate max-w-[150px]">
                                {sale.pdv_invoice_items[0]?.pdv_products?.name}
                                {sale.pdv_invoice_items.length > 1 ? ` (+${sale.pdv_invoice_items.length - 1})` : ''}
                              </span>
                            )}
                          </TableCell>

                          {/* Pagamento */}
                          <TableCell className="whitespace-nowrap text-xs">
                            <Badge variant="outline" className="text-[10px] font-normal border-border">
                              {PAYMENT_LABELS[sale.payment_method] || sale.payment_method}
                              {sale.installments && sale.installments > 1 ? ` (${sale.installments}x)` : ''}
                            </Badge>
                          </TableCell>

                          {/* Total */}
                          <TableCell className="whitespace-nowrap text-xs font-bold text-right">
                            <span className={isCancelled ? 'line-through text-muted-foreground' : 'text-primary'}>
                              R$ {Number(sale.total).toFixed(2)}
                            </span>
                          </TableCell>

                          {/* Ações */}
                          <TableCell className="whitespace-nowrap text-xs text-center">
                            <div className="flex items-center justify-center gap-1">
                              {/* Ver detalhes */}
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-7 w-7 p-0"
                                title="Ver Detalhes da Venda"
                                onClick={() => {
                                  setSelectedSale(sale);
                                  setShowDetailDialog(true);
                                }}
                              >
                                <Eye className="h-3.5 w-3.5" />
                              </Button>

                              {/* Reimprimir Cupom */}
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-7 w-7 p-0"
                                title="Reimprimir Cupom"
                                onClick={() => handleReprint(sale)}
                              >
                                <Printer className="h-3.5 w-3.5" />
                              </Button>

                              {/* Cancelar Venda */}
                              {!isCancelled && (
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-7 px-2 text-destructive hover:bg-destructive/10 hover:text-destructive text-xs gap-1"
                                  title="Cancelar Venda e Estornar Estoque"
                                  onClick={() => {
                                    setSaleToCancel(sale);
                                    setCancelReason('');
                                  }}
                                >
                                  <XCircle className="h-3.5 w-3.5" />
                                  <span className="hidden md:inline">Cancelar</span>
                                </Button>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Modal de Detalhes da Venda */}
      <Dialog open={showDetailDialog} onOpenChange={setShowDetailDialog}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl max-h-[90dvh] overflow-y-auto">
          <DialogHeader>
            <div className="flex items-center justify-between gap-2 pr-4">
              <DialogTitle className="text-balance text-base font-bold flex items-center gap-2">
                <span>Venda {selectedSale?.number}</span>
                {selectedSale?.status === 'cancelada' ? (
                  <Badge variant="destructive" className="text-[10px]">CANCELADA</Badge>
                ) : (
                  <Badge className="bg-success text-success-foreground text-[10px]">CONCLUÍDA</Badge>
                )}
              </DialogTitle>
            </div>
            <DialogDescription className="text-xs">
              Emitida em {selectedSale && new Date(selectedSale.created_at).toLocaleString('pt-BR')}
            </DialogDescription>
          </DialogHeader>

          {selectedSale && (
            <div className="space-y-4 py-2 text-sm">
              {/* Alerta de Cancelamento */}
              {selectedSale.status === 'cancelada' && (
                <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-3 text-destructive text-xs space-y-1">
                  <div className="flex items-center gap-1.5 font-semibold">
                    <AlertTriangle className="h-4 w-4 shrink-0" />
                    <span>Esta venda foi cancelada e os itens foram estornados ao estoque.</span>
                  </div>
                  {selectedSale.cancellation_reason && (
                    <p className="pl-5 text-foreground">
                      <strong>Motivo:</strong> {selectedSale.cancellation_reason}
                    </p>
                  )}
                  {selectedSale.cancelled_at && (
                    <p className="pl-5 text-muted-foreground text-[11px]">
                      Cancelado em: {new Date(selectedSale.cancelled_at).toLocaleString('pt-BR')}
                    </p>
                  )}
                </div>
              )}

              {/* Informações da Venda */}
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3 bg-muted/30 p-3 rounded-lg border border-border text-xs">
                <div>
                  <span className="text-muted-foreground block">Cliente:</span>
                  <span className="font-semibold text-foreground">
                    {selectedSale.customers?.name || 'Consumidor Final'}
                  </span>
                  {selectedSale.customers?.cpf_cnpj && (
                    <span className="block text-muted-foreground">{selectedSale.customers.cpf_cnpj}</span>
                  )}
                </div>
                <div>
                  <span className="text-muted-foreground block">Forma de Pagamento:</span>
                  <span className="font-semibold text-foreground">
                    {PAYMENT_LABELS[selectedSale.payment_method] || selectedSale.payment_method}
                    {selectedSale.installments && selectedSale.installments > 1 ? ` (${selectedSale.installments}x)` : ''}
                  </span>
                </div>
                <div>
                  <span className="text-muted-foreground block">Operador:</span>
                  <span className="font-semibold text-foreground">
                    {selectedSale.profiles?.full_name || selectedSale.profiles?.username || 'Sistema'}
                  </span>
                </div>
              </div>

              {/* Tabela de Itens */}
              <div>
                <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">
                  Itens da Venda ({selectedSale.pdv_invoice_items?.length || 0})
                </p>
                <div className="border border-border rounded-lg overflow-hidden">
                  <Table className="[&>div]:max-w-full">
                    <TableHeader className="bg-muted/40">
                      <TableRow>
                        <TableHead className="text-xs py-2">Produto</TableHead>
                        <TableHead className="text-xs py-2 text-center">Qtd</TableHead>
                        <TableHead className="text-xs py-2 text-right">Preço Unit.</TableHead>
                        <TableHead className="text-xs py-2 text-right">Total</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {selectedSale.pdv_invoice_items?.map(item => (
                        <TableRow key={item.id}>
                          <TableCell className="text-xs py-2">
                            <span className="font-medium text-foreground">{item.pdv_products?.name || 'Produto'}</span>
                            {item.pdv_products?.code && (
                              <span className="block text-[11px] text-muted-foreground">{item.pdv_products.code}</span>
                            )}
                          </TableCell>
                          <TableCell className="text-xs py-2 text-center font-mono">
                            {item.quantity} {item.pdv_products?.unit || 'un'}
                          </TableCell>
                          <TableCell className="text-xs py-2 text-right font-mono">
                            R$ {Number(item.unit_price).toFixed(2)}
                          </TableCell>
                          <TableCell className="text-xs py-2 text-right font-mono font-semibold">
                            R$ {Number(item.total_price).toFixed(2)}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>

              {/* Resumo de Valores */}
              <div className="border-t border-border pt-3 space-y-1 text-xs">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Subtotal:</span>
                  <span>R$ {Number(selectedSale.subtotal || selectedSale.total).toFixed(2)}</span>
                </div>
                {Number(selectedSale.discount) > 0 && (
                  <div className="flex justify-between text-destructive">
                    <span>Desconto:</span>
                    <span>- R$ {Number(selectedSale.discount).toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between text-base font-bold pt-1 border-t border-border">
                  <span>Total da Venda:</span>
                  <span className="text-primary">R$ {Number(selectedSale.total).toFixed(2)}</span>
                </div>
              </div>
            </div>
          )}

          <DialogFooter className="gap-2 pt-2">
            <Button variant="outline" size="sm" onClick={() => setShowDetailDialog(false)}>
              Fechar
            </Button>
            {selectedSale && (
              <Button
                variant="outline"
                size="sm"
                className="gap-1.5"
                onClick={() => handleReprint(selectedSale)}
              >
                <Printer className="h-4 w-4" /> Reimprimir Cupom
              </Button>
            )}
            {selectedSale && selectedSale.status !== 'cancelada' && (
              <Button
                variant="destructive"
                size="sm"
                className="gap-1.5"
                onClick={() => {
                  setSaleToCancel(selectedSale);
                  setCancelReason('');
                }}
              >
                <XCircle className="h-4 w-4" /> Cancelar Venda
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal de Confirmação de Cancelamento com Justificativa Obrigatória */}
      <Dialog open={!!saleToCancel} onOpenChange={open => { if (!open) setSaleToCancel(null); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-balance text-destructive flex items-center gap-2">
              <AlertTriangle className="h-5 w-5" /> Cancelar Venda {saleToCancel?.number}
            </DialogTitle>
            <DialogDescription className="text-pretty text-xs">
              Esta ação reverterá o faturamento e devolverá as quantidades ao estoque.
            </DialogDescription>
          </DialogHeader>

          {saleToCancel && (
            <div className="space-y-3.5 py-2">
              {/* Card de Resumo da Venda a ser cancelada */}
              <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-3 space-y-1.5 text-xs">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Valor Total:</span>
                  <span className="font-bold text-destructive text-sm">
                    R$ {Number(saleToCancel.total).toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Cliente:</span>
                  <span className="font-medium text-foreground">
                    {saleToCancel.customers?.name || 'Consumidor Final'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Forma de Pagamento:</span>
                  <span className="font-medium text-foreground">
                    {PAYMENT_LABELS[saleToCancel.payment_method] || saleToCancel.payment_method}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Total de Itens:</span>
                  <span className="font-medium text-foreground">
                    {saleToCancel.pdv_invoice_items?.length || 0} produto(s)
                  </span>
                </div>
              </div>

              {/* Consequências automáticas */}
              <div className="bg-muted/50 rounded-lg p-3 text-xs space-y-1 text-muted-foreground">
                <p className="font-semibold text-foreground flex items-center gap-1">
                  <RotateCcw className="h-3.5 w-3.5 text-primary" /> O que acontecerá ao confirmar:
                </p>
                <ul className="list-disc pl-4 space-y-0.5">
                  <li>O status da venda será alterado para <strong>Cancelada</strong>.</li>
                  <li>Todos os itens vendidos serão <strong>devolvidos ao estoque físico</strong>.</li>
                  <li>Serão gravadas movimentações de estoque do tipo <strong>entrada por cancelamento</strong>.</li>
                  <li>Os lançamentos financeiros da venda serão <strong>estornados do caixa</strong>.</li>
                </ul>
              </div>

              {/* Justificativa Obrigatória */}
              <div className="space-y-1.5">
                <Label htmlFor="cancel-reason" className="text-xs font-semibold">
                  Justificativa do Cancelamento <span className="text-destructive">*</span>
                </Label>
                <Textarea
                  id="cancel-reason"
                  placeholder="Informe detalhadamente o motivo do cancelamento (ex: desistência do cliente, devolução imediata, erro de digitação do operador, etc.)..."
                  value={cancelReason}
                  onChange={e => setCancelReason(e.target.value)}
                  className="min-h-[85px] text-xs"
                  autoFocus
                />
                <p className="text-[11px] text-muted-foreground">
                  A justificativa é registrada para fins de auditoria e segurança.
                </p>
              </div>
            </div>
          )}

          <DialogFooter className="gap-2">
            <Button
              variant="outline"
              size="sm"
              disabled={cancelling}
              onClick={() => {
                setSaleToCancel(null);
                setCancelReason('');
              }}
            >
              Voltar
            </Button>
            <Button
              variant="destructive"
              size="sm"
              disabled={cancelling || !cancelReason.trim()}
              onClick={handleConfirmCancel}
              className="gap-1.5"
            >
              {cancelling && <Loader2 className="h-4 w-4 animate-spin" />}
              Confirmar Cancelamento e Estorno
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PdvLayout>
  );
}
