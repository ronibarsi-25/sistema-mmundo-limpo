import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  LayoutDashboard, Store, Users, Package, TrendingUp,
  ShieldCheck, AlertTriangle, Loader2, Ban, CheckCircle2,
  Crown, CircleDollarSign, Activity
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';
import type { Tenant } from '@/types/types';

interface TenantStats extends Tenant {
  product_count: number;
  user_count: number;
  order_count: number;
}

export default function SuperAdminDashboard() {
  const { profile } = useAuth();
  const navigate = useNavigate();
  const [tenants, setTenants] = useState<TenantStats[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (profile?.role !== 'admin') {
      toast.error('Acesso restrito');
      navigate('/');
      return;
    }
    loadTenants();
  }, [profile?.role]);

  const loadTenants = async () => {
    setLoading(true);
    const { data: tenantData, error } = await supabase
      .from('tenants')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      toast.error('Erro ao carregar lojas');
      setLoading(false);
      return;
    }

    const enriched = await Promise.all(
      (tenantData || []).map(async (t) => {
        const [{ count: pc }, { count: uc }, { count: oc }] = await Promise.all([
          supabase.from('products').select('id', { count: 'exact', head: true }).eq('tenant_id', t.id),
          supabase.from('profiles').select('id', { count: 'exact', head: true }).eq('tenant_id', t.id),
          supabase.from('orders').select('id', { count: 'exact', head: true }).eq('tenant_id', t.id),
        ]);
        return { ...t, product_count: pc || 0, user_count: uc || 0, order_count: oc || 0 } as TenantStats;
      })
    );

    setTenants(enriched);
    setLoading(false);
  };

  const toggleStatus = async (tenant: TenantStats) => {
    const newStatus = tenant.status === 'active' ? 'suspended' : 'active';
    const { error } = await supabase
      .from('tenants')
      .update({ status: newStatus })
      .eq('id', tenant.id);

    if (error) {
      toast.error('Erro ao atualizar status');
      return;
    }

    toast.success(`Loja ${tenant.name} ${newStatus === 'active' ? 'ativada' : 'suspensa'}`);
    loadTenants();
  };

  const getPlanBadge = (plan: string) => {
    const map: Record<string, { label: string; variant: 'default' | 'secondary' | 'outline' }> = {
      free: { label: 'Free', variant: 'outline' },
      pro: { label: 'Pro', variant: 'secondary' },
      ouro: { label: 'Ouro', variant: 'default' },
    };
    return map[plan] || { label: plan, variant: 'outline' };
  };

  const totalProducts = tenants.reduce((s, t) => s + t.product_count, 0);
  const totalUsers = tenants.reduce((s, t) => s + t.user_count, 0);
  const totalOrders = tenants.reduce((s, t) => s + t.order_count, 0);
  const activeTenants = tenants.filter(t => t.status === 'active').length;

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
            <ShieldCheck className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h1 className="text-xl md:text-2xl font-bold text-balance">Super Admin</h1>
            <p className="text-sm text-muted-foreground">Gerenciamento de todas as lojas</p>
          </div>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-normal flex items-center gap-2">
                <Store className="h-4 w-4 text-primary" /> Lojas Ativas
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{activeTenants}</p>
              <p className="text-xs text-muted-foreground">de {tenants.length} total</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-normal flex items-center gap-2">
                <Package className="h-4 w-4 text-primary" /> Produtos
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{totalProducts}</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-normal flex items-center gap-2">
                <Users className="h-4 w-4 text-primary" /> Usuários
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{totalUsers}</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-normal flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-primary" /> Pedidos
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{totalOrders}</p>
            </CardContent>
          </Card>
        </div>

        {/* Tenants Table */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base font-medium flex items-center gap-2">
              <Activity className="h-4 w-4" /> Todas as Lojas
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto w-full">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border bg-muted/50">
                    <th className="text-left font-medium p-3 whitespace-nowrap">Loja</th>
                    <th className="text-left font-medium p-3 whitespace-nowrap">Plano</th>
                    <th className="text-center font-medium p-3 whitespace-nowrap">Produtos</th>
                    <th className="text-center font-medium p-3 whitespace-nowrap">Usuários</th>
                    <th className="text-center font-medium p-3 whitespace-nowrap">Pedidos</th>
                    <th className="text-center font-medium p-3 whitespace-nowrap">Status</th>
                    <th className="text-right font-medium p-3 whitespace-nowrap">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {tenants.map((t) => {
                    const pb = getPlanBadge(t.plan);
                    const isExpired = t.plan_expires_at ? new Date(t.plan_expires_at) < new Date() : false;
                    return (
                      <tr key={t.id} className="border-b border-border hover:bg-muted/30 transition-colors">
                        <td className="p-3 whitespace-nowrap">
                          <div className="flex items-center gap-2">
                            {t.logo_url ? (
                              <img src={t.logo_url} alt="" className="h-8 w-8 rounded object-contain bg-muted" />
                            ) : (
                              <div className="h-8 w-8 rounded bg-primary/10 flex items-center justify-center text-xs font-bold text-primary">
                                {t.name.charAt(0).toUpperCase()}
                              </div>
                            )}
                            <div>
                              <p className="font-medium">{t.name}</p>
                              <p className="text-xs text-muted-foreground">{t.slug}</p>
                            </div>
                          </div>
                        </td>
                        <td className="p-3 whitespace-nowrap">
                          <Badge variant={pb.variant}>{pb.label}</Badge>
                          {isExpired && (
                            <span className="ml-1 text-xs text-destructive flex items-center gap-0.5">
                              <AlertTriangle className="h-3 w-3" /> Expirado
                            </span>
                          )}
                        </td>
                        <td className="p-3 text-center whitespace-nowrap">{t.product_count}</td>
                        <td className="p-3 text-center whitespace-nowrap">{t.user_count}</td>
                        <td className="p-3 text-center whitespace-nowrap">{t.order_count}</td>
                        <td className="p-3 text-center whitespace-nowrap">
                          {t.status === 'active' ? (
                            <span className="inline-flex items-center gap-1 text-xs text-success">
                              <CheckCircle2 className="h-3.5 w-3.5" /> Ativa
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-xs text-destructive">
                              <Ban className="h-3.5 w-3.5" /> Suspensa
                            </span>
                          )}
                        </td>
                        <td className="p-3 text-right whitespace-nowrap">
                          <Button
                            variant="ghost"
                            size="sm"
                            className={t.status === 'active' ? 'text-destructive' : 'text-success'}
                            onClick={() => toggleStatus(t)}
                          >
                            {t.status === 'active' ? 'Suspender' : 'Ativar'}
                          </Button>
                        </td>
                      </tr>
                    );
                  })}
                  {tenants.length === 0 && (
                    <tr>
                      <td colSpan={7} className="p-8 text-center text-muted-foreground">
                        Nenhuma loja cadastrada.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
