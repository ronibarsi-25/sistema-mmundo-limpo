import type { ReactNode } from 'react';
import { lazy, Suspense } from 'react';

// Customer pages
const HomePage = lazy(() => import('./pages/HomePage'));
const ProductsPage = lazy(() => import('./pages/ProductsPage'));
const ProductDetailPage = lazy(() => import('./pages/ProductDetailPage'));
const CartPage = lazy(() => import('./pages/CartPage'));
const CheckoutPage = lazy(() => import('./pages/CheckoutPage'));
const WishlistPage = lazy(() => import('./pages/WishlistPage'));
const ComparePage = lazy(() => import('./pages/ComparePage'));
const PortfolioPage = lazy(() => import('./pages/PortfolioPage'));
const LoginPage = lazy(() => import('./pages/LoginPage'));
const OrdersPage = lazy(() => import('./pages/OrdersPage'));
const ProfilePage = lazy(() => import('./pages/ProfilePage'));
const CustomerChatPage = lazy(() => import('./pages/CustomerChatPage'));
const PaymentSuccessPage = lazy(() => import('./pages/PaymentSuccessPage'));
const OnboardingPage = lazy(() => import('./pages/OnboardingPage'));

// PDV pages - base
const PdvLoginPage = lazy(() => import('./pages/pdv/PdvLoginPage'));
const PdvDashboard = lazy(() => import('./pages/pdv/PdvDashboard'));
const PdvCaixa = lazy(() => import('./pages/pdv/PdvCaixa'));
const PdvVendas = lazy(() => import('./pages/pdv/PdvVendas'));
const PdvProdutos = lazy(() => import('./pages/pdv/PdvProdutos'));
const PdvImportarNota = lazy(() => import('./pages/pdv/PdvImportarNota'));
const PdvFiscal = lazy(() => import('./pages/pdv/PdvFiscal'));
const PdvCupomFiscal = lazy(() => import('./pages/pdv/PdvCupomFiscal'));
const PdvMetodosPagamento = lazy(() => import('./pages/pdv/PdvMetodosPagamento'));
const PdvCategorias = lazy(() => import('./pages/pdv/PdvCategorias'));
const PdvClientes = lazy(() => import('./pages/pdv/PdvClientes'));
const PdvCRM = lazy(() => import('./pages/pdv/PdvCRM'));
const PdvFornecedores = lazy(() => import('./pages/pdv/PdvFornecedores'));
const PdvEntradaMercadorias = lazy(() => import('./pages/pdv/PdvEntradaMercadorias'));
const PdvEstoque = lazy(() => import('./pages/pdv/PdvEstoque'));
const PdvNotasFiscais = lazy(() => import('./pages/pdv/PdvNotasFiscais'));
const PdvEtiquetas = lazy(() => import('./pages/pdv/PdvEtiquetas'));
const PdvConfiguracaoEtiquetas = lazy(() => import('./pages/pdv/PdvConfiguracaoEtiquetas'));
const PdvFinanceiro = lazy(() => import('./pages/pdv/PdvFinanceiro'));
const PdvUsuarios = lazy(() => import('./pages/pdv/PdvUsuarios'));
const PdvEmpresa = lazy(() => import('./pages/pdv/PdvEmpresa'));
const PdvConfiguracoes = lazy(() => import('./pages/pdv/PdvConfiguracoes'));
const PdvMarketing = lazy(() => import('./pages/pdv/PdvMarketing'));

// PDV pages - módulos avançados
const PdvGrades = lazy(() => import('./pages/pdv/PdvGrades'));
const PdvLotes = lazy(() => import('./pages/pdv/PdvLotes'));
const PdvContasPagar = lazy(() => import('./pages/pdv/PdvContasPagar'));
const PdvDevolucoes = lazy(() => import('./pages/pdv/PdvDevolucoes'));
const PdvFidelidade = lazy(() => import('./pages/pdv/PdvFidelidade'));
const PdvComissoes = lazy(() => import('./pages/pdv/PdvComissoes'));
const PdvEntregas = lazy(() => import('./pages/pdv/PdvEntregas'));
const PdvFiliais = lazy(() => import('./pages/pdv/PdvFiliais'));
const PdvAnalisePreditiva = lazy(() => import('./pages/pdv/PdvAnalisePreditiva'));
const PdvPedidosOnline = lazy(() => import('./pages/pdv/PdvPedidosOnline'));
const PdvRastreabilidade = lazy(() => import('./pages/pdv/PdvRastreabilidade'));
const PdvRelatorios = lazy(() => import('./pages/pdv/PdvRelatorios'));
const PdvGarantias = lazy(() => import('./pages/pdv/PdvGarantias'));
const PdvIndicacoes = lazy(() => import('./pages/pdv/PdvIndicacoes'));
const PdvMarketplaces = lazy(() => import('./pages/pdv/PdvMarketplaces'));
const PdvConciliacao = lazy(() => import('./pages/pdv/PdvConciliacao'));
const PdvContabilidade = lazy(() => import('./pages/pdv/PdvContabilidade'));
const PdvAuditoria = lazy(() => import('./pages/pdv/PdvAuditoria'));

// Admin pages
const AdminLoginPage = lazy(() => import('./pages/admin/AdminLoginPage'));
const AdminDashboard = lazy(() => import('./pages/admin/AdminDashboard'));
const AdminProducts = lazy(() => import('./pages/admin/AdminProducts'));
const AdminCategories = lazy(() => import('./pages/admin/AdminCategories'));
const AdminOrders = lazy(() => import('./pages/admin/AdminOrders'));
const AdminStock = lazy(() => import('./pages/admin/AdminStock'));
const AdminReports = lazy(() => import('./pages/admin/AdminReports'));
const AdminChat = lazy(() => import('./pages/admin/AdminChat'));
const AdminSettings = lazy(() => import('./pages/admin/AdminSettings'));
const AdminBanners = lazy(() => import('./pages/admin/AdminBanners'));
const AdminPromotions = lazy(() => import('./pages/admin/AdminPromotions'));
const AdminTheme = lazy(() => import('./pages/admin/AdminTheme'));
const AdminCoupons = lazy(() => import('./pages/admin/AdminCoupons'));
const AdminSubscription = lazy(() => import('./pages/admin/AdminSubscription'));
const AdminPaymentGateways = lazy(() => import('./pages/admin/AdminPaymentGateways'));
const AdminImport = lazy(() => import('./pages/admin/AdminImport'));
const AdminWhiteLabel = lazy(() => import('./pages/admin/AdminWhiteLabel'));
const AdminBannerInauguracao = lazy(() => import('./pages/admin/AdminBannerInauguracao'));
const AdminEntregas = lazy(() => import('./pages/admin/AdminEntregas'));
const AdminCouponConfig = lazy(() => import('./pages/admin/AdminCouponConfig'));
const AdminPdvSync = lazy(() => import('./pages/admin/AdminPdvSync'));
const AdminRH = lazy(() => import('./pages/admin/AdminRH'));
const AdminFolha = lazy(() => import('./pages/admin/AdminFolha'));
const AdminPonto = lazy(() => import('./pages/admin/AdminPonto'));
const AdminAgendamentos = lazy(() => import('./pages/admin/AdminAgendamentos'));
const AdminNotifications = lazy(() => import('./pages/admin/AdminNotifications'));
const AdminExportData = lazy(() => import('./pages/admin/AdminExportData'));
const AdminImportProducts = lazy(() => import('./pages/admin/AdminImportProducts'));
const AdminStockMovements = lazy(() => import('./pages/admin/AdminStockMovements'));
const AdminPermissions = lazy(() => import('./pages/admin/AdminPermissions'));
const AdminLabelPrint = lazy(() => import('./pages/admin/AdminLabelPrint'));
const AdminBannersSociais = lazy(() => import('./pages/admin/AdminBannersSociais'));
const AdminPedidoEletronico = lazy(() => import('./pages/admin/AdminPedidoEletronico'));
const SuperAdminDashboard = lazy(() => import('./pages/superadmin/SuperAdminDashboard'));
const ExpiredStorePage = lazy(() => import('./pages/ExpiredStorePage'));
const PublicMetaFeed = lazy(() => import('./pages/PublicMetaFeed'));
const MetaSocialFeed = lazy(() => import('./pages/marketing/MetaSocialFeed'));

// Mobile inventory app
const MobileHome = lazy(() => import('./pages/mobile/MobileHome'));
const MobileScanner = lazy(() => import('./pages/mobile/MobileScanner'));
const MobileContagem = lazy(() => import('./pages/mobile/MobileContagem'));
const MobileListaProdutos = lazy(() => import('./pages/mobile/MobileListaProdutos'));
const MobileProdutoDetalhe = lazy(() => import('./pages/mobile/MobileProdutoDetalhe'));

const Loading = () => (
  <div className="flex items-center justify-center min-h-screen">
    <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary" />
  </div>
);

const S = (element: ReactNode) => <Suspense fallback={<Loading />}>{element}</Suspense>;

export interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
  /** Accessible without login. Routes without this flag require authentication. */
  public?: boolean;
}

export const routes: RouteConfig[] = [
  // --- Public / Customer ---
  { name: 'Início', path: '/', element: S(<HomePage />), public: true },
  { name: 'Produtos', path: '/produtos', element: S(<ProductsPage />), public: true },
  { name: 'Produto', path: '/produto/:slug', element: S(<ProductDetailPage />), public: true },
  { name: 'Carrinho', path: '/carrinho', element: S(<CartPage />), public: true },
  { name: 'Checkout', path: '/checkout', element: S(<CheckoutPage />) },
  { name: 'Lista de Desejos', path: '/lista-de-desejos', element: S(<WishlistPage />) },
  { name: 'Comparar', path: '/comparar', element: S(<ComparePage />), public: true },
  { name: 'Portfólio', path: '/portfolio', element: S(<PortfolioPage />), public: true },
  { name: 'Login', path: '/login', element: S(<LoginPage />), public: true },
  { name: 'Criar Loja', path: '/onboarding', element: S(<OnboardingPage />) },
  { name: 'Meus Pedidos', path: '/minha-conta/pedidos', element: S(<OrdersPage />) },
  { name: 'Meu Perfil', path: '/minha-conta/perfil', element: S(<ProfilePage />) },
  { name: 'Chat', path: '/minha-conta/chat', element: S(<CustomerChatPage />) },
  { name: 'Pagamento Confirmado', path: '/pagamento/sucesso', element: S(<PaymentSuccessPage />), public: true },

  // --- Admin ---
  { name: 'Admin Login', path: '/admin/login', element: S(<AdminLoginPage />), public: true },
  { name: 'Admin Dashboard', path: '/admin', element: S(<AdminDashboard />) },
  { name: 'Admin Produtos', path: '/admin/produtos', element: S(<AdminProducts />) },
  { name: 'Admin Categorias', path: '/admin/categorias', element: S(<AdminCategories />) },
  { name: 'Admin Pedidos', path: '/admin/pedidos', element: S(<AdminOrders />) },
  { name: 'Admin Estoque', path: '/admin/estoque', element: S(<AdminStock />) },
  { name: 'Admin Relatórios', path: '/admin/relatorios', element: S(<AdminReports />) },
  { name: 'Admin Chat', path: '/admin/chat', element: S(<AdminChat />) },
  { name: 'Admin Configurações', path: '/admin/configuracoes', element: S(<AdminSettings />) },
  { name: 'Admin Banners', path: '/admin/banners', element: S(<AdminBanners />) },
  { name: 'Admin Promoções', path: '/admin/promocoes', element: S(<AdminPromotions />) },
  { name: 'Admin Cupons', path: '/admin/cupons', element: S(<AdminCoupons />) },
  { name: 'Admin Tema', path: '/admin/tema', element: S(<AdminTheme />) },
  { name: 'Admin Assinatura', path: '/admin/assinatura', element: S(<AdminSubscription />) },
  { name: 'Admin Gateways', path: '/admin/gateways', element: S(<AdminPaymentGateways />) },
  { name: 'Admin Importar', path: '/admin/importar', element: S(<AdminImport />) },
  { name: 'Admin White Label', path: '/admin/white-label', element: S(<AdminWhiteLabel />) },
  { name: 'Admin Banner Inauguração', path: '/admin/banner-inauguracao', element: S(<AdminBannerInauguracao />) },
  { name: 'Admin Entregas', path: '/admin/entregas', element: S(<AdminEntregas />) },
  { name: 'Admin Cupom Desconto', path: '/admin/cupom-desconto', element: S(<AdminCouponConfig />) },
  { name: 'Admin Sincronizar PDV', path: '/admin/sincronizar-pdv', element: S(<AdminPdvSync />) },
  { name: 'Admin RH', path: '/admin/rh', element: S(<AdminRH />) },
  { name: 'Admin Folha', path: '/admin/folha', element: S(<AdminFolha />) },
  { name: 'Admin Ponto', path: '/admin/ponto', element: S(<AdminPonto />) },
  { name: 'Admin Agendamentos', path: '/admin/agendamentos', element: S(<AdminAgendamentos />) },
  { name: 'Admin Notificações', path: '/admin/notificacoes', element: S(<AdminNotifications />) },
  { name: 'Admin Exportar Dados', path: '/admin/exportar-dados', element: S(<AdminExportData />) },
  { name: 'Admin Importar Produtos', path: '/admin/importar-produtos', element: S(<AdminImportProducts />) },
  { name: 'Admin Movimentações', path: '/admin/movimentacoes', element: S(<AdminStockMovements />) },
  { name: 'Admin Permissões', path: '/admin/permissoes', element: S(<AdminPermissions />) },
  { name: 'Admin Etiquetas', path: '/admin/etiquetas', element: S(<AdminLabelPrint />) },
  { name: 'Admin Banners Sociais', path: '/admin/banners-sociais', element: S(<AdminBannersSociais />) },
  { name: 'Admin Pedido Eletrônico', path: '/admin/pedido-eletronico', element: S(<AdminPedidoEletronico />) },
  { name: 'Super Admin', path: '/super-admin', element: S(<SuperAdminDashboard />) },
  { name: 'Loja Expirada', path: '/loja-suspensa', element: S(<ExpiredStorePage />), public: true },

  // --- Mobile Inventory App ---
  { name: 'Mobile Início', path: '/mobile', element: S(<MobileHome />) },
  { name: 'Mobile Scanner', path: '/mobile/scanner', element: S(<MobileScanner />) },
  { name: 'Mobile Contagem', path: '/mobile/contagem', element: S(<MobileContagem />) },
  { name: 'Mobile Produtos', path: '/mobile/produtos', element: S(<MobileListaProdutos />) },
  { name: 'Mobile Produto', path: '/mobile/produto/:id', element: S(<MobileProdutoDetalhe />) },

  // --- PDV base ---
  { name: 'PDV Login', path: '/pdv/login', element: S(<PdvLoginPage />), public: true },
  { name: 'PDV Dashboard', path: '/pdv', element: S(<PdvDashboard />) },
  { name: 'PDV Caixa', path: '/pdv/caixa', element: S(<PdvCaixa />) },
  { name: 'PDV Vendas e Cancelamento', path: '/pdv/vendas', element: S(<PdvVendas />) },
  { name: 'PDV Produtos', path: '/pdv/produtos', element: S(<PdvProdutos />) },
  { name: 'PDV Importar Nota', path: '/pdv/importar-nota', element: S(<PdvImportarNota />) },
  { name: 'PDV Fiscal', path: '/pdv/fiscal', element: S(<PdvFiscal />) },
  { name: 'PDV Cupom Fiscal', path: '/pdv/cupom-fiscal', element: S(<PdvCupomFiscal />) },
  { name: 'PDV Métodos Pagamento', path: '/pdv/metodos-pagamento', element: S(<PdvMetodosPagamento />) },
  { name: 'PDV Categorias', path: '/pdv/categorias', element: S(<PdvCategorias />) },
  { name: 'PDV Clientes', path: '/pdv/clientes', element: S(<PdvClientes />) },
  { name: 'PDV CRM', path: '/pdv/crm', element: S(<PdvCRM />) },
  { name: 'PDV Fornecedores', path: '/pdv/fornecedores', element: S(<PdvFornecedores />) },
  { name: 'PDV Entrada Mercadorias', path: '/pdv/entrada-mercadorias', element: S(<PdvEntradaMercadorias />) },
  { name: 'PDV Estoque', path: '/pdv/estoque', element: S(<PdvEstoque />) },
  { name: 'PDV Notas Fiscais', path: '/pdv/notas-fiscais', element: S(<PdvNotasFiscais />) },
  { name: 'PDV Etiquetas', path: '/pdv/etiquetas', element: S(<PdvEtiquetas />) },
  { name: 'PDV Configuração Etiquetas', path: '/pdv/configuracao-etiquetas', element: S(<PdvConfiguracaoEtiquetas />) },
  { name: 'PDV Financeiro', path: '/pdv/financeiro', element: S(<PdvFinanceiro />) },
  { name: 'PDV Usuarios', path: '/pdv/usuarios', element: S(<PdvUsuarios />) },
  { name: 'PDV Empresa', path: '/pdv/empresa', element: S(<PdvEmpresa />) },
  { name: 'PDV Configuracoes', path: '/pdv/configuracoes', element: S(<PdvConfiguracoes />) },
  { name: 'PDV Marketing & Meta Pixel', path: '/pdv/marketing', element: S(<PdvMarketing />) },
  { name: 'PDV Feed Meta Shopping', path: '/pdv/feed-meta', element: S(<MetaSocialFeed />) },
  { name: 'PDV Marketing Feed Meta', path: '/pdv/marketing/feed-meta', element: S(<MetaSocialFeed />) },
  { name: 'Admin Feed Meta Shopping', path: '/admin/marketing/feed-meta', element: S(<MetaSocialFeed />) },
  { name: 'Marketing Feed Meta', path: '/marketing/feed-meta', element: S(<MetaSocialFeed />) },
  { name: 'Gerador Posts Sociais', path: '/marketing/gerador-posts', element: S(<MetaSocialFeed />) },
  { name: 'Feed Meta Shopping', path: '/feed/meta', element: S(<PublicMetaFeed />), public: true },
  { name: 'Feed Meta Format CSV', path: '/feed/meta/format=csv', element: S(<PublicMetaFeed />), public: true },
  { name: 'Feed Meta Format XML', path: '/feed/meta/format=xml', element: S(<PublicMetaFeed />), public: true },
  { name: 'Feed Meta CSV Subpath', path: '/feed/meta/csv', element: S(<PublicMetaFeed />), public: true },
  { name: 'Feed Meta XML Subpath', path: '/feed/meta/xml', element: S(<PublicMetaFeed />), public: true },
  { name: 'Feed Meta XML', path: '/feed/meta.xml', element: S(<PublicMetaFeed />), public: true },
  { name: 'Feed Meta CSV', path: '/feed/meta.csv', element: S(<PublicMetaFeed />), public: true },
  { name: 'Feed Meta Wildcard', path: '/feed/meta/*', element: S(<PublicMetaFeed />), public: true },
  { name: 'Feed Geral Wildcard', path: '/feed/*', element: S(<PublicMetaFeed />), public: true },
  { name: 'Configurações Marketing', path: '/configuracoes/marketing', element: S(<PdvMarketing />) },

  // --- PDV módulos avançados ---
  { name: 'PDV Grades', path: '/pdv/grades', element: S(<PdvGrades />) },
  { name: 'PDV Lotes', path: '/pdv/lotes', element: S(<PdvLotes />) },
  { name: 'PDV Contas', path: '/pdv/contas', element: S(<PdvContasPagar />) },
  { name: 'PDV Devoluções', path: '/pdv/devolucoes', element: S(<PdvDevolucoes />) },
  { name: 'PDV Fidelidade', path: '/pdv/fidelidade', element: S(<PdvFidelidade />) },
  { name: 'PDV Comissões', path: '/pdv/comissoes', element: S(<PdvComissoes />) },
  { name: 'PDV Entregas', path: '/pdv/entregas', element: S(<PdvEntregas />) },
  { name: 'PDV Filiais', path: '/pdv/filiais', element: S(<PdvFiliais />) },
  { name: 'PDV Análise Preditiva', path: '/pdv/analise-preditiva', element: S(<PdvAnalisePreditiva />) },
  { name: 'PDV Pedidos Online', path: '/pdv/pedidos-online', element: S(<PdvPedidosOnline />) },
  { name: 'PDV Rastreabilidade', path: '/pdv/rastreabilidade', element: S(<PdvRastreabilidade />) },
  { name: 'PDV Relatórios', path: '/pdv/relatorios', element: S(<PdvRelatorios />) },
  { name: 'PDV Garantias', path: '/pdv/garantias', element: S(<PdvGarantias />) },
  { name: 'PDV Indicações', path: '/pdv/indicacoes', element: S(<PdvIndicacoes />) },
  { name: 'PDV Marketplaces', path: '/pdv/marketplaces', element: S(<PdvMarketplaces />) },
  { name: 'PDV Conciliação', path: '/pdv/conciliacao', element: S(<PdvConciliacao />) },
  { name: 'PDV Contabilidade', path: '/pdv/contabilidade', element: S(<PdvContabilidade />) },
  { name: 'PDV Auditoria', path: '/pdv/auditoria', element: S(<PdvAuditoria />) },
];
