// Tipos centrais da aplicação

export type UserRole = 'user' | 'admin' | 'gestor' | 'operador' | 'vendedor';

export interface LabelConfig {
  id: string;
  width_mm: number;
  height_mm: number;
  preset: string;
  show_name: boolean;
  show_code: boolean;
  show_price: boolean;
  show_barcode: boolean;
  show_qr: boolean;
  logo_url: string | null;
  logo_position: 'top' | 'left' | 'right';
  logo_size_pct: number;
  bg_image_url: string | null;
  bg_opacity: number;
  cols: number;
  rows: number;
  paper_size: 'A4' | 'A5' | 'Carta' | 'Oficio' | 'Termico';
  updated_at: string;
}

// ===== Tenant (Multi-tenant SaaS) =====
export interface Tenant {
  id: string;
  name: string;
  slug: string;
  domain: string | null;
  logo_url: string | null;
  primary_color: string;
  secondary_color: string;
  accent_color: string;
  description: string | null;
  phone: string | null;
  email: string | null;
  address: string | null;
  settings: Record<string, unknown>;
  plan: string;
  plan_expires_at: string | null;
  status: string;
  created_at: string;
  updated_at: string;
}

export interface PlanLimit {
  plan_name: string;
  max_products: number;
  max_categories: number;
  max_users: number;
  max_orders_per_month: number;
  has_white_label: boolean;
  has_custom_domain: boolean;
  has_advanced_reports: boolean;
  has_api_access: boolean;
  price_monthly: number;
}

// Base interface for tenant-aware entities
export interface TenantAware {
  tenant_id?: string | null;
}

// ===== PDV Types =====

export interface PdvCategory {
  id: string;
  name: string;
  description: string | null;
  color: string;
  created_at: string;
}

export interface PdvProduct {
  id: string;
  code: string;
  barcode: string | null;
  name: string;
  description: string | null;
  category_id: string | null;
  unit: string;
  cost_price: number;
  sale_price: number;
  margin_percent: number;
  markup_percent: number;
  stock_qty: number;
  stock_min: number;
  active: boolean;
  publish_to_site: boolean;
  site_product_id: string | null;
  is_fraction: boolean;
  fraction_unit: string | null;
  wholesale_price: number;
  retail_price: number;
  ncm: string | null;
  cest: string | null;
  created_at: string;
  updated_at: string;
  pdv_categories?: PdvCategory | null;
}

export interface Customer {
  id: string;
  name: string;
  cpf_cnpj: string | null;
  email: string | null;
  phone: string | null;
  birth_date: string | null;
  cep: string | null;
  logradouro: string | null;
  numero: string | null;
  complemento: string | null;
  bairro: string | null;
  cidade: string | null;
  estado: string | null;
  notes: string | null;
  active: boolean;
  created_at: string;
  updated_at: string;
}

export interface Supplier {
  id: string;
  razao_social: string;
  nome_fantasia: string | null;
  cnpj: string | null;
  email: string | null;
  phone: string | null;
  contact_name: string | null;
  cep: string | null;
  logradouro: string | null;
  numero: string | null;
  complemento: string | null;
  bairro: string | null;
  cidade: string | null;
  estado: string | null;
  notes: string | null;
  active: boolean;
  created_at: string;
  updated_at: string;
}

export type PaymentMethod = 'dinheiro' | 'cartao_debito' | 'cartao_credito' | 'pix' | 'outros' | string;
export type InvoiceType = 'entrada' | 'saida';
export type InvoiceStatus = 'pendente' | 'emitida' | 'cancelada';

export interface PdvInvoice {
  id: string;
  number: string;
  type: InvoiceType;
  status: InvoiceStatus;
  customer_id: string | null;
  supplier_id: string | null;
  cash_register_id: string | null;
  subtotal: number;
  discount: number;
  total: number;
  payment_method: PaymentMethod;
  notes: string | null;
  issued_at: string;
  created_by: string | null;
  created_at: string;
  customers?: Customer | null;
  suppliers?: Supplier | null;
}

export interface PdvInvoiceItem {
  id: string;
  invoice_id: string;
  product_id: string;
  quantity: number;
  unit_price: number;
  total_price: number;
  created_at: string;
  pdv_products?: PdvProduct | null;
}

export interface CashRegister {
  id: string;
  operator_id: string;
  opening_amount: number;
  closing_amount: number | null;
  expected_amount: number | null;
  difference: number | null;
  notes: string | null;
  opened_at: string;
  closed_at: string | null;
  status: 'aberto' | 'fechado';
  profiles?: { username: string | null; full_name: string | null } | null;
}

export interface StockMovement {
  id: string;
  product_id: string;
  type: 'entrada' | 'saida' | 'ajuste';
  quantity: number;
  previous_qty: number;
  new_qty: number;
  reference_id: string | null;
  reference_type: string | null;
  notes: string | null;
  created_by: string | null;
  created_at: string;
  pdv_products?: PdvProduct | null;
}

export interface GoodsReceipt {
  id: string;
  supplier_id: string | null;
  invoice_number: string | null;
  total_amount: number;
  notes: string | null;
  received_by: string | null;
  received_at: string;
  created_at: string;
  suppliers?: Supplier | null;
}

export interface GoodsReceiptItem {
  id: string;
  receipt_id: string;
  product_id: string;
  quantity: number;
  cost_price: number;
  total_price: number;
  created_at: string;
  pdv_products?: PdvProduct | null;
}

export type TransactionType = 'receita' | 'despesa';

export interface Transaction {
  id: string;
  type: TransactionType;
  category: string;
  description: string;
  amount: number;
  payment_method: PaymentMethod;
  supplier_id: string | null;
  invoice_id: string | null;
  transaction_date: string;
  notes: string | null;
  created_by: string | null;
  created_at: string;
  suppliers?: Supplier | null;
}

export interface Company {
  id: string;
  razao_social: string;
  nome_fantasia: string;
  cnpj: string | null;
  inscricao_estadual: string | null;
  regime_tributario: string | null;
  telefone: string | null;
  email: string | null;
  website: string | null;
  whatsapp: string | null;
  cep: string | null;
  logradouro: string | null;
  numero: string | null;
  complemento: string | null;
  bairro: string | null;
  cidade: string | null;
  estado: string | null;
  logo_url: string | null;
  backup_frequency: string | null;
  site_integration_url: string | null;
  created_at: string;
  updated_at: string;
}

export interface Profile {
  id: string;
  email: string | null;
  full_name: string | null;
  phone: string | null;
  avatar_url: string | null;
  username: string | null;
  active: boolean;
  role: UserRole;
  tenant_id: string | null;
  created_at: string;
  updated_at: string;
}

export interface StoreFeature {
  icon: string;
  title: string;
  desc: string;
}

export interface StoreSettings {
  id: number;
  store_name: string;
  store_description: string | null;
  store_logo_url: string | null;
  store_address: string | null;
  store_city: string | null;
  store_state: string | null;
  store_zip: string | null;
  store_cep: string | null;
  store_phone: string | null;
  store_email: string | null;
  pix_key: string | null;
  pix_key_type: string;
  low_stock_threshold: number;
  freight_base_value: number;
  store_features: StoreFeature[] | null;
  // Configurações Correios
  correios_cep_origin: string | null;
  correios_contract: string | null;
  correios_password: string | null;
  correios_pac_enabled: boolean;
  correios_sedex_enabled: boolean;
  free_shipping_threshold: number | null;
  default_weight_kg: number;
  default_length_cm: number;
  default_width_cm: number;
  default_height_cm: number;
  created_at: string;
  updated_at: string;
}

export interface ShippingMethod {
  id: string;
  tenant_id: string | null;
  name: string;
  carrier: string;
  code: string | null;
  type: 'fixed' | 'free' | 'correios_pac' | 'correios_sedex' | 'correios_sedex10';
  price: number;
  min_days: number;
  max_days: number;
  is_active: boolean;
  sort_order: number;
}

export interface ShippingOption {
  id: string;
  name: string;
  carrier: string;
  price: number;
  min_days: number;
  max_days: number;
  type: string;
  error?: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  image_url: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface ProductImage {
  url: string;
  alt: string;
}

export interface Product {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  price: number;
  compare_at_price: number | null;
  category_id: string | null;
  images: ProductImage[];
  stock_quantity: number;
  is_available: boolean;
  is_featured: boolean;
  attributes: Record<string, string>;
  code: string | null;
  cost_price: number | null;
  barcode: string | null;
  unit: string | null;
  pdv_product_id: string | null;
  tenant_id: string | null;
  weight: number | null;
  dimensions: string | null;
  brand: string | null;
  sku: string | null;
  expiry_date: string | null;
  video_url: string | null;
  created_at: string;
  updated_at: string;
  categories?: Category;
}

export type OrderStatus = 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled' | 'completed';

export interface OrderItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  image_url: string;
}

export interface DeliveryAddress {
  name: string;
  phone: string;
  cep: string;
  street: string;
  number: string;
  complement?: string;
  neighborhood: string;
  city: string;
  state: string;
}

export interface Order {
  id: string;
  order_number: string;
  user_id: string | null;
  items: OrderItem[];
  subtotal: number;
  freight_amount: number;
  discount_amount: number;
  total_amount: number;
  currency: string;
  status: OrderStatus;
  delivery_type: 'delivery' | 'pickup';
  delivery_address: DeliveryAddress | null;
  payment_method: string;
  stripe_session_id: string | null;
  stripe_payment_intent_id: string | null;
  customer_email: string | null;
  customer_name: string | null;
  customer_phone: string | null;
  coupon_id: string | null;
  pix_paid: boolean;
  notes: string | null;
  completed_at: string | null;
  created_at: string;
  updated_at: string;
  profiles?: Profile;
}

export type StockMovementType = 'entrada' | 'saida' | 'ajuste' | 'venda';

// Movimentação de estoque do e-commerce/admin (tabela: stock_movements)
export interface AdminStockMovement {
  id: string;
  product_id: string;
  type: StockMovementType;
  quantity: number;
  previous_quantity: number;
  new_quantity: number;
  notes: string | null;
  order_id: string | null;
  created_by: string | null;
  created_at: string;
  products?: Product;
}

export interface WishlistItem {
  id: string;
  user_id: string;
  product_id: string;
  created_at: string;
  products?: Product;
}

export interface ChatMessage {
  id: string;
  conversation_id: string;
  user_id: string | null;
  sender_role: 'user' | 'admin';
  message: string;
  is_read: boolean;
  created_at: string;
  profiles?: Profile;
}

// Tipos para carrinho de compras (estado local)
export interface CartItem {
  product: Product;
  quantity: number;
}

// Banner
export interface Banner {
  id: string;
  title: string;
  subtitle: string | null;
  image_url: string;
  cta_text: string;
  cta_link: string;
  sort_order: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

// Promoção
export type DiscountType = 'percent' | 'fixed';
export type PromotionScope = 'all' | 'categories' | 'products';
export type PromotionType = 'standard' | 'buy_x_get_y' | 'progressive';

export interface ProgressiveTier {
  min_qty: number;
  max_qty: number | null;
  discount_percent: number;
}

export interface Promotion {
  id: string;
  name: string;
  description: string | null;
  discount_type: DiscountType;
  discount_value: number;
  starts_at: string;
  ends_at: string;
  scope: PromotionScope;
  scope_ids: string[];
  banner_text: string | null;
  banner_color: string;
  is_active: boolean;
  promo_type: PromotionType;
  buy_quantity: number | null;
  get_quantity: number | null;
  progressive_tiers: ProgressiveTier[] | null;
  created_at: string;
  updated_at: string;
}

// Tema
export interface ThemeSettings {
  id: string;
  primary_color: string;
  secondary_color: string;
  accent_color: string;
  background_color: string;
  preset_name: string;
  font_family: string;
  border_radius: string;
  shadow_style: string;
  button_style: string;
  created_at: string;
  updated_at: string;
}

// Cupons
export type CouponDiscountType = 'percent' | 'fixed' | 'free_shipping';

export interface Coupon {
  id: string;
  code: string;
  discount_type: CouponDiscountType;
  discount_value: number;
  min_order_value: number;
  max_uses: number | null;
  max_uses_per_user: number | null;
  used_count: number;
  starts_at: string;
  ends_at: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface CouponUsage {
  id: string;
  coupon_id: string;
  order_id: string | null;
  user_id: string | null;
  discount_applied: number;
  used_at: string;
}

export interface Subscription {
  id: string;
  trial_days: number;
  trial_ends_at: string;
  expires_at: string;
  status: 'active' | 'expired' | 'trial' | 'canceled';
  plan_name: string;
  plan_level: 'prata' | 'ouro' | 'diamond';
  monthly_price: number;
  last_billing_date: string;
  created_at: string;
}

export const PLAN_LIMITS = {
  prata: { maxProducts: 20, maxBanners: 2, hasCoupons: false },
  ouro: { maxProducts: 100, maxBanners: 5, hasCoupons: true },
  diamond: { maxProducts: 9999, maxBanners: 10, hasCoupons: true },
};

// Gateway de pagamento
export interface PaymentGateway {
  id: string;
  name: string;
  description: string | null;
  icon: string;
  is_active: boolean;
  config: Record<string, string>;
  sort_order: number;
  created_at: string;
  updated_at: string;
}

// ===== PDV Fiscal Types =====

export interface PdvFiscalConfig {
  id: string;
  company_name: string;
  company_fantasy_name: string | null;
  cnpj: string | null;
  ie: string | null;
  im: string | null;
  cnae: string | null;
  crt: '1' | '2' | '3';
  address: string | null;
  address_number: string | null;
  neighborhood: string | null;
  city_code: string | null;
  city_name: string | null;
  state: string | null;
  zip_code: string | null;
  phone: string | null;
  email: string | null;
  sat_enabled: boolean;
  sat_sign_ac: string | null;
  sat_activation_code: string | null;
  sat_environment: 'homologacao' | 'producao';
  created_at: string;
  updated_at: string;
}

export interface PdvCertificate {
  id: string;
  alias: string;
  certificate_type: 'A1' | 'A3';
  certificate_data: string;
  password_hint: string | null;
  valid_from: string | null;
  valid_until: string | null;
  serial_number: string | null;
  issuer: string | null;
  subject: string | null;
  is_active: boolean;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

export interface PdvCupom {
  id: string;
  invoice_id: string | null;
  invoice_number: string;
  cupom_type: 'cfe' | 'nfce';
  serie: string | null;
  numero: string | null;
  chave_acesso: string | null;
  qr_code: string | null;
  status: 'pendente' | 'autorizado' | 'cancelado' | 'rejeitado' | 'contingencia';
  xml: string | null;
  pdf_url: string | null;
  envio_status: string | null;
  envio_msg: string | null;
  cancelado_em: string | null;
  cancelado_motivo: string | null;
  total: number;
  cnpj_emitente: string | null;
  total_items: number;
  created_at: string;
  updated_at: string;
  pdv_cupom_items?: PdvCupomItem[];
}

export interface PdvCupomItem {
  id: string;
  cupom_id: string;
  product_id: string | null;
  product_code: string;
  product_name: string;
  quantity: number;
  unit: string;
  unit_price: number;
  total_price: number;
  discount: number;
  icms_aliquota: number | null;
  pis_aliquota: number | null;
  cofins_aliquota: number | null;
  created_at: string;
}

export interface PdvCupomContingencia {
  id: string;
  cupom_id: string | null;
  numero: string;
  chave: string | null;
  xml: string | null;
  motivo: string | null;
  data_hora: string;
  resolvido: boolean;
  resolvido_em: string | null;
  created_at: string;
}

export interface PdvPaymentMethod {
  id: string;
  name: string;
  code: string;
  type: 'dinheiro' | 'cartao_debito' | 'cartao_credito' | 'pix' | 'boleto' | 'vale' | 'crediario' | 'outro';
  provider: string | null;
  icon: string | null;
  is_active: boolean;
  fee_percent: number;
  fee_fixed: number;
  terminal_id: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
}
