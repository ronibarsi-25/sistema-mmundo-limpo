/**
 * Utilitários de geração e validação de códigos de barras EAN-13.
 *
 * O prefixo 200–299 é reservado para uso interno da loja (códigos gerados
 * localmente, sem conflito com códigos de fabricantes registrados no GS1).
 */

const INTERNAL_PREFIX = '200';

/**
 * Calcula o dígito verificador de um EAN-13 a partir dos 12 primeiros dígitos.
 */
export function calculateEan13CheckDigit(base12: string): number {
  const digits = base12.replace(/\D/g, '');
  if (digits.length !== 12) {
    throw new Error('O EAN-13 exige exatamente 12 dígitos para o cálculo do dígito verificador.');
  }
  let sum = 0;
  for (let i = 0; i < 12; i++) {
    const digit = Number(digits[i]);
    sum += i % 2 === 0 ? digit : digit * 3;
  }
  return (10 - (sum % 10)) % 10;
}

/**
 * Valida um código EAN-13 completo (13 dígitos + dígito verificador correto).
 */
export function isValidEan13(barcode: string): boolean {
  const digits = (barcode || '').replace(/\D/g, '');
  if (digits.length !== 13) return false;
  const checkDigit = calculateEan13CheckDigit(digits.slice(0, 12));
  return checkDigit === Number(digits[12]);
}

/**
 * Gera um EAN-13 interno a partir de um número sequencial.
 * Ex.: sequencial 1 -> 2000000000017
 */
export function generateEan13(sequential: number): string {
  const padded = String(Math.max(0, Math.floor(sequential))).padStart(9, '0').slice(-9);
  const base12 = `${INTERNAL_PREFIX}${padded}`;
  return `${base12}${calculateEan13CheckDigit(base12)}`;
}

/**
 * Gera uma lista de códigos EAN-13 únicos, ignorando os já existentes.
 */
export function generateUniqueEan13List(count: number, existing: Iterable<string> = []): string[] {
  const used = new Set<string>();
  for (const code of existing) {
    const clean = (code || '').replace(/\D/g, '');
    if (clean) used.add(clean);
  }

  const result: string[] = [];
  let sequential = 1;
  while (result.length < count) {
    const candidate = generateEan13(sequential);
    sequential++;
    if (!used.has(candidate)) {
      used.add(candidate);
      result.push(candidate);
    }
    if (sequential > 999_999_999) {
      throw new Error('Limite de códigos internos EAN-13 atingido.');
    }
  }
  return result;
}

/**
 * Formata o código para exibição agrupada (ex.: 200 000000 0017).
 */
export function formatEan13(barcode: string): string {
  const digits = (barcode || '').replace(/\D/g, '');
  if (digits.length !== 13) return barcode;
  return `${digits.slice(0, 3)} ${digits.slice(3, 9)} ${digits.slice(9)}`;
}
