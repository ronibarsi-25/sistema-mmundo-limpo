import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { supabase } from '@/db/supabase';

export interface CancelledSaleReportItem {
  id: string;
  number: string;
  created_at: string;
  cancelled_at?: string | null;
  cancelled_by_name?: string | null;
  cancellation_reason?: string | null;
  total: number;
  payment_method?: string;
  customer_name?: string | null;
  items_count?: number;
}

export interface CancellationReportOptions {
  periodLabel: string;
  startDate?: string;
  endDate?: string;
  operatorName?: string;
  sales: CancelledSaleReportItem[];
}

const PAYMENT_LABELS: Record<string, string> = {
  dinheiro: 'Dinheiro',
  cartao_debito: 'Cartão Débito',
  cartao_credito: 'Cartão Crédito',
  pix: 'PIX',
  multiplo: 'Combinado',
  outros: 'Outros',
};

export async function generateCancellationReportPdf(options: CancellationReportOptions) {
  const { periodLabel, operatorName, sales } = options;

  // 1. Buscar dados da empresa para o cabeçalho oficial
  const { data: company } = await supabase.from('company').select('*').limit(1).maybeSingle();

  const companyName = company?.nome_fantasia || company?.razao_social || 'Mundo Limpo - Produtos de Limpeza';
  const cnpj = company?.cnpj ? `CNPJ: ${company.cnpj}` : '';
  const addressParts = [
    company?.logradouro,
    company?.numero ? `nº ${company.numero}` : '',
    company?.bairro,
    company?.cidade ? `${company.cidade}/${company?.estado || ''}` : '',
  ].filter(Boolean).join(', ');
  const phone = company?.telefone ? `Tel: ${company.telefone}` : '';

  // 2. Inicializar documento em orientação Paisagem (Landscape) para tabelas ricas
  const doc = new jsPDF({
    orientation: 'landscape',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 14;

  // Métricas do relatório
  const totalCount = sales.length;
  const totalAmount = sales.reduce((acc, s) => acc + (Number(s.total) || 0), 0);
  const totalItemsDevolvidos = sales.reduce((acc, s) => acc + (Number(s.items_count) || 0), 0);
  const ticketMedio = totalCount > 0 ? totalAmount / totalCount : 0;

  // ── CABEÇALHO DO DOCUMENTO ──
  // Faixa superior com a cor primária (#2563EB)
  doc.setFillColor(37, 99, 235);
  doc.rect(margin, margin, pageWidth - (margin * 2), 2.5, 'F');

  // Nome da Empresa
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.setTextColor(15, 23, 42); // #0F172A
  doc.text(companyName.toUpperCase(), margin, margin + 9);

  // Subtítulo e endereço
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(71, 85, 105); // #475569
  const infoLine1 = [cnpj, phone].filter(Boolean).join('  |  ');
  if (infoLine1) {
    doc.text(infoLine1, margin, margin + 14);
  }
  if (addressParts) {
    doc.text(addressParts, margin, margin + 18.5);
  }

  // Título do Relatório no lado direito
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.setTextColor(220, 38, 38); // Vermelho de Alerta / Cancelamento (#DC2626)
  doc.text('RELATÓRIO DE VENDAS CANCELADAS', pageWidth - margin, margin + 9, { align: 'right' });

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(71, 85, 105);
  doc.text(`Período Consultado: ${periodLabel}`, pageWidth - margin, margin + 14, { align: 'right' });
  doc.text(
    `Emissão: ${new Date().toLocaleString('pt-BR')} ${operatorName ? `por ${operatorName}` : ''}`,
    pageWidth - margin,
    margin + 18.5,
    { align: 'right' }
  );

  // Linha separadora
  doc.setDrawColor(226, 232, 240); // #E2E8F0
  doc.setLineWidth(0.5);
  doc.line(margin, margin + 22, pageWidth - margin, margin + 22);

  // ── QUADRO DE RESUMO CONSOLIDADO (KPIS) ──
  const kpiY = margin + 25;
  const kpiWidth = (pageWidth - (margin * 2) - 9) / 4;
  const kpiHeight = 16;

  const kpis = [
    { label: 'VENDAS CANCELADAS', value: `${totalCount}`, color: [220, 38, 38] },
    { label: 'TOTAL ESTORNADO (R$)', value: `R$ ${totalAmount.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, color: [220, 38, 38] },
    { label: 'ITENS ESTORNADOS', value: `${totalItemsDevolvidos} un`, color: [37, 99, 235] },
    { label: 'TICKET MÉDIO CANCELADO', value: `R$ ${ticketMedio.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, color: [71, 85, 105] },
  ];

  kpis.forEach((kpi, idx) => {
    const kpiX = margin + idx * (kpiWidth + 3);
    // Card background
    doc.setFillColor(248, 250, 252);
    doc.setDrawColor(226, 232, 240);
    doc.roundedRect(kpiX, kpiY, kpiWidth, kpiHeight, 1.5, 1.5, 'FD');

    // Label
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(100, 116, 139);
    doc.text(kpi.label, kpiX + 3.5, kpiY + 5);

    // Value
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(kpi.color[0], kpi.color[1], kpi.color[2]);
    doc.text(kpi.value, kpiX + 3.5, kpiY + 12);
  });

  // ── TABELA DETALHADA COM jspdf-autotable ──
  const tableRows = sales.map((sale) => {
    const emissaoFormatted = sale.created_at
      ? new Date(sale.created_at).toLocaleString('pt-BR', {
          day: '2-digit',
          month: '2-digit',
          year: '2-digit',
          hour: '2-digit',
          minute: '2-digit',
        })
      : '-';

    const cancelamentoFormatted = sale.cancelled_at
      ? new Date(sale.cancelled_at).toLocaleString('pt-BR', {
          day: '2-digit',
          month: '2-digit',
          year: '2-digit',
          hour: '2-digit',
          minute: '2-digit',
        })
      : emissaoFormatted;

    const cliente = sale.customer_name || 'Consumidor Final';
    const pagamento = PAYMENT_LABELS[sale.payment_method || ''] || sale.payment_method || 'Outros';
    const valor = `R$ ${Number(sale.total).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    const motivo = sale.cancellation_reason?.trim() || 'Sem justificativa informada';
    const responsavel = sale.cancelled_by_name || '-';

    return [
      sale.number,
      emissaoFormatted,
      cancelamentoFormatted,
      cliente,
      pagamento,
      valor,
      responsavel,
      motivo,
    ];
  });

  autoTable(doc, {
    startY: kpiY + kpiHeight + 5,
    margin: { left: margin, right: margin, bottom: 16 },
    head: [[
      'Nº Venda',
      'Data Emissão',
      'Data Cancel.',
      'Cliente',
      'Pagamento',
      'Valor Estornado',
      'Operador',
      'Justificativa do Cancelamento',
    ]],
    body: tableRows.length > 0 ? tableRows : [
      ['Nenhuma venda cancelada encontrada no período selecionado.', '', '', '', '', '', '', '']
    ],
    theme: 'grid',
    styles: {
      font: 'helvetica',
      fontSize: 8,
      cellPadding: 2.5,
      textColor: [15, 23, 42],
      lineColor: [226, 232, 240],
      lineWidth: 0.2,
      overflow: 'linebreak',
    },
    headStyles: {
      fillColor: [37, 99, 235], // #2563EB
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 8,
      halign: 'left',
    },
    columnStyles: {
      0: { fontStyle: 'bold', cellWidth: 24, textColor: [220, 38, 38] }, // Nº Venda
      1: { cellWidth: 26 }, // Emissão
      2: { cellWidth: 26 }, // Cancelamento
      3: { cellWidth: 35 }, // Cliente
      4: { cellWidth: 24 }, // Pagamento
      5: { cellWidth: 28, halign: 'right', fontStyle: 'bold', textColor: [220, 38, 38] }, // Valor
      6: { cellWidth: 25 }, // Responsável
      7: { cellWidth: 'auto' }, // Justificativa
    },
    alternateRowStyles: {
      fillColor: [248, 250, 252],
    },
    didDrawPage: (data) => {
      // Rodapé da página
      const pageStr = `Página ${data.pageNumber} de ${doc.getNumberOfPages()}`;
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7.5);
      doc.setTextColor(148, 163, 184); // #94A3B8

      doc.text(
        'Documento confidencial gerado pelo Sistema PDV & Estoque Mundo Limpo - Todos os direitos reservados',
        margin,
        pageHeight - 6
      );
      doc.text(pageStr, pageWidth - margin, pageHeight - 6, { align: 'right' });
    },
  });

  // 3. Salvar e disparar download
  const timestamp = new Date().toISOString().slice(0, 10);
  const fileName = `relatorio-vendas-canceladas-${timestamp}.pdf`;
  doc.save(fileName);
}
