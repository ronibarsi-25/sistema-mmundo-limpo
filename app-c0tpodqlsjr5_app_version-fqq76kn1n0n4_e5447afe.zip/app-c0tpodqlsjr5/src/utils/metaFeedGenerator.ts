export interface MetaProductItem {
  id: string;
  title: string;
  description: string;
  availability: 'in stock' | 'out of stock';
  condition: 'new';
  price: string; // e.g. "76.90 BRL"
  link: string;
  image_link: string;
  brand: string;
  gtin: string; // EAN / Barcode
  item_group_id?: string;
  fb_product_category?: string;
  google_product_category?: string;
  sale_price?: string;
}

export interface StoreFeedMeta {
  storeName: string;
  storeUrl: string;
  storeDescription: string;
}

/**
 * Sanitizes and guarantees that an image link is a valid HTTP/HTTPS URL,
 * specifically preferring the official store domain:
 * https://mundolimpo.store/uploads/produtos/foto.jpg
 */
export function sanitizeMetaImageUrl(url?: string, fallbackOrigin?: string, slugOrId?: string): string {
  const origin = fallbackOrigin || (typeof window !== 'undefined' ? window.location.origin : 'https://mundolimpo.store');
  const defaultFoto = `${origin}/uploads/produtos/foto.jpg`;

  if (!url || typeof url !== 'string') {
    return defaultFoto;
  }

  const trimmed = url.trim();

  // Rejeita estritamente data URI / base64 e gstatic
  if (trimmed.startsWith('data:') || trimmed.includes('gstatic.com') || trimmed.includes('encrypted-tbn')) {
    if (slugOrId) {
      return `${origin}/uploads/produtos/${slugOrId}.jpg`;
    }
    return defaultFoto;
  }

  // Se já for do formato da loja /uploads/produtos
  if (trimmed.includes('/uploads/produtos/')) {
    if (trimmed.startsWith('http://') || trimmed.startsWith('https://')) {
      return trimmed.replace('http://', 'https://');
    }
    return `${origin}${trimmed.startsWith('/') ? '' : '/'}${trimmed}`;
  }

  // Se for URL HTTP/HTTPS válida
  if (trimmed.startsWith('https://') || trimmed.startsWith('http://')) {
    return trimmed;
  }

  if (trimmed.startsWith('/')) {
    return `${origin}${trimmed}`;
  }

  return `${origin}/${trimmed}`;
}

/**
 * Escapes characters for XML
 */
function escapeXml(str: string): string {
  if (!str) return '';
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

/**
 * Generates an official XML RSS 2.0 Feed compatible with Meta Commerce Manager,
 * Facebook Shop, Instagram Shopping and Google Merchant Center.
 */
export function generateMetaXml(items: MetaProductItem[], meta: StoreFeedMeta): string {
  const channelTitle = escapeXml(meta.storeName || 'Mundo Limpo');
  const channelLink = escapeXml(meta.storeUrl || window.location.origin);
  const channelDesc = escapeXml(meta.storeDescription || 'Catálogo oficial de produtos Mundo Limpo para Facebook e Instagram Shopping');

  const itemsXml = items.map(item => {
    const safeImageUrl = sanitizeMetaImageUrl(item.image_link, meta.storeUrl);
    return `    <item>
      <g:id>${escapeXml(item.id)}</g:id>
      <g:title>${escapeXml(item.title)}</g:title>
      <g:description>${escapeXml(item.description || item.title)}</g:description>
      <g:link>${escapeXml(item.link)}</g:link>
      <g:image_link>${escapeXml(safeImageUrl)}</g:image_link>
      <g:brand>${escapeXml(item.brand || 'Mundo Limpo')}</g:brand>
      <g:condition>${item.condition || 'new'}</g:condition>
      <g:availability>${item.availability}</g:availability>
      <g:price>${escapeXml(item.price)}</g:price>
${item.sale_price ? `      <g:sale_price>${escapeXml(item.sale_price)}</g:sale_price>\n` : ''}${item.gtin ? `      <g:gtin>${escapeXml(item.gtin)}</g:gtin>\n` : '      <g:identifier_exists>no</g:identifier_exists>\n'}      <g:fb_product_category>Health &amp; Beauty &gt; Personal Care</g:fb_product_category>
    </item>`;
  }).join('\n');

  return `<?xml version="1.0" encoding="UTF-8"?>
<rss xmlns:g="http://base.google.com/ns/1.0" version="2.0">
  <channel>
    <title>${channelTitle}</title>
    <link>${channelLink}</link>
    <description>${channelDesc}</description>
${itemsXml}
  </channel>
</rss>`;
}

/**
 * Generates CSV Feed format recognized by Meta Commerce Manager
 */
export function generateMetaCsv(items: MetaProductItem[], storeUrl?: string): string {
  const headers = [
    'id',
    'title',
    'description',
    'availability',
    'condition',
    'price',
    'link',
    'image_link',
    'brand',
    'gtin',
    'fb_product_category'
  ];

  const escapeCsv = (val: string) => {
    if (!val) return '""';
    const escaped = val.replace(/"/g, '""');
    return `"${escaped}"`;
  };

  const rows = items.map(item => {
    const safeImageUrl = sanitizeMetaImageUrl(item.image_link, storeUrl);
    return [
      escapeCsv(item.id),
      escapeCsv(item.title),
      escapeCsv(item.description || item.title),
      escapeCsv(item.availability),
      escapeCsv(item.condition || 'new'),
      escapeCsv(item.price),
      escapeCsv(item.link),
      escapeCsv(safeImageUrl),
      escapeCsv(item.brand || 'Mundo Limpo'),
      escapeCsv(item.gtin || ''),
      escapeCsv('Health & Beauty > Personal Care')
    ].join(',');
  });

  return [headers.join(','), ...rows].join('\n');
}

/**
 * Validates a product for Meta Commerce Manager readiness
 */
export function validateMetaProduct(product: Partial<MetaProductItem>): {
  isReady: boolean;
  issues: string[];
} {
  const issues: string[] = [];

  if (!product.title || product.title.trim().length === 0) {
    issues.push('Título do produto ausente');
  }
  if (!product.image_link || product.image_link.trim().length === 0) {
    issues.push('Foto obrigatória ausente (a Meta exige imagem)');
  } else if (product.image_link.startsWith('data:')) {
    issues.push('Foto em Base64 inválida (a Meta exige URL https://)');
  } else if (!product.image_link.startsWith('http://') && !product.image_link.startsWith('https://')) {
    issues.push('URL da foto deve iniciar com https://');
  }
  if (!product.price || product.price === '0.00 BRL') {
    issues.push('Preço não configurado');
  }
  if (!product.gtin || product.gtin.trim().length === 0) {
    issues.push('Código de barras (EAN/GTIN) não preenchido');
  }

  return {
    isReady: issues.length === 0,
    issues
  };
}

/**
 * Triggers file download in browser
 */
export function downloadFile(content: string, filename: string, mimeType: string) {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
