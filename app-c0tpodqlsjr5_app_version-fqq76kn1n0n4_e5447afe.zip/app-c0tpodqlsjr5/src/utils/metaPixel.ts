import { supabase } from '@/db/supabase';

// Declaração de tipos para a biblioteca do Facebook Pixel
declare global {
  interface Window {
    fbq?: {
      (...args: any[]): void;
      callMethod?: (...args: any[]) => void;
      queue?: any[];
      push?: (...args: any[]) => void;
      loaded?: boolean;
      version?: string;
    };
    _fbq?: any;
  }
}

export interface MetaPixelEventLog {
  id: string;
  timestamp: string;
  eventName: string;
  parameters?: Record<string, any>;
  status: 'sent' | 'blocked' | 'disabled';
}

class MetaPixelService {
  private currentPixelId: string | null = null;
  private isEnabled: boolean = false;
  private scriptLoaded: boolean = false;
  private recentLogs: MetaPixelEventLog[] = [];
  private logListeners: Array<(logs: MetaPixelEventLog[]) => void> = [];

  constructor() {
    // Carregar configurações locais ou inicializar com o Pixel ID configurado
    try {
      const cached = localStorage.getItem('meta_pixel_cached_cfg');
      if (cached) {
        const parsed = JSON.parse(cached);
        if (parsed.pixelId && parsed.active) {
          this.init(parsed.pixelId);
          return;
        }
      }
      this.init('1815239886415985');
    } catch {
      this.init('1815239886415985');
    }
  }

  /**
   * Adiciona log à lista de histórico em memória para auditoria e tela de configurações
   */
  private addLog(eventName: string, parameters?: Record<string, any>, status: 'sent' | 'blocked' | 'disabled' = 'sent') {
    const newLog: MetaPixelEventLog = {
      id: `${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      timestamp: new Date().toLocaleTimeString('pt-BR'),
      eventName,
      parameters,
      status,
    };
    this.recentLogs = [newLog, ...this.recentLogs.slice(0, 29)];
    this.logListeners.forEach(listener => listener(this.recentLogs));
  }

  public subscribeLogs(listener: (logs: MetaPixelEventLog[]) => void): () => void {
    this.logListeners.push(listener);
    listener(this.recentLogs);
    return () => {
      this.logListeners = this.logListeners.filter(l => l !== listener);
    };
  }

  public getLogs(): MetaPixelEventLog[] {
    return this.recentLogs;
  }

  /**
   * Injeta o script base oficial do Meta Pixel (fbq) e inicializa o Pixel ID
   */
  public init(pixelId: string) {
    const cleanId = pixelId.trim();
    if (!cleanId) return;

    this.currentPixelId = cleanId;
    this.isEnabled = true;

    // Se já foi inicializado no window, apenas chama fbq('init', cleanId)
    if (typeof window !== 'undefined') {
      if (!window.fbq) {
        const n: any = function (...args: any[]) {
          if (n.callMethod) {
            n.callMethod.apply(n, args);
          } else {
            n.queue.push(args);
          }
        };
        if (!window._fbq) window._fbq = n;
        n.push = n;
        n.loaded = true;
        n.version = '2.0';
        n.queue = [];
        window.fbq = n;

        // Injetar a tag de script do Meta Pixel de forma assíncrona
        try {
          const script = document.createElement('script');
          script.async = true;
          script.src = 'https://connect.facebook.net/en_US/fbevents.js';
          script.onerror = () => {
            console.warn('[Meta Pixel] O script fbevents.js não pôde ser carregado (bloqueador de anúncios ativo ou sem conexão).');
            this.scriptLoaded = false;
          };
          script.onload = () => {
            this.scriptLoaded = true;
          };
          const firstScript = document.getElementsByTagName('script')[0];
          if (firstScript && firstScript.parentNode) {
            firstScript.parentNode.insertBefore(script, firstScript);
          } else {
            document.head.appendChild(script);
          }
        } catch (err) {
          console.warn('[Meta Pixel] Falha ao injetar script:', err);
        }
      }

      try {
        if (window.fbq) {
          window.fbq('init', cleanId);
          window.fbq('track', 'PageView');
          this.addLog('Init & PageView', { pixelId: cleanId }, 'sent');
        }
      } catch (err) {
        console.warn('[Meta Pixel] Erro ao disparar init/PageView:', err);
      }
    }
  }

  /**
   * Desativa o rastreamento em tempo de execução
   */
  public disable() {
    this.isEnabled = false;
    this.addLog('Pixel Desativado', undefined, 'disabled');
  }

  public isActive(): boolean {
    return this.isEnabled && Boolean(this.currentPixelId);
  }

  public getPixelId(): string | null {
    return this.currentPixelId;
  }

  /**
   * Dispara evento de PageView (troca de rota)
   */
  public trackPageView(url?: string) {
    if (!this.isActive() || typeof window === 'undefined' || !window.fbq) {
      if (!this.isEnabled) this.addLog('PageView', { url }, 'disabled');
      return;
    }
    try {
      window.fbq('track', 'PageView');
      this.addLog('PageView', { path: url || window.location.pathname }, 'sent');
    } catch {
      this.addLog('PageView', { path: url || window.location.pathname }, 'blocked');
    }
  }

  /**
   * Dispara evento ViewContent (Visualização de Produto ou Detalhes)
   */
  public trackViewContent(params: {
    id: string;
    name: string;
    price: number;
    category?: string;
  }) {
    if (!this.isActive() || typeof window === 'undefined' || !window.fbq) {
      return;
    }
    try {
      const data = {
        content_ids: [params.id],
        content_name: params.name,
        content_type: 'product',
        content_category: params.category || 'Geral',
        value: Number(params.price) || 0,
        currency: 'BRL',
      };
      window.fbq('track', 'ViewContent', data);
      this.addLog('ViewContent', data, 'sent');
    } catch {
      this.addLog('ViewContent', params, 'blocked');
    }
  }

  /**
   * Dispara evento AddToCart (Item adicionado ao carrinho no PDV ou Loja)
   */
  public trackAddToCart(params: {
    id: string;
    name: string;
    price: number;
    quantity: number;
    category?: string;
  }) {
    if (!this.isActive() || typeof window === 'undefined' || !window.fbq) {
      return;
    }
    try {
      const data = {
        content_ids: [params.id],
        content_name: params.name,
        content_type: 'product',
        content_category: params.category || 'Geral',
        value: (Number(params.price) || 0) * (Number(params.quantity) || 1),
        currency: 'BRL',
        num_items: Number(params.quantity) || 1,
      };
      window.fbq('track', 'AddToCart', data);
      this.addLog('AddToCart', data, 'sent');
    } catch {
      this.addLog('AddToCart', params, 'blocked');
    }
  }

  /**
   * Dispara evento InitiateCheckout (Início de Pagamento no PDV)
   */
  public trackInitiateCheckout(params: {
    itemsCount: number;
    totalValue: number;
    items?: Array<{ id: string; name?: string; price: number; quantity: number }>;
  }) {
    if (!this.isActive() || typeof window === 'undefined' || !window.fbq) {
      return;
    }
    try {
      const data = {
        content_ids: params.items ? params.items.map(i => i.id) : [],
        num_items: params.itemsCount,
        value: Number(params.totalValue) || 0,
        currency: 'BRL',
      };
      window.fbq('track', 'InitiateCheckout', data);
      this.addLog('InitiateCheckout', data, 'sent');
    } catch {
      this.addLog('InitiateCheckout', params, 'blocked');
    }
  }

  /**
   * Dispara evento Purchase (Compra Concluída)
   */
  public trackPurchase(params: {
    orderId: string;
    totalValue: number;
    itemsCount?: number;
    items?: Array<{ id: string; quantity: number }>;
  }) {
    if (!this.isActive() || typeof window === 'undefined' || !window.fbq) {
      return;
    }
    try {
      const data = {
        content_ids: params.items ? params.items.map(i => i.id) : [],
        content_type: 'product',
        num_items: params.itemsCount || (params.items ? params.items.reduce((acc, it) => acc + (it.quantity || 1), 0) : 1),
        value: Number(params.totalValue) || 0,
        currency: 'BRL',
        order_id: params.orderId,
      };
      window.fbq('track', 'Purchase', data);
      this.addLog('Purchase', data, 'sent');
    } catch {
      this.addLog('Purchase', params, 'blocked');
    }
  }

  /**
   * Dispara evento personalizado para teste de comunicação
   */
  public sendTestEvent(): { success: boolean; message: string; pixelId?: string } {
    if (!this.currentPixelId) {
      return { success: false, message: 'Nenhum Pixel ID configurado no sistema.' };
    }
    if (!this.isEnabled) {
      return { success: false, message: 'O Meta Pixel está desativado nas configurações.' };
    }
    if (typeof window === 'undefined' || !window.fbq) {
      return {
        success: false,
        message: 'A biblioteca fbq não foi encontrada (verifique se possui adblocker ativo).',
      };
    }

    try {
      const testData = {
        test_source: 'Painel_Administrativo_Mundo_Limpo',
        timestamp: new Date().toISOString(),
        status: 'conectado',
      };
      window.fbq('trackCustom', 'MundoLimpoTestEvent', testData);
      this.addLog('MundoLimpoTestEvent (Teste)', testData, 'sent');
      return {
        success: true,
        message: `Sinal de teste transmitido com sucesso ao Meta Pixel (${this.currentPixelId})!`,
        pixelId: this.currentPixelId,
      };
    } catch (err: any) {
      this.addLog('MundoLimpoTestEvent', undefined, 'blocked');
      return {
        success: false,
        message: `Falha ao emitir sinal: ${err?.message || 'Erro desconhecido'}`,
      };
    }
  }

  /**
   * Carrega a configuração do Meta Pixel do Supabase e sincroniza o estado global
   */
  public async loadFromSupabase(): Promise<{ pixelId: string; active: boolean }> {
    try {
      const { data, error } = await supabase
        .from('company')
        .select('meta_pixel_id, meta_pixel_active')
        .limit(1)
        .maybeSingle();

      if (error) {
        console.warn('[Meta Pixel] Erro ao carregar configurações do Supabase:', error);
      }

      const pixelId = data?.meta_pixel_id?.trim() || '';
      const active = Boolean(data?.meta_pixel_active && pixelId);

      // Atualizar cache
      try {
        localStorage.setItem('meta_pixel_cached_cfg', JSON.stringify({ pixelId, active }));
      } catch {
        // Ignora
      }

      if (active && pixelId) {
        this.init(pixelId);
      } else {
        this.disable();
        this.currentPixelId = pixelId;
      }

      return { pixelId, active };
    } catch (err) {
      console.warn('[Meta Pixel] Erro durante loadFromSupabase:', err);
      return { pixelId: this.currentPixelId || '', active: this.isEnabled };
    }
  }

  /**
   * Salva as configurações do Meta Pixel no banco de dados Supabase
   */
  public async saveToSupabase(pixelId: string, active: boolean): Promise<void> {
    const cleanId = pixelId.trim();

    // 1. Atualizar ou inserir na tabela company
    const { data: existing } = await supabase.from('company').select('id').limit(1).maybeSingle();

    if (existing?.id) {
      const { error } = await supabase
        .from('company')
        .update({
          meta_pixel_id: cleanId,
          meta_pixel_active: active,
          updated_at: new Date().toISOString(),
        })
        .eq('id', existing.id);

      if (error) throw error;
    } else {
      const { error } = await supabase.from('company').insert({
        meta_pixel_id: cleanId,
        meta_pixel_active: active,
        razao_social: 'Mundo Limpo',
      });
      if (error) throw error;
    }

    // 2. Atualizar cache e estado local
    try {
      localStorage.setItem('meta_pixel_cached_cfg', JSON.stringify({ pixelId: cleanId, active }));
    } catch {
      // Ignora
    }

    if (active && cleanId) {
      this.init(cleanId);
    } else {
      this.disable();
      this.currentPixelId = cleanId;
    }
  }
}

export const metaPixel = new MetaPixelService();
