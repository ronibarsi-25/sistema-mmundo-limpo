// Parser robusto de Nota Fiscal Eletrônica (NF-e XML) e DANFE PDF
import { supabase } from '@/db/supabase';

export interface ParsedSupplier {
  cnpj: string;
  razaoSocial: string;
  nomeFantasia?: string;
  ie?: string;
  logradouro?: string;
  numero?: string;
  bairro?: string;
  municipio?: string;
  uf?: string;
  cep?: string;
  telefone?: string;
}

export interface ParsedInvoiceTotals {
  valorProdutos: number;
  frete: number;
  seguro: number;
  desconto: number;
  outrasDespesas: number;
  ipi: number;
  icmsSt: number;
  valorTotal: number;
}

export interface ParsedDuplicate {
  numero: string;
  vencimento: string; // YYYY-MM-DD
  valor: number;
}

export interface ParsedInvoiceItem {
  id: string; // temporary id
  codigoFornecedor: string;
  barcode: string;
  descricao: string;
  ncm: string;
  cfop: string;
  unidade: string;
  quantidade: number;
  valorUnitarioBruto: number;
  valorTotalBruto: number;
  freteRateado: number;
  ipiRateado: number;
  stRateado: number;
  outrasDespesasRateado: number;
  descontoRateado: number;
  custoRealUnitario: number;
  precoVendaSugerido: number;
  // Matching state with system products
  matchedProductId?: string;
  matchedProductName?: string;
  matchedCurrentStock?: number;
  action: 'update' | 'create';
  selected: boolean;
}

export interface ParsedNfeData {
  tipoArquivo: 'xml' | 'pdf';
  numero: string;
  serie: string;
  chaveAcesso: string;
  dataEmissao: string;
  fornecedor: ParsedSupplier;
  totais: ParsedInvoiceTotals;
  duplicatas: ParsedDuplicate[];
  itens: ParsedInvoiceItem[];
}

/**
 * Lê e extrai dados completos de um XML de NF-e utilizando DOMParser do navegador
 */
export function parseNfeXmlString(xmlContent: string, defaultMarkup = 50, includeTaxes = true): ParsedNfeData {
  const parser = new DOMParser();
  const doc = parser.parseFromString(xmlContent, 'text/xml');

  const getText = (parent: Element | null, tag: string): string => {
    if (!parent) return '';
    const el = parent.getElementsByTagName(tag)[0];
    return el?.textContent?.trim() || '';
  };

  const getNum = (parent: Element | null, tag: string): number => {
    const val = getText(parent, tag);
    return parseFloat(val) || 0;
  };

  // Identificação e Chave
  const infNFe = doc.getElementsByTagName('infNFe')[0];
  let chaveAcesso = infNFe?.getAttribute('Id') || '';
  chaveAcesso = chaveAcesso.replace(/^NFe/i, '');

  const ide = doc.getElementsByTagName('ide')[0];
  const numero = getText(ide, 'nNF');
  const serie = getText(ide, 'serie');
  const dhEmi = getText(ide, 'dhEmi') || getText(ide, 'dEmi');

  // Emitente (Fornecedor)
  const emit = doc.getElementsByTagName('emit')[0];
  const enderEmit = emit?.getElementsByTagName('enderEmit')[0];
  const fornecedor: ParsedSupplier = {
    cnpj: getText(emit, 'CNPJ') || getText(emit, 'CPF'),
    razaoSocial: getText(emit, 'xNome') || 'Fornecedor sem razão social',
    nomeFantasia: getText(emit, 'xFant') || getText(emit, 'xNome'),
    ie: getText(emit, 'IE'),
    logradouro: getText(enderEmit, 'xLgr'),
    numero: getText(enderEmit, 'nro'),
    bairro: getText(enderEmit, 'xBairro'),
    municipio: getText(enderEmit, 'xMun'),
    uf: getText(enderEmit, 'UF'),
    cep: getText(enderEmit, 'CEP'),
    telefone: getText(enderEmit, 'fone'),
  };

  // Totais
  const icmsTot = doc.getElementsByTagName('ICMSTot')[0];
  const totais: ParsedInvoiceTotals = {
    valorProdutos: getNum(icmsTot, 'vProd'),
    frete: getNum(icmsTot, 'vFrete'),
    seguro: getNum(icmsTot, 'vSeg'),
    desconto: getNum(icmsTot, 'vDesc'),
    outrasDespesas: getNum(icmsTot, 'vOutro'),
    ipi: getNum(icmsTot, 'vIPI'),
    icmsSt: getNum(icmsTot, 'vST'),
    valorTotal: getNum(icmsTot, 'vNF') || getNum(icmsTot, 'vProd'),
  };

  // Duplicatas / Faturas
  const duplicatas: ParsedDuplicate[] = [];
  const dups = doc.getElementsByTagName('dup');
  for (let i = 0; i < dups.length; i++) {
    const d = dups[i];
    duplicatas.push({
      numero: getText(d, 'nDup') || `Parc ${i + 1}`,
      vencimento: getText(d, 'dVenc') || new Date().toISOString().split('T')[0],
      valor: getNum(d, 'vDup'),
    });
  }

  // Itens (<det>)
  const detElements = doc.getElementsByTagName('det');
  const itens: ParsedInvoiceItem[] = [];

  for (let i = 0; i < detElements.length; i++) {
    const det = detElements[i];
    const prod = det.getElementsByTagName('prod')[0];
    const imposto = det.getElementsByTagName('imposto')[0];

    const cProd = getText(prod, 'cProd') || `ITEM_${i + 1}`;
    let cEAN = getText(prod, 'cEAN');
    if (cEAN === 'SEM GTIN' || cEAN === 'SEMGTIN' || cEAN === '') {
      cEAN = getText(prod, 'cEANTrib');
    }
    if (cEAN === 'SEM GTIN' || cEAN === 'SEMGTIN') {
      cEAN = '';
    }

    const xProd = getText(prod, 'xProd') || 'Produto sem descrição';
    const ncm = getText(prod, 'NCM');
    const cfop = getText(prod, 'CFOP');
    const uCom = (getText(prod, 'uCom') || 'UN').toUpperCase();
    const qCom = getNum(prod, 'qCom') || 1;
    const vUnCom = getNum(prod, 'vUnCom') || 0;
    const vProd = getNum(prod, 'vProd') || (qCom * vUnCom);

    // Custos do item
    const vFreteItem = getNum(prod, 'vFrete');
    const vDescItem = getNum(prod, 'vDesc');
    const vOutroItem = getNum(prod, 'vOutro');

    // Impostos do item
    let vIpiItem = 0;
    const ipiEl = imposto?.getElementsByTagName('IPI')[0];
    if (ipiEl) {
      vIpiItem = getNum(ipiEl, 'vIPI');
    }

    let vStItem = 0;
    const icmsEl = imposto?.getElementsByTagName('ICMS')[0];
    if (icmsEl) {
      vStItem = getNum(icmsEl, 'vICMSST');
    }

    // Rateio proporcional caso não venha no item mas exista no total
    let freteRateado = vFreteItem;
    let ipiRateado = vIpiItem;
    let stRateado = vStItem;
    let outrasDespesasRateado = vOutroItem;
    let descontoRateado = vDescItem;

    if (totais.valorProdutos > 0) {
      const prop = vProd / totais.valorProdutos;
      if (freteRateado === 0 && totais.frete > 0) freteRateado = totais.frete * prop;
      if (ipiRateado === 0 && totais.ipi > 0) ipiRateado = totais.ipi * prop;
      if (stRateado === 0 && totais.icmsSt > 0) stRateado = totais.icmsSt * prop;
      if (outrasDespesasRateado === 0 && totais.outrasDespesas > 0) outrasDespesasRateado = totais.outrasDespesas * prop;
      if (descontoRateado === 0 && totais.desconto > 0) descontoRateado = totais.desconto * prop;
    }

    // Custo real unitário
    let custoAdicionalUnitario = 0;
    if (includeTaxes && qCom > 0) {
      const totalAdicional = (freteRateado + ipiRateado + stRateado + outrasDespesasRateado) - descontoRateado;
      custoAdicionalUnitario = totalAdicional / qCom;
    }

    const custoRealUnitario = Math.max(0.01, Number((vUnCom + custoAdicionalUnitario).toFixed(2)));
    const precoVendaSugerido = Number((custoRealUnitario * (1 + defaultMarkup / 100)).toFixed(2));

    itens.push({
      id: `xml_item_${i}_${Date.now()}`,
      codigoFornecedor: cProd,
      barcode: cEAN,
      descricao: xProd,
      ncm,
      cfop,
      unidade: uCom,
      quantidade: qCom,
      valorUnitarioBruto: vUnCom,
      valorTotalBruto: vProd,
      freteRateado,
      ipiRateado,
      stRateado,
      outrasDespesasRateado,
      descontoRateado,
      custoRealUnitario,
      precoVendaSugerido,
      action: 'create',
      selected: true,
    });
  }

  return {
    tipoArquivo: 'xml',
    numero,
    serie,
    chaveAcesso,
    dataEmissao: dhEmi || new Date().toISOString(),
    fornecedor,
    totais,
    duplicatas,
    itens,
  };
}

/**
 * Processa PDF de DANFE fazendo upload e chamando Edge Function com fallback inteligente
 */
export async function parseDanfePdf(
  file: File,
  defaultMarkup = 50,
  includeTaxes = true
): Promise<ParsedNfeData> {
  const fileName = `notas/${Date.now()}_${file.name.replace(/\s+/g, '_')}`;

  // 1. Upload do PDF no storage bucket
  const { error: uploadError } = await supabase.storage
    .from('invoices')
    .upload(fileName, file, { upsert: true });

  if (uploadError) {
    throw new Error(`Falha no upload do arquivo PDF: ${uploadError.message}`);
  }

  // 2. Chama a Edge Function extract-invoice-products
  const { data, error } = await supabase.functions.invoke('extract-invoice-products', {
    body: {
      filePath: fileName,
      defaultMarkup,
      includeTaxesAndFreight: includeTaxes,
    },
  });

  if (error) {
    let errMsg = 'Erro no processamento da nota em PDF.';
    try {
      const errText = await error.context?.text?.();
      if (errText) {
        const parsed = JSON.parse(errText);
        errMsg = parsed?.message || errText;
      }
    } catch {
      errMsg = error.message || errMsg;
    }
    throw new Error(errMsg);
  }

  const rawProducts = data?.data?.products || [];
  if (!Array.isArray(rawProducts) || rawProducts.length === 0) {
    throw new Error('Nenhum item reconhecido no arquivo PDF da nota. Verifique se o documento é legível.');
  }

  const itens: ParsedInvoiceItem[] = rawProducts.map((p: any, idx: number) => {
    const cost = Number(p.cost_price) || 0;
    const qty = Number(p.quantity) || 1;
    let sale = Number(p.sale_price) || 0;
    if (sale === 0 && cost > 0) {
      sale = Number((cost * (1 + defaultMarkup / 100)).toFixed(2));
    }

    return {
      id: `pdf_item_${idx}_${Date.now()}`,
      codigoFornecedor: p.code || `PDF_${idx + 1}`,
      barcode: p.barcode || '',
      descricao: p.name || `Item ${idx + 1}`,
      ncm: p.ncm || '',
      cfop: '',
      unidade: (p.unit || 'UN').toUpperCase(),
      quantidade: qty,
      valorUnitarioBruto: cost,
      valorTotalBruto: Number((cost * qty).toFixed(2)),
      freteRateado: 0,
      ipiRateado: 0,
      stRateado: 0,
      outrasDespesasRateado: 0,
      descontoRateado: 0,
      custoRealUnitario: cost,
      precoVendaSugerido: sale,
      action: 'create',
      selected: true,
    };
  });

  const totalValor = itens.reduce((s, it) => s + it.valorTotalBruto, 0);

  return {
    tipoArquivo: 'pdf',
    numero: file.name.replace(/\D/g, '').slice(0, 9) || 'S/N',
    serie: '1',
    chaveAcesso: '',
    dataEmissao: new Date().toISOString(),
    fornecedor: {
      cnpj: '',
      razaoSocial: file.name.replace(/\.[^/.]+$/, '').slice(0, 40) || 'Fornecedor da Nota',
    },
    totais: {
      valorProdutos: totalValor,
      frete: 0,
      seguro: 0,
      desconto: 0,
      outrasDespesas: 0,
      ipi: 0,
      icmsSt: 0,
      valorTotal: totalValor,
    },
    duplicatas: [
      {
        numero: '001',
        vencimento: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        valor: totalValor,
      },
    ],
    itens,
  };
}

/**
 * Recalcula custos e preços de venda sugeridos em lote com base nas opções ativas
 */
export function recalculateInvoiceItems(
  items: ParsedInvoiceItem[],
  totais: ParsedInvoiceTotals,
  defaultMarkup: number,
  includeTaxes: boolean
): ParsedInvoiceItem[] {
  return items.map(item => {
    let custoAdicionalUnitario = 0;
    if (includeTaxes && item.quantidade > 0 && totais.valorProdutos > 0) {
      const prop = item.valorTotalBruto / totais.valorProdutos;
      const frete = item.freteRateado || (totais.frete * prop);
      const ipi = item.ipiRateado || (totais.ipi * prop);
      const st = item.stRateado || (totais.icmsSt * prop);
      const outras = item.outrasDespesasRateado || (totais.outrasDespesas * prop);
      const desc = item.descontoRateado || (totais.desconto * prop);

      const totalAdicional = (frete + ipi + st + outras) - desc;
      custoAdicionalUnitario = totalAdicional / item.quantidade;
    }

    const custoRealUnitario = Math.max(0.01, Number((item.valorUnitarioBruto + custoAdicionalUnitario).toFixed(2)));
    const precoVendaSugerido = Number((custoRealUnitario * (1 + defaultMarkup / 100)).toFixed(2));

    return {
      ...item,
      custoRealUnitario,
      precoVendaSugerido,
    };
  });
}
