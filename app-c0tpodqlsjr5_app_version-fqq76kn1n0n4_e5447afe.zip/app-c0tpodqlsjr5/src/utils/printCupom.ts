// Utilitário para impressão de cupom fiscal em impressoras térmicas (80mm)
// Abre janela de impressão do navegador com layout estilizado para cupom.

export interface CupomItem {
  name: string;
  qty: number;
  unit: string;
  unit_price: number;
  total_price: number;
  discount?: number;
}

export interface CupomData {
  number: string;
  issued_at: string;
  // Empresa
  store_name: string;
  cnpj?: string | null;
  logradouro?: string | null;
  numero?: string | null;
  bairro?: string | null;
  cidade?: string | null;
  estado?: string | null;
  telefone?: string | null;
  // Venda
  items: CupomItem[];
  subtotal: number;
  discount: number;
  total: number;
  payment_method: string;
  amount_paid?: number;
  change?: number;
  customer_name?: string | null;
  operator_name?: string | null;
}

const PAYMENT_LABELS: Record<string, string> = {
  dinheiro: 'Dinheiro',
  cartao_debito: 'Cartão Débito',
  cartao_credito: 'Cartão Crédito',
  pix: 'PIX',
  outros: 'Outros',
};

function fmt(value: number) {
  return value.toFixed(2).replace('.', ',');
}

function line(char = '-', len = 40) {
  return char.repeat(len);
}

export function printCupomFiscal(data: CupomData) {
  const address = [
    data.logradouro && data.numero ? `${data.logradouro}, ${data.numero}` : data.logradouro,
    data.bairro,
    data.cidade && data.estado ? `${data.cidade} - ${data.estado}` : data.cidade,
  ].filter(Boolean).join(' | ');

  const itemRows = data.items.map(i => `
    <tr>
      <td colspan="2" class="name">${i.name}</td>
    </tr>
    <tr>
      <td class="qty">${fmt(i.qty)} ${i.unit} x R$ ${fmt(i.unit_price)}${i.discount && i.discount > 0 ? ` (Desc: R$ ${fmt(i.discount)})` : ''}</td>
      <td class="price">R$ ${fmt(i.total_price)}</td>
    </tr>`).join('');

  const html = `<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8"/>
<title>Cupom ${data.number}</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    font-family: 'Courier New', Courier, monospace;
    font-size: 12px;
    font-weight: bold;
    width: 300px;
    margin: 0 auto;
    padding: 8px 4px;
    color: #000;
    background: #fff;
  }
  .center { text-align: center; }
  .bold { font-weight: bold; }
  .right { text-align: right; }
  .big { font-size: 15px; font-weight: bold; }
  .sep { border-top: 2px dashed #000; margin: 4px 0; }
  table { width: 100%; border-collapse: collapse; }
  td { padding: 1px 0; vertical-align: top; font-weight: bold; }
  td.name { font-weight: bold; }
  td.qty { color: #222; font-weight: bold; }
  td.price { text-align: right; font-weight: bold; }
  .total-row td { font-size: 14px; font-weight: bold; padding-top: 3px; }
  .footer { margin-top: 6px; font-size: 11px; font-weight: bold; }
  @media print {
    body { width: 100%; padding: 0; }
    @page { margin: 4mm; size: 80mm auto; }
  }
</style>
</head>
<body>

<div class="center bold big">${data.store_name}</div>
${data.cnpj ? `<div class="center">CNPJ: ${data.cnpj}</div>` : ''}
${address ? `<div class="center">${address}</div>` : ''}
${data.telefone ? `<div class="center">Tel: ${data.telefone}</div>` : ''}

<div class="sep"></div>
<div class="center bold">CUPOM FISCAL</div>
<div class="center">Nº ${data.number}</div>
<div class="center">${new Date(data.issued_at).toLocaleString('pt-BR')}</div>
${data.operator_name ? `<div class="center">Operador: ${data.operator_name}</div>` : ''}
${data.customer_name ? `<div class="center">Cliente: ${data.customer_name}</div>` : ''}

<div class="sep"></div>
<table>
  <thead>
    <tr>
      <td class="bold">ITEM / QTD x PREÇO</td>
      <td class="bold right">TOTAL</td>
    </tr>
  </thead>
  <tbody>${itemRows}</tbody>
</table>

<div class="sep"></div>
<table>
  <tr>
    <td>Subtotal</td>
    <td class="right">R$ ${fmt(data.subtotal)}</td>
  </tr>
  ${data.discount > 0 ? `<tr><td>Desconto</td><td class="right">-R$ ${fmt(data.discount)}</td></tr>` : ''}
  <tr class="total-row">
    <td>TOTAL</td>
    <td class="right">R$ ${fmt(data.total)}</td>
  </tr>
  <tr>
    <td>Pagamento</td>
    <td class="right">${PAYMENT_LABELS[data.payment_method] || data.payment_method}</td>
  </tr>
  ${data.amount_paid && data.amount_paid > 0 ? `<tr><td>Valor Pago</td><td class="right">R$ ${fmt(data.amount_paid)}</td></tr>` : ''}
  ${data.change && data.change > 0 ? `<tr><td>Troco</td><td class="right">R$ ${fmt(data.change)}</td></tr>` : ''}
</table>

<div class="sep"></div>
<div class="center footer">
  <p>${line('*')}</p>
  <p class="bold">OBRIGADO PELA PREFERÊNCIA!</p>
  <p>Volte sempre!</p>
  <p>${line('*')}</p>
  <p style="margin-top:4px; font-size:9px;">Este documento não possui valor fiscal.</p>
</div>

<script>window.onload = function(){ window.print(); window.onafterprint = function(){ window.close(); }; };</script>
</body>
</html>`;

  const win = window.open('', '_blank', 'width=360,height=600,toolbar=0,menubar=0,location=0');
  if (!win) { alert('Permita popups para imprimir o cupom.'); return; }
  win.document.write(html);
  win.document.close();
}
