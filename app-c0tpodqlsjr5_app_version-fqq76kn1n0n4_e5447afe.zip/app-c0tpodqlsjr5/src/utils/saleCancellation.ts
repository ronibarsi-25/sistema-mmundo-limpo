import { supabase } from '@/db/supabase';

export interface CancelSaleResult {
  success: boolean;
  message?: string;
  error?: string;
}

export async function cancelPdvSale(
  invoiceId: string,
  reason: string,
  userId?: string
): Promise<CancelSaleResult> {
  if (!invoiceId) {
    return { success: false, error: 'ID da venda não informado.' };
  }

  const trimmedReason = reason?.trim();
  if (!trimmedReason) {
    return { success: false, error: 'A justificativa do cancelamento é obrigatória.' };
  }

  try {
    // 1. Buscar a venda e seus itens
    const { data: invoice, error: invError } = await supabase
      .from('pdv_invoices')
      .select('id, number, status, notes, total, pdv_invoice_items(id, product_id, quantity, unit_price)')
      .eq('id', invoiceId)
      .maybeSingle();

    if (invError || !invoice) {
      return { success: false, error: 'Venda não encontrada no sistema.' };
    }

    if (invoice.status === 'cancelada') {
      return { success: false, error: 'Esta venda já está cancelada.' };
    }

    const items = invoice.pdv_invoice_items || [];

    // 2. Estornar as quantidades dos produtos no estoque e registrar movimentação
    for (const item of items) {
      if (!item.product_id || !item.quantity) continue;

      const qtyToRestore = Number(item.quantity) || 0;
      if (qtyToRestore <= 0) continue;

      // Buscar produto atual para saber estoque anterior
      const { data: prod } = await supabase
        .from('pdv_products')
        .select('id, stock_qty, name')
        .eq('id', item.product_id)
        .maybeSingle();

      const currentStock = Number(prod?.stock_qty) || 0;
      const newStock = currentStock + qtyToRestore;

      // Atualizar estoque do produto
      await supabase
        .from('pdv_products')
        .update({ stock_qty: newStock })
        .eq('id', item.product_id);

      // Inserir registro na tabela de movimentações de estoque (pdv_stock_movements)
      await supabase
        .from('pdv_stock_movements')
        .insert({
          product_id: item.product_id,
          type: 'entrada',
          quantity: qtyToRestore,
          previous_qty: currentStock,
          new_qty: newStock,
          reference_id: invoice.id,
          reference_type: 'cancelamento_venda',
          notes: `Estorno por cancelamento da venda ${invoice.number}. Justificativa: ${trimmedReason}`,
        });
    }

    // 3. Atualizar status da nota para 'cancelada' com data, justificativa e usuário
    const updatedNotes = invoice.notes
      ? `${invoice.notes} | [CANCELAMENTO ${new Date().toLocaleDateString('pt-BR')}]: ${trimmedReason}`
      : `[CANCELAMENTO ${new Date().toLocaleDateString('pt-BR')}]: ${trimmedReason}`;

    const { error: updError } = await supabase
      .from('pdv_invoices')
      .update({
        status: 'cancelada',
        cancellation_reason: trimmedReason,
        cancelled_at: new Date().toISOString(),
        cancelled_by: userId || null,
        notes: updatedNotes,
      })
      .eq('id', invoiceId);

    if (updError) {
      throw updError;
    }

    // 4. Estorno financeiro: remove os lançamentos de receita gerados pela venda
    await supabase
      .from('transactions')
      .delete()
      .eq('invoice_id', invoiceId);

    return {
      success: true,
      message: `Venda ${invoice.number} cancelada com sucesso. Itens devolvidos ao estoque e financeiro estornado.`,
    };
  } catch (err: unknown) {
    console.error('Erro ao cancelar venda:', err);
    const msg = err instanceof Error ? err.message : 'Falha ao processar cancelamento da venda.';
    return { success: false, error: msg };
  }
}
