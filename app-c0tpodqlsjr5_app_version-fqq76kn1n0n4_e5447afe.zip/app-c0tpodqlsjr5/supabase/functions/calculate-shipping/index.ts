import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface ShippingRequest {
  cep_origin: string;
  cep_destiny: string;
  weight_kg: number;
  length_cm: number;
  width_cm: number;
  height_cm: number;
  declared_value?: number;
  services?: string[]; // ['04669','04162']
}

interface ShippingOption {
  code: string;
  name: string;
  price: number;
  min_days: number;
  max_days: number;
  error?: string;
}

// Mapa de códigos Correios
const SERVICE_NAMES: Record<string, string> = {
  '04669': 'PAC',
  '04510': 'PAC (contrato)',
  '04162': 'SEDEX',
  '04014': 'SEDEX (contrato)',
  '04790': 'SEDEX 10',
  '04804': 'SEDEX Hoje',
  '04693': 'PAC Mini',
};

function cleanCep(cep: string): string {
  return cep.replace(/\D/g, '');
}

async function fetchCorreios(params: ShippingRequest, services: string[]): Promise<ShippingOption[]> {
  const cepO = cleanCep(params.cep_origin);
  const cepD = cleanCep(params.cep_destiny);

  if (cepO.length !== 8 || cepD.length !== 8) {
    throw new Error('CEP inválido');
  }

  const weight = Math.max(0.1, params.weight_kg);
  const servicesCsv = services.join(',');
  const declaredValue = params.declared_value || 0;

  const url = new URL('https://ws.correios.com.br/calculador/CalcPrecoPrazo.aspx');
  url.searchParams.set('nCdEmpresa', '');
  url.searchParams.set('sDsSenha', '');
  url.searchParams.set('nCdServico', servicesCsv);
  url.searchParams.set('sCepOrigem', cepO);
  url.searchParams.set('sCepDestino', cepD);
  url.searchParams.set('nVlPeso', String(weight));
  url.searchParams.set('nCdFormato', '1'); // 1=caixa
  url.searchParams.set('nVlComprimento', String(params.length_cm));
  url.searchParams.set('nVlAltura', String(params.height_cm));
  url.searchParams.set('nVlLargura', String(params.width_cm));
  url.searchParams.set('nVlDiametro', '0');
  url.searchParams.set('sCdMaoPropria', 'N');
  url.searchParams.set('nVlValorDeclarado', String(declaredValue));
  url.searchParams.set('sCdAvisoRecebimento', 'N');
  url.searchParams.set('StrRetorno', 'xml');
  url.searchParams.set('nIndicaCalculo', '3');

  const response = await fetch(url.toString(), {
    headers: { 'User-Agent': 'Mozilla/5.0' },
    signal: AbortSignal.timeout(10000),
  });

  if (!response.ok) throw new Error(`Correios respondeu ${response.status}`);
  const xml = await response.text();

  // Parse XML com regex (sem DOMParser no Deno edge)
  const results: ShippingOption[] = [];
  const serviceBlocks = xml.match(/<cServico>[\s\S]*?<\/cServico>/g) || [];

  for (const block of serviceBlocks) {
    const get = (tag: string) => {
      const m = block.match(new RegExp(`<${tag}>([^<]*)</${tag}>`));
      return m ? m[1].trim() : '';
    };

    const code = get('Codigo');
    const errCode = get('Erro');
    const errMsg = get('MsgErro');
    const priceStr = get('Valor').replace('.', '').replace(',', '.');
    const price = parseFloat(priceStr) || 0;
    const prazo = parseInt(get('PrazoEntrega') || '0', 10);

    if (errCode && errCode !== '0' && errCode !== '') {
      results.push({
        code,
        name: SERVICE_NAMES[code] || code,
        price: 0,
        min_days: 0,
        max_days: 0,
        error: errMsg || `Erro ${errCode}`,
      });
      continue;
    }

    const days = prazo > 0 ? prazo : (code === '04162' ? 3 : 8);
    results.push({
      code,
      name: SERVICE_NAMES[code] || code,
      price,
      min_days: days > 1 ? days - 1 : 1,
      max_days: days + 1,
    });
  }

  return results;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: CORS });

  try {
    const body: ShippingRequest = await req.json();

    if (!body.cep_origin || !body.cep_destiny) {
      return new Response(JSON.stringify({ error: 'CEP origem e destino são obrigatórios' }), {
        status: 400,
        headers: { ...CORS, 'Content-Type': 'application/json' },
      });
    }

    const services = body.services?.length ? body.services : ['04669', '04162'];
    const options = await fetchCorreios(body, services);

    return new Response(JSON.stringify({ options }), {
      headers: { ...CORS, 'Content-Type': 'application/json' },
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Erro interno';
    return new Response(JSON.stringify({ error: msg }), {
      status: 500,
      headers: { ...CORS, 'Content-Type': 'application/json' },
    });
  }
});
