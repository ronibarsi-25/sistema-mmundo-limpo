import { createClient } from "jsr:@supabase/supabase-js@2";
import Stripe from "npm:stripe@19.1.0";

const supabaseUrl = Deno.env.get("SUPABASE_URL");
const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
const supabase = createClient(supabaseUrl!, supabaseKey!);

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

function ok(data: unknown): Response {
  return new Response(JSON.stringify({ code: "SUCCESS", message: "ok", data }), {
    status: 200,
    headers: { "Content-Type": "application/json", ...corsHeaders },
  });
}

function fail(msg: string, code = 400): Response {
  return new Response(JSON.stringify({ code: "FAIL", message: msg }), {
    status: code,
    headers: { "Content-Type": "application/json", ...corsHeaders },
  });
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });

  try {
    const body = await req.json();
    const { items, delivery_type, delivery_address, freight_amount: inputFreight = 0, customer_name, customer_phone, coupon: inputCoupon } = body;

    if (!items?.length) throw new Error("Itens não podem ser vazios");

    const authHeader = req.headers.get("Authorization");
    const token = authHeader?.replace("Bearer ", "");
    const { data: { user } } = token
      ? await supabase.auth.getUser(token)
      : { data: { user: null } };

    const stripeSecretKey = Deno.env.get("STRIPE_SECRET_KEY");
    if (!stripeSecretKey) throw new Error("STRIPE_SECRET_KEY não configurado. Configure em Supabase > Project Settings > Edge Functions > Secrets.");

    const stripe = new Stripe(stripeSecretKey, { apiVersion: "2025-08-27.basil" });

    // Validate products server-side
    const productIds = items.map((i: { id: string }) => i.id);
    const { data: products, error: prodError } = await supabase
      .from("products")
      .select("id, name, price, stock_quantity, is_available, images")
      .in("id", productIds);

    if (prodError) throw new Error("Erro ao validar produtos");

    const lineItems: Stripe.Checkout.SessionCreateParams.LineItem[] = [];
    const validatedItems: unknown[] = [];
    let subtotal = 0;

    for (const item of items) {
      const product = products?.find((p) => p.id === item.id);
      if (!product) throw new Error(`Produto não encontrado: ${item.id}`);
      if (!product.is_available) throw new Error(`Produto indisponível: ${product.name}`);
      if (product.stock_quantity < item.quantity) throw new Error(`Estoque insuficiente para: ${product.name}`);

      const unitPrice = Math.round(product.price * 100);
      subtotal += product.price * item.quantity;
      const imageUrl = product.images?.[0]?.url;

      lineItems.push({
        price_data: {
          currency: "brl",
          product_data: {
            name: product.name,
            images: imageUrl && imageUrl.startsWith("http") ? [imageUrl] : [],
          },
          unit_amount: unitPrice,
        },
        quantity: item.quantity,
      });

      validatedItems.push({
        id: product.id,
        name: product.name,
        price: product.price,
        quantity: item.quantity,
        image_url: imageUrl || "",
      });
    }

    // Processa cupom de desconto
    let freightAmount = inputFreight;
    let couponId: string | null = null;
    let discountAmount = 0;
    const stripeDiscounts: { coupon: string }[] = [];

    let couponUsedCount = 0;
    if (inputCoupon?.id) {
      const { data: coupon } = await supabase
        .from("coupons")
        .select("*")
        .eq("id", inputCoupon.id)
        .maybeSingle();

      if (coupon) {
        const now = new Date();
        const isActive = coupon.is_active;
        const started = new Date(coupon.starts_at) <= now;
        const notExpired = !coupon.ends_at || new Date(coupon.ends_at) >= now;
        const hasUsesLeft = coupon.max_uses === null || coupon.used_count < coupon.max_uses;
        const meetsMin = coupon.min_order_value === 0 || subtotal >= coupon.min_order_value;

        let perUserUses = 0;
        if (coupon.max_uses_per_user !== null && user) {
          const { count } = await supabase
            .from("coupon_usages")
            .select("*", { count: "exact", head: true })
            .eq("coupon_id", coupon.id)
            .eq("user_id", user.id);
          perUserUses = count || 0;
        }
        const withinPerUserLimit = coupon.max_uses_per_user === null || perUserUses < coupon.max_uses_per_user;

        if (isActive && started && notExpired && hasUsesLeft && meetsMin && withinPerUserLimit) {
          couponId = coupon.id;
          couponUsedCount = coupon.used_count;

          if (coupon.discount_type === "free_shipping") {
            discountAmount = freightAmount;
            freightAmount = 0;
          } else if (coupon.discount_type === "percent") {
            discountAmount = Math.round((subtotal * coupon.discount_value / 100) * 100) / 100;
            const stripeCoupon = await stripe.coupons.create({
              percent_off: coupon.discount_value,
              duration: "once",
              name: `Cupom ${coupon.code}`,
            });
            stripeDiscounts.push({ coupon: stripeCoupon.id });
          } else if (coupon.discount_type === "fixed") {
            discountAmount = Math.min(coupon.discount_value, subtotal);
            const stripeCoupon = await stripe.coupons.create({
              amount_off: Math.round(discountAmount * 100),
              currency: "brl",
              duration: "once",
              name: `Cupom ${coupon.code}`,
            });
            stripeDiscounts.push({ coupon: stripeCoupon.id });
          }
        }
      }
    }

    const freightCents = Math.round(freightAmount * 100);
    if (freightCents > 0) {
      lineItems.push({
        price_data: {
          currency: "brl",
          product_data: { name: "Frete" },
          unit_amount: freightCents,
        },
        quantity: 1,
      });
    }

    const totalAmount = Math.max(0, subtotal + freightAmount - discountAmount);

    const { data: order, error: orderError } = await supabase
      .from("orders")
      .insert({
        user_id: user?.id || null,
        items: validatedItems,
        subtotal,
        freight_amount: freightAmount,
        discount_amount: discountAmount,
        total_amount: totalAmount,
        currency: "brl",
        status: "pending",
        delivery_type: delivery_type || "delivery",
        delivery_address: delivery_address || null,
        payment_method: "card",
        customer_email: user?.email || null,
        customer_name: customer_name || user?.user_metadata?.full_name || null,
        customer_phone: customer_phone || null,
        coupon_id: couponId,
      })
      .select()
      .single();

    if (orderError) throw new Error(`Erro ao criar pedido: ${orderError.message}`);

    const origin = req.headers.get("origin") || "";
    const sessionPayload: Stripe.Checkout.SessionCreateParams = {
      line_items: lineItems,
      mode: "payment",
      success_url: `${origin}/pagamento-sucesso?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${origin}/carrinho`,
      payment_method_types: ["card"],
      locale: "pt-BR",
      metadata: { order_id: order.id, user_id: user?.id || "" },
    };

    if (stripeDiscounts.length > 0) {
      sessionPayload.discounts = stripeDiscounts;
    }

    const session = await stripe.checkout.sessions.create(sessionPayload);

    await supabase.from("orders").update({
      stripe_session_id: session.id,
      stripe_payment_intent_id: session.payment_intent as string,
    }).eq("id", order.id);

    // Registrar uso do cupom
    if (couponId) {
      await supabase.from("coupon_usages").insert({
        coupon_id: couponId,
        order_id: order.id,
        user_id: user?.id || null,
        discount_applied: discountAmount,
      });
      await supabase.from("coupons").update({ used_count: couponUsedCount + 1 }).eq("id", couponId);
    }

    return ok({ url: session.url, sessionId: session.id, orderId: order.id });
  } catch (error) {
    console.error("create_stripe_checkout error:", error);
    return fail(error instanceof Error ? error.message : "Erro no processamento do pagamento", 500);
  }
});
