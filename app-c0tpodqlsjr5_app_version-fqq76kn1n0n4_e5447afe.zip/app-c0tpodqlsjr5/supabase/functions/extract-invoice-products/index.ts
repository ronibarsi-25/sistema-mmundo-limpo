import { createClient } from "jsr:@supabase/supabase-js@2";
import { encodeBase64 } from "jsr:@std/encoding/base64";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

function ok(data: unknown): Response {
  return new Response(JSON.stringify({ code: "SUCCESS", data }), {
    status: 200,
    headers: { "Content-Type": "application/json", ...corsHeaders },
  });
}

function fail(msg: string, code = 400): Response {
  return new Response(JSON.stringify({ code: "FAIL", message: msg }), {
    status: code,
    headers: { "Content-Type": "application/json", ...corsHeaders },
  });
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });

  try {
    const body = await req.json();
    const { filePath, pdfUrl, defaultMarkup = 50 } = body;

    if (!filePath && !pdfUrl) {
      return fail("Informe filePath ou pdfUrl");
    }

    // --- 1. Gerar URL assinada do storage ---
    let finalUrl = pdfUrl;
    if (filePath) {
      const supabaseUrl = Deno.env.get("SUPABASE_URL");
      const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
      const supabase = createClient(supabaseUrl!, supabaseKey!);
      const { data } = await supabase.storage.from("invoices").createSignedUrl(filePath, 600);
      if (!data?.signedUrl) {
        return fail("Não foi possível gerar URL assinada para o PDF");
      }
      finalUrl = data.signedUrl;
    }

    // --- 2. Baixar o PDF ---
    let pdfBuffer: ArrayBuffer;
    try {
      const pdfRes = await fetch(finalUrl);
      if (!pdfRes.ok) throw new Error(`HTTP ${pdfRes.status}`);
      pdfBuffer = await pdfRes.arrayBuffer();
    } catch (e) {
      return fail(`Erro ao acessar o arquivo PDF: ${e instanceof Error ? e.message : String(e)}`);
    }

    const pdfBase64 = encodeBase64(pdfBuffer);

    // --- 3. Chamar Gemini via generateContent (não-streaming) ---
    const apiKey = Deno.env.get("INTEGRATIONS_API_KEY");
    if (!apiKey) return fail("API key não configurada", 500);

    const prompt = `Você é um assistente especialista em notas fiscais brasileiras.
Analise o PDF em anexo e extraia APENAS os produtos/itens da nota fiscal.
Retorne SOMENTE um JSON array válido, sem markdown, sem texto extra, sem explicação.
Formato obrigatório: [{"code":"str","name":"str","unit":"str","quantity":number,"cost_price":number,"sale_price":number,"barcode":null}]
- "code": código do produto (string, pode ser vazio)
- "name": nome do produto
- "unit": unidade (UN, KG, L, CX, etc)
- "quantity": quantidade numérica
- "cost_price": preço unitário de custo (valor da nota)
- "sale_price": preço de venda sugerido com markup de ${defaultMarkup}% sobre cost_price
- "barcode": código de barras (null se não houver)
Se não encontrar produtos, retorne um array vazio: []`;

    const models = ["gemini-2.5-flash", "gemini-1.5-flash"];
    let fullText = "";
    let lastError = "";

    for (const model of models) {
      // Tenta até 3 vezes com backoff para lidar com rate limit passageiro
      for (let attempt = 1; attempt <= 3; attempt++) {
        try {
          const llmRes = await fetch(
            `https://app-c0tpodqlsjr5-api-VaOwP8E7dJqa.gateway.appmedo.com/v1beta/models/${model}:generateContent`,
            {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
                "X-Gateway-Authorization": `Bearer ${apiKey}`,
              },
              body: JSON.stringify({
                contents: [{
                  role: "user",
                  parts: [
                    { text: prompt },
                    { inlineData: { mimeType: "application/pdf", data: pdfBase64 } }
                  ]
                }],
                generationConfig: { maxOutputTokens: 4096, temperature: 0.1 }
              }),
            }
          );

          if (!llmRes.ok) {
            const errText = await llmRes.text();
            if (llmRes.status === 429) {
              if (attempt < 3) {
                // Aguarda antes de tentar novamente (2s, 4s)
                await new Promise(r => setTimeout(r, attempt * 2000));
                continue;
              }
              return fail("Limite de requisições da IA atingido. Aguarde alguns segundos e tente novamente.", 429);
            }
            lastError = `${model} HTTP ${llmRes.status}: ${errText.slice(0, 200)}`;
            console.error(lastError);
            break; // tenta próximo modelo
          }

          const llmData = await llmRes.json();
          const text = llmData?.candidates?.[0]?.content?.parts?.[0]?.text;
          if (text) { fullText = text; break; }
          lastError = `${model}: resposta sem texto`;
          break;
        } catch (e) {
          lastError = `${model} erro: ${e instanceof Error ? e.message : String(e)}`;
          console.error(lastError);
          break;
        }
      }
      if (fullText) break;
    }

    if (!fullText) {
      return fail(`Erro ao processar com IA: ${lastError}`, 500);
    }

    // --- 4. Extrair JSON da resposta ---
    let products: unknown[] = [];
    try {
      const cleaned = fullText.replace(/```json\s*/gi, "").replace(/```\s*/gi, "").trim();
      const jsonMatch = cleaned.match(/\[[\s\S]*\]/);
      products = JSON.parse(jsonMatch ? jsonMatch[0] : cleaned);
    } catch {
      console.error("Falha ao parsear JSON:", fullText.slice(0, 500));
      return fail("Não foi possível interpretar a resposta da IA. Verifique a qualidade do PDF.", 500);
    }

    if (!Array.isArray(products)) {
      return fail("Resposta da IA não contém uma lista de produtos válida.", 500);
    }

    const normalized = (products as any[]).map((p) => ({
      code: String(p.code || ""),
      name: String(p.name || ""),
      unit: String(p.unit || "UN"),
      quantity: Number(p.quantity) || 1,
      cost_price: Number(p.cost_price) || 0,
      sale_price: Number(p.sale_price) || 0,
      barcode: p.barcode || null,
    }));

    return ok({
      products: normalized,
      extractedTextPreview: "(Extraído via Gemini Multimodal)",
      totalProducts: normalized.length,
    });

  } catch (error) {
    console.error("extract-invoice-products error:", error);
    return fail(error instanceof Error ? error.message : "Erro inesperado no processamento", 500);
  }
});
