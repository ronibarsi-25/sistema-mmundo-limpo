import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.8';

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, OPTIONS',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

function escapeXml(str: string): string {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: CORS });
  }

  const url = new URL(req.url);
  const format = url.searchParams.get('format') || 'xml';

  const supabaseUrl = Deno.env.get('SUPABASE_URL') || '';
  const supabaseKey = Deno.env.get('SUPABASE_ANON_KEY') || Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || '';
  const supabase = createClient(supabaseUrl, supabaseKey);

  const { data: onlineProducts } = await supabase
    .from('products')
    .select('id, name, slug, description, price, stock_quantity, is_available, images, barcode')
    .eq('is_available', true);

  const { data: pdvList } = await supabase
    .from('pdv_products')
    .select('name, code, barcode, site_product_id');

  const barcodeBySiteId = new Map<string, string>();
  const barcodeByName = new Map<string, string>();
  pdvList?.forEach((p: any) => {
    if (p.barcode?.trim()) {
      if (p.site_product_id) barcodeBySiteId.set(p.site_product_id, p.barcode.trim());
      barcodeByName.set(p.name.trim().toLowerCase(), p.barcode.trim());
    }
  });

  const origin = 'https://mundolimpo.store';
  const items = (onlineProducts || []).map((p: any) => {
    const barcode = (p.barcode || '').trim() || barcodeBySiteId.get(p.id) || barcodeByName.get(p.name.trim().toLowerCase()) || '';
    const filename = `${p.slug || p.id}.jpg`;
    const imgUrl = `${origin}/uploads/produtos/${filename}`;
    const link = `${origin}/produto/${p.slug || p.id}`;
    const priceFormatted = `${Number(p.price || 0).toFixed(2)} BRL`;

    return {
      id: p.id,
      title: p.name,
      description: p.description || p.name,
      availability: (p.stock_quantity || 0) > 0 ? 'in stock' : 'out of stock',
      condition: 'new',
      price: priceFormatted,
      link,
      image_link: imgUrl,
      brand: 'Mundo Limpo',
      gtin: barcode,
    };
  });

  if (format === 'csv') {
    const escapeCsv = (val: any) => {
      if (!val) return '""';
      return `"${String(val).replace(/"/g, '""')}"`;
    };
    const headers = ['id','title','description','availability','condition','price','link','image_link','brand','gtin','fb_product_category'];
    const rows = items.map((item: any) => [
      escapeCsv(item.id),
      escapeCsv(item.title),
      escapeCsv(item.description || item.title),
      escapeCsv(item.availability),
      escapeCsv(item.condition || 'new'),
      escapeCsv(item.price),
      escapeCsv(item.link),
      escapeCsv(item.image_link),
      escapeCsv(item.brand || 'Mundo Limpo'),
      escapeCsv(item.gtin || ''),
      escapeCsv('Health & Beauty > Personal Care')
    ].join(','));

    return new Response([headers.join(','), ...rows].join('\n'), {
      headers: {
        ...CORS,
        'Content-Type': 'text/csv; charset=utf-8',
        'Cache-Control': 'public, max-age=300',
      },
    });
  }

  // XML RSS 2.0
  const itemsXml = items.map((item: any) => {
    return `    <item>
      <g:id>${escapeXml(item.id)}</g:id>
      <g:title>${escapeXml(item.title)}</g:title>
      <g:description>${escapeXml(item.description || item.title)}</g:description>
      <g:link>${escapeXml(item.link)}</g:link>
      <g:image_link>${escapeXml(item.image_link)}</g:image_link>
      <g:brand>${escapeXml(item.brand || 'Mundo Limpo')}</g:brand>
      <g:condition>${item.condition}</g:condition>
      <g:availability>${item.availability}</g:availability>
      <g:price>${escapeXml(item.price)}</g:price>
${item.gtin ? `      <g:gtin>${escapeXml(item.gtin)}</g:gtin>\n` : '      <g:identifier_exists>no</g:identifier_exists>\n'}      <g:fb_product_category>Health &amp; Beauty &gt; Personal Care</g:fb_product_category>
    </item>`;
  }).join('\n');

  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<rss xmlns:g="http://base.google.com/ns/1.0" version="2.0">
  <channel>
    <title>Mundo Limpo</title>
    <link>${origin}</link>
    <description>Catálogo oficial de produtos Mundo Limpo para Facebook e Instagram Shopping</description>
${itemsXml}
  </channel>
</rss>`;

  return new Response(xml, {
    headers: {
      ...CORS,
      'Content-Type': 'application/xml; charset=utf-8',
      'Cache-Control': 'public, max-age=300',
    },
  });
});
