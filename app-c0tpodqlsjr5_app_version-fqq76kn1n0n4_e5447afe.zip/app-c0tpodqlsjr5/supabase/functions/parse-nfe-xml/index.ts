import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { corsHeaders } from "../_shared/cors.ts";

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const formData = await req.formData();
    const file = formData.get('file');

    if (!file || !(file instanceof File)) {
      return new Response(JSON.stringify({ error: 'Nenhum arquivo XML recebido' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const xmlText = await file.text();
    
    // Very basic regex-based XML parsing to avoid large dependencies in Edge Function
    // Extracts elements inside <det> which represent items in NFe
    const items: any[] = [];
    
    // Find all <det> blocks
    const detRegex = /<det nItem="([^"]+)">([\s\S]*?)<\/det>/g;
    let detMatch;
    
    while ((detMatch = detRegex.exec(xmlText)) !== null) {
      const itemXml = detMatch[2];
      
      // Extract fields
      const extractField = (regex: RegExp) => {
        const match = regex.exec(itemXml);
        return match ? match[1] : '';
      };
      
      const cProd = extractField(/<cProd>([^<]+)<\/cProd>/);
      const xProd = extractField(/<xProd>([^<]+)<\/xProd>/);
      const uCom = extractField(/<uCom>([^<]+)<\/uCom>/);
      const qCom = extractField(/<qCom>([^<]+)<\/qCom>/);
      const vUnCom = extractField(/<vUnCom>([^<]+)<\/vUnCom>/);
      const cEAN = extractField(/<cEAN>([^<]+)<\/cEAN>/);
      
      if (cProd && xProd) {
        items.push({
          code: cProd,
          name: xProd,
          description: null,
          unit: uCom || 'UN',
          cost_price: parseFloat(vUnCom) || 0,
          quantity: parseFloat(qCom) || 0,
          barcode: (cEAN && cEAN !== 'SEM GTIN') ? cEAN : null
        });
      }
    }
    
    // Extrair info geral da nota (NF-e)
    const nNF = /<nNF>([^<]+)<\/nNF>/.exec(xmlText)?.[1] || '';
    const serie = /<serie>([^<]+)<\/serie>/.exec(xmlText)?.[1] || '';
    const dhEmi = /<dhEmi>([^<]+)<\/dhEmi>/.exec(xmlText)?.[1] || '';
    const emitNome = /<emit>[\s\S]*?<xNome>([^<]+)<\/xNome>/.exec(xmlText)?.[1] || '';
    const emitCNPJ = /<emit>[\s\S]*?<CNPJ>([^<]+)<\/CNPJ>/.exec(xmlText)?.[1] || '';
    const destNome = /<dest>[\s\S]*?<xNome>([^<]+)<\/xNome>/.exec(xmlText)?.[1] || '';
    const destCNPJ = /<dest>[\s\S]*?<CNPJ>([^<]+)<\/CNPJ>/.exec(xmlText)?.[1] || '';
    const vNF = /<ICMSTot>[\s\S]*?<vNF>([^<]+)<\/vNF>/.exec(xmlText)?.[1] || '0';

    return new Response(JSON.stringify({ 
      code: "SUCCESS",
      data: {
        products: items,
        invoiceInfo: {
          numero: nNF,
          serie,
          dataEmissao: dhEmi,
          emitenteNome: emitNome,
          emitenteCnpj: emitCNPJ,
          destinatarioNome: destNome,
          destinatarioCnpj: destCNPJ,
          valorTotal: vNF
        }
      }
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 200,
    });
  } catch (error) {
    return new Response(JSON.stringify({ code: "FAIL", message: error.message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
