import { createClient } from "jsr:@supabase/supabase-js@2";
import Stripe from "npm:stripe@19.1.0";

const supabaseUrl = Deno.env.get("SUPABASE_URL");
const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
const supabase = createClient(supabaseUrl!, supabaseKey!);

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

function ok(data: unknown): Response {
  return new Response(JSON.stringify({ code: "SUCCESS", message: "ok", data }), {
    status: 200,
    headers: { "Content-Type": "application/json", ...corsHeaders },
  });
}

function fail(msg: string, code = 400): Response {
  return new Response(JSON.stringify({ code: "FAIL", message: msg }), {
    status: code,
    headers: { "Content-Type": "application/json", ...corsHeaders },
  });
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { sessionId } = await req.json();
    if (!sessionId) throw new Error("Parâmetro session_id não encontrado");

    const stripeSecretKey = Deno.env.get("STRIPE_SECRET_KEY");
    if (!stripeSecretKey) throw new Error("STRIPE_SECRET_KEY não configurado");

    const stripe = new Stripe(stripeSecretKey, { apiVersion: "2025-08-27.basil" });
    const session = await stripe.checkout.sessions.retrieve(sessionId);

    if (session.payment_status !== "paid") {
      return ok({ verified: false, status: session.payment_status, sessionId: session.id });
    }

    const { data: order, error: fetchError } = await supabase
      .from("orders")
      .select("id, status, order_number")
      .eq("stripe_session_id", sessionId)
      .maybeSingle();

    if (fetchError || !order) {
      return ok({ verified: true, status: "paid", orderUpdated: false, sessionId: session.id });
    }

    if (order.status === "completed") {
      return ok({ verified: true, status: "paid", orderUpdated: true, orderId: order.id, orderNumber: order.order_number });
    }

    const { error: updateError } = await supabase
      .from("orders")
      .update({
        status: "completed",
        completed_at: new Date().toISOString(),
        customer_email: session.customer_details?.email,
        customer_name: session.customer_details?.name,
        stripe_payment_intent_id: session.payment_intent as string,
      })
      .eq("id", order.id)
      .eq("status", "pending");

    if (updateError) {
      console.error("Erro ao atualizar pedido:", updateError);
    }

    return ok({
      verified: true,
      status: "paid",
      sessionId: session.id,
      orderId: order.id,
      orderNumber: order.order_number,
      amount: session.amount_total,
      currency: session.currency,
      customerEmail: session.customer_details?.email,
      customerName: session.customer_details?.name,
      orderUpdated: !updateError,
    });
  } catch (error) {
    console.error("verify_stripe_payment error:", error);
    return fail(error instanceof Error ? error.message : "Erro na verificação do pagamento", 500);
  }
});
