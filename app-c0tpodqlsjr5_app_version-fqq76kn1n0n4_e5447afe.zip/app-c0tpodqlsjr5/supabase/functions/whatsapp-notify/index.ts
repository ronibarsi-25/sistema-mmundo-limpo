import { createClient } from "jsr:@supabase/supabase-js@2";

const supabaseUrl = Deno.env.get("SUPABASE_URL");
const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
const supabase = createClient(supabaseUrl!, supabaseKey!);

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

function ok(data: unknown): Response {
  return new Response(JSON.stringify({ code: "SUCCESS", message: "ok", data }), {
    status: 200,
    headers: { "Content-Type": "application/json", ...corsHeaders },
  });
}

function fail(msg: string, code = 400): Response {
  return new Response(JSON.stringify({ code: "FAIL", message: msg }), {
    status: code,
    headers: { "Content-Type": "application/json", ...corsHeaders },
  });
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });

  try {
    const body = await req.json();
    const { order_id } = body;
    if (!order_id) return fail("order_id é obrigatório");

    // Buscar configurações de notificação
    const { data: config, error: configError } = await supabase
      .from("notification_settings")
      .select("*")
      .limit(1)
      .maybeSingle();

    if (configError || !config || !config.whatsapp_enabled) {
      return ok({ sent: false, reason: "Notificações WhatsApp desativadas ou não configuradas" });
    }

    // Buscar pedido
    const { data: order, error: orderError } = await supabase
      .from("orders")
      .select("order_number, total_amount, status, customer_name")
      .eq("id", order_id)
      .maybeSingle();

    if (orderError || !order) {
      return fail("Pedido não encontrado");
    }

    // Montar mensagem
    let message = config.message_template || "Novo pedido #{order_number}";
    message = message
      .replace(/{order_number}/g, order.order_number || "")
      .replace(/{total}/g, (order.total_amount || 0).toLocaleString("pt-BR", { style: "currency", currency: "BRL" }))
      .replace(/{customer_name}/g, order.customer_name || "Cliente")
      .replace(/{status}/g, order.status || "pendente");

    const phone = config.whatsapp_number?.replace(/\D/g, "");
    if (!phone) {
      return ok({ sent: false, reason: "Número de WhatsApp não configurado" });
    }

    let sent = false;
    let providerResponse: unknown = null;

    // Provider: CallMeBot (API gratuita)
    if (config.whatsapp_provider === "callmebot" && config.whatsapp_api_key) {
      const url = `https://api.callmebot.com/whatsapp.php?phone=${encodeURIComponent(phone)}&text=${encodeURIComponent(message)}&apikey=${encodeURIComponent(config.whatsapp_api_key)}`;
      const resp = await fetch(url, { method: "GET" });
      providerResponse = await resp.text();
      sent = resp.ok;
    }
    // Provider: webhook genérico
    else if (config.whatsapp_provider === "webhook" && config.whatsapp_webhook_url) {
      const resp = await fetch(config.whatsapp_webhook_url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone, message, order }),
      });
      providerResponse = await resp.text().catch(() => null);
      sent = resp.ok;
    }
    // Fallback: CallMeBot sem apikey não envia
    else {
      return ok({ sent: false, reason: "Provider não configurado corretamente" });
    }

    return ok({ sent, provider: config.whatsapp_provider, providerResponse, message });
  } catch (error) {
    console.error("whatsapp-notify error:", error);
    return fail(error instanceof Error ? error.message : "Erro ao enviar notificação WhatsApp", 500);
  }
});
