
-- Enable RLS
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.wishlist ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.stock_movements ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.store_settings ENABLE ROW LEVEL SECURITY;

-- Helper function for role checking
CREATE OR REPLACE FUNCTION get_user_role(uid uuid)
RETURNS public.user_role
LANGUAGE sql SECURITY DEFINER SET search_path = public
AS $$ SELECT role FROM profiles WHERE id = uid; $$;

-- Profiles policies
CREATE POLICY "Admins full access profiles" ON public.profiles
  FOR ALL TO authenticated USING (get_user_role(auth.uid()) = 'admin'::public.user_role);

CREATE POLICY "Users view own profile" ON public.profiles
  FOR SELECT TO authenticated USING (auth.uid() = id);

CREATE POLICY "Users update own profile" ON public.profiles
  FOR UPDATE TO authenticated USING (auth.uid() = id)
  WITH CHECK (role IS NOT DISTINCT FROM get_user_role(auth.uid()));

-- Public profiles view
CREATE VIEW public.public_profiles AS SELECT id, role, full_name, avatar_url FROM public.profiles;

-- Products policies
CREATE POLICY "Anyone can view available products" ON public.products
  FOR SELECT USING (is_available = true OR get_user_role(auth.uid()) = 'admin'::public.user_role);

CREATE POLICY "Admins manage products" ON public.products
  FOR ALL TO authenticated USING (get_user_role(auth.uid()) = 'admin'::public.user_role);

-- Categories policies
CREATE POLICY "Anyone can view active categories" ON public.categories
  FOR SELECT USING (is_active = true OR get_user_role(auth.uid()) = 'admin'::public.user_role);

CREATE POLICY "Admins manage categories" ON public.categories
  FOR ALL TO authenticated USING (get_user_role(auth.uid()) = 'admin'::public.user_role);

-- Orders policies
CREATE POLICY "Users view own orders" ON public.orders
  FOR SELECT TO authenticated USING (auth.uid() = user_id OR get_user_role(auth.uid()) = 'admin'::public.user_role);

CREATE POLICY "Users insert own orders" ON public.orders
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins update orders" ON public.orders
  FOR UPDATE TO authenticated USING (get_user_role(auth.uid()) = 'admin'::public.user_role);

CREATE POLICY "Service role manage orders" ON public.orders
  FOR ALL USING (auth.jwt()->>'role' = 'service_role');

-- Wishlist policies
CREATE POLICY "Users manage own wishlist" ON public.wishlist
  FOR ALL TO authenticated USING (auth.uid() = user_id);

-- Chat messages policies
CREATE POLICY "Users view own conversations" ON public.chat_messages
  FOR SELECT TO authenticated USING (
    user_id = auth.uid() OR
    get_user_role(auth.uid()) = 'admin'::public.user_role
  );

CREATE POLICY "Users insert messages" ON public.chat_messages
  FOR INSERT TO authenticated WITH CHECK (
    user_id = auth.uid() OR
    get_user_role(auth.uid()) = 'admin'::public.user_role
  );

CREATE POLICY "Admins update chat messages" ON public.chat_messages
  FOR UPDATE TO authenticated USING (get_user_role(auth.uid()) = 'admin'::public.user_role);

-- Stock movements policies
CREATE POLICY "Admins manage stock movements" ON public.stock_movements
  FOR ALL TO authenticated USING (get_user_role(auth.uid()) = 'admin'::public.user_role);

CREATE POLICY "Service role manage stock" ON public.stock_movements
  FOR ALL USING (auth.jwt()->>'role' = 'service_role');

-- Store settings policies
CREATE POLICY "Anyone can view store settings" ON public.store_settings
  FOR SELECT USING (true);

CREATE POLICY "Admins manage store settings" ON public.store_settings
  FOR ALL TO authenticated USING (get_user_role(auth.uid()) = 'admin'::public.user_role);
