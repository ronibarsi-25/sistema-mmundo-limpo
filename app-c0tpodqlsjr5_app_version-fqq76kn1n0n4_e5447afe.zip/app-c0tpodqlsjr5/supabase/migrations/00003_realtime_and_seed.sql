
-- Enable realtime for chat and orders
ALTER PUBLICATION supabase_realtime ADD TABLE public.chat_messages;
ALTER PUBLICATION supabase_realtime ADD TABLE public.orders;

-- Seed categories
INSERT INTO public.categories (name, slug, description, is_active) VALUES
  ('Eletrônicos', 'eletronicos', 'Smartphones, notebooks, tablets e acessórios', true),
  ('Moda', 'moda', 'Roupas, calçados e acessórios de moda', true),
  ('Casa e Decoração', 'casa-decoracao', 'Móveis, decoração e utilidades domésticas', true),
  ('Esportes', 'esportes', 'Equipamentos e roupas esportivas', true),
  ('Alimentos', 'alimentos', 'Alimentos naturais, orgânicos e especiais', true),
  ('Beleza', 'beleza', 'Cosméticos, perfumes e cuidados pessoais', true);

-- Seed sample products
INSERT INTO public.products (name, slug, description, price, compare_at_price, category_id, images, stock_quantity, is_available, is_featured, attributes)
SELECT
  'Smartphone Premium X12', 'smartphone-premium-x12',
  'Smartphone de última geração com câmera de 108MP, bateria de 5000mAh e tela AMOLED 6.7"',
  1899.90, 2199.90, id,
  '[{"url":"placeholder-smartphone.jpg","alt":"Smartphone Premium X12"}]'::jsonb,
  25, true, true,
  '{"cor":"Preto","armazenamento":"128GB","memória":"8GB"}'::jsonb
FROM public.categories WHERE slug = 'eletronicos';

INSERT INTO public.products (name, slug, description, price, compare_at_price, category_id, images, stock_quantity, is_available, is_featured, attributes)
SELECT
  'Notebook UltraSlim Pro', 'notebook-ultraslim-pro',
  'Notebook ultrafino com processador Intel i7, 16GB RAM, SSD 512GB e tela Full HD',
  3499.90, 4199.90, id,
  '[{"url":"placeholder-notebook.jpg","alt":"Notebook UltraSlim Pro"}]'::jsonb,
  12, true, true,
  '{"processador":"Intel i7","ram":"16GB","armazenamento":"512GB SSD"}'::jsonb
FROM public.categories WHERE slug = 'eletronicos';

INSERT INTO public.products (name, slug, description, price, category_id, images, stock_quantity, is_available, is_featured, attributes)
SELECT
  'Tênis Running Performance', 'tenis-running-performance',
  'Tênis de corrida com amortecimento avançado, cabedal respirável e solado de alta durabilidade',
  289.90, id,
  '[{"url":"placeholder-tenis.jpg","alt":"Tênis Running Performance"}]'::jsonb,
  50, true, true,
  '{"material":"Mesh respirável","solado":"Borracha de alta durabilidade"}'::jsonb
FROM public.categories WHERE slug = 'esportes';

INSERT INTO public.products (name, slug, description, price, compare_at_price, category_id, images, stock_quantity, is_available, is_featured, attributes)
SELECT
  'Sofá Retrátil 3 Lugares', 'sofa-retratil-3-lugares',
  'Sofá retrátil e reclinável em suede, com espuma D33 e estrutura reforçada em madeira',
  1199.90, 1599.90, id,
  '[{"url":"placeholder-sofa.jpg","alt":"Sofá Retrátil 3 Lugares"}]'::jsonb,
  8, true, false,
  '{"tecido":"Suede","lugares":"3","cor":"Cinza"}'::jsonb
FROM public.categories WHERE slug = 'casa-decoracao';

INSERT INTO public.products (name, slug, description, price, category_id, images, stock_quantity, is_available, is_featured, attributes)
SELECT
  'Kit Skincare Completo', 'kit-skincare-completo',
  'Kit completo de cuidados com a pele: limpador facial, hidratante, sérum e protetor solar FPS50',
  189.90, id,
  '[{"url":"placeholder-skincare.jpg","alt":"Kit Skincare Completo"}]'::jsonb,
  35, true, true,
  '{"tipo":"Pele mista","volume":"4 produtos","fórmula":"Natural"}'::jsonb
FROM public.categories WHERE slug = 'beleza';

INSERT INTO public.products (name, slug, description, price, category_id, images, stock_quantity, is_available, is_featured, attributes)
SELECT
  'Vestido Floral Premium', 'vestido-floral-premium',
  'Vestido midi com estampa floral exclusiva, tecido viscose com caimento perfeito',
  159.90, id,
  '[{"url":"placeholder-vestido.jpg","alt":"Vestido Floral Premium"}]'::jsonb,
  3, true, false,
  '{"material":"Viscose","comprimento":"Midi","estampa":"Floral"}'::jsonb
FROM public.categories WHERE slug = 'moda';
