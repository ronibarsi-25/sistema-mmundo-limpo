
-- Add guest order support (allow anon insert)
CREATE POLICY "Anyone can create orders" ON public.orders
  FOR INSERT WITH CHECK (true);

-- Allow service role to do everything with orders
DROP POLICY IF EXISTS "Service role manage orders" ON public.orders;
CREATE POLICY "Service role all orders" ON public.orders
  FOR ALL USING (true) WITH CHECK (true);
