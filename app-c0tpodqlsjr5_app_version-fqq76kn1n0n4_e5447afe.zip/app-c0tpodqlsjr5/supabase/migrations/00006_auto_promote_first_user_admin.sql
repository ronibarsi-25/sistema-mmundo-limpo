
-- Function: promote first registered user to admin automatically
CREATE OR REPLACE FUNCTION promote_first_user_to_admin()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  -- If this is the very first profile, make them admin
  IF (SELECT COUNT(*) FROM public.profiles) = 1 THEN
    UPDATE public.profiles SET role = 'admin' WHERE id = NEW.id;
  END IF;
  RETURN NEW;
END;
$$;

-- Trigger: runs after each new profile insert
DROP TRIGGER IF EXISTS on_new_profile_promote_first_admin ON public.profiles;
CREATE TRIGGER on_new_profile_promote_first_admin
  AFTER INSERT ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION promote_first_user_to_admin();

-- RPC: allow a user to request admin promotion (only if NO admin exists yet)
CREATE OR REPLACE FUNCTION request_admin_access(user_email text)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE
  admin_count int;
  target_profile profiles%ROWTYPE;
BEGIN
  -- Check if any admin already exists
  SELECT COUNT(*) INTO admin_count FROM public.profiles WHERE role = 'admin';
  IF admin_count > 0 THEN
    RETURN jsonb_build_object('success', false, 'message', 'Já existe um administrador cadastrado.');
  END IF;

  -- Find user by email
  SELECT p.* INTO target_profile FROM public.profiles p
    JOIN auth.users u ON u.id = p.id
    WHERE u.email = user_email LIMIT 1;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'message', 'Usuário não encontrado.');
  END IF;

  -- Promote
  UPDATE public.profiles SET role = 'admin' WHERE id = target_profile.id;
  RETURN jsonb_build_object('success', true, 'message', 'Acesso admin concedido!');
END;
$$;
