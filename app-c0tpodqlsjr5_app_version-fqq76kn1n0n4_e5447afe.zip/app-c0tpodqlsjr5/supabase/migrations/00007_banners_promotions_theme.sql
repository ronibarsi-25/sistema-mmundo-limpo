
-- Tabela de banners
CREATE TABLE public.banners (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  subtitle text,
  image_url text NOT NULL,
  cta_text text DEFAULT 'Ver mais',
  cta_link text DEFAULT '/',
  sort_order int NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.banners ENABLE ROW LEVEL SECURITY;

CREATE POLICY "banners_public_read" ON public.banners FOR SELECT USING (true);
CREATE POLICY "banners_admin_all" ON public.banners FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'))
  WITH CHECK (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'));

-- Tabela de promoções
CREATE TABLE public.promotions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  discount_type text NOT NULL CHECK (discount_type IN ('percent', 'fixed')),
  discount_value numeric NOT NULL CHECK (discount_value > 0),
  starts_at timestamptz NOT NULL DEFAULT now(),
  ends_at timestamptz NOT NULL,
  scope text NOT NULL DEFAULT 'all' CHECK (scope IN ('all', 'categories', 'products')),
  scope_ids uuid[] DEFAULT '{}',
  banner_text text,
  banner_color text DEFAULT '#DC2626',
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT promotions_dates_check CHECK (ends_at > starts_at)
);

ALTER TABLE public.promotions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "promotions_public_read" ON public.promotions FOR SELECT USING (true);
CREATE POLICY "promotions_admin_all" ON public.promotions FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'))
  WITH CHECK (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'));

-- Tabela de configurações de tema
CREATE TABLE public.theme_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  primary_color text NOT NULL DEFAULT '#2563EB',
  secondary_color text NOT NULL DEFAULT '#7C3AED',
  accent_color text NOT NULL DEFAULT '#F59E0B',
  background_color text NOT NULL DEFAULT '#FAFAFA',
  preset_name text DEFAULT 'custom',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.theme_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "theme_public_read" ON public.theme_settings FOR SELECT USING (true);
CREATE POLICY "theme_admin_all" ON public.theme_settings FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'))
  WITH CHECK (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'));

-- Seed: tema padrão vibrante
INSERT INTO public.theme_settings (primary_color, secondary_color, accent_color, background_color, preset_name)
VALUES ('#2563EB', '#7C3AED', '#F59E0B', '#FAFAFA', 'azul-vibrante');

-- Seed: banners iniciais
INSERT INTO public.banners (title, subtitle, image_url, cta_text, cta_link, sort_order, is_active) VALUES
('Novidades em destaque', 'Confira os melhores produtos da temporada', 'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=1200&q=80', 'Ver Produtos', '/produtos', 0, true),
('Ofertas especiais', 'Descontos imperdíveis para você', 'https://images.unsplash.com/photo-1607082349566-187342175e2f?w=1200&q=80', 'Ver Ofertas', '/produtos', 1, true);

-- Realtime para banners e promotions
ALTER PUBLICATION supabase_realtime ADD TABLE public.banners;
ALTER PUBLICATION supabase_realtime ADD TABLE public.promotions;
ALTER PUBLICATION supabase_realtime ADD TABLE public.theme_settings;
