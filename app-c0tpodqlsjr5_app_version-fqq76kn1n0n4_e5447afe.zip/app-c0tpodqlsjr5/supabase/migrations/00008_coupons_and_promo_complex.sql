
-- Cupons de desconto
CREATE TABLE public.coupons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text UNIQUE NOT NULL,
  discount_type text NOT NULL CHECK (discount_type IN ('percent', 'fixed', 'free_shipping')),
  discount_value numeric NOT NULL DEFAULT 0 CHECK (discount_value >= 0),
  min_order_value numeric NOT NULL DEFAULT 0,
  max_uses integer,
  used_count integer NOT NULL DEFAULT 0,
  starts_at timestamptz NOT NULL DEFAULT now(),
  ends_at timestamptz,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.coupons ENABLE ROW LEVEL SECURITY;
CREATE POLICY "coupons_public_read" ON public.coupons FOR SELECT USING (true);
CREATE POLICY "coupons_admin_all" ON public.coupons FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'))
  WITH CHECK (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'));

-- Uso dos cupons
CREATE TABLE public.coupon_usages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  coupon_id uuid NOT NULL REFERENCES public.coupons(id) ON DELETE CASCADE,
  order_id uuid REFERENCES public.orders(id) ON DELETE SET NULL,
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  discount_applied numeric NOT NULL DEFAULT 0,
  used_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.coupon_usages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "coupon_usages_admin_all" ON public.coupon_usages FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'))
  WITH CHECK (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'));
CREATE POLICY "coupon_usages_own_read" ON public.coupon_usages FOR SELECT TO authenticated
  USING (user_id = auth.uid());

-- Adicionar campos de promoções complexas na tabela promotions
ALTER TABLE public.promotions
  ADD COLUMN promo_type text NOT NULL DEFAULT 'standard'
    CHECK (promo_type IN ('standard', 'buy_x_get_y', 'progressive')),
  ADD COLUMN buy_quantity integer,
  ADD COLUMN get_quantity integer,
  ADD COLUMN progressive_tiers jsonb;

-- Adicionar campos de tipografia/espaçamento/borda/sombra ao theme_settings
ALTER TABLE public.theme_settings
  ADD COLUMN font_family text NOT NULL DEFAULT 'Inter',
  ADD COLUMN border_radius text NOT NULL DEFAULT '8',
  ADD COLUMN shadow_style text NOT NULL DEFAULT 'md',
  ADD COLUMN button_style text NOT NULL DEFAULT 'solid';

-- Realtime
ALTER PUBLICATION supabase_realtime ADD TABLE public.coupons;
ALTER PUBLICATION supabase_realtime ADD TABLE public.coupon_usages;
