ALTER TABLE store_settings ADD COLUMN IF NOT EXISTS store_features jsonb DEFAULT '[
  {"icon": "Truck", "title": "Entrega Rápida", "desc": "Todo o Brasil"},
  {"icon": "Shield", "title": "Compra Segura", "desc": "Pagamento protegido"},
  {"icon": "RefreshCw", "title": "Troca Fácil", "desc": "Sem burocracia"},
  {"icon": "MessageCircle", "title": "Suporte 24h", "desc": "Sempre disponível"}
]'::jsonb;

UPDATE store_settings SET store_features = '[
  {"icon": "Truck", "title": "Entrega Rápida", "desc": "Todo o Brasil"},
  {"icon": "Shield", "title": "Compra Segura", "desc": "Pagamento protegido"},
  {"icon": "RefreshCw", "title": "Troca Fácil", "desc": "Sem burocracia"},
  {"icon": "MessageCircle", "title": "Suporte 24h", "desc": "Sempre disponível"}
]'::jsonb WHERE store_features IS NULL;