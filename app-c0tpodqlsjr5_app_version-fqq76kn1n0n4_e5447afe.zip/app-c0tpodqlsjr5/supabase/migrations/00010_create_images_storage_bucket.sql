INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'store-images',
  'store-images',
  true,
  5242880,
  ARRAY['image/jpeg','image/jpg','image/png','image/webp','image/gif','image/svg+xml']
);

CREATE POLICY "Imagens publicas para leitura"
ON storage.objects FOR SELECT
USING (bucket_id = 'store-images');

CREATE POLICY "Admin pode fazer upload"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'store-images'
  AND (SELECT role FROM profiles WHERE id = auth.uid()) = 'admin'
);

CREATE POLICY "Admin pode deletar imagens"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'store-images'
  AND (SELECT role FROM profiles WHERE id = auth.uid()) = 'admin'
);