-- Tabela de assinaturas
CREATE TABLE IF NOT EXISTS subscriptions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  trial_days INTEGER NOT NULL DEFAULT 7,
  trial_ends_at TIMESTAMP WITH TIME ZONE DEFAULT (now() + interval '7 days'),
  expires_at TIMESTAMP WITH TIME ZONE DEFAULT (now() + interval '37 days'), -- 7 trial + 30 first month
  status TEXT NOT NULL CHECK (status IN ('active', 'expired', 'trial', 'canceled')) DEFAULT 'trial',
  plan_name TEXT NOT NULL DEFAULT 'Mensal',
  monthly_price DECIMAL(10,2) DEFAULT 49.90,
  last_billing_date TIMESTAMP WITH TIME ZONE DEFAULT now(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Inserir assinatura inicial se não existir
INSERT INTO subscriptions (status, plan_name)
SELECT 'trial', 'Mensal'
WHERE NOT EXISTS (SELECT 1 FROM subscriptions);

-- Políticas RLS
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow select for everyone" ON subscriptions
  FOR SELECT USING (true);

CREATE POLICY "Admin can update subscriptions" ON subscriptions
  FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'));

-- Função para verificar se a loja está ativa
CREATE OR REPLACE FUNCTION is_store_active()
RETURNS BOOLEAN
LANGUAGE sql
SECURITY DEFINER
AS $$
  SELECT EXISTS (
    SELECT 1 FROM subscriptions 
    WHERE (status = 'active' AND expires_at > now())
    OR (status = 'trial' AND trial_ends_at > now())
  );
$$;
