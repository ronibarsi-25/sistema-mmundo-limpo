-- Adicionar nível do plano à tabela de assinaturas
ALTER TABLE subscriptions ADD COLUMN IF NOT EXISTS plan_level TEXT CHECK (plan_level IN ('prata', 'ouro', 'diamond')) DEFAULT 'prata';

-- Atualizar o plano existente para prata (padrão)
UPDATE subscriptions SET plan_level = 'prata' WHERE plan_level IS NULL;
