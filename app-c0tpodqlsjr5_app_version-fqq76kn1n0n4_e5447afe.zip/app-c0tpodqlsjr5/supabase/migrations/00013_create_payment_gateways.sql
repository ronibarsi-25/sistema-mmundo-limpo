
CREATE TABLE payment_gateways (
  id text PRIMARY KEY,
  name text NOT NULL,
  description text,
  icon text NOT NULL DEFAULT 'CreditCard',
  is_active boolean NOT NULL DEFAULT false,
  config jsonb NOT NULL DEFAULT '{}',
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

INSERT INTO payment_gateways (id, name, description, icon, is_active, config, sort_order) VALUES
  ('pix',         'PIX',                   'Pagamento instantâneo via Pix (QR Code)',         'QrCode',     true,  '{}', 1),
  ('stripe',      'Cartão (Stripe)',        'Cartão de crédito/débito via Stripe',              'CreditCard', true,  '{}', 2),
  ('pagseguro',   'PagSeguro',             'Pagamento via PagSeguro (boleto, cartão, pix)',    'Landmark',   false, '{"email":"","token":"","checkout_url":""}', 3),
  ('mercadopago', 'Mercado Pago',          'Pagamento via Mercado Pago',                       'Wallet',     false, '{"access_token":"","checkout_url":""}', 4),
  ('boleto',      'Boleto Bancário',       'Pagamento via boleto bancário (manual)',           'FileText',   false, '{"bank":"","instructions":"Pague o boleto em qualquer banco ou lotérica até o vencimento."}', 5),
  ('deposito',    'Depósito / Transferência', 'Transferência bancária manual (TED/DOC)',       'Building2',  false, '{"bank_name":"","agency":"","account":"","account_holder":"","instructions":"Envie o comprovante via WhatsApp."}', 6);

ALTER TABLE payment_gateways ENABLE ROW LEVEL SECURITY;

CREATE POLICY "gateways_public_read" ON payment_gateways
  FOR SELECT TO public USING (true);

CREATE POLICY "gateways_admin_all" ON payment_gateways
  FOR ALL TO authenticated
  USING (exists (select 1 from profiles where id = auth.uid() and role = 'admin'))
  WITH CHECK (exists (select 1 from profiles where id = auth.uid() and role = 'admin'));
