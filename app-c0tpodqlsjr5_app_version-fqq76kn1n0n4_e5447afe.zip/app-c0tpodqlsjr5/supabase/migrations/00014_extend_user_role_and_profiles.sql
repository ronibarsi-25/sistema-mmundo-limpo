
-- Adicionar roles do PDV ao enum existente
ALTER TYPE public.user_role ADD VALUE IF NOT EXISTS 'gestor';
ALTER TYPE public.user_role ADD VALUE IF NOT EXISTS 'operador';

-- Adicionar username à tabela profiles
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS username text;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS active boolean NOT NULL DEFAULT true;

-- Criar índice único para username (somente onde não é null)
CREATE UNIQUE INDEX IF NOT EXISTS profiles_username_unique ON public.profiles(username) WHERE username IS NOT NULL;
