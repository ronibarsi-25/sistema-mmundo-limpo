
-- Extensões
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Tipos enumerados PDV
CREATE TYPE public.payment_method AS ENUM ('dinheiro', 'cartao_debito', 'cartao_credito', 'pix', 'outros');
CREATE TYPE public.invoice_type AS ENUM ('entrada', 'saida');
CREATE TYPE public.invoice_status AS ENUM ('pendente', 'emitida', 'cancelada');
CREATE TYPE public.movement_direction AS ENUM ('entrada', 'saida', 'ajuste');
CREATE TYPE public.transaction_type AS ENUM ('receita', 'despesa');

-- Tabela: dados da empresa
CREATE TABLE public.company (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  razao_social text NOT NULL DEFAULT 'Mundo Limpo',
  nome_fantasia text NOT NULL DEFAULT 'Mundo Limpo',
  cnpj text,
  inscricao_estadual text,
  regime_tributario text DEFAULT 'Simples Nacional',
  telefone text,
  email text,
  website text,
  whatsapp text,
  cep text,
  logradouro text,
  numero text,
  complemento text,
  bairro text,
  cidade text,
  estado text DEFAULT 'SP',
  logo_url text,
  backup_frequency text DEFAULT 'diario',
  site_integration_url text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Tabela: categorias PDV
CREATE TABLE public.pdv_categories (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  name text NOT NULL,
  description text,
  color text DEFAULT '#0A5C5A',
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Tabela: produtos PDV
CREATE TABLE public.pdv_products (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  code text UNIQUE NOT NULL,
  barcode text,
  name text NOT NULL,
  description text,
  category_id uuid REFERENCES public.pdv_categories(id),
  unit text NOT NULL DEFAULT 'UN',
  cost_price numeric(10,2) NOT NULL DEFAULT 0,
  sale_price numeric(10,2) NOT NULL DEFAULT 0,
  stock_qty numeric(10,3) NOT NULL DEFAULT 0,
  stock_min numeric(10,3) NOT NULL DEFAULT 5,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Tabela: clientes
CREATE TABLE public.customers (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  name text NOT NULL,
  cpf_cnpj text,
  email text,
  phone text,
  birth_date date,
  cep text,
  logradouro text,
  numero text,
  complemento text,
  bairro text,
  cidade text,
  estado text,
  notes text,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Tabela: fornecedores
CREATE TABLE public.suppliers (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  razao_social text NOT NULL,
  nome_fantasia text,
  cnpj text,
  email text,
  phone text,
  contact_name text,
  cep text,
  logradouro text,
  numero text,
  complemento text,
  bairro text,
  cidade text,
  estado text,
  notes text,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Tabela: caixa
CREATE TABLE public.cash_registers (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  operator_id uuid NOT NULL REFERENCES public.profiles(id),
  opening_amount numeric(10,2) NOT NULL DEFAULT 0,
  closing_amount numeric(10,2),
  expected_amount numeric(10,2),
  difference numeric(10,2),
  notes text,
  opened_at timestamptz NOT NULL DEFAULT now(),
  closed_at timestamptz,
  status text NOT NULL DEFAULT 'aberto'
);

-- Tabela: notas fiscais / vendas
CREATE TABLE public.pdv_invoices (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  number text NOT NULL,
  type public.invoice_type NOT NULL,
  status public.invoice_status NOT NULL DEFAULT 'pendente',
  customer_id uuid REFERENCES public.customers(id),
  supplier_id uuid REFERENCES public.suppliers(id),
  cash_register_id uuid REFERENCES public.cash_registers(id),
  subtotal numeric(10,2) NOT NULL DEFAULT 0,
  discount numeric(10,2) NOT NULL DEFAULT 0,
  total numeric(10,2) NOT NULL DEFAULT 0,
  payment_method public.payment_method DEFAULT 'dinheiro',
  notes text,
  issued_at timestamptz NOT NULL DEFAULT now(),
  created_by uuid REFERENCES public.profiles(id),
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Sequência para número de nota
CREATE SEQUENCE IF NOT EXISTS pdv_invoice_seq START 1;

-- Tabela: itens de notas fiscais
CREATE TABLE public.pdv_invoice_items (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  invoice_id uuid NOT NULL REFERENCES public.pdv_invoices(id) ON DELETE CASCADE,
  product_id uuid NOT NULL REFERENCES public.pdv_products(id),
  quantity numeric(10,3) NOT NULL,
  unit_price numeric(10,2) NOT NULL,
  total_price numeric(10,2) NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Tabela: movimentações de estoque PDV
CREATE TABLE public.pdv_stock_movements (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  product_id uuid NOT NULL REFERENCES public.pdv_products(id),
  type public.movement_direction NOT NULL,
  quantity numeric(10,3) NOT NULL,
  previous_qty numeric(10,3) NOT NULL,
  new_qty numeric(10,3) NOT NULL,
  reference_id uuid,
  reference_type text,
  notes text,
  created_by uuid REFERENCES public.profiles(id),
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Tabela: entrada de mercadorias
CREATE TABLE public.goods_receipts (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  supplier_id uuid REFERENCES public.suppliers(id),
  invoice_number text,
  total_amount numeric(10,2) NOT NULL DEFAULT 0,
  notes text,
  received_by uuid REFERENCES public.profiles(id),
  received_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Tabela: itens de entrada
CREATE TABLE public.goods_receipt_items (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  receipt_id uuid NOT NULL REFERENCES public.goods_receipts(id) ON DELETE CASCADE,
  product_id uuid NOT NULL REFERENCES public.pdv_products(id),
  quantity numeric(10,3) NOT NULL,
  cost_price numeric(10,2) NOT NULL,
  total_price numeric(10,2) NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Tabela: financeiro
CREATE TABLE public.transactions (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  type public.transaction_type NOT NULL,
  category text NOT NULL,
  description text NOT NULL,
  amount numeric(10,2) NOT NULL,
  payment_method public.payment_method DEFAULT 'outros',
  supplier_id uuid REFERENCES public.suppliers(id),
  invoice_id uuid REFERENCES public.pdv_invoices(id),
  transaction_date date NOT NULL DEFAULT CURRENT_DATE,
  notes text,
  created_by uuid REFERENCES public.profiles(id),
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Trigger: updated_at genérico
CREATE OR REPLACE FUNCTION update_updated_at_col()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;

CREATE TRIGGER trg_company_upd BEFORE UPDATE ON public.company FOR EACH ROW EXECUTE FUNCTION update_updated_at_col();
CREATE TRIGGER trg_pdv_products_upd BEFORE UPDATE ON public.pdv_products FOR EACH ROW EXECUTE FUNCTION update_updated_at_col();
CREATE TRIGGER trg_customers_upd BEFORE UPDATE ON public.customers FOR EACH ROW EXECUTE FUNCTION update_updated_at_col();
CREATE TRIGGER trg_suppliers_upd BEFORE UPDATE ON public.suppliers FOR EACH ROW EXECUTE FUNCTION update_updated_at_col();

-- Trigger: atualizar estoque ao vender
CREATE OR REPLACE FUNCTION pdv_update_stock_on_sale()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_type invoice_type; v_prev numeric;
BEGIN
  SELECT type INTO v_type FROM pdv_invoices WHERE id = NEW.invoice_id;
  IF v_type = 'saida' THEN
    SELECT stock_qty INTO v_prev FROM pdv_products WHERE id = NEW.product_id;
    UPDATE pdv_products SET stock_qty = stock_qty - NEW.quantity WHERE id = NEW.product_id;
    INSERT INTO pdv_stock_movements (product_id, type, quantity, previous_qty, new_qty, reference_id, reference_type, notes)
    VALUES (NEW.product_id, 'saida', NEW.quantity, v_prev, v_prev - NEW.quantity, NEW.invoice_id, 'invoice', 'Venda automática');
  END IF;
  RETURN NEW;
END;
$$;
CREATE TRIGGER trg_pdv_stock_sale AFTER INSERT ON public.pdv_invoice_items FOR EACH ROW EXECUTE FUNCTION pdv_update_stock_on_sale();

-- Trigger: atualizar estoque ao receber mercadoria
CREATE OR REPLACE FUNCTION pdv_update_stock_on_receipt()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_prev numeric;
BEGIN
  SELECT stock_qty INTO v_prev FROM pdv_products WHERE id = NEW.product_id;
  UPDATE pdv_products SET stock_qty = stock_qty + NEW.quantity, cost_price = NEW.cost_price WHERE id = NEW.product_id;
  INSERT INTO pdv_stock_movements (product_id, type, quantity, previous_qty, new_qty, reference_id, reference_type, notes)
  VALUES (NEW.product_id, 'entrada', NEW.quantity, v_prev, v_prev + NEW.quantity, NEW.receipt_id, 'goods_receipt', 'Entrada de mercadoria');
  RETURN NEW;
END;
$$;
CREATE TRIGGER trg_pdv_stock_receipt AFTER INSERT ON public.goods_receipt_items FOR EACH ROW EXECUTE FUNCTION pdv_update_stock_on_receipt();

-- Índices
CREATE INDEX idx_pdv_products_cat ON public.pdv_products(category_id);
CREATE INDEX idx_pdv_products_barcode ON public.pdv_products(barcode);
CREATE INDEX idx_pdv_invoices_type ON public.pdv_invoices(type);
CREATE INDEX idx_pdv_invoices_issued ON public.pdv_invoices(issued_at);
CREATE INDEX idx_pdv_invoice_items_inv ON public.pdv_invoice_items(invoice_id);
CREATE INDEX idx_pdv_stock_mov_prod ON public.pdv_stock_movements(product_id);
CREATE INDEX idx_transactions_type ON public.transactions(type);
CREATE INDEX idx_transactions_date ON public.transactions(transaction_date);
CREATE INDEX idx_cash_reg_status ON public.cash_registers(status);
