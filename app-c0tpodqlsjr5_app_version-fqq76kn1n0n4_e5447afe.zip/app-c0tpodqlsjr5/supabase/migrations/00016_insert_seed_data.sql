
-- Dados da empresa
INSERT INTO public.company (razao_social, nome_fantasia, telefone, email, cidade, estado, whatsapp)
VALUES ('Mundo Limpo Distribuidora Ltda', 'Mundo Limpo', '(11) 99999-0000', 'contato@mundolimpo.com.br', 'São Paulo', 'SP', '(11) 99999-0000');

-- Categorias de produtos
INSERT INTO public.pdv_categories (name, description, color) VALUES
('Limpeza Doméstica', 'Produtos para limpeza residencial', '#0A5C5A'),
('Piscina', 'Tratamento e manutenção de piscinas', '#1A6B9A'),
('Lavanderia', 'Produtos para lavagem de roupas', '#5A3A8A'),
('Estética Automotiva', 'Produtos para cuidado e limpeza de veículos', '#8A3A1A'),
('Condomínios', 'Produtos para limpeza de áreas comuns', '#3A6A2A');

-- Produtos de exemplo
INSERT INTO public.pdv_products (code, barcode, name, description, category_id, unit, cost_price, sale_price, stock_qty, stock_min) VALUES
('DET001', '7891234560001', 'Detergente Neutro 5L', 'Detergente concentrado neutro para limpeza geral', (SELECT id FROM public.pdv_categories WHERE name='Limpeza Doméstica'), 'UN', 8.50, 15.90, 50, 10),
('DET002', '7891234560002', 'Detergente Degreaser 1L', 'Desengordurante industrial potente', (SELECT id FROM public.pdv_categories WHERE name='Limpeza Doméstica'), 'UN', 6.00, 11.90, 30, 5),
('CLON001', '7891234560003', 'Cloro Granulado 1kg', 'Cloro granulado para tratamento de piscina', (SELECT id FROM public.pdv_categories WHERE name='Piscina'), 'UN', 12.00, 22.90, 40, 8),
('ALG001', '7891234560004', 'Algicida Manutenção 1L', 'Algicida para manutenção preventiva de piscinas', (SELECT id FROM public.pdv_categories WHERE name='Piscina'), 'UN', 15.00, 28.90, 20, 5),
('SAB001', '7891234560005', 'Sabão em Pó 5kg', 'Sabão em pó para lavanderia profissional', (SELECT id FROM public.pdv_categories WHERE name='Lavanderia'), 'UN', 25.00, 45.90, 35, 8),
('AMC001', '7891234560006', 'Amaciante Concentrado 5L', 'Amaciante concentrado para roupas', (SELECT id FROM public.pdv_categories WHERE name='Lavanderia'), 'UN', 18.00, 34.90, 25, 5),
('POL001', '7891234560007', 'Polish Automotivo 500ml', 'Polish para polimento de pintura automotiva', (SELECT id FROM public.pdv_categories WHERE name='Estética Automotiva'), 'UN', 20.00, 38.90, 15, 3),
('SHC001', '7891234560008', 'Shampoo Automotivo 1L', 'Shampoo neutro para lavagem de veículos', (SELECT id FROM public.pdv_categories WHERE name='Estética Automotiva'), 'UN', 12.00, 22.90, 20, 4),
('DES001', '7891234560009', 'Desinfetante Lavanda 5L', 'Desinfetante perfumado para pisos de condomínios', (SELECT id FROM public.pdv_categories WHERE name='Condomínios'), 'UN', 14.00, 26.90, 45, 10),
('MUL001', '7891234560010', 'Multiuso Concentrado 2L', 'Limpador multiuso concentrado para uso geral', (SELECT id FROM public.pdv_categories WHERE name='Condomínios'), 'UN', 9.00, 17.90, 60, 12);
