
-- Habilitar RLS nas novas tabelas PDV
ALTER TABLE public.company ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pdv_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pdv_products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.suppliers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.cash_registers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pdv_invoices ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pdv_invoice_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pdv_stock_movements ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.goods_receipts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.goods_receipt_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.transactions ENABLE ROW LEVEL SECURITY;

-- Helper: verificar se é admin ou gestor ou operador (staff)
CREATE OR REPLACE FUNCTION public.is_pdv_staff(uid uuid)
RETURNS boolean LANGUAGE sql SECURITY DEFINER SET search_path = public AS $$
  SELECT role IN ('admin'::user_role, 'gestor'::user_role, 'operador'::user_role) FROM profiles WHERE id = uid;
$$;

-- Helper: verificar se é admin
CREATE OR REPLACE FUNCTION public.is_pdv_admin(uid uuid)
RETURNS boolean LANGUAGE sql SECURITY DEFINER SET search_path = public AS $$
  SELECT role = 'admin'::user_role FROM profiles WHERE id = uid;
$$;

-- Helper: get role
CREATE OR REPLACE FUNCTION public.get_pdv_user_role(uid uuid)
RETURNS public.user_role LANGUAGE sql SECURITY DEFINER SET search_path = public AS $$
  SELECT role FROM profiles WHERE id = uid;
$$;

-- Políticas: company
CREATE POLICY "pdv_staff_read_company" ON public.company FOR SELECT TO authenticated USING (is_pdv_staff(auth.uid()));
CREATE POLICY "pdv_admin_write_company" ON public.company FOR INSERT TO authenticated WITH CHECK (is_pdv_admin(auth.uid()));
CREATE POLICY "pdv_admin_update_company" ON public.company FOR UPDATE TO authenticated USING (is_pdv_admin(auth.uid()));

-- Políticas: categorias PDV
CREATE POLICY "pdv_staff_read_categories" ON public.pdv_categories FOR SELECT TO authenticated USING (is_pdv_staff(auth.uid()));
CREATE POLICY "pdv_admin_write_categories" ON public.pdv_categories FOR INSERT TO authenticated WITH CHECK (get_pdv_user_role(auth.uid()) IN ('admin'::user_role,'gestor'::user_role));
CREATE POLICY "pdv_admin_update_categories" ON public.pdv_categories FOR UPDATE TO authenticated USING (get_pdv_user_role(auth.uid()) IN ('admin'::user_role,'gestor'::user_role));
CREATE POLICY "pdv_admin_delete_categories" ON public.pdv_categories FOR DELETE TO authenticated USING (is_pdv_admin(auth.uid()));

-- Políticas: produtos PDV
CREATE POLICY "pdv_staff_all_products" ON public.pdv_products FOR ALL TO authenticated USING (is_pdv_staff(auth.uid())) WITH CHECK (is_pdv_staff(auth.uid()));

-- Políticas: clientes
CREATE POLICY "pdv_staff_all_customers" ON public.customers FOR ALL TO authenticated USING (is_pdv_staff(auth.uid())) WITH CHECK (is_pdv_staff(auth.uid()));

-- Políticas: fornecedores
CREATE POLICY "pdv_staff_all_suppliers" ON public.suppliers FOR ALL TO authenticated USING (is_pdv_staff(auth.uid())) WITH CHECK (is_pdv_staff(auth.uid()));

-- Políticas: caixa
CREATE POLICY "pdv_staff_all_cash" ON public.cash_registers FOR ALL TO authenticated USING (is_pdv_staff(auth.uid())) WITH CHECK (is_pdv_staff(auth.uid()));

-- Políticas: notas fiscais
CREATE POLICY "pdv_staff_all_invoices" ON public.pdv_invoices FOR ALL TO authenticated USING (is_pdv_staff(auth.uid())) WITH CHECK (is_pdv_staff(auth.uid()));
CREATE POLICY "pdv_staff_all_invoice_items" ON public.pdv_invoice_items FOR ALL TO authenticated USING (is_pdv_staff(auth.uid())) WITH CHECK (is_pdv_staff(auth.uid()));

-- Políticas: movimentações de estoque
CREATE POLICY "pdv_staff_all_stock_mov" ON public.pdv_stock_movements FOR ALL TO authenticated USING (is_pdv_staff(auth.uid())) WITH CHECK (is_pdv_staff(auth.uid()));

-- Políticas: entrada de mercadorias
CREATE POLICY "pdv_staff_all_receipts" ON public.goods_receipts FOR ALL TO authenticated USING (is_pdv_staff(auth.uid())) WITH CHECK (is_pdv_staff(auth.uid()));
CREATE POLICY "pdv_staff_all_receipt_items" ON public.goods_receipt_items FOR ALL TO authenticated USING (is_pdv_staff(auth.uid())) WITH CHECK (is_pdv_staff(auth.uid()));

-- Políticas: transações
CREATE POLICY "pdv_staff_all_transactions" ON public.transactions FOR ALL TO authenticated USING (is_pdv_staff(auth.uid())) WITH CHECK (is_pdv_staff(auth.uid()));
