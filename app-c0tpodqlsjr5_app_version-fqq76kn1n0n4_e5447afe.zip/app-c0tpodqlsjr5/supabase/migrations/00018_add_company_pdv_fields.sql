ALTER TABLE company ADD COLUMN IF NOT EXISTS phone text;
ALTER TABLE company ADD COLUMN IF NOT EXISTS whatsapp_message text DEFAULT 'Ola! Gostaria de informacoes sobre os produtos da Mundo Limpo.';
ALTER TABLE company ADD COLUMN IF NOT EXISTS invoice_footer text;