
-- =============================================
-- FILIAIS
-- =============================================
CREATE TABLE branches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  cnpj text,
  phone text,
  email text,
  cep text,
  logradouro text,
  numero text,
  complemento text,
  bairro text,
  cidade text,
  estado text,
  is_main boolean NOT NULL DEFAULT false,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- =============================================
-- GRADES DE PRODUTOS (variações)
-- =============================================
CREATE TABLE product_variants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid NOT NULL REFERENCES pdv_products(id) ON DELETE CASCADE,
  variant_name text NOT NULL,         -- ex: "Azul - P"
  color text,
  size text,
  flavor text,
  barcode text UNIQUE,
  stock_qty numeric NOT NULL DEFAULT 0,
  cost_price numeric NOT NULL DEFAULT 0,
  sale_price numeric,                 -- NULL = herda do produto pai
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- =============================================
-- LOTES DE PRODUTOS
-- =============================================
CREATE TABLE product_batches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid NOT NULL REFERENCES pdv_products(id) ON DELETE CASCADE,
  batch_number text NOT NULL,
  manufacturing_date date,
  expiry_date date,
  initial_qty numeric NOT NULL DEFAULT 0,
  current_qty numeric NOT NULL DEFAULT 0,
  cost_price numeric NOT NULL DEFAULT 0,
  receipt_id uuid REFERENCES goods_receipts(id),
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_batches_expiry ON product_batches(expiry_date);
CREATE INDEX idx_batches_product ON product_batches(product_id);

-- Adicionar campo de validade e lote ao produto
ALTER TABLE pdv_products ADD COLUMN IF NOT EXISTS has_variants boolean NOT NULL DEFAULT false;
ALTER TABLE pdv_products ADD COLUMN IF NOT EXISTS track_batches boolean NOT NULL DEFAULT false;
ALTER TABLE pdv_products ADD COLUMN IF NOT EXISTS expiry_date date;

-- =============================================
-- PROGRAMA DE FIDELIDADE
-- =============================================
CREATE TABLE loyalty_config (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  points_per_real numeric NOT NULL DEFAULT 1,       -- pontos por R$1 gasto
  real_per_point numeric NOT NULL DEFAULT 0.01,     -- R$ de desconto por ponto
  min_redemption_points integer NOT NULL DEFAULT 100,
  active boolean NOT NULL DEFAULT true,
  updated_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO loyalty_config (points_per_real, real_per_point, min_redemption_points) VALUES (1, 0.01, 100);

CREATE TABLE loyalty_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  type text NOT NULL CHECK (type IN ('acumulo', 'resgate', 'expiracao', 'bonus_indicacao')),
  points integer NOT NULL,
  balance_after integer NOT NULL DEFAULT 0,
  reference_id uuid,                 -- invoice_id, etc.
  description text,
  created_at timestamptz NOT NULL DEFAULT now()
);
-- Saldo de pontos no cliente
ALTER TABLE customers ADD COLUMN IF NOT EXISTS loyalty_points integer NOT NULL DEFAULT 0;

-- =============================================
-- PROGRAMA DE INDICAÇÃO
-- =============================================
CREATE TABLE referrals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  referrer_id uuid NOT NULL REFERENCES customers(id),
  referred_id uuid NOT NULL REFERENCES customers(id),
  bonus_type text NOT NULL DEFAULT 'pontos' CHECK (bonus_type IN ('pontos', 'desconto', 'credito')),
  bonus_value numeric NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'pendente' CHECK (status IN ('pendente', 'confirmado', 'cancelado')),
  created_at timestamptz NOT NULL DEFAULT now()
);

-- =============================================
-- COMISSÕES DE VENDEDORES
-- =============================================
CREATE TABLE seller_commissions_config (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  commission_pct numeric NOT NULL DEFAULT 0 CHECK (commission_pct >= 0 AND commission_pct <= 100),
  active boolean NOT NULL DEFAULT true,
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(profile_id)
);

CREATE TABLE commissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid NOT NULL REFERENCES profiles(id),
  invoice_id uuid REFERENCES pdv_invoices(id),
  sale_amount numeric NOT NULL DEFAULT 0,
  commission_pct numeric NOT NULL DEFAULT 0,
  commission_value numeric NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'pendente' CHECK (status IN ('pendente', 'pago', 'cancelado')),
  paid_at timestamptz,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- =============================================
-- DEVOLUÇÕES E TROCAS
-- =============================================
CREATE TABLE returns (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  original_invoice_id uuid REFERENCES pdv_invoices(id),
  customer_id uuid REFERENCES customers(id),
  return_date date NOT NULL DEFAULT CURRENT_DATE,
  reason text NOT NULL,
  resolution text NOT NULL DEFAULT 'credito' CHECK (resolution IN ('credito', 'troca', 'reembolso')),
  total_amount numeric NOT NULL DEFAULT 0,
  credit_issued numeric NOT NULL DEFAULT 0,
  notes text,
  processed_by uuid REFERENCES profiles(id),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE return_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  return_id uuid NOT NULL REFERENCES returns(id) ON DELETE CASCADE,
  product_id uuid NOT NULL REFERENCES pdv_products(id),
  quantity numeric NOT NULL DEFAULT 1,
  unit_price numeric NOT NULL DEFAULT 0,
  total_price numeric NOT NULL DEFAULT 0,
  condition text DEFAULT 'bom' CHECK (condition IN ('bom', 'danificado', 'defeituoso')),
  restock boolean NOT NULL DEFAULT true
);

-- =============================================
-- GARANTIAS
-- =============================================
CREATE TABLE warranties (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_id uuid REFERENCES pdv_invoices(id),
  product_id uuid NOT NULL REFERENCES pdv_products(id),
  customer_id uuid REFERENCES customers(id),
  warranty_months integer NOT NULL DEFAULT 12,
  start_date date NOT NULL DEFAULT CURRENT_DATE,
  end_date date NOT NULL,
  status text NOT NULL DEFAULT 'ativa' CHECK (status IN ('ativa', 'expirada', 'acionada')),
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- =============================================
-- AGENDAMENTO DE ENTREGAS
-- =============================================
CREATE TABLE deliveries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_id uuid REFERENCES pdv_invoices(id),
  customer_id uuid REFERENCES customers(id),
  scheduled_date date NOT NULL,
  scheduled_time time,
  address text NOT NULL,
  city text,
  state text,
  driver_name text,
  status text NOT NULL DEFAULT 'agendado' CHECK (status IN ('agendado', 'em_rota', 'entregue', 'cancelado', 'reagendado')),
  notes text,
  delivered_at timestamptz,
  created_by uuid REFERENCES profiles(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_deliveries_date ON deliveries(scheduled_date);

-- =============================================
-- CONTAS A PAGAR / RECEBER
-- =============================================
CREATE TABLE bills (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  type text NOT NULL CHECK (type IN ('pagar', 'receber')),
  description text NOT NULL,
  total_amount numeric NOT NULL DEFAULT 0,
  installments integer NOT NULL DEFAULT 1,
  category text NOT NULL DEFAULT 'outros',
  supplier_id uuid REFERENCES suppliers(id),
  customer_id uuid REFERENCES customers(id),
  invoice_id uuid REFERENCES pdv_invoices(id),
  notes text,
  created_by uuid REFERENCES profiles(id),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE bill_installments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  bill_id uuid NOT NULL REFERENCES bills(id) ON DELETE CASCADE,
  installment_number integer NOT NULL DEFAULT 1,
  amount numeric NOT NULL DEFAULT 0,
  due_date date NOT NULL,
  paid_date date,
  paid_amount numeric,
  status text NOT NULL DEFAULT 'pendente' CHECK (status IN ('pendente', 'pago', 'vencido', 'cancelado')),
  payment_method text DEFAULT 'dinheiro',
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_installments_due ON bill_installments(due_date);
CREATE INDEX idx_installments_bill ON bill_installments(bill_id);

-- =============================================
-- TRANSFERÊNCIAS ENTRE FILIAIS
-- =============================================
CREATE TABLE stock_transfers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  from_branch_id uuid REFERENCES branches(id),
  to_branch_id uuid REFERENCES branches(id),
  status text NOT NULL DEFAULT 'pendente' CHECK (status IN ('pendente', 'confirmado', 'cancelado')),
  notes text,
  transferred_by uuid REFERENCES profiles(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  confirmed_at timestamptz
);

CREATE TABLE stock_transfer_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transfer_id uuid NOT NULL REFERENCES stock_transfers(id) ON DELETE CASCADE,
  product_id uuid NOT NULL REFERENCES pdv_products(id),
  quantity numeric NOT NULL DEFAULT 0
);

-- =============================================
-- CONCILIAÇÃO BANCÁRIA
-- =============================================
CREATE TABLE bank_statements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  bank_name text NOT NULL,
  account text,
  statement_date date NOT NULL,
  description text NOT NULL,
  amount numeric NOT NULL,
  type text NOT NULL CHECK (type IN ('credito', 'debito')),
  reconciled boolean NOT NULL DEFAULT false,
  transaction_id uuid REFERENCES transactions(id),
  imported_at timestamptz NOT NULL DEFAULT now()
);

-- =============================================
-- MARKETPLACES
-- =============================================
CREATE TABLE marketplace_listings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid NOT NULL REFERENCES pdv_products(id),
  marketplace text NOT NULL CHECK (marketplace IN ('mercado_livre', 'shopee', 'amazon', 'americanas', 'outro')),
  listing_id text,                   -- ID externo do anúncio
  title text NOT NULL,
  listed_price numeric NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'ativo' CHECK (status IN ('ativo', 'pausado', 'encerrado', 'pendente')),
  url text,
  last_sync_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- =============================================
-- CONFIGURAÇÕES FISCAIS (NFC-e / Boleto)
-- =============================================
CREATE TABLE fiscal_config (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  emit_nfce boolean NOT NULL DEFAULT false,
  environment text NOT NULL DEFAULT 'homologacao' CHECK (environment IN ('homologacao', 'producao')),
  series_nfe text DEFAULT '1',
  series_nfce text DEFAULT '1',
  next_nfe_number integer NOT NULL DEFAULT 1,
  next_nfce_number integer NOT NULL DEFAULT 1,
  csc_id text,                       -- CSC identificador NFC-e
  csc_token text,                    -- CSC token NFC-e
  certificate_name text,
  certificate_expiry date,
  boleto_bank text,
  boleto_agency text,
  boleto_account text,
  boleto_cedente text,
  boleto_convenio text,
  updated_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO fiscal_config DEFAULT VALUES;

-- =============================================
-- PLANO DE CONTAS (Exportação Contábil)
-- =============================================
CREATE TABLE accounting_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE,
  name text NOT NULL,
  type text NOT NULL CHECK (type IN ('ativo', 'passivo', 'receita', 'despesa', 'patrimonio')),
  parent_id uuid REFERENCES accounting_accounts(id),
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Seed padrão do plano de contas
INSERT INTO accounting_accounts (code, name, type) VALUES
  ('1', 'ATIVO', 'ativo'),
  ('1.1', 'Caixa e Equivalentes', 'ativo'),
  ('1.2', 'Estoque', 'ativo'),
  ('2', 'PASSIVO', 'passivo'),
  ('2.1', 'Fornecedores a Pagar', 'passivo'),
  ('3', 'RECEITAS', 'receita'),
  ('3.1', 'Receita de Vendas', 'receita'),
  ('4', 'DESPESAS', 'despesa'),
  ('4.1', 'Custo de Mercadorias', 'despesa'),
  ('4.2', 'Despesas Operacionais', 'despesa');

-- =============================================
-- HABILITAR REALTIME NAS NOVAS TABELAS
-- =============================================
ALTER PUBLICATION supabase_realtime ADD TABLE deliveries;
ALTER PUBLICATION supabase_realtime ADD TABLE bill_installments;
ALTER PUBLICATION supabase_realtime ADD TABLE returns;
