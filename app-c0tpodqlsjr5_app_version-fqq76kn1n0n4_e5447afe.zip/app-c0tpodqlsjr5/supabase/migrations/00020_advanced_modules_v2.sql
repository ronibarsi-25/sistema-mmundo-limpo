
-- Returns / Trocas
CREATE TABLE IF NOT EXISTS returns (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  original_invoice_id uuid REFERENCES pdv_invoices(id) ON DELETE SET NULL,
  customer_id uuid REFERENCES customers(id) ON DELETE SET NULL,
  return_date date NOT NULL DEFAULT CURRENT_DATE,
  reason text NOT NULL,
  resolution text NOT NULL DEFAULT 'credito' CHECK (resolution IN ('credito','troca','reembolso')),
  total_amount numeric(12,2) NOT NULL DEFAULT 0,
  credit_issued numeric(12,2) NOT NULL DEFAULT 0,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS return_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  return_id uuid NOT NULL REFERENCES returns(id) ON DELETE CASCADE,
  product_id uuid NOT NULL REFERENCES pdv_products(id) ON DELETE RESTRICT,
  quantity numeric(12,3) NOT NULL DEFAULT 1,
  unit_price numeric(12,2) NOT NULL DEFAULT 0,
  total_price numeric(12,2) NOT NULL DEFAULT 0,
  condition text NOT NULL DEFAULT 'bom' CHECK (condition IN ('bom','danificado','defeituoso')),
  restock boolean NOT NULL DEFAULT true
);

-- Warranties / Garantias
CREATE TABLE IF NOT EXISTS warranties (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid NOT NULL REFERENCES pdv_products(id) ON DELETE RESTRICT,
  customer_id uuid REFERENCES customers(id) ON DELETE SET NULL,
  invoice_id uuid REFERENCES pdv_invoices(id) ON DELETE SET NULL,
  warranty_months int NOT NULL DEFAULT 12,
  start_date date NOT NULL DEFAULT CURRENT_DATE,
  end_date date NOT NULL,
  status text NOT NULL DEFAULT 'ativa' CHECK (status IN ('ativa','expirada','acionada')),
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Online Orders / Pedidos Online
CREATE TABLE IF NOT EXISTS online_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid REFERENCES customers(id) ON DELETE SET NULL,
  channel text NOT NULL DEFAULT 'site' CHECK (channel IN ('whatsapp','site','app','instagram','ifood','outro')),
  status text NOT NULL DEFAULT 'pendente' CHECK (status IN ('pendente','confirmado','em_preparacao','pronto','entregue','cancelado')),
  subtotal numeric(12,2) NOT NULL DEFAULT 0,
  discount numeric(12,2) NOT NULL DEFAULT 0,
  total numeric(12,2) NOT NULL DEFAULT 0,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS online_order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES online_orders(id) ON DELETE CASCADE,
  product_id uuid NOT NULL REFERENCES pdv_products(id) ON DELETE RESTRICT,
  quantity numeric(12,3) NOT NULL DEFAULT 1,
  unit_price numeric(12,2) NOT NULL DEFAULT 0,
  total_price numeric(12,2) NOT NULL DEFAULT 0
);

-- Ensure pdv_products has min_stock column
ALTER TABLE pdv_products ADD COLUMN IF NOT EXISTS min_stock int NOT NULL DEFAULT 5;

-- Ensure customers has loyalty_points column
ALTER TABLE customers ADD COLUMN IF NOT EXISTS loyalty_points int NOT NULL DEFAULT 0;

-- RLS
ALTER TABLE returns ENABLE ROW LEVEL SECURITY;
ALTER TABLE return_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE warranties ENABLE ROW LEVEL SECURITY;
ALTER TABLE online_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE online_order_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "returns_auth" ON returns FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "return_items_auth" ON return_items FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "warranties_auth" ON warranties FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "online_orders_auth" ON online_orders FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "online_order_items_auth" ON online_order_items FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Realtime
ALTER PUBLICATION supabase_realtime ADD TABLE online_orders;
