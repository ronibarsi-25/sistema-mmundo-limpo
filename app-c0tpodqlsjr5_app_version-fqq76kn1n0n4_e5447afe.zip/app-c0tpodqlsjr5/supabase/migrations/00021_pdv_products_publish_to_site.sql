
ALTER TABLE pdv_products
  ADD COLUMN publish_to_site boolean NOT NULL DEFAULT false,
  ADD COLUMN site_product_id uuid REFERENCES products(id) ON DELETE SET NULL;
