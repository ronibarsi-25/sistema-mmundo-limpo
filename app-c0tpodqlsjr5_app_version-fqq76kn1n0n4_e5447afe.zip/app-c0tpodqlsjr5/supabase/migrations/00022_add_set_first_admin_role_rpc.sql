
-- RPC called right after the first admin signs up + logs in.
-- SECURITY DEFINER bypasses RLS so it can UPDATE profiles.role.
CREATE OR REPLACE FUNCTION public.set_first_admin_role()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  admin_count int;
BEGIN
  -- Guard: refuse if an admin already exists
  SELECT COUNT(*) INTO admin_count
  FROM public.profiles
  WHERE role = 'admin';

  IF admin_count > 0 THEN
    RETURN jsonb_build_object(
      'success', false,
      'message', 'Já existe um administrador cadastrado.'
    );
  END IF;

  -- Promote the currently authenticated user
  UPDATE public.profiles
  SET role = 'admin'
  WHERE id = auth.uid();

  IF NOT FOUND THEN
    RETURN jsonb_build_object(
      'success', false,
      'message', 'Perfil não encontrado. Tente novamente em alguns segundos.'
    );
  END IF;

  RETURN jsonb_build_object('success', true, 'message', 'Admin criado com sucesso!');
END;
$$;
