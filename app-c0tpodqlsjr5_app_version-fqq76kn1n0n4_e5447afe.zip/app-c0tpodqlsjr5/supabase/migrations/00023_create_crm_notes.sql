
-- Tabela de notas/interações CRM por cliente
CREATE TABLE crm_notes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  author_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  type text NOT NULL DEFAULT 'nota' CHECK (type IN ('nota','ligacao','email','visita','reclamacao','elogio')),
  content text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE crm_notes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "crm_notes_all" ON crm_notes FOR ALL USING (true) WITH CHECK (true);

-- Vista materializada de métricas CRM por cliente
CREATE OR REPLACE VIEW customer_crm_metrics AS
SELECT
  c.id,
  c.name,
  c.email,
  c.phone,
  c.cpf_cnpj,
  c.birth_date,
  c.active,
  c.created_at,
  COUNT(DISTINCT i.id)                              AS total_orders,
  COALESCE(SUM(i.total), 0)                        AS total_spent,
  MAX(i.issued_at)                                  AS last_purchase_at,
  COALESCE(AVG(i.total), 0)                        AS avg_ticket,
  COUNT(DISTINCT n.id)                              AS total_notes
FROM customers c
LEFT JOIN pdv_invoices i
       ON i.customer_id = c.id AND i.type = 'saida' AND i.status = 'emitida'
LEFT JOIN crm_notes n ON n.customer_id = c.id
GROUP BY c.id, c.name, c.email, c.phone, c.cpf_cnpj, c.birth_date, c.active, c.created_at;
