-- ============================================================
-- PDV: Cupom Fiscal, Certificado Digital, Fração e Cadastro Fiscal
-- ============================================================

-- ---------- 1. Novas colunas em pdv_products (fração + preços) ----------
ALTER TABLE public.pdv_products
  ADD COLUMN IF NOT EXISTS is_fraction boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS fraction_unit text DEFAULT 'KG',
  ADD COLUMN IF NOT EXISTS wholesale_price numeric(10,2) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS retail_price numeric(10,2) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS ncm text,
  ADD COLUMN IF NOT EXISTS cest text;

-- ---------- 2. Tabela: configurações fiscais do emitente ----------
CREATE TABLE IF NOT EXISTS public.pdv_fiscal_config (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_name text NOT NULL DEFAULT '',
  company_fantasy_name text,
  cnpj text,
  ie text,
  im text,
  cnae text,
  crt text NOT NULL DEFAULT '1' CHECK (crt IN ('1','2','3')),
  address text,
  address_number text,
  neighborhood text,
  city_code text,
  city_name text,
  state text,
  zip_code text,
  phone text,
  email text,
  sat_enabled boolean NOT NULL DEFAULT false,
  sat_sign_ac text,
  sat_activation_code text,
  sat_environment text NOT NULL DEFAULT 'homologacao' CHECK (sat_environment IN ('homologacao','producao')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

INSERT INTO public.pdv_fiscal_config (company_name)
SELECT ''
WHERE NOT EXISTS (SELECT 1 FROM public.pdv_fiscal_config LIMIT 1);

-- ---------- 3. Tabela: certificados digitais ----------
CREATE TABLE IF NOT EXISTS public.pdv_certificates (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  alias text NOT NULL,
  certificate_type text NOT NULL DEFAULT 'A1' CHECK (certificate_type IN ('A1','A3')),
  certificate_data text NOT NULL DEFAULT '',
  password_hint text,
  valid_from timestamptz,
  valid_until timestamptz,
  serial_number text,
  issuer text,
  subject text,
  is_active boolean NOT NULL DEFAULT true,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- ---------- 4. Tabela: cupons fiscais emitidos ----------
CREATE TABLE IF NOT EXISTS public.pdv_cupons (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  invoice_id uuid REFERENCES public.pdv_invoices(id) ON DELETE SET NULL,
  invoice_number text NOT NULL,
  cupom_type text NOT NULL DEFAULT 'cfe' CHECK (cupom_type IN ('cfe','nfce')),
  serie text,
  numero text,
  chave_acesso text,
  qr_code text,
  status text NOT NULL DEFAULT 'pendente' CHECK (status IN ('pendente','autorizado','cancelado','rejeitado','contingencia')),
  xml text,
  pdf_url text,
  envio_status text,
  envio_msg text,
  cancelado_em timestamptz,
  cancelado_motivo text,
  total numeric(12,2) NOT NULL DEFAULT 0,
  cnpj_emitente text,
  total_items int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- ---------- 5. Tabela: itens do cupom fiscal ----------
CREATE TABLE IF NOT EXISTS public.pdv_cupom_items (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  cupom_id uuid NOT NULL REFERENCES public.pdv_cupons(id) ON DELETE CASCADE,
  product_id uuid REFERENCES public.pdv_products(id) ON DELETE SET NULL,
  product_code text NOT NULL,
  product_name text NOT NULL,
  quantity numeric(12,3) NOT NULL DEFAULT 0,
  unit text NOT NULL DEFAULT 'UN',
  unit_price numeric(12,2) NOT NULL DEFAULT 0,
  total_price numeric(12,2) NOT NULL DEFAULT 0,
  discount numeric(10,2) NOT NULL DEFAULT 0,
  icms_aliquota numeric(5,2),
  pis_aliquota numeric(5,2),
  cofins_aliquota numeric(5,2),
  created_at timestamptz NOT NULL DEFAULT now()
);

-- ---------- 6. Tabela: contingência de cupons ----------
CREATE TABLE IF NOT EXISTS public.pdv_cupom_contingencia (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  cupom_id uuid REFERENCES public.pdv_cupons(id) ON DELETE SET NULL,
  numero text NOT NULL,
  chave text,
  xml text,
  motivo text,
  data_hora timestamptz NOT NULL DEFAULT now(),
  resolvido boolean NOT NULL DEFAULT false,
  resolvido_em timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- ---------- 7. Índices ----------
CREATE INDEX IF NOT EXISTS idx_pdv_cupons_invoice_id ON public.pdv_cupons(invoice_id);
CREATE INDEX IF NOT EXISTS idx_pdv_cupons_status ON public.pdv_cupons(status);
CREATE INDEX IF NOT EXISTS idx_pdv_cupons_chave ON public.pdv_cupons(chave_acesso);
CREATE INDEX IF NOT EXISTS idx_pdv_cupons_created ON public.pdv_cupons(created_at);
CREATE INDEX IF NOT EXISTS idx_pdv_cupom_items_cupom_id ON public.pdv_cupom_items(cupom_id);
CREATE INDEX IF NOT EXISTS idx_pdv_certificates_active ON public.pdv_certificates(is_active);
CREATE INDEX IF NOT EXISTS idx_pdv_cupom_contingencia_resolvido ON public.pdv_cupom_contingencia(resolvido);

-- ---------- 8. RLS Policies ----------
ALTER TABLE public.pdv_fiscal_config ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pdv_certificates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pdv_cupons ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pdv_cupom_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pdv_cupom_contingencia ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view fiscal config" ON public.pdv_fiscal_config
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admins can manage fiscal config" ON public.pdv_fiscal_config
  FOR ALL TO authenticated USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role IN ('admin','gestor'))
  );

CREATE POLICY "Anyone can view certificates" ON public.pdv_certificates
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admins can manage certificates" ON public.pdv_certificates
  FOR ALL TO authenticated USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role IN ('admin','gestor'))
  );

CREATE POLICY "Anyone can view cupons" ON public.pdv_cupons
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admins can manage cupons" ON public.pdv_cupons
  FOR ALL TO authenticated USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role IN ('admin','gestor'))
  );

CREATE POLICY "Anyone can view cupom items" ON public.pdv_cupom_items
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admins can manage cupom items" ON public.pdv_cupom_items
  FOR ALL TO authenticated USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role IN ('admin','gestor'))
  );

CREATE POLICY "Anyone can view contingencia" ON public.pdv_cupom_contingencia
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admins can manage contingencia" ON public.pdv_cupom_contingencia
  FOR ALL TO authenticated USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role IN ('admin','gestor'))
  );