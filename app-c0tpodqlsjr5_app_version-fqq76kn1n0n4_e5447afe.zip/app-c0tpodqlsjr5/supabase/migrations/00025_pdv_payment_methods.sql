-- Tabela: métodos de pagamento personalizados do PDV
CREATE TABLE IF NOT EXISTS public.pdv_payment_methods (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  name text NOT NULL,
  code text NOT NULL UNIQUE,
  type text NOT NULL DEFAULT 'outro' CHECK (type IN ('dinheiro','cartao_debito','cartao_credito','pix','boleto','vale','crediario','outro')),
  provider text, -- Ex: Stone, Cielo, PagSeguro, Rede, etc.
  icon text DEFAULT 'CreditCard', -- nome do ícone lucide
  is_active boolean NOT NULL DEFAULT true,
  fee_percent numeric(5,2) NOT NULL DEFAULT 0, -- taxa sobre transação
  fee_fixed numeric(10,2) NOT NULL DEFAULT 0, -- taxa fixa em reais
  terminal_id text, -- ID do terminal/pinpad
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Seed com os métodos nativos já existentes
INSERT INTO public.pdv_payment_methods (name, code, type, icon, is_active)
VALUES
  ('Dinheiro', 'dinheiro', 'dinheiro', 'Banknote', true),
  ('Cartão de Débito', 'cartao_debito', 'cartao_debito', 'CreditCard', true),
  ('Cartão de Crédito', 'cartao_credito', 'cartao_credito', 'CreditCard', true),
  ('PIX', 'pix', 'pix', 'QrCode', true),
  ('Outros', 'outros', 'outro', 'Wallet', true)
ON CONFLICT (code) DO NOTHING;

-- Índice
CREATE INDEX IF NOT EXISTS idx_pdv_payment_methods_active ON public.pdv_payment_methods(is_active);

-- RLS
ALTER TABLE public.pdv_payment_methods ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view payment methods" ON public.pdv_payment_methods
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Admins can manage payment methods" ON public.pdv_payment_methods
  FOR ALL TO authenticated USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role IN ('admin','gestor'))
  );