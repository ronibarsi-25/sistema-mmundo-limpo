
-- Create tenants table
CREATE TABLE tenants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text UNIQUE NOT NULL,
  domain text,
  logo_url text,
  primary_color text DEFAULT '#0f172a',
  secondary_color text DEFAULT '#64748b',
  accent_color text DEFAULT '#f59e0b',
  description text,
  phone text,
  email text,
  address text,
  settings jsonb DEFAULT '{}',
  plan text DEFAULT 'free',
  status text DEFAULT 'active',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Add tenant_id to core tables (only existing tables)
ALTER TABLE profiles ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE products ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE categories ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE orders ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE coupons ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE payment_gateways ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE store_settings ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE banners ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE promotions ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE stock_movements ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE customers ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE suppliers ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE coupon_usages ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE pdv_products ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE pdv_categories ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE pdv_invoices ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE pdv_cupons ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE cash_registers ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE fiscal_config ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE subscriptions ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE company ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE pdv_fiscal_config ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE pdv_certificates ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE chat_messages ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE commissions ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE bills ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE bill_installments ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE transactions ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE branches ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE deliveries ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE returns ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE warranties ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE wishlist ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE marketplace_listings ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE referrals ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE seller_commissions_config ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE loyalty_config ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE loyalty_transactions ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE crm_notes ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE goods_receipts ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE product_variants ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE product_batches ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE stock_transfers ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE online_orders ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE theme_settings ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE accounting_accounts ADD COLUMN tenant_id uuid REFERENCES tenants(id);
ALTER TABLE bank_statements ADD COLUMN tenant_id uuid REFERENCES tenants(id);

-- Create indexes for tenant_id lookups
CREATE INDEX idx_profiles_tenant_id ON profiles(tenant_id);
CREATE INDEX idx_products_tenant_id ON products(tenant_id);
CREATE INDEX idx_categories_tenant_id ON categories(tenant_id);
CREATE INDEX idx_orders_tenant_id ON orders(tenant_id);
CREATE INDEX idx_coupons_tenant_id ON coupons(tenant_id);
CREATE INDEX idx_pdv_products_tenant_id ON pdv_products(tenant_id);
