
-- Tabela de métodos de envio
CREATE TABLE IF NOT EXISTS shipping_methods (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id   uuid REFERENCES tenants(id) ON DELETE CASCADE,
  name        text NOT NULL,
  carrier     text NOT NULL DEFAULT 'custom', -- 'correios', 'custom'
  code        text,                            -- '04669' PAC, '04162' SEDEX
  type        text NOT NULL DEFAULT 'fixed',   -- 'fixed','free','correios_pac','correios_sedex','correios_sedex10'
  price       numeric(10,2) NOT NULL DEFAULT 0,
  min_days    int NOT NULL DEFAULT 1,
  max_days    int NOT NULL DEFAULT 10,
  is_active   boolean NOT NULL DEFAULT true,
  sort_order  int NOT NULL DEFAULT 0,
  created_at  timestamptz DEFAULT now(),
  updated_at  timestamptz DEFAULT now()
);

-- Índice para tenant
CREATE INDEX IF NOT EXISTS idx_shipping_methods_tenant ON shipping_methods(tenant_id);

-- Colunas de configuração Correios na store_settings
ALTER TABLE store_settings
  ADD COLUMN IF NOT EXISTS correios_cep_origin     text,
  ADD COLUMN IF NOT EXISTS correios_contract       text,
  ADD COLUMN IF NOT EXISTS correios_password       text,
  ADD COLUMN IF NOT EXISTS correios_pac_enabled    boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS correios_sedex_enabled  boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS free_shipping_threshold numeric(10,2),
  ADD COLUMN IF NOT EXISTS default_weight_kg       numeric(6,3) NOT NULL DEFAULT 0.5,
  ADD COLUMN IF NOT EXISTS default_length_cm       int NOT NULL DEFAULT 20,
  ADD COLUMN IF NOT EXISTS default_width_cm        int NOT NULL DEFAULT 15,
  ADD COLUMN IF NOT EXISTS default_height_cm       int NOT NULL DEFAULT 10;

-- Coluna de método de envio nos pedidos
ALTER TABLE orders
  ADD COLUMN IF NOT EXISTS shipping_method_id   uuid,
  ADD COLUMN IF NOT EXISTS shipping_method_name text,
  ADD COLUMN IF NOT EXISTS shipping_carrier     text,
  ADD COLUMN IF NOT EXISTS tracking_code        text,
  ADD COLUMN IF NOT EXISTS estimated_delivery   text;

-- RLS
ALTER TABLE shipping_methods ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Leitura pública de métodos de envio"
  ON shipping_methods FOR SELECT USING (true);

CREATE POLICY "Admin gerencia métodos de envio"
  ON shipping_methods FOR ALL
  USING (get_current_tenant_id() = tenant_id OR tenant_id IS NULL)
  WITH CHECK (get_current_tenant_id() = tenant_id OR tenant_id IS NULL);

-- Insere métodos padrão Correios (sem tenant – global fallback, opcional por loja)
INSERT INTO shipping_methods (name, carrier, code, type, price, min_days, max_days, sort_order)
VALUES
  ('PAC', 'correios', '04669', 'correios_pac',   0, 5, 10, 1),
  ('SEDEX', 'correios', '04162', 'correios_sedex', 0, 1, 3,  2)
ON CONFLICT DO NOTHING;
