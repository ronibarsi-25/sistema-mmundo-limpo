
-- ═══════════════════════════════════════════════════════
-- EMPLOYEES (RH)
-- ═══════════════════════════════════════════════════════
CREATE TABLE public.employees (
  id           uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id    uuid REFERENCES public.tenants(id) ON DELETE CASCADE NOT NULL DEFAULT get_current_tenant_id(),
  name         text NOT NULL,
  cpf          text NOT NULL,
  email        text,
  phone        text,
  role         text NOT NULL,
  department   text NOT NULL,
  base_salary  numeric(12,2) NOT NULL DEFAULT 0,
  hired_at     date NOT NULL,
  fired_at     date,
  status       text NOT NULL DEFAULT 'active' CHECK (status IN ('active','inactive')),
  notes        text,
  created_at   timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, cpf)
);
ALTER TABLE public.employees ENABLE ROW LEVEL SECURITY;
CREATE POLICY "employees_select" ON public.employees FOR SELECT USING (tenant_id = get_current_tenant_id());
CREATE POLICY "employees_insert" ON public.employees FOR INSERT WITH CHECK (tenant_id = get_current_tenant_id());
CREATE POLICY "employees_update" ON public.employees FOR UPDATE USING (tenant_id = get_current_tenant_id()) WITH CHECK (tenant_id = get_current_tenant_id());
CREATE POLICY "employees_delete" ON public.employees FOR DELETE USING (tenant_id = get_current_tenant_id());
CREATE INDEX idx_employees_tenant ON public.employees(tenant_id);

-- ═══════════════════════════════════════════════════════
-- PAYROLL ENTRIES
-- ═══════════════════════════════════════════════════════
CREATE TABLE public.payroll_entries (
  id                uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id         uuid REFERENCES public.tenants(id) ON DELETE CASCADE NOT NULL DEFAULT get_current_tenant_id(),
  employee_id       uuid REFERENCES public.employees(id) ON DELETE CASCADE NOT NULL,
  competence_month  int NOT NULL CHECK (competence_month BETWEEN 1 AND 12),
  competence_year   int NOT NULL,
  base_salary       numeric(12,2) NOT NULL DEFAULT 0,
  overtime_hours    numeric(6,2)  NOT NULL DEFAULT 0,
  overtime_value    numeric(12,2) NOT NULL DEFAULT 0,
  advance           numeric(12,2) NOT NULL DEFAULT 0,
  transport_voucher numeric(12,2) NOT NULL DEFAULT 0,
  inss_discount     numeric(12,2) NOT NULL DEFAULT 0,
  irrf_discount     numeric(12,2) NOT NULL DEFAULT 0,
  other_discounts   numeric(12,2) NOT NULL DEFAULT 0,
  gross_salary      numeric(12,2) NOT NULL DEFAULT 0,
  net_salary        numeric(12,2) NOT NULL DEFAULT 0,
  notes             text,
  created_at        timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, employee_id, competence_month, competence_year)
);
ALTER TABLE public.payroll_entries ENABLE ROW LEVEL SECURITY;
CREATE POLICY "payroll_select" ON public.payroll_entries FOR SELECT USING (tenant_id = get_current_tenant_id());
CREATE POLICY "payroll_insert" ON public.payroll_entries FOR INSERT WITH CHECK (tenant_id = get_current_tenant_id());
CREATE POLICY "payroll_update" ON public.payroll_entries FOR UPDATE USING (tenant_id = get_current_tenant_id()) WITH CHECK (tenant_id = get_current_tenant_id());
CREATE POLICY "payroll_delete" ON public.payroll_entries FOR DELETE USING (tenant_id = get_current_tenant_id());
CREATE INDEX idx_payroll_entries_tenant_comp ON public.payroll_entries(tenant_id, competence_year, competence_month);

-- ═══════════════════════════════════════════════════════
-- TIME RECORDS (Ponto Eletrônico)
-- ═══════════════════════════════════════════════════════
CREATE TABLE public.time_records (
  id          uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id   uuid REFERENCES public.tenants(id) ON DELETE CASCADE NOT NULL DEFAULT get_current_tenant_id(),
  employee_id uuid REFERENCES public.employees(id) ON DELETE CASCADE NOT NULL,
  punch_type  text NOT NULL CHECK (punch_type IN ('entry','lunch_start','lunch_end','exit')),
  punched_at  timestamptz NOT NULL DEFAULT now(),
  notes       text,
  created_at  timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.time_records ENABLE ROW LEVEL SECURITY;
CREATE POLICY "time_records_select" ON public.time_records FOR SELECT USING (tenant_id = get_current_tenant_id());
CREATE POLICY "time_records_insert" ON public.time_records FOR INSERT WITH CHECK (tenant_id = get_current_tenant_id());
CREATE POLICY "time_records_update" ON public.time_records FOR UPDATE USING (tenant_id = get_current_tenant_id()) WITH CHECK (tenant_id = get_current_tenant_id());
CREATE POLICY "time_records_delete" ON public.time_records FOR DELETE USING (tenant_id = get_current_tenant_id());
CREATE INDEX idx_time_records_employee_date ON public.time_records(employee_id, punched_at);

-- ═══════════════════════════════════════════════════════
-- BOOKABLE RESOURCES
-- ═══════════════════════════════════════════════════════
CREATE TABLE public.bookable_resources (
  id          uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id   uuid REFERENCES public.tenants(id) ON DELETE CASCADE NOT NULL DEFAULT get_current_tenant_id(),
  name        text NOT NULL,
  description text,
  color       text NOT NULL DEFAULT '#0A5C5A',
  is_active   boolean NOT NULL DEFAULT true,
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.bookable_resources ENABLE ROW LEVEL SECURITY;
CREATE POLICY "resources_select" ON public.bookable_resources FOR SELECT USING (tenant_id = get_current_tenant_id());
CREATE POLICY "resources_insert" ON public.bookable_resources FOR INSERT WITH CHECK (tenant_id = get_current_tenant_id());
CREATE POLICY "resources_update" ON public.bookable_resources FOR UPDATE USING (tenant_id = get_current_tenant_id()) WITH CHECK (tenant_id = get_current_tenant_id());
CREATE POLICY "resources_delete" ON public.bookable_resources FOR DELETE USING (tenant_id = get_current_tenant_id());

-- ═══════════════════════════════════════════════════════
-- APPOINTMENTS (Agendamentos)
-- ═══════════════════════════════════════════════════════
CREATE TABLE public.appointments (
  id             uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id      uuid REFERENCES public.tenants(id) ON DELETE CASCADE NOT NULL DEFAULT get_current_tenant_id(),
  resource_id    uuid REFERENCES public.bookable_resources(id) ON DELETE SET NULL,
  customer_name  text NOT NULL,
  customer_phone text,
  customer_email text,
  title          text NOT NULL,
  description    text,
  starts_at      timestamptz NOT NULL,
  ends_at        timestamptz NOT NULL,
  status         text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','confirmed','cancelled','completed')),
  notes          text,
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT appointments_start_before_end CHECK (ends_at > starts_at)
);
ALTER TABLE public.appointments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "appointments_select" ON public.appointments FOR SELECT USING (tenant_id = get_current_tenant_id());
CREATE POLICY "appointments_insert" ON public.appointments FOR INSERT WITH CHECK (tenant_id = get_current_tenant_id());
CREATE POLICY "appointments_update" ON public.appointments FOR UPDATE USING (tenant_id = get_current_tenant_id()) WITH CHECK (tenant_id = get_current_tenant_id());
CREATE POLICY "appointments_delete" ON public.appointments FOR DELETE USING (tenant_id = get_current_tenant_id());
CREATE INDEX idx_appointments_tenant_dates ON public.appointments(tenant_id, starts_at, ends_at);
CREATE INDEX idx_appointments_resource ON public.appointments(resource_id);
