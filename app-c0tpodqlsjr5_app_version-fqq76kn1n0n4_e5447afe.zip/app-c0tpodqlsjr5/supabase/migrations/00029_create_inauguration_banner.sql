CREATE TABLE IF NOT EXISTS inauguration_banner (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  is_active boolean NOT NULL DEFAULT true,
  store_name text NOT NULL DEFAULT 'Mundo Limpo',
  headline text NOT NULL DEFAULT '🎉 Grande Inauguração!',
  subtitle text DEFAULT 'Aproveite nossos preços especiais de lançamento!',
  coupon_code text NOT NULL DEFAULT 'INAUGURA10',
  discount_text text NOT NULL DEFAULT '10% OFF na primeira compra',
  whatsapp_message text DEFAULT 'Olá! Estou inaugurando a Mundo Limpo e tenho um presente especial para você! 🎉 Use o cupom *{coupon}* e ganhe {discount} na sua primeira compra. Válido até {expiry}. Acesse: {url}',
  expires_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE inauguration_banner ENABLE ROW LEVEL SECURITY;

-- Leitura pública para exibir o banner
CREATE POLICY "inauguration_banner_public_read" ON inauguration_banner
  FOR SELECT USING (true);

-- Apenas admins podem modificar
CREATE POLICY "inauguration_banner_admin_write" ON inauguration_banner
  FOR ALL USING (
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- Inserir registro padrão
INSERT INTO inauguration_banner (is_active, store_name, headline, subtitle, coupon_code, discount_text, expires_at)
VALUES (
  true,
  'Mundo Limpo',
  '🎉 Grande Inauguração Mundo Limpo!',
  'Aproveite nossos preços especiais de lançamento. Produtos de limpeza com qualidade e preço justo!',
  'INAUGURA15',
  '15% OFF em toda a loja',
  now() + interval '60 days'
)
ON CONFLICT DO NOTHING;