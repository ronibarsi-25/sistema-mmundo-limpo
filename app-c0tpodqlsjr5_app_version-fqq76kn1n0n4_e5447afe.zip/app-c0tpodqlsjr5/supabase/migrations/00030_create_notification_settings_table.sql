CREATE TABLE IF NOT EXISTS notification_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  whatsapp_enabled boolean NOT NULL DEFAULT false,
  whatsapp_number text DEFAULT '',
  whatsapp_provider text NOT NULL DEFAULT 'callmebot',
  whatsapp_api_key text DEFAULT '',
  whatsapp_webhook_url text DEFAULT '',
  message_template text NOT NULL DEFAULT 'Olá! 🛒 Novo pedido #{order_number} de R${total} recebido no site. Cliente: {customer_name}. Status: {status}.',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE notification_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "notification_settings_public_read" ON notification_settings
  FOR SELECT USING (true);

CREATE POLICY "notification_settings_admin_write" ON notification_settings
  FOR ALL USING (
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
  );

INSERT INTO notification_settings (whatsapp_enabled, whatsapp_number, message_template)
VALUES (false, '', 'Olá! 🛒 Novo pedido #{order_number} de R${total} recebido no site. Cliente: {customer_name}. Status: {status}.')
ON CONFLICT DO NOTHING;