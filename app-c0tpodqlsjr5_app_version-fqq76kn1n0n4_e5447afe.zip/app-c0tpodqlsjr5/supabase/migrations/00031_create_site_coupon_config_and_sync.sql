CREATE TABLE IF NOT EXISTS site_coupon_config (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  show_banner boolean NOT NULL DEFAULT false,
  code text NOT NULL DEFAULT 'BEMVINDO',
  discount_percentage integer NOT NULL DEFAULT 10,
  min_order_value numeric(10,2) NOT NULL DEFAULT 0,
  expires_at timestamptz DEFAULT NULL,
  banner_headline text NOT NULL DEFAULT 'Use o cupom {code} e ganhe {discount}% de desconto!',
  banner_subtitle text DEFAULT 'Válido por tempo limitado. Aproveite!',
  bg_color text NOT NULL DEFAULT '#10b981',
  text_color text NOT NULL DEFAULT '#ffffff',
  button_text text NOT NULL DEFAULT 'Copiar Cupom',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE site_coupon_config ENABLE ROW LEVEL SECURITY;

CREATE POLICY "site_coupon_config_public_read" ON site_coupon_config
  FOR SELECT USING (true);

CREATE POLICY "site_coupon_config_admin_write" ON site_coupon_config
  FOR ALL USING (
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
  );

INSERT INTO site_coupon_config (show_banner, code, discount_percentage, banner_headline, banner_subtitle)
VALUES (false, 'BEMVINDO', 10, 'Use o cupom {code} e ganhe {discount}% de desconto!', 'Válido por tempo limitado. Aproveite!')
ON CONFLICT DO NOTHING;