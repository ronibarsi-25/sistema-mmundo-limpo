ALTER TABLE public.pdv_invoices ADD COLUMN IF NOT EXISTS installments integer DEFAULT 1;
ALTER TABLE public.transactions ADD COLUMN IF NOT EXISTS installments integer DEFAULT 1;