CREATE TABLE public.audit_logs (
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    created_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    user_id uuid REFERENCES auth.users(id),
    module text NOT NULL,
    action text NOT NULL,
    description text,
    metadata jsonb DEFAULT '{}'::jsonb
);

-- Habilitar RLS
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

-- Políticas de RLS
CREATE POLICY "Auditoria visível para usuários autenticados" ON public.audit_logs
    FOR SELECT TO authenticated
    USING (true);

CREATE POLICY "Usuários autenticados podem inserir auditoria" ON public.audit_logs
    FOR INSERT TO authenticated
    WITH CHECK (true);
