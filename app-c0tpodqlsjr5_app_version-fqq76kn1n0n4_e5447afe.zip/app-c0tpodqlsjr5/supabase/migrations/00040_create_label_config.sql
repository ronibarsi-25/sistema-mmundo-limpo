
create table if not exists label_config (
  id uuid primary key default gen_random_uuid(),
  -- Dimensões da etiqueta
  width_mm numeric not null default 50,
  height_mm numeric not null default 25,
  preset text not null default 'custom',
  -- Campos visíveis
  show_name boolean not null default true,
  show_code boolean not null default true,
  show_price boolean not null default true,
  show_barcode boolean not null default true,
  show_qr boolean not null default false,
  -- Logo
  logo_url text,
  logo_position text not null default 'top', -- top | left | right
  logo_size_pct integer not null default 30,
  -- Layout de impressão
  cols integer not null default 3,
  rows integer not null default 6,
  paper_size text not null default 'A4', -- A4 | A5 | Carta | Oficio | Termico
  -- Metadados
  updated_at timestamptz not null default now()
);

-- Apenas um registro de configuração ativo
alter table label_config enable row level security;

create policy "admin_all_label_config" on label_config
  for all using (
    exists (
      select 1 from profiles where id = auth.uid() and role in ('admin','gestor')
    )
  );

-- Seed: configuração padrão
insert into label_config (width_mm, height_mm, preset, show_name, show_code, show_price, show_barcode, show_qr, cols, rows, paper_size)
values (50, 25, '50x25', true, true, true, true, false, 4, 6, 'A4');
