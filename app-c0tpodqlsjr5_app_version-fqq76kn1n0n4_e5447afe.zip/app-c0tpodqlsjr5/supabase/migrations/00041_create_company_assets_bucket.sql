
-- Bucket público para assets da empresa (logo, etc.)
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'company-assets',
  'company-assets',
  true,
  2097152,
  array['image/png','image/jpeg','image/jpg','image/webp','image/svg+xml']
);

-- Política: admin/gestor podem fazer upload e deletar
create policy "company_assets_upload" on storage.objects
  for insert with check (
    bucket_id = 'company-assets'
    and exists (
      select 1 from profiles where id = auth.uid() and role in ('admin','gestor')
    )
  );

create policy "company_assets_update" on storage.objects
  for update using (
    bucket_id = 'company-assets'
    and exists (
      select 1 from profiles where id = auth.uid() and role in ('admin','gestor')
    )
  );

create policy "company_assets_delete" on storage.objects
  for delete using (
    bucket_id = 'company-assets'
    and exists (
      select 1 from profiles where id = auth.uid() and role in ('admin','gestor')
    )
  );

-- Leitura pública (bucket já é public=true, mas política explícita para anon)
create policy "company_assets_public_read" on storage.objects
  for select using (bucket_id = 'company-assets');
