
alter table label_config
  add column if not exists bg_image_url text default null,
  add column if not exists bg_opacity integer default 20;
