
-- Bucket para notas fiscais (PDF/XML)
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'invoices',
  'invoices',
  false,
  20971520,
  array['application/pdf','text/xml','application/xml','text/plain']
) on conflict (id) do nothing;

-- Admin/gestor podem upload
create policy "invoices_upload" on storage.objects
  for insert with check (
    bucket_id = 'invoices'
    and exists (select 1 from profiles where id = auth.uid() and role in ('admin','gestor','operador'))
  );

-- Admin/gestor podem ler
create policy "invoices_read" on storage.objects
  for select using (
    bucket_id = 'invoices'
    and exists (select 1 from profiles where id = auth.uid() and role in ('admin','gestor','operador'))
  );

-- Admin/gestor podem deletar
create policy "invoices_delete" on storage.objects
  for delete using (
    bucket_id = 'invoices'
    and exists (select 1 from profiles where id = auth.uid() and role in ('admin','gestor','operador'))
  );
