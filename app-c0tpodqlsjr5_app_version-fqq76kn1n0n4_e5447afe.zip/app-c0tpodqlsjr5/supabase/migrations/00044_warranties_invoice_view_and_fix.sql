
-- Cria view para pdv_invoices com alias invoice_number para compatibilidade
CREATE OR REPLACE VIEW pdv_invoices_view AS
  SELECT id, number AS invoice_number, type, status, customer_id, supplier_id,
         cash_register_id, subtotal, discount, total, payment_method,
         notes, issued_at, created_by, created_at, tenant_id, installments
  FROM pdv_invoices;

-- Adiciona coluna customer_name e product_name na tabela warranties para facilitar impressão
ALTER TABLE warranties ADD COLUMN IF NOT EXISTS product_name text;
ALTER TABLE warranties ADD COLUMN IF NOT EXISTS customer_name text;
ALTER TABLE warranties ADD COLUMN IF NOT EXISTS invoice_number text;
