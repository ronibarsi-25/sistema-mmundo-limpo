
-- Adiciona suporte a pagamento parcial em parcelas
ALTER TABLE bill_installments 
  ADD COLUMN IF NOT EXISTS partial_paid_amount numeric DEFAULT 0,
  ADD COLUMN IF NOT EXISTS remaining_amount numeric;

-- Atualiza remaining_amount existente
UPDATE bill_installments 
SET remaining_amount = CASE 
  WHEN status = 'pago' THEN 0 
  ELSE amount 
END
WHERE remaining_amount IS NULL;

-- Adiciona status 'parcial' como válido (text sem constraint, já aceita)
-- Adiciona tabela de ciclos mensais
CREATE TABLE IF NOT EXISTS monthly_cycles (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  month         integer NOT NULL,   -- 1-12
  year          integer NOT NULL,
  type          text NOT NULL DEFAULT 'pagar', -- 'pagar' | 'receber'
  status        text NOT NULL DEFAULT 'aberto', -- 'aberto' | 'fechado'
  pending_total numeric NOT NULL DEFAULT 0,     -- total pendente carregado do mês anterior
  carried_over  numeric NOT NULL DEFAULT 0,     -- saldo arrastado deste ciclo para o próximo
  notes         text,
  closed_at     timestamptz,
  created_at    timestamptz NOT NULL DEFAULT now(),
  tenant_id     uuid,
  UNIQUE (month, year, type)
);

-- RLS para monthly_cycles
ALTER TABLE monthly_cycles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "cycles_auth" ON monthly_cycles FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- RLS para bill_installments caso não tenha
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='bill_installments') THEN
    ALTER TABLE bill_installments ENABLE ROW LEVEL SECURITY;
    CREATE POLICY "bill_inst_auth" ON bill_installments FOR ALL TO authenticated USING (true) WITH CHECK (true);
  END IF;
END$$;
