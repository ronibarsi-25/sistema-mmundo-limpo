
-- Corrige parcelas com remaining_amount NULL (criadas antes da migration)
-- Para parcelas pagas, remaining = 0
-- Para parcelas pendentes/vencidas/parciais, remaining = amount - partial_paid_amount
UPDATE bill_installments
SET remaining_amount = CASE
  WHEN status = 'pago' THEN 0
  WHEN status = 'parcial' THEN amount - COALESCE(partial_paid_amount, 0)
  ELSE amount - COALESCE(partial_paid_amount, 0)
END
WHERE remaining_amount IS NULL;

-- Garante partial_paid_amount nunca NULL
UPDATE bill_installments
SET partial_paid_amount = 0
WHERE partial_paid_amount IS NULL;
