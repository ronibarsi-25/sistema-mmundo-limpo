ALTER TABLE company 
ADD COLUMN IF NOT EXISTS meta_pixel_id text,
ADD COLUMN IF NOT EXISTS meta_pixel_active boolean DEFAULT false;