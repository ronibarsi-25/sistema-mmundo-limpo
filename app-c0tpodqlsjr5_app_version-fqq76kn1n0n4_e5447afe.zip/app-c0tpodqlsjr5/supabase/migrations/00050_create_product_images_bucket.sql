INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('product-images', 'product-images', true, 52428800, ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/gif'])
ON CONFLICT (id) DO UPDATE SET public = true;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies WHERE tablename = 'objects' AND policyname = 'Public Read Product Images'
    ) THEN
        CREATE POLICY "Public Read Product Images" ON storage.objects FOR SELECT USING (bucket_id = 'product-images');
    END IF;
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies WHERE tablename = 'objects' AND policyname = 'Allow Upload Product Images'
    ) THEN
        CREATE POLICY "Allow Upload Product Images" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'product-images');
    END IF;
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies WHERE tablename = 'objects' AND policyname = 'Allow Update Product Images'
    ) THEN
        CREATE POLICY "Allow Update Product Images" ON storage.objects FOR UPDATE USING (bucket_id = 'product-images');
    END IF;
END $$;