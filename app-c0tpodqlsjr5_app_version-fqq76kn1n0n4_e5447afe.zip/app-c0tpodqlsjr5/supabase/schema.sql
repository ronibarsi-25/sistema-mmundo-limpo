-- ============================================================
-- SECTION: SCHEMA
-- ============================================================

--
-- PostgreSQL database dump
--


-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA IF NOT EXISTS "public";


--
-- Name: SCHEMA "public"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA "public" IS 'standard public schema';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "pgcrypto" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "pgcrypto"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "pgcrypto" IS 'cryptographic functions';


--
-- Name: supabase_vault; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "supabase_vault" WITH SCHEMA "vault";


--
-- Name: EXTENSION "supabase_vault"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "supabase_vault" IS 'Supabase Vault Extension';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: invoice_status; Type: TYPE; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_type t
    JOIN pg_namespace n ON n.oid = t.typnamespace
    WHERE n.nspname = 'public'
      AND t.typname = 'invoice_status'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE TYPE "public"."invoice_status" AS ENUM (
    'pendente',
    'emitida',
    'cancelada'
);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: invoice_type; Type: TYPE; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_type t
    JOIN pg_namespace n ON n.oid = t.typnamespace
    WHERE n.nspname = 'public'
      AND t.typname = 'invoice_type'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE TYPE "public"."invoice_type" AS ENUM (
    'entrada',
    'saida'
);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: movement_direction; Type: TYPE; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_type t
    JOIN pg_namespace n ON n.oid = t.typnamespace
    WHERE n.nspname = 'public'
      AND t.typname = 'movement_direction'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE TYPE "public"."movement_direction" AS ENUM (
    'entrada',
    'saida',
    'ajuste'
);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: order_status; Type: TYPE; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_type t
    JOIN pg_namespace n ON n.oid = t.typnamespace
    WHERE n.nspname = 'public'
      AND t.typname = 'order_status'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE TYPE "public"."order_status" AS ENUM (
    'pending',
    'processing',
    'shipped',
    'delivered',
    'cancelled',
    'completed'
);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: payment_method; Type: TYPE; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_type t
    JOIN pg_namespace n ON n.oid = t.typnamespace
    WHERE n.nspname = 'public'
      AND t.typname = 'payment_method'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE TYPE "public"."payment_method" AS ENUM (
    'dinheiro',
    'cartao_debito',
    'cartao_credito',
    'pix',
    'outros',
    'multiplo'
);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: stock_movement_type; Type: TYPE; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_type t
    JOIN pg_namespace n ON n.oid = t.typnamespace
    WHERE n.nspname = 'public'
      AND t.typname = 'stock_movement_type'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE TYPE "public"."stock_movement_type" AS ENUM (
    'entrada',
    'saida',
    'ajuste',
    'venda'
);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: transaction_type; Type: TYPE; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_type t
    JOIN pg_namespace n ON n.oid = t.typnamespace
    WHERE n.nspname = 'public'
      AND t.typname = 'transaction_type'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE TYPE "public"."transaction_type" AS ENUM (
    'receita',
    'despesa'
);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: user_role; Type: TYPE; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_type t
    JOIN pg_namespace n ON n.oid = t.typnamespace
    WHERE n.nspname = 'public'
      AND t.typname = 'user_role'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE TYPE "public"."user_role" AS ENUM (
    'user',
    'admin',
    'gestor',
    'operador',
    'vendedor'
);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: decrement_stock_on_order(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE OR REPLACE FUNCTION "public"."decrement_stock_on_order"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  item jsonb;
  prod_id uuid;
  qty int;
  prev_qty int;
BEGIN
  IF NEW.status = 'completed' AND OLD.status != 'completed' THEN
    FOR item IN SELECT * FROM jsonb_array_elements(NEW.items) LOOP
      prod_id := (item->>'id')::uuid;
      qty := (item->>'quantity')::int;
      SELECT stock_quantity INTO prev_qty FROM public.products WHERE id = prod_id;
      UPDATE public.products SET
        stock_quantity = GREATEST(0, stock_quantity - qty),
        is_available = CASE WHEN stock_quantity - qty <= 0 THEN false ELSE is_available END
      WHERE id = prod_id;
      INSERT INTO public.stock_movements (product_id, type, quantity, previous_quantity, new_quantity, notes, order_id)
      VALUES (prod_id, 'venda', qty, prev_qty, GREATEST(0, prev_qty - qty), 'Venda - Pedido ' || NEW.order_number, NEW.id);
    END LOOP;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: generate_order_number(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE OR REPLACE FUNCTION "public"."generate_order_number"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
BEGIN
  NEW.order_number := 'PED-' || LPAD(nextval('order_number_seq')::text, 6, '0');
  RETURN NEW;
END;
$$;


--
-- Name: get_current_tenant_id(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE OR REPLACE FUNCTION "public"."get_current_tenant_id"() RETURNS "uuid"
    LANGUAGE "sql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
  SELECT tenant_id FROM profiles WHERE id = auth.uid();
$$;


--
-- Name: get_pdv_user_role("uuid"); Type: FUNCTION; Schema: public; Owner: -
--

CREATE OR REPLACE FUNCTION "public"."get_pdv_user_role"("uid" "uuid") RETURNS "public"."user_role"
    LANGUAGE "sql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
  SELECT role FROM profiles WHERE id = uid;
$$;


--
-- Name: get_user_role("uuid"); Type: FUNCTION; Schema: public; Owner: -
--

CREATE OR REPLACE FUNCTION "public"."get_user_role"("uid" "uuid") RETURNS "public"."user_role"
    LANGUAGE "sql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$ SELECT role FROM profiles WHERE id = uid; $$;


--
-- Name: handle_new_user(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE OR REPLACE FUNCTION "public"."handle_new_user"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name, role)
  VALUES (NEW.id, NEW.email, NEW.raw_user_meta_data->>'full_name', 'user');
  RETURN NEW;
END;
$$;


--
-- Name: is_pdv_admin("uuid"); Type: FUNCTION; Schema: public; Owner: -
--

CREATE OR REPLACE FUNCTION "public"."is_pdv_admin"("uid" "uuid") RETURNS boolean
    LANGUAGE "sql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
  SELECT role = 'admin'::user_role FROM profiles WHERE id = uid;
$$;


--
-- Name: is_pdv_staff("uuid"); Type: FUNCTION; Schema: public; Owner: -
--

CREATE OR REPLACE FUNCTION "public"."is_pdv_staff"("uid" "uuid") RETURNS boolean
    LANGUAGE "sql" SECURITY DEFINER
    AS $$ SELECT role IN ('admin'::user_role, 'gestor'::user_role, 'operador'::user_role, 'vendedor'::user_role) FROM profiles WHERE id = uid; $$;


--
-- Name: is_store_active(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE OR REPLACE FUNCTION "public"."is_store_active"() RETURNS boolean
    LANGUAGE "sql" SECURITY DEFINER
    AS $$
  SELECT EXISTS (
    SELECT 1 FROM subscriptions 
    WHERE (status = 'active' AND expires_at > now())
    OR (status = 'trial' AND trial_ends_at > now())
  );
$$;


--
-- Name: is_super_admin(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE OR REPLACE FUNCTION "public"."is_super_admin"() RETURNS boolean
    LANGUAGE "sql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
  SELECT role = 'admin'::user_role FROM profiles WHERE id = auth.uid();
$$;


--
-- Name: pdv_update_stock_on_receipt(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE OR REPLACE FUNCTION "public"."pdv_update_stock_on_receipt"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE v_prev numeric;
BEGIN
  SELECT stock_qty INTO v_prev FROM pdv_products WHERE id = NEW.product_id;
  UPDATE pdv_products SET stock_qty = stock_qty + NEW.quantity, cost_price = NEW.cost_price WHERE id = NEW.product_id;
  INSERT INTO pdv_stock_movements (product_id, type, quantity, previous_qty, new_qty, reference_id, reference_type, notes)
  VALUES (NEW.product_id, 'entrada', NEW.quantity, v_prev, v_prev + NEW.quantity, NEW.receipt_id, 'goods_receipt', 'Entrada de mercadoria');
  RETURN NEW;
END;
$$;


--
-- Name: pdv_update_stock_on_sale(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE OR REPLACE FUNCTION "public"."pdv_update_stock_on_sale"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE v_type invoice_type; v_prev numeric;
BEGIN
  SELECT type INTO v_type FROM pdv_invoices WHERE id = NEW.invoice_id;
  IF v_type = 'saida' THEN
    SELECT stock_qty INTO v_prev FROM pdv_products WHERE id = NEW.product_id;
    UPDATE pdv_products SET stock_qty = stock_qty - NEW.quantity WHERE id = NEW.product_id;
    INSERT INTO pdv_stock_movements (product_id, type, quantity, previous_qty, new_qty, reference_id, reference_type, notes)
    VALUES (NEW.product_id, 'saida', NEW.quantity, v_prev, v_prev - NEW.quantity, NEW.invoice_id, 'invoice', 'Venda automática');
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: promote_first_user_to_admin(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE OR REPLACE FUNCTION "public"."promote_first_user_to_admin"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
BEGIN
  -- If this is the very first profile, make them admin
  IF (SELECT COUNT(*) FROM public.profiles) = 1 THEN
    UPDATE public.profiles SET role = 'admin' WHERE id = NEW.id;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: request_admin_access("text"); Type: FUNCTION; Schema: public; Owner: -
--

CREATE OR REPLACE FUNCTION "public"."request_admin_access"("user_email" "text") RETURNS "jsonb"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
DECLARE
  admin_count int;
  target_profile profiles%ROWTYPE;
BEGIN
  -- Check if any admin already exists
  SELECT COUNT(*) INTO admin_count FROM public.profiles WHERE role = 'admin';
  IF admin_count > 0 THEN
    RETURN jsonb_build_object('success', false, 'message', 'Já existe um administrador cadastrado.');
  END IF;

  -- Find user by email
  SELECT p.* INTO target_profile FROM public.profiles p
    JOIN auth.users u ON u.id = p.id
    WHERE u.email = user_email LIMIT 1;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'message', 'Usuário não encontrado.');
  END IF;

  -- Promote
  UPDATE public.profiles SET role = 'admin' WHERE id = target_profile.id;
  RETURN jsonb_build_object('success', true, 'message', 'Acesso admin concedido!');
END;
$$;


--
-- Name: set_first_admin_role(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE OR REPLACE FUNCTION "public"."set_first_admin_role"() RETURNS "jsonb"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  admin_count int;
BEGIN
  -- Guard: refuse if an admin already exists
  SELECT COUNT(*) INTO admin_count
  FROM public.profiles
  WHERE role = 'admin';

  IF admin_count > 0 THEN
    RETURN jsonb_build_object(
      'success', false,
      'message', 'Já existe um administrador cadastrado.'
    );
  END IF;

  -- Promote the currently authenticated user
  UPDATE public.profiles
  SET role = 'admin'
  WHERE id = auth.uid();

  IF NOT FOUND THEN
    RETURN jsonb_build_object(
      'success', false,
      'message', 'Perfil não encontrado. Tente novamente em alguns segundos.'
    );
  END IF;

  RETURN jsonb_build_object('success', true, 'message', 'Admin criado com sucesso!');
END;
$$;


--
-- Name: update_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE OR REPLACE FUNCTION "public"."update_updated_at"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;


--
-- Name: update_updated_at_col(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE OR REPLACE FUNCTION "public"."update_updated_at_col"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;


SET default_tablespace = '';

SET default_table_access_method = "heap";

--
-- Name: accounting_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."accounting_accounts" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "code" "text" NOT NULL,
    "name" "text" NOT NULL,
    "type" "text" NOT NULL,
    "parent_id" "uuid",
    "active" boolean DEFAULT true NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "tenant_id" "uuid",
    CONSTRAINT "accounting_accounts_type_check" CHECK (("type" = ANY (ARRAY['ativo'::"text", 'passivo'::"text", 'receita'::"text", 'despesa'::"text", 'patrimonio'::"text"])))
);


--
-- Name: appointments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."appointments" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "tenant_id" "uuid" DEFAULT "public"."get_current_tenant_id"() NOT NULL,
    "resource_id" "uuid",
    "customer_name" "text" NOT NULL,
    "customer_phone" "text",
    "customer_email" "text",
    "title" "text" NOT NULL,
    "description" "text",
    "starts_at" timestamp with time zone NOT NULL,
    "ends_at" timestamp with time zone NOT NULL,
    "status" "text" DEFAULT 'pending'::"text" NOT NULL,
    "notes" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "appointments_start_before_end" CHECK (("ends_at" > "starts_at")),
    CONSTRAINT "appointments_status_check" CHECK (("status" = ANY (ARRAY['pending'::"text", 'confirmed'::"text", 'cancelled'::"text", 'completed'::"text"])))
);


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."audit_logs" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "created_at" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    "user_id" "uuid",
    "module" "text" NOT NULL,
    "action" "text" NOT NULL,
    "description" "text",
    "metadata" "jsonb" DEFAULT '{}'::"jsonb"
);


--
-- Name: bank_statements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."bank_statements" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "bank_name" "text" NOT NULL,
    "account" "text",
    "statement_date" "date" NOT NULL,
    "description" "text" NOT NULL,
    "amount" numeric NOT NULL,
    "type" "text" NOT NULL,
    "reconciled" boolean DEFAULT false NOT NULL,
    "transaction_id" "uuid",
    "imported_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "tenant_id" "uuid",
    CONSTRAINT "bank_statements_type_check" CHECK (("type" = ANY (ARRAY['credito'::"text", 'debito'::"text"])))
);


--
-- Name: banners; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."banners" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "title" "text" NOT NULL,
    "subtitle" "text",
    "image_url" "text" NOT NULL,
    "cta_text" "text" DEFAULT 'Ver mais'::"text",
    "cta_link" "text" DEFAULT '/'::"text",
    "sort_order" integer DEFAULT 0 NOT NULL,
    "is_active" boolean DEFAULT true NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "tenant_id" "uuid"
);


--
-- Name: bill_installments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."bill_installments" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "bill_id" "uuid" NOT NULL,
    "installment_number" integer DEFAULT 1 NOT NULL,
    "amount" numeric DEFAULT 0 NOT NULL,
    "due_date" "date" NOT NULL,
    "paid_date" "date",
    "paid_amount" numeric,
    "status" "text" DEFAULT 'pendente'::"text" NOT NULL,
    "payment_method" "text" DEFAULT 'dinheiro'::"text",
    "notes" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "tenant_id" "uuid",
    "partial_paid_amount" numeric DEFAULT 0,
    "remaining_amount" numeric,
    CONSTRAINT "bill_installments_status_check" CHECK (("status" = ANY (ARRAY['pendente'::"text", 'pago'::"text", 'vencido'::"text", 'cancelado'::"text"])))
);


--
-- Name: bills; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."bills" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "type" "text" NOT NULL,
    "description" "text" NOT NULL,
    "total_amount" numeric DEFAULT 0 NOT NULL,
    "installments" integer DEFAULT 1 NOT NULL,
    "category" "text" DEFAULT 'outros'::"text" NOT NULL,
    "supplier_id" "uuid",
    "customer_id" "uuid",
    "invoice_id" "uuid",
    "notes" "text",
    "created_by" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "tenant_id" "uuid",
    CONSTRAINT "bills_type_check" CHECK (("type" = ANY (ARRAY['pagar'::"text", 'receber'::"text"])))
);


--
-- Name: bookable_resources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."bookable_resources" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "tenant_id" "uuid" DEFAULT "public"."get_current_tenant_id"() NOT NULL,
    "name" "text" NOT NULL,
    "description" "text",
    "color" "text" DEFAULT '#0A5C5A'::"text" NOT NULL,
    "is_active" boolean DEFAULT true NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


--
-- Name: branches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."branches" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "name" "text" NOT NULL,
    "cnpj" "text",
    "phone" "text",
    "email" "text",
    "cep" "text",
    "logradouro" "text",
    "numero" "text",
    "complemento" "text",
    "bairro" "text",
    "cidade" "text",
    "estado" "text",
    "is_main" boolean DEFAULT false NOT NULL,
    "active" boolean DEFAULT true NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "tenant_id" "uuid"
);


--
-- Name: cash_registers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."cash_registers" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "operator_id" "uuid" NOT NULL,
    "opening_amount" numeric(10,2) DEFAULT 0 NOT NULL,
    "closing_amount" numeric(10,2),
    "expected_amount" numeric(10,2),
    "difference" numeric(10,2),
    "notes" "text",
    "opened_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "closed_at" timestamp with time zone,
    "status" "text" DEFAULT 'aberto'::"text" NOT NULL,
    "tenant_id" "uuid"
);


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."categories" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "name" "text" NOT NULL,
    "slug" "text" NOT NULL,
    "description" "text",
    "image_url" "text",
    "is_active" boolean DEFAULT true NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "tenant_id" "uuid"
);


--
-- Name: chat_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."chat_messages" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "conversation_id" "uuid" NOT NULL,
    "user_id" "uuid",
    "sender_role" "text" DEFAULT 'user'::"text" NOT NULL,
    "message" "text" NOT NULL,
    "is_read" boolean DEFAULT false NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "tenant_id" "uuid"
);


--
-- Name: commissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."commissions" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "profile_id" "uuid" NOT NULL,
    "invoice_id" "uuid",
    "sale_amount" numeric DEFAULT 0 NOT NULL,
    "commission_pct" numeric DEFAULT 0 NOT NULL,
    "commission_value" numeric DEFAULT 0 NOT NULL,
    "status" "text" DEFAULT 'pendente'::"text" NOT NULL,
    "paid_at" timestamp with time zone,
    "notes" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "tenant_id" "uuid",
    CONSTRAINT "commissions_status_check" CHECK (("status" = ANY (ARRAY['pendente'::"text", 'pago'::"text", 'cancelado'::"text"])))
);


--
-- Name: company; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."company" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "razao_social" "text" DEFAULT 'Mundo Limpo'::"text" NOT NULL,
    "nome_fantasia" "text" DEFAULT 'Mundo Limpo'::"text" NOT NULL,
    "cnpj" "text",
    "inscricao_estadual" "text",
    "regime_tributario" "text" DEFAULT 'Simples Nacional'::"text",
    "telefone" "text",
    "email" "text",
    "website" "text",
    "whatsapp" "text",
    "cep" "text",
    "logradouro" "text",
    "numero" "text",
    "complemento" "text",
    "bairro" "text",
    "cidade" "text",
    "estado" "text" DEFAULT 'SP'::"text",
    "logo_url" "text",
    "backup_frequency" "text" DEFAULT 'diario'::"text",
    "site_integration_url" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "phone" "text",
    "whatsapp_message" "text" DEFAULT 'Ola! Gostaria de informacoes sobre os produtos da Mundo Limpo.'::"text",
    "invoice_footer" "text",
    "tenant_id" "uuid",
    "auto_print_cupom" boolean DEFAULT false,
    "printer_width_mm" integer DEFAULT 80,
    "printer_model" "text" DEFAULT ''::"text",
    "meta_pixel_id" "text",
    "meta_pixel_active" boolean DEFAULT false
);


--
-- Name: coupon_usages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."coupon_usages" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "coupon_id" "uuid" NOT NULL,
    "order_id" "uuid",
    "user_id" "uuid",
    "discount_applied" numeric DEFAULT 0 NOT NULL,
    "used_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "tenant_id" "uuid"
);


--
-- Name: coupons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."coupons" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "code" "text" NOT NULL,
    "discount_type" "text" NOT NULL,
    "discount_value" numeric DEFAULT 0 NOT NULL,
    "min_order_value" numeric DEFAULT 0 NOT NULL,
    "max_uses" integer,
    "used_count" integer DEFAULT 0 NOT NULL,
    "starts_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "ends_at" timestamp with time zone,
    "is_active" boolean DEFAULT true NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "tenant_id" "uuid",
    "max_uses_per_user" integer,
    CONSTRAINT "coupons_discount_type_check" CHECK (("discount_type" = ANY (ARRAY['percent'::"text", 'fixed'::"text", 'free_shipping'::"text"]))),
    CONSTRAINT "coupons_discount_value_check" CHECK (("discount_value" >= (0)::numeric))
);


--
-- Name: crm_notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."crm_notes" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "customer_id" "uuid" NOT NULL,
    "author_id" "uuid",
    "type" "text" DEFAULT 'nota'::"text" NOT NULL,
    "content" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "tenant_id" "uuid",
    CONSTRAINT "crm_notes_type_check" CHECK (("type" = ANY (ARRAY['nota'::"text", 'ligacao'::"text", 'email'::"text", 'visita'::"text", 'reclamacao'::"text", 'elogio'::"text"])))
);


--
-- Name: customers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."customers" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "name" "text" NOT NULL,
    "cpf_cnpj" "text",
    "email" "text",
    "phone" "text",
    "birth_date" "date",
    "cep" "text",
    "logradouro" "text",
    "numero" "text",
    "complemento" "text",
    "bairro" "text",
    "cidade" "text",
    "estado" "text",
    "notes" "text",
    "active" boolean DEFAULT true NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "loyalty_points" integer DEFAULT 0 NOT NULL,
    "tenant_id" "uuid"
);


--
-- Name: pdv_invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."pdv_invoices" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "number" "text" NOT NULL,
    "type" "public"."invoice_type" NOT NULL,
    "status" "public"."invoice_status" DEFAULT 'pendente'::"public"."invoice_status" NOT NULL,
    "customer_id" "uuid",
    "supplier_id" "uuid",
    "cash_register_id" "uuid",
    "subtotal" numeric(10,2) DEFAULT 0 NOT NULL,
    "discount" numeric(10,2) DEFAULT 0 NOT NULL,
    "total" numeric(10,2) DEFAULT 0 NOT NULL,
    "payment_method" "public"."payment_method" DEFAULT 'dinheiro'::"public"."payment_method",
    "notes" "text",
    "issued_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "created_by" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "tenant_id" "uuid",
    "installments" integer DEFAULT 1,
    "cancellation_reason" "text",
    "cancelled_at" timestamp with time zone,
    "cancelled_by" "uuid"
);


--
-- Name: customer_crm_metrics; Type: VIEW; Schema: public; Owner: -
--

CREATE OR REPLACE VIEW "public"."customer_crm_metrics" AS
 SELECT "c"."id",
    "c"."name",
    "c"."email",
    "c"."phone",
    "c"."cpf_cnpj",
    "c"."birth_date",
    "c"."active",
    "c"."created_at",
    "count"(DISTINCT "i"."id") AS "total_orders",
    COALESCE("sum"("i"."total"), (0)::numeric) AS "total_spent",
    "max"("i"."issued_at") AS "last_purchase_at",
    COALESCE("avg"("i"."total"), (0)::numeric) AS "avg_ticket",
    "count"(DISTINCT "n"."id") AS "total_notes"
   FROM (("public"."customers" "c"
     LEFT JOIN "public"."pdv_invoices" "i" ON ((("i"."customer_id" = "c"."id") AND ("i"."type" = 'saida'::"public"."invoice_type") AND ("i"."status" = 'emitida'::"public"."invoice_status"))))
     LEFT JOIN "public"."crm_notes" "n" ON (("n"."customer_id" = "c"."id")))
  GROUP BY "c"."id", "c"."name", "c"."email", "c"."phone", "c"."cpf_cnpj", "c"."birth_date", "c"."active", "c"."created_at";


--
-- Name: deliveries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."deliveries" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "invoice_id" "uuid",
    "customer_id" "uuid",
    "scheduled_date" "date" NOT NULL,
    "scheduled_time" time without time zone,
    "address" "text" NOT NULL,
    "city" "text",
    "state" "text",
    "driver_name" "text",
    "status" "text" DEFAULT 'agendado'::"text" NOT NULL,
    "notes" "text",
    "delivered_at" timestamp with time zone,
    "created_by" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "tenant_id" "uuid",
    CONSTRAINT "deliveries_status_check" CHECK (("status" = ANY (ARRAY['agendado'::"text", 'em_rota'::"text", 'entregue'::"text", 'cancelado'::"text", 'reagendado'::"text"])))
);


--
-- Name: employees; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."employees" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "tenant_id" "uuid" DEFAULT "public"."get_current_tenant_id"() NOT NULL,
    "name" "text" NOT NULL,
    "cpf" "text" NOT NULL,
    "email" "text",
    "phone" "text",
    "role" "text" NOT NULL,
    "department" "text" NOT NULL,
    "base_salary" numeric(12,2) DEFAULT 0 NOT NULL,
    "hired_at" "date" NOT NULL,
    "fired_at" "date",
    "status" "text" DEFAULT 'active'::"text" NOT NULL,
    "notes" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "employees_status_check" CHECK (("status" = ANY (ARRAY['active'::"text", 'inactive'::"text"])))
);


--
-- Name: fiscal_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."fiscal_config" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "emit_nfce" boolean DEFAULT false NOT NULL,
    "environment" "text" DEFAULT 'homologacao'::"text" NOT NULL,
    "series_nfe" "text" DEFAULT '1'::"text",
    "series_nfce" "text" DEFAULT '1'::"text",
    "next_nfe_number" integer DEFAULT 1 NOT NULL,
    "next_nfce_number" integer DEFAULT 1 NOT NULL,
    "csc_id" "text",
    "csc_token" "text",
    "certificate_name" "text",
    "certificate_expiry" "date",
    "boleto_bank" "text",
    "boleto_agency" "text",
    "boleto_account" "text",
    "boleto_cedente" "text",
    "boleto_convenio" "text",
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "tenant_id" "uuid",
    CONSTRAINT "fiscal_config_environment_check" CHECK (("environment" = ANY (ARRAY['homologacao'::"text", 'producao'::"text"])))
);


--
-- Name: goods_receipt_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."goods_receipt_items" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "receipt_id" "uuid" NOT NULL,
    "product_id" "uuid" NOT NULL,
    "quantity" numeric(10,3) NOT NULL,
    "cost_price" numeric(10,2) NOT NULL,
    "total_price" numeric(10,2) NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


--
-- Name: goods_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."goods_receipts" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "supplier_id" "uuid",
    "invoice_number" "text",
    "total_amount" numeric(10,2) DEFAULT 0 NOT NULL,
    "notes" "text",
    "received_by" "uuid",
    "received_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "tenant_id" "uuid"
);


--
-- Name: inauguration_banner; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."inauguration_banner" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "is_active" boolean DEFAULT true NOT NULL,
    "store_name" "text" DEFAULT 'Mundo Limpo'::"text" NOT NULL,
    "headline" "text" DEFAULT '🎉 Grande Inauguração!'::"text" NOT NULL,
    "subtitle" "text" DEFAULT 'Aproveite nossos preços especiais de lançamento!'::"text",
    "coupon_code" "text" DEFAULT 'INAUGURA10'::"text" NOT NULL,
    "discount_text" "text" DEFAULT '10% OFF na primeira compra'::"text" NOT NULL,
    "whatsapp_message" "text" DEFAULT 'Olá! Estou inaugurando a Mundo Limpo e tenho um presente especial para você! 🎉 Use o cupom *{coupon}* e ganhe {discount} na sua primeira compra. Válido até {expiry}. Acesse: {url}'::"text",
    "expires_at" timestamp with time zone,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


--
-- Name: label_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."label_config" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "width_mm" numeric DEFAULT 50 NOT NULL,
    "height_mm" numeric DEFAULT 25 NOT NULL,
    "preset" "text" DEFAULT 'custom'::"text" NOT NULL,
    "show_name" boolean DEFAULT true NOT NULL,
    "show_code" boolean DEFAULT true NOT NULL,
    "show_price" boolean DEFAULT true NOT NULL,
    "show_barcode" boolean DEFAULT true NOT NULL,
    "show_qr" boolean DEFAULT false NOT NULL,
    "logo_url" "text",
    "logo_position" "text" DEFAULT 'top'::"text" NOT NULL,
    "logo_size_pct" integer DEFAULT 30 NOT NULL,
    "cols" integer DEFAULT 3 NOT NULL,
    "rows" integer DEFAULT 6 NOT NULL,
    "paper_size" "text" DEFAULT 'A4'::"text" NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "bg_image_url" "text",
    "bg_opacity" integer DEFAULT 20
);


--
-- Name: loyalty_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."loyalty_config" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "points_per_real" numeric DEFAULT 1 NOT NULL,
    "real_per_point" numeric DEFAULT 0.01 NOT NULL,
    "min_redemption_points" integer DEFAULT 100 NOT NULL,
    "active" boolean DEFAULT true NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "tenant_id" "uuid"
);


--
-- Name: loyalty_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."loyalty_transactions" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "customer_id" "uuid" NOT NULL,
    "type" "text" NOT NULL,
    "points" integer NOT NULL,
    "balance_after" integer DEFAULT 0 NOT NULL,
    "reference_id" "uuid",
    "description" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "tenant_id" "uuid",
    CONSTRAINT "loyalty_transactions_type_check" CHECK (("type" = ANY (ARRAY['acumulo'::"text", 'resgate'::"text", 'expiracao'::"text", 'bonus_indicacao'::"text"])))
);


--
-- Name: marketplace_listings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."marketplace_listings" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "product_id" "uuid" NOT NULL,
    "marketplace" "text" NOT NULL,
    "listing_id" "text",
    "title" "text" NOT NULL,
    "listed_price" numeric DEFAULT 0 NOT NULL,
    "status" "text" DEFAULT 'ativo'::"text" NOT NULL,
    "url" "text",
    "last_sync_at" timestamp with time zone,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "tenant_id" "uuid",
    CONSTRAINT "marketplace_listings_marketplace_check" CHECK (("marketplace" = ANY (ARRAY['mercado_livre'::"text", 'shopee'::"text", 'amazon'::"text", 'americanas'::"text", 'outro'::"text"]))),
    CONSTRAINT "marketplace_listings_status_check" CHECK (("status" = ANY (ARRAY['ativo'::"text", 'pausado'::"text", 'encerrado'::"text", 'pendente'::"text"])))
);


--
-- Name: monthly_cycles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."monthly_cycles" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "month" integer NOT NULL,
    "year" integer NOT NULL,
    "type" "text" DEFAULT 'pagar'::"text" NOT NULL,
    "status" "text" DEFAULT 'aberto'::"text" NOT NULL,
    "pending_total" numeric DEFAULT 0 NOT NULL,
    "carried_over" numeric DEFAULT 0 NOT NULL,
    "notes" "text",
    "closed_at" timestamp with time zone,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "tenant_id" "uuid"
);


--
-- Name: notification_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."notification_settings" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "whatsapp_enabled" boolean DEFAULT false NOT NULL,
    "whatsapp_number" "text" DEFAULT ''::"text",
    "whatsapp_provider" "text" DEFAULT 'callmebot'::"text" NOT NULL,
    "whatsapp_api_key" "text" DEFAULT ''::"text",
    "whatsapp_webhook_url" "text" DEFAULT ''::"text",
    "message_template" "text" DEFAULT 'Olá! 🛒 Novo pedido #{order_number} de R${total} recebido no site. Cliente: {customer_name}. Status: {status}.'::"text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


--
-- Name: online_order_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."online_order_items" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "order_id" "uuid" NOT NULL,
    "product_id" "uuid" NOT NULL,
    "quantity" numeric(12,3) DEFAULT 1 NOT NULL,
    "unit_price" numeric(12,2) DEFAULT 0 NOT NULL,
    "total_price" numeric(12,2) DEFAULT 0 NOT NULL
);


--
-- Name: online_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."online_orders" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "customer_id" "uuid",
    "channel" "text" DEFAULT 'site'::"text" NOT NULL,
    "status" "text" DEFAULT 'pendente'::"text" NOT NULL,
    "subtotal" numeric(12,2) DEFAULT 0 NOT NULL,
    "discount" numeric(12,2) DEFAULT 0 NOT NULL,
    "total" numeric(12,2) DEFAULT 0 NOT NULL,
    "notes" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "tenant_id" "uuid",
    CONSTRAINT "online_orders_channel_check" CHECK (("channel" = ANY (ARRAY['whatsapp'::"text", 'site'::"text", 'app'::"text", 'instagram'::"text", 'ifood'::"text", 'outro'::"text"]))),
    CONSTRAINT "online_orders_status_check" CHECK (("status" = ANY (ARRAY['pendente'::"text", 'confirmado'::"text", 'em_preparacao'::"text", 'pronto'::"text", 'entregue'::"text", 'cancelado'::"text"])))
);


--
-- Name: order_number_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE IF NOT EXISTS "public"."order_number_seq"
    START WITH 1000
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."orders" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "order_number" "text" NOT NULL,
    "user_id" "uuid",
    "items" "jsonb" NOT NULL,
    "subtotal" numeric(12,2) NOT NULL,
    "freight_amount" numeric(12,2) DEFAULT 0 NOT NULL,
    "total_amount" numeric(12,2) NOT NULL,
    "currency" "text" DEFAULT 'brl'::"text" NOT NULL,
    "status" "public"."order_status" DEFAULT 'pending'::"public"."order_status" NOT NULL,
    "delivery_type" "text" DEFAULT 'delivery'::"text" NOT NULL,
    "delivery_address" "jsonb",
    "payment_method" "text" DEFAULT 'pix'::"text" NOT NULL,
    "stripe_session_id" "text",
    "stripe_payment_intent_id" "text",
    "customer_email" "text",
    "customer_name" "text",
    "customer_phone" "text",
    "pix_paid" boolean DEFAULT false,
    "notes" "text",
    "completed_at" timestamp with time zone,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "tenant_id" "uuid",
    "shipping_method_id" "uuid",
    "shipping_method_name" "text",
    "shipping_carrier" "text",
    "tracking_code" "text",
    "estimated_delivery" "text",
    "coupon_id" "uuid",
    "discount_amount" numeric(12,2) DEFAULT 0 NOT NULL
);


--
-- Name: payment_gateways; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."payment_gateways" (
    "id" "text" NOT NULL,
    "name" "text" NOT NULL,
    "description" "text",
    "icon" "text" DEFAULT 'CreditCard'::"text" NOT NULL,
    "is_active" boolean DEFAULT false NOT NULL,
    "config" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "sort_order" integer DEFAULT 0 NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "tenant_id" "uuid"
);


--
-- Name: payroll_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."payroll_entries" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "tenant_id" "uuid" DEFAULT "public"."get_current_tenant_id"() NOT NULL,
    "employee_id" "uuid" NOT NULL,
    "competence_month" integer NOT NULL,
    "competence_year" integer NOT NULL,
    "base_salary" numeric(12,2) DEFAULT 0 NOT NULL,
    "overtime_hours" numeric(6,2) DEFAULT 0 NOT NULL,
    "overtime_value" numeric(12,2) DEFAULT 0 NOT NULL,
    "advance" numeric(12,2) DEFAULT 0 NOT NULL,
    "transport_voucher" numeric(12,2) DEFAULT 0 NOT NULL,
    "inss_discount" numeric(12,2) DEFAULT 0 NOT NULL,
    "irrf_discount" numeric(12,2) DEFAULT 0 NOT NULL,
    "other_discounts" numeric(12,2) DEFAULT 0 NOT NULL,
    "gross_salary" numeric(12,2) DEFAULT 0 NOT NULL,
    "net_salary" numeric(12,2) DEFAULT 0 NOT NULL,
    "notes" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "payroll_entries_competence_month_check" CHECK ((("competence_month" >= 1) AND ("competence_month" <= 12)))
);


--
-- Name: pdv_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."pdv_categories" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "name" "text" NOT NULL,
    "description" "text",
    "color" "text" DEFAULT '#0A5C5A'::"text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "tenant_id" "uuid"
);


--
-- Name: pdv_certificates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."pdv_certificates" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "alias" "text" NOT NULL,
    "certificate_type" "text" DEFAULT 'A1'::"text" NOT NULL,
    "certificate_data" "text" DEFAULT ''::"text" NOT NULL,
    "password_hint" "text",
    "valid_from" timestamp with time zone,
    "valid_until" timestamp with time zone,
    "serial_number" "text",
    "issuer" "text",
    "subject" "text",
    "is_active" boolean DEFAULT true NOT NULL,
    "notes" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "tenant_id" "uuid",
    CONSTRAINT "pdv_certificates_certificate_type_check" CHECK (("certificate_type" = ANY (ARRAY['A1'::"text", 'A3'::"text"])))
);


--
-- Name: pdv_cupom_contingencia; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."pdv_cupom_contingencia" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "cupom_id" "uuid",
    "numero" "text" NOT NULL,
    "chave" "text",
    "xml" "text",
    "motivo" "text",
    "data_hora" timestamp with time zone DEFAULT "now"() NOT NULL,
    "resolvido" boolean DEFAULT false NOT NULL,
    "resolvido_em" timestamp with time zone,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


--
-- Name: pdv_cupom_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."pdv_cupom_items" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "cupom_id" "uuid" NOT NULL,
    "product_id" "uuid",
    "product_code" "text" NOT NULL,
    "product_name" "text" NOT NULL,
    "quantity" numeric(12,3) DEFAULT 0 NOT NULL,
    "unit" "text" DEFAULT 'UN'::"text" NOT NULL,
    "unit_price" numeric(12,2) DEFAULT 0 NOT NULL,
    "total_price" numeric(12,2) DEFAULT 0 NOT NULL,
    "discount" numeric(10,2) DEFAULT 0 NOT NULL,
    "icms_aliquota" numeric(5,2),
    "pis_aliquota" numeric(5,2),
    "cofins_aliquota" numeric(5,2),
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


--
-- Name: pdv_cupons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."pdv_cupons" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "invoice_id" "uuid",
    "invoice_number" "text" NOT NULL,
    "cupom_type" "text" DEFAULT 'cfe'::"text" NOT NULL,
    "serie" "text",
    "numero" "text",
    "chave_acesso" "text",
    "qr_code" "text",
    "status" "text" DEFAULT 'pendente'::"text" NOT NULL,
    "xml" "text",
    "pdf_url" "text",
    "envio_status" "text",
    "envio_msg" "text",
    "cancelado_em" timestamp with time zone,
    "cancelado_motivo" "text",
    "total" numeric(12,2) DEFAULT 0 NOT NULL,
    "cnpj_emitente" "text",
    "total_items" integer DEFAULT 0 NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "tenant_id" "uuid",
    CONSTRAINT "pdv_cupons_cupom_type_check" CHECK (("cupom_type" = ANY (ARRAY['cfe'::"text", 'nfce'::"text"]))),
    CONSTRAINT "pdv_cupons_status_check" CHECK (("status" = ANY (ARRAY['pendente'::"text", 'autorizado'::"text", 'cancelado'::"text", 'rejeitado'::"text", 'contingencia'::"text"])))
);


--
-- Name: pdv_fiscal_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."pdv_fiscal_config" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "company_name" "text" DEFAULT ''::"text" NOT NULL,
    "company_fantasy_name" "text",
    "cnpj" "text",
    "ie" "text",
    "im" "text",
    "cnae" "text",
    "crt" "text" DEFAULT '1'::"text" NOT NULL,
    "address" "text",
    "address_number" "text",
    "neighborhood" "text",
    "city_code" "text",
    "city_name" "text",
    "state" "text",
    "zip_code" "text",
    "phone" "text",
    "email" "text",
    "sat_enabled" boolean DEFAULT false NOT NULL,
    "sat_sign_ac" "text",
    "sat_activation_code" "text",
    "sat_environment" "text" DEFAULT 'homologacao'::"text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "tenant_id" "uuid",
    CONSTRAINT "pdv_fiscal_config_crt_check" CHECK (("crt" = ANY (ARRAY['1'::"text", '2'::"text", '3'::"text"]))),
    CONSTRAINT "pdv_fiscal_config_sat_environment_check" CHECK (("sat_environment" = ANY (ARRAY['homologacao'::"text", 'producao'::"text"])))
);


--
-- Name: pdv_invoice_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."pdv_invoice_items" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "invoice_id" "uuid" NOT NULL,
    "product_id" "uuid" NOT NULL,
    "quantity" numeric(10,3) NOT NULL,
    "unit_price" numeric(10,2) NOT NULL,
    "total_price" numeric(10,2) NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


--
-- Name: pdv_invoice_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE IF NOT EXISTS "public"."pdv_invoice_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pdv_invoices_view; Type: VIEW; Schema: public; Owner: -
--

CREATE OR REPLACE VIEW "public"."pdv_invoices_view" AS
 SELECT "id",
    "number" AS "invoice_number",
    "type",
    "status",
    "customer_id",
    "supplier_id",
    "cash_register_id",
    "subtotal",
    "discount",
    "total",
    "payment_method",
    "notes",
    "issued_at",
    "created_by",
    "created_at",
    "tenant_id",
    "installments"
   FROM "public"."pdv_invoices";


--
-- Name: pdv_payment_methods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."pdv_payment_methods" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "name" "text" NOT NULL,
    "code" "text" NOT NULL,
    "type" "text" DEFAULT 'outro'::"text" NOT NULL,
    "provider" "text",
    "icon" "text" DEFAULT 'CreditCard'::"text",
    "is_active" boolean DEFAULT true NOT NULL,
    "fee_percent" numeric(5,2) DEFAULT 0 NOT NULL,
    "fee_fixed" numeric(10,2) DEFAULT 0 NOT NULL,
    "terminal_id" "text",
    "notes" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "pdv_payment_methods_type_check" CHECK (("type" = ANY (ARRAY['dinheiro'::"text", 'cartao_debito'::"text", 'cartao_credito'::"text", 'pix'::"text", 'boleto'::"text", 'vale'::"text", 'crediario'::"text", 'outro'::"text"])))
);


--
-- Name: pdv_products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."pdv_products" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "code" "text" NOT NULL,
    "barcode" "text",
    "name" "text" NOT NULL,
    "description" "text",
    "category_id" "uuid",
    "unit" "text" DEFAULT 'UN'::"text" NOT NULL,
    "cost_price" numeric(10,2) DEFAULT 0 NOT NULL,
    "sale_price" numeric(10,2) DEFAULT 0 NOT NULL,
    "stock_qty" numeric(10,3) DEFAULT 0 NOT NULL,
    "stock_min" numeric(10,3) DEFAULT 5 NOT NULL,
    "active" boolean DEFAULT true NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "has_variants" boolean DEFAULT false NOT NULL,
    "track_batches" boolean DEFAULT false NOT NULL,
    "expiry_date" "date",
    "min_stock" integer DEFAULT 5 NOT NULL,
    "publish_to_site" boolean DEFAULT false NOT NULL,
    "site_product_id" "uuid",
    "is_fraction" boolean DEFAULT false NOT NULL,
    "fraction_unit" "text" DEFAULT 'KG'::"text",
    "wholesale_price" numeric(10,2) DEFAULT 0 NOT NULL,
    "retail_price" numeric(10,2) DEFAULT 0 NOT NULL,
    "ncm" "text",
    "cest" "text",
    "margin_percent" numeric(10,2) DEFAULT 0 NOT NULL,
    "markup_percent" numeric(10,2) DEFAULT 0 NOT NULL,
    "tenant_id" "uuid"
);


--
-- Name: pdv_stock_movements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."pdv_stock_movements" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "product_id" "uuid" NOT NULL,
    "type" "public"."movement_direction" NOT NULL,
    "quantity" numeric(10,3) NOT NULL,
    "previous_qty" numeric(10,3) NOT NULL,
    "new_qty" numeric(10,3) NOT NULL,
    "reference_id" "uuid",
    "reference_type" "text",
    "notes" "text",
    "created_by" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


--
-- Name: plan_limits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."plan_limits" (
    "plan_name" "text" NOT NULL,
    "max_products" integer DEFAULT 50,
    "max_categories" integer DEFAULT 10,
    "max_users" integer DEFAULT 2,
    "max_orders_per_month" integer DEFAULT 100,
    "has_white_label" boolean DEFAULT false,
    "has_custom_domain" boolean DEFAULT false,
    "has_advanced_reports" boolean DEFAULT false,
    "has_api_access" boolean DEFAULT false,
    "price_monthly" numeric(10,2) DEFAULT 0,
    "created_at" timestamp with time zone DEFAULT "now"()
);


--
-- Name: product_batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."product_batches" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "product_id" "uuid" NOT NULL,
    "batch_number" "text" NOT NULL,
    "manufacturing_date" "date",
    "expiry_date" "date",
    "initial_qty" numeric DEFAULT 0 NOT NULL,
    "current_qty" numeric DEFAULT 0 NOT NULL,
    "cost_price" numeric DEFAULT 0 NOT NULL,
    "receipt_id" "uuid",
    "notes" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "tenant_id" "uuid"
);


--
-- Name: product_variants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."product_variants" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "product_id" "uuid" NOT NULL,
    "variant_name" "text" NOT NULL,
    "color" "text",
    "size" "text",
    "flavor" "text",
    "barcode" "text",
    "stock_qty" numeric DEFAULT 0 NOT NULL,
    "cost_price" numeric DEFAULT 0 NOT NULL,
    "sale_price" numeric,
    "active" boolean DEFAULT true NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "tenant_id" "uuid"
);


--
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."products" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "name" "text" NOT NULL,
    "slug" "text" NOT NULL,
    "description" "text",
    "price" numeric(12,2) NOT NULL,
    "compare_at_price" numeric(12,2),
    "category_id" "uuid",
    "images" "jsonb" DEFAULT '[]'::"jsonb" NOT NULL,
    "stock_quantity" integer DEFAULT 0 NOT NULL,
    "is_available" boolean DEFAULT true NOT NULL,
    "is_featured" boolean DEFAULT false NOT NULL,
    "attributes" "jsonb" DEFAULT '{}'::"jsonb",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "tenant_id" "uuid",
    "code" "text",
    "cost_price" numeric(10,2) DEFAULT 0,
    "barcode" "text",
    "unit" "text" DEFAULT 'un'::"text",
    "pdv_product_id" "uuid",
    "weight" numeric(10,3) DEFAULT NULL::numeric,
    "dimensions" "text",
    "brand" "text",
    "sku" "text",
    "expiry_date" "date",
    "video_url" "text"
);


--
-- Name: profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."profiles" (
    "id" "uuid" NOT NULL,
    "email" "text",
    "full_name" "text",
    "phone" "text",
    "avatar_url" "text",
    "role" "public"."user_role" DEFAULT 'user'::"public"."user_role" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "username" "text",
    "active" boolean DEFAULT true NOT NULL,
    "tenant_id" "uuid"
);


--
-- Name: promotions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."promotions" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "name" "text" NOT NULL,
    "description" "text",
    "discount_type" "text" NOT NULL,
    "discount_value" numeric NOT NULL,
    "starts_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "ends_at" timestamp with time zone NOT NULL,
    "scope" "text" DEFAULT 'all'::"text" NOT NULL,
    "scope_ids" "uuid"[] DEFAULT '{}'::"uuid"[],
    "banner_text" "text",
    "banner_color" "text" DEFAULT '#DC2626'::"text",
    "is_active" boolean DEFAULT true NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "promo_type" "text" DEFAULT 'standard'::"text" NOT NULL,
    "buy_quantity" integer,
    "get_quantity" integer,
    "progressive_tiers" "jsonb",
    "tenant_id" "uuid",
    CONSTRAINT "promotions_dates_check" CHECK (("ends_at" > "starts_at")),
    CONSTRAINT "promotions_discount_type_check" CHECK (("discount_type" = ANY (ARRAY['percent'::"text", 'fixed'::"text"]))),
    CONSTRAINT "promotions_discount_value_check" CHECK (("discount_value" > (0)::numeric)),
    CONSTRAINT "promotions_promo_type_check" CHECK (("promo_type" = ANY (ARRAY['standard'::"text", 'buy_x_get_y'::"text", 'progressive'::"text"]))),
    CONSTRAINT "promotions_scope_check" CHECK (("scope" = ANY (ARRAY['all'::"text", 'categories'::"text", 'products'::"text"])))
);


--
-- Name: public_profiles; Type: VIEW; Schema: public; Owner: -
--

CREATE OR REPLACE VIEW "public"."public_profiles" AS
 SELECT "id",
    "role",
    "full_name",
    "avatar_url"
   FROM "public"."profiles";


--
-- Name: referrals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."referrals" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "referrer_id" "uuid" NOT NULL,
    "referred_id" "uuid" NOT NULL,
    "bonus_type" "text" DEFAULT 'pontos'::"text" NOT NULL,
    "bonus_value" numeric DEFAULT 0 NOT NULL,
    "status" "text" DEFAULT 'pendente'::"text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "tenant_id" "uuid",
    CONSTRAINT "referrals_bonus_type_check" CHECK (("bonus_type" = ANY (ARRAY['pontos'::"text", 'desconto'::"text", 'credito'::"text"]))),
    CONSTRAINT "referrals_status_check" CHECK (("status" = ANY (ARRAY['pendente'::"text", 'confirmado'::"text", 'cancelado'::"text"])))
);


--
-- Name: return_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."return_items" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "return_id" "uuid" NOT NULL,
    "product_id" "uuid" NOT NULL,
    "quantity" numeric DEFAULT 1 NOT NULL,
    "unit_price" numeric DEFAULT 0 NOT NULL,
    "total_price" numeric DEFAULT 0 NOT NULL,
    "condition" "text" DEFAULT 'bom'::"text",
    "restock" boolean DEFAULT true NOT NULL,
    CONSTRAINT "return_items_condition_check" CHECK (("condition" = ANY (ARRAY['bom'::"text", 'danificado'::"text", 'defeituoso'::"text"])))
);


--
-- Name: returns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."returns" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "original_invoice_id" "uuid",
    "customer_id" "uuid",
    "return_date" "date" DEFAULT CURRENT_DATE NOT NULL,
    "reason" "text" NOT NULL,
    "resolution" "text" DEFAULT 'credito'::"text" NOT NULL,
    "total_amount" numeric DEFAULT 0 NOT NULL,
    "credit_issued" numeric DEFAULT 0 NOT NULL,
    "notes" "text",
    "processed_by" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "tenant_id" "uuid",
    CONSTRAINT "returns_resolution_check" CHECK (("resolution" = ANY (ARRAY['credito'::"text", 'troca'::"text", 'reembolso'::"text"])))
);


--
-- Name: seller_commissions_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."seller_commissions_config" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "profile_id" "uuid" NOT NULL,
    "commission_pct" numeric DEFAULT 0 NOT NULL,
    "active" boolean DEFAULT true NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "tenant_id" "uuid",
    CONSTRAINT "seller_commissions_config_commission_pct_check" CHECK ((("commission_pct" >= (0)::numeric) AND ("commission_pct" <= (100)::numeric)))
);


--
-- Name: shipping_methods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."shipping_methods" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "tenant_id" "uuid",
    "name" "text" NOT NULL,
    "carrier" "text" DEFAULT 'custom'::"text" NOT NULL,
    "code" "text",
    "type" "text" DEFAULT 'fixed'::"text" NOT NULL,
    "price" numeric(10,2) DEFAULT 0 NOT NULL,
    "min_days" integer DEFAULT 1 NOT NULL,
    "max_days" integer DEFAULT 10 NOT NULL,
    "is_active" boolean DEFAULT true NOT NULL,
    "sort_order" integer DEFAULT 0 NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"()
);


--
-- Name: site_coupon_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."site_coupon_config" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "show_banner" boolean DEFAULT false NOT NULL,
    "code" "text" DEFAULT 'BEMVINDO'::"text" NOT NULL,
    "discount_percentage" integer DEFAULT 10 NOT NULL,
    "min_order_value" numeric(10,2) DEFAULT 0 NOT NULL,
    "expires_at" timestamp with time zone,
    "banner_headline" "text" DEFAULT 'Use o cupom {code} e ganhe {discount}% de desconto!'::"text" NOT NULL,
    "banner_subtitle" "text" DEFAULT 'Válido por tempo limitado. Aproveite!'::"text",
    "bg_color" "text" DEFAULT '#10b981'::"text" NOT NULL,
    "text_color" "text" DEFAULT '#ffffff'::"text" NOT NULL,
    "button_text" "text" DEFAULT 'Copiar Cupom'::"text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


--
-- Name: stock_movements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."stock_movements" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "product_id" "uuid" NOT NULL,
    "type" "public"."stock_movement_type" NOT NULL,
    "quantity" integer NOT NULL,
    "previous_quantity" integer NOT NULL,
    "new_quantity" integer NOT NULL,
    "notes" "text",
    "order_id" "uuid",
    "created_by" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "tenant_id" "uuid"
);


--
-- Name: stock_transfer_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."stock_transfer_items" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "transfer_id" "uuid" NOT NULL,
    "product_id" "uuid" NOT NULL,
    "quantity" numeric DEFAULT 0 NOT NULL
);


--
-- Name: stock_transfers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."stock_transfers" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "from_branch_id" "uuid",
    "to_branch_id" "uuid",
    "status" "text" DEFAULT 'pendente'::"text" NOT NULL,
    "notes" "text",
    "transferred_by" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "confirmed_at" timestamp with time zone,
    "tenant_id" "uuid",
    CONSTRAINT "stock_transfers_status_check" CHECK (("status" = ANY (ARRAY['pendente'::"text", 'confirmado'::"text", 'cancelado'::"text"])))
);


--
-- Name: store_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."store_settings" (
    "id" integer DEFAULT 1 NOT NULL,
    "store_name" "text" DEFAULT 'Minha Loja'::"text" NOT NULL,
    "store_logo_url" "text",
    "store_address" "text",
    "store_city" "text",
    "store_state" "text",
    "store_cep" "text",
    "store_phone" "text",
    "store_email" "text",
    "pix_key" "text",
    "pix_key_type" "text" DEFAULT 'cpf'::"text",
    "low_stock_threshold" integer DEFAULT 5 NOT NULL,
    "freight_base_value" numeric(10,2) DEFAULT 10.00,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "store_description" "text",
    "store_zip" "text",
    "store_features" "jsonb" DEFAULT '[{"desc": "Todo o Brasil", "icon": "Truck", "title": "Entrega Rápida"}, {"desc": "Pagamento protegido", "icon": "Shield", "title": "Compra Segura"}, {"desc": "Sem burocracia", "icon": "RefreshCw", "title": "Troca Fácil"}, {"desc": "Sempre disponível", "icon": "MessageCircle", "title": "Suporte 24h"}]'::"jsonb",
    "tenant_id" "uuid",
    "correios_cep_origin" "text",
    "correios_contract" "text",
    "correios_password" "text",
    "correios_pac_enabled" boolean DEFAULT true NOT NULL,
    "correios_sedex_enabled" boolean DEFAULT true NOT NULL,
    "free_shipping_threshold" numeric(10,2),
    "default_weight_kg" numeric(6,3) DEFAULT 0.5 NOT NULL,
    "default_length_cm" integer DEFAULT 20 NOT NULL,
    "default_width_cm" integer DEFAULT 15 NOT NULL,
    "default_height_cm" integer DEFAULT 10 NOT NULL
);


--
-- Name: subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."subscriptions" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "trial_days" integer DEFAULT 7 NOT NULL,
    "trial_ends_at" timestamp with time zone DEFAULT ("now"() + '7 days'::interval),
    "expires_at" timestamp with time zone DEFAULT ("now"() + '37 days'::interval),
    "status" "text" DEFAULT 'trial'::"text" NOT NULL,
    "plan_name" "text" DEFAULT 'Mensal'::"text" NOT NULL,
    "monthly_price" numeric(10,2) DEFAULT 49.90,
    "last_billing_date" timestamp with time zone DEFAULT "now"(),
    "created_at" timestamp with time zone DEFAULT "now"(),
    "plan_level" "text" DEFAULT 'prata'::"text",
    "tenant_id" "uuid",
    CONSTRAINT "subscriptions_plan_level_check" CHECK (("plan_level" = ANY (ARRAY['prata'::"text", 'ouro'::"text", 'diamond'::"text"]))),
    CONSTRAINT "subscriptions_status_check" CHECK (("status" = ANY (ARRAY['active'::"text", 'expired'::"text", 'trial'::"text", 'canceled'::"text"])))
);


--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."suppliers" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "razao_social" "text" NOT NULL,
    "nome_fantasia" "text",
    "cnpj" "text",
    "email" "text",
    "phone" "text",
    "contact_name" "text",
    "cep" "text",
    "logradouro" "text",
    "numero" "text",
    "complemento" "text",
    "bairro" "text",
    "cidade" "text",
    "estado" "text",
    "notes" "text",
    "active" boolean DEFAULT true NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "tenant_id" "uuid"
);


--
-- Name: tenants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."tenants" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "name" "text" NOT NULL,
    "slug" "text" NOT NULL,
    "domain" "text",
    "logo_url" "text",
    "primary_color" "text" DEFAULT '#0f172a'::"text",
    "secondary_color" "text" DEFAULT '#64748b'::"text",
    "accent_color" "text" DEFAULT '#f59e0b'::"text",
    "description" "text",
    "phone" "text",
    "email" "text",
    "address" "text",
    "settings" "jsonb" DEFAULT '{}'::"jsonb",
    "plan" "text" DEFAULT 'free'::"text",
    "status" "text" DEFAULT 'active'::"text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "plan_expires_at" timestamp with time zone
);


--
-- Name: theme_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."theme_settings" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "primary_color" "text" DEFAULT '#2563EB'::"text" NOT NULL,
    "secondary_color" "text" DEFAULT '#7C3AED'::"text" NOT NULL,
    "accent_color" "text" DEFAULT '#F59E0B'::"text" NOT NULL,
    "background_color" "text" DEFAULT '#FAFAFA'::"text" NOT NULL,
    "preset_name" "text" DEFAULT 'custom'::"text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "font_family" "text" DEFAULT 'Inter'::"text" NOT NULL,
    "border_radius" "text" DEFAULT '8'::"text" NOT NULL,
    "shadow_style" "text" DEFAULT 'md'::"text" NOT NULL,
    "button_style" "text" DEFAULT 'solid'::"text" NOT NULL,
    "tenant_id" "uuid"
);


--
-- Name: time_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."time_records" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "tenant_id" "uuid" DEFAULT "public"."get_current_tenant_id"() NOT NULL,
    "employee_id" "uuid" NOT NULL,
    "punch_type" "text" NOT NULL,
    "punched_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "notes" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "time_records_punch_type_check" CHECK (("punch_type" = ANY (ARRAY['entry'::"text", 'lunch_start'::"text", 'lunch_end'::"text", 'exit'::"text"])))
);


--
-- Name: transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."transactions" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "type" "public"."transaction_type" NOT NULL,
    "category" "text" NOT NULL,
    "description" "text" NOT NULL,
    "amount" numeric(10,2) NOT NULL,
    "payment_method" "public"."payment_method" DEFAULT 'outros'::"public"."payment_method",
    "supplier_id" "uuid",
    "invoice_id" "uuid",
    "transaction_date" "date" DEFAULT CURRENT_DATE NOT NULL,
    "notes" "text",
    "created_by" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "tenant_id" "uuid",
    "installments" integer DEFAULT 1
);


--
-- Name: user_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."user_permissions" (
    "user_id" "uuid" NOT NULL,
    "permissions" "text"[] DEFAULT '{}'::"text"[],
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"()
);


--
-- Name: warranties; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."warranties" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "invoice_id" "uuid",
    "product_id" "uuid" NOT NULL,
    "customer_id" "uuid",
    "warranty_months" integer DEFAULT 12 NOT NULL,
    "start_date" "date" DEFAULT CURRENT_DATE NOT NULL,
    "end_date" "date" NOT NULL,
    "status" "text" DEFAULT 'ativa'::"text" NOT NULL,
    "notes" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "tenant_id" "uuid",
    "product_name" "text",
    "customer_name" "text",
    "invoice_number" "text",
    CONSTRAINT "warranties_status_check" CHECK (("status" = ANY (ARRAY['ativa'::"text", 'expirada'::"text", 'acionada'::"text"])))
);


--
-- Name: wishlist; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS "public"."wishlist" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "product_id" "uuid" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "tenant_id" "uuid"
);


--
-- Name: accounting_accounts accounting_accounts_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'accounting_accounts_code_key'
      AND n.nspname = 'public'
      AND c.relname = 'accounting_accounts'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."accounting_accounts"
    ADD CONSTRAINT "accounting_accounts_code_key" UNIQUE ("code");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: accounting_accounts accounting_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'accounting_accounts_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'accounting_accounts'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."accounting_accounts"
    ADD CONSTRAINT "accounting_accounts_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'appointments_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'appointments'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."appointments"
    ADD CONSTRAINT "appointments_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'audit_logs_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'audit_logs'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."audit_logs"
    ADD CONSTRAINT "audit_logs_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: bank_statements bank_statements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'bank_statements_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'bank_statements'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."bank_statements"
    ADD CONSTRAINT "bank_statements_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: banners banners_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'banners_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'banners'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."banners"
    ADD CONSTRAINT "banners_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: bill_installments bill_installments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'bill_installments_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'bill_installments'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."bill_installments"
    ADD CONSTRAINT "bill_installments_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: bills bills_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'bills_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'bills'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."bills"
    ADD CONSTRAINT "bills_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: bookable_resources bookable_resources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'bookable_resources_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'bookable_resources'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."bookable_resources"
    ADD CONSTRAINT "bookable_resources_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: branches branches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'branches_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'branches'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."branches"
    ADD CONSTRAINT "branches_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: cash_registers cash_registers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'cash_registers_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'cash_registers'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."cash_registers"
    ADD CONSTRAINT "cash_registers_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'categories_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'categories'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."categories"
    ADD CONSTRAINT "categories_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: categories categories_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'categories_slug_key'
      AND n.nspname = 'public'
      AND c.relname = 'categories'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."categories"
    ADD CONSTRAINT "categories_slug_key" UNIQUE ("slug");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: chat_messages chat_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'chat_messages_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'chat_messages'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."chat_messages"
    ADD CONSTRAINT "chat_messages_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: commissions commissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'commissions_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'commissions'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."commissions"
    ADD CONSTRAINT "commissions_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: company company_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'company_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'company'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."company"
    ADD CONSTRAINT "company_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: coupon_usages coupon_usages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'coupon_usages_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'coupon_usages'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."coupon_usages"
    ADD CONSTRAINT "coupon_usages_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: coupons coupons_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'coupons_code_key'
      AND n.nspname = 'public'
      AND c.relname = 'coupons'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."coupons"
    ADD CONSTRAINT "coupons_code_key" UNIQUE ("code");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: coupons coupons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'coupons_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'coupons'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."coupons"
    ADD CONSTRAINT "coupons_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: crm_notes crm_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'crm_notes_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'crm_notes'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."crm_notes"
    ADD CONSTRAINT "crm_notes_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'customers_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'customers'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."customers"
    ADD CONSTRAINT "customers_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: deliveries deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'deliveries_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'deliveries'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."deliveries"
    ADD CONSTRAINT "deliveries_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'employees_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'employees'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."employees"
    ADD CONSTRAINT "employees_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: employees employees_tenant_id_cpf_key; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'employees_tenant_id_cpf_key'
      AND n.nspname = 'public'
      AND c.relname = 'employees'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."employees"
    ADD CONSTRAINT "employees_tenant_id_cpf_key" UNIQUE ("tenant_id", "cpf");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: fiscal_config fiscal_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'fiscal_config_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'fiscal_config'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."fiscal_config"
    ADD CONSTRAINT "fiscal_config_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: goods_receipt_items goods_receipt_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'goods_receipt_items_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'goods_receipt_items'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."goods_receipt_items"
    ADD CONSTRAINT "goods_receipt_items_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: goods_receipts goods_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'goods_receipts_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'goods_receipts'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."goods_receipts"
    ADD CONSTRAINT "goods_receipts_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: inauguration_banner inauguration_banner_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'inauguration_banner_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'inauguration_banner'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."inauguration_banner"
    ADD CONSTRAINT "inauguration_banner_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: label_config label_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'label_config_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'label_config'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."label_config"
    ADD CONSTRAINT "label_config_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: loyalty_config loyalty_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'loyalty_config_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'loyalty_config'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."loyalty_config"
    ADD CONSTRAINT "loyalty_config_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: loyalty_transactions loyalty_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'loyalty_transactions_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'loyalty_transactions'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."loyalty_transactions"
    ADD CONSTRAINT "loyalty_transactions_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: marketplace_listings marketplace_listings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'marketplace_listings_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'marketplace_listings'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."marketplace_listings"
    ADD CONSTRAINT "marketplace_listings_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: monthly_cycles monthly_cycles_month_year_type_key; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'monthly_cycles_month_year_type_key'
      AND n.nspname = 'public'
      AND c.relname = 'monthly_cycles'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."monthly_cycles"
    ADD CONSTRAINT "monthly_cycles_month_year_type_key" UNIQUE ("month", "year", "type");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: monthly_cycles monthly_cycles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'monthly_cycles_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'monthly_cycles'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."monthly_cycles"
    ADD CONSTRAINT "monthly_cycles_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: notification_settings notification_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'notification_settings_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'notification_settings'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."notification_settings"
    ADD CONSTRAINT "notification_settings_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: online_order_items online_order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'online_order_items_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'online_order_items'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."online_order_items"
    ADD CONSTRAINT "online_order_items_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: online_orders online_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'online_orders_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'online_orders'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."online_orders"
    ADD CONSTRAINT "online_orders_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: orders orders_order_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'orders_order_number_key'
      AND n.nspname = 'public'
      AND c.relname = 'orders'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."orders"
    ADD CONSTRAINT "orders_order_number_key" UNIQUE ("order_number");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'orders_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'orders'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."orders"
    ADD CONSTRAINT "orders_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: orders orders_stripe_session_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'orders_stripe_session_id_key'
      AND n.nspname = 'public'
      AND c.relname = 'orders'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."orders"
    ADD CONSTRAINT "orders_stripe_session_id_key" UNIQUE ("stripe_session_id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: payment_gateways payment_gateways_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'payment_gateways_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'payment_gateways'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."payment_gateways"
    ADD CONSTRAINT "payment_gateways_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: payroll_entries payroll_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'payroll_entries_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'payroll_entries'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."payroll_entries"
    ADD CONSTRAINT "payroll_entries_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: payroll_entries payroll_entries_tenant_id_employee_id_competence_month_comp_key; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'payroll_entries_tenant_id_employee_id_competence_month_comp_key'
      AND n.nspname = 'public'
      AND c.relname = 'payroll_entries'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."payroll_entries"
    ADD CONSTRAINT "payroll_entries_tenant_id_employee_id_competence_month_comp_key" UNIQUE ("tenant_id", "employee_id", "competence_month", "competence_year");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_categories pdv_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'pdv_categories_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_categories'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."pdv_categories"
    ADD CONSTRAINT "pdv_categories_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_certificates pdv_certificates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'pdv_certificates_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_certificates'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."pdv_certificates"
    ADD CONSTRAINT "pdv_certificates_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_cupom_contingencia pdv_cupom_contingencia_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'pdv_cupom_contingencia_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_cupom_contingencia'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."pdv_cupom_contingencia"
    ADD CONSTRAINT "pdv_cupom_contingencia_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_cupom_items pdv_cupom_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'pdv_cupom_items_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_cupom_items'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."pdv_cupom_items"
    ADD CONSTRAINT "pdv_cupom_items_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_cupons pdv_cupons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'pdv_cupons_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_cupons'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."pdv_cupons"
    ADD CONSTRAINT "pdv_cupons_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_fiscal_config pdv_fiscal_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'pdv_fiscal_config_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_fiscal_config'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."pdv_fiscal_config"
    ADD CONSTRAINT "pdv_fiscal_config_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_invoice_items pdv_invoice_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'pdv_invoice_items_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_invoice_items'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."pdv_invoice_items"
    ADD CONSTRAINT "pdv_invoice_items_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_invoices pdv_invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'pdv_invoices_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_invoices'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."pdv_invoices"
    ADD CONSTRAINT "pdv_invoices_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_payment_methods pdv_payment_methods_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'pdv_payment_methods_code_key'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_payment_methods'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."pdv_payment_methods"
    ADD CONSTRAINT "pdv_payment_methods_code_key" UNIQUE ("code");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_payment_methods pdv_payment_methods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'pdv_payment_methods_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_payment_methods'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."pdv_payment_methods"
    ADD CONSTRAINT "pdv_payment_methods_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_products pdv_products_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'pdv_products_code_key'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_products'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."pdv_products"
    ADD CONSTRAINT "pdv_products_code_key" UNIQUE ("code");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_products pdv_products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'pdv_products_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_products'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."pdv_products"
    ADD CONSTRAINT "pdv_products_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_stock_movements pdv_stock_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'pdv_stock_movements_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_stock_movements'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."pdv_stock_movements"
    ADD CONSTRAINT "pdv_stock_movements_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: plan_limits plan_limits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'plan_limits_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'plan_limits'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."plan_limits"
    ADD CONSTRAINT "plan_limits_pkey" PRIMARY KEY ("plan_name");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: product_batches product_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'product_batches_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'product_batches'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."product_batches"
    ADD CONSTRAINT "product_batches_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: product_variants product_variants_barcode_key; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'product_variants_barcode_key'
      AND n.nspname = 'public'
      AND c.relname = 'product_variants'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."product_variants"
    ADD CONSTRAINT "product_variants_barcode_key" UNIQUE ("barcode");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: product_variants product_variants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'product_variants_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'product_variants'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."product_variants"
    ADD CONSTRAINT "product_variants_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'products_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'products'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."products"
    ADD CONSTRAINT "products_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: products products_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'products_slug_key'
      AND n.nspname = 'public'
      AND c.relname = 'products'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."products"
    ADD CONSTRAINT "products_slug_key" UNIQUE ("slug");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'profiles_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'profiles'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."profiles"
    ADD CONSTRAINT "profiles_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: promotions promotions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'promotions_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'promotions'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."promotions"
    ADD CONSTRAINT "promotions_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: referrals referrals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'referrals_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'referrals'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."referrals"
    ADD CONSTRAINT "referrals_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: return_items return_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'return_items_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'return_items'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."return_items"
    ADD CONSTRAINT "return_items_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: returns returns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'returns_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'returns'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."returns"
    ADD CONSTRAINT "returns_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: seller_commissions_config seller_commissions_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'seller_commissions_config_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'seller_commissions_config'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."seller_commissions_config"
    ADD CONSTRAINT "seller_commissions_config_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: seller_commissions_config seller_commissions_config_profile_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'seller_commissions_config_profile_id_key'
      AND n.nspname = 'public'
      AND c.relname = 'seller_commissions_config'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."seller_commissions_config"
    ADD CONSTRAINT "seller_commissions_config_profile_id_key" UNIQUE ("profile_id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: shipping_methods shipping_methods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'shipping_methods_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'shipping_methods'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."shipping_methods"
    ADD CONSTRAINT "shipping_methods_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: site_coupon_config site_coupon_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'site_coupon_config_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'site_coupon_config'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."site_coupon_config"
    ADD CONSTRAINT "site_coupon_config_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: stock_movements stock_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'stock_movements_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'stock_movements'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."stock_movements"
    ADD CONSTRAINT "stock_movements_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: stock_transfer_items stock_transfer_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'stock_transfer_items_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'stock_transfer_items'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."stock_transfer_items"
    ADD CONSTRAINT "stock_transfer_items_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: stock_transfers stock_transfers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'stock_transfers_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'stock_transfers'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."stock_transfers"
    ADD CONSTRAINT "stock_transfers_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: store_settings store_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'store_settings_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'store_settings'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."store_settings"
    ADD CONSTRAINT "store_settings_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'subscriptions_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'subscriptions'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."subscriptions"
    ADD CONSTRAINT "subscriptions_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'suppliers_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'suppliers'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."suppliers"
    ADD CONSTRAINT "suppliers_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'tenants_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'tenants'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."tenants"
    ADD CONSTRAINT "tenants_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: tenants tenants_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'tenants_slug_key'
      AND n.nspname = 'public'
      AND c.relname = 'tenants'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."tenants"
    ADD CONSTRAINT "tenants_slug_key" UNIQUE ("slug");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: theme_settings theme_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'theme_settings_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'theme_settings'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."theme_settings"
    ADD CONSTRAINT "theme_settings_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: time_records time_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'time_records_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'time_records'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."time_records"
    ADD CONSTRAINT "time_records_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'transactions_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'transactions'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."transactions"
    ADD CONSTRAINT "transactions_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: user_permissions user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'user_permissions_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'user_permissions'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."user_permissions"
    ADD CONSTRAINT "user_permissions_pkey" PRIMARY KEY ("user_id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: warranties warranties_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'warranties_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'warranties'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."warranties"
    ADD CONSTRAINT "warranties_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: wishlist wishlist_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'wishlist_pkey'
      AND n.nspname = 'public'
      AND c.relname = 'wishlist'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."wishlist"
    ADD CONSTRAINT "wishlist_pkey" PRIMARY KEY ("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: wishlist wishlist_user_id_product_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'wishlist_user_id_product_id_key'
      AND n.nspname = 'public'
      AND c.relname = 'wishlist'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."wishlist"
    ADD CONSTRAINT "wishlist_user_id_product_id_key" UNIQUE ("user_id", "product_id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: idx_appointments_resource; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS "idx_appointments_resource" ON "public"."appointments" USING "btree" ("resource_id");


--
-- Name: idx_appointments_tenant_dates; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS "idx_appointments_tenant_dates" ON "public"."appointments" USING "btree" ("tenant_id", "starts_at", "ends_at");


--
-- Name: idx_batches_expiry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS "idx_batches_expiry" ON "public"."product_batches" USING "btree" ("expiry_date");


--
-- Name: idx_batches_product; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS "idx_batches_product" ON "public"."product_batches" USING "btree" ("product_id");


--
-- Name: idx_cash_reg_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS "idx_cash_reg_status" ON "public"."cash_registers" USING "btree" ("status");


--
-- Name: idx_categories_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS "idx_categories_tenant_id" ON "public"."categories" USING "btree" ("tenant_id");


--
-- Name: idx_chat_conversation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS "idx_chat_conversation" ON "public"."chat_messages" USING "btree" ("conversation_id");


--
-- Name: idx_coupons_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS "idx_coupons_tenant_id" ON "public"."coupons" USING "btree" ("tenant_id");


--
-- Name: idx_deliveries_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS "idx_deliveries_date" ON "public"."deliveries" USING "btree" ("scheduled_date");


--
-- Name: idx_employees_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS "idx_employees_tenant" ON "public"."employees" USING "btree" ("tenant_id");


--
-- Name: idx_installments_bill; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS "idx_installments_bill" ON "public"."bill_installments" USING "btree" ("bill_id");


--
-- Name: idx_installments_due; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS "idx_installments_due" ON "public"."bill_installments" USING "btree" ("due_date");


--
-- Name: idx_orders_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS "idx_orders_status" ON "public"."orders" USING "btree" ("status");


--
-- Name: idx_orders_stripe_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS "idx_orders_stripe_session" ON "public"."orders" USING "btree" ("stripe_session_id");


--
-- Name: idx_orders_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS "idx_orders_tenant_id" ON "public"."orders" USING "btree" ("tenant_id");


--
-- Name: idx_orders_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS "idx_orders_user" ON "public"."orders" USING "btree" ("user_id");


--
-- Name: idx_payroll_entries_tenant_comp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS "idx_payroll_entries_tenant_comp" ON "public"."payroll_entries" USING "btree" ("tenant_id", "competence_year", "competence_month");


--
-- Name: idx_pdv_certificates_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS "idx_pdv_certificates_active" ON "public"."pdv_certificates" USING "btree" ("is_active");


--
-- Name: idx_pdv_cupom_contingencia_resolvido; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS "idx_pdv_cupom_contingencia_resolvido" ON "public"."pdv_cupom_contingencia" USING "btree" ("resolvido");


--
-- Name: idx_pdv_cupom_items_cupom_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS "idx_pdv_cupom_items_cupom_id" ON "public"."pdv_cupom_items" USING "btree" ("cupom_id");


--
-- Name: idx_pdv_cupons_chave; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS "idx_pdv_cupons_chave" ON "public"."pdv_cupons" USING "btree" ("chave_acesso");


--
-- Name: idx_pdv_cupons_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS "idx_pdv_cupons_created" ON "public"."pdv_cupons" USING "btree" ("created_at");


--
-- Name: idx_pdv_cupons_invoice_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS "idx_pdv_cupons_invoice_id" ON "public"."pdv_cupons" USING "btree" ("invoice_id");


--
-- Name: idx_pdv_cupons_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS "idx_pdv_cupons_status" ON "public"."pdv_cupons" USING "btree" ("status");


--
-- Name: idx_pdv_invoice_items_inv; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS "idx_pdv_invoice_items_inv" ON "public"."pdv_invoice_items" USING "btree" ("invoice_id");


--
-- Name: idx_pdv_invoices_issued; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS "idx_pdv_invoices_issued" ON "public"."pdv_invoices" USING "btree" ("issued_at");


--
-- Name: idx_pdv_invoices_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS "idx_pdv_invoices_type" ON "public"."pdv_invoices" USING "btree" ("type");


--
-- Name: idx_pdv_payment_methods_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS "idx_pdv_payment_methods_active" ON "public"."pdv_payment_methods" USING "btree" ("is_active");


--
-- Name: idx_pdv_products_barcode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS "idx_pdv_products_barcode" ON "public"."pdv_products" USING "btree" ("barcode");


--
-- Name: idx_pdv_products_cat; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS "idx_pdv_products_cat" ON "public"."pdv_products" USING "btree" ("category_id");


--
-- Name: idx_pdv_products_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS "idx_pdv_products_tenant_id" ON "public"."pdv_products" USING "btree" ("tenant_id");


--
-- Name: idx_pdv_stock_mov_prod; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS "idx_pdv_stock_mov_prod" ON "public"."pdv_stock_movements" USING "btree" ("product_id");


--
-- Name: idx_products_available; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS "idx_products_available" ON "public"."products" USING "btree" ("is_available");


--
-- Name: idx_products_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS "idx_products_category" ON "public"."products" USING "btree" ("category_id");


--
-- Name: idx_products_featured; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS "idx_products_featured" ON "public"."products" USING "btree" ("is_featured");


--
-- Name: idx_products_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS "idx_products_tenant_id" ON "public"."products" USING "btree" ("tenant_id");


--
-- Name: idx_profiles_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS "idx_profiles_tenant_id" ON "public"."profiles" USING "btree" ("tenant_id");


--
-- Name: idx_shipping_methods_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS "idx_shipping_methods_tenant" ON "public"."shipping_methods" USING "btree" ("tenant_id");


--
-- Name: idx_stock_movements_product; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS "idx_stock_movements_product" ON "public"."stock_movements" USING "btree" ("product_id");


--
-- Name: idx_time_records_employee_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS "idx_time_records_employee_date" ON "public"."time_records" USING "btree" ("employee_id", "punched_at");


--
-- Name: idx_transactions_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS "idx_transactions_date" ON "public"."transactions" USING "btree" ("transaction_date");


--
-- Name: idx_transactions_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS "idx_transactions_type" ON "public"."transactions" USING "btree" ("type");


--
-- Name: idx_wishlist_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS "idx_wishlist_user" ON "public"."wishlist" USING "btree" ("user_id");


--
-- Name: profiles_username_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX IF NOT EXISTS "profiles_username_unique" ON "public"."profiles" USING "btree" ("username") WHERE ("username" IS NOT NULL);


--
-- Name: profiles on_new_profile_promote_first_admin; Type: TRIGGER; Schema: public; Owner: -
--

CREATE OR REPLACE TRIGGER "on_new_profile_promote_first_admin" AFTER INSERT ON "public"."profiles" FOR EACH ROW EXECUTE FUNCTION "public"."promote_first_user_to_admin"();


--
-- Name: orders set_order_number; Type: TRIGGER; Schema: public; Owner: -
--

CREATE OR REPLACE TRIGGER "set_order_number" BEFORE INSERT ON "public"."orders" FOR EACH ROW EXECUTE FUNCTION "public"."generate_order_number"();


--
-- Name: company trg_company_upd; Type: TRIGGER; Schema: public; Owner: -
--

CREATE OR REPLACE TRIGGER "trg_company_upd" BEFORE UPDATE ON "public"."company" FOR EACH ROW EXECUTE FUNCTION "public"."update_updated_at_col"();


--
-- Name: customers trg_customers_upd; Type: TRIGGER; Schema: public; Owner: -
--

CREATE OR REPLACE TRIGGER "trg_customers_upd" BEFORE UPDATE ON "public"."customers" FOR EACH ROW EXECUTE FUNCTION "public"."update_updated_at_col"();


--
-- Name: orders trg_decrement_stock; Type: TRIGGER; Schema: public; Owner: -
--

CREATE OR REPLACE TRIGGER "trg_decrement_stock" AFTER UPDATE ON "public"."orders" FOR EACH ROW EXECUTE FUNCTION "public"."decrement_stock_on_order"();


--
-- Name: orders trg_orders_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE OR REPLACE TRIGGER "trg_orders_updated_at" BEFORE UPDATE ON "public"."orders" FOR EACH ROW EXECUTE FUNCTION "public"."update_updated_at"();


--
-- Name: pdv_products trg_pdv_products_upd; Type: TRIGGER; Schema: public; Owner: -
--

CREATE OR REPLACE TRIGGER "trg_pdv_products_upd" BEFORE UPDATE ON "public"."pdv_products" FOR EACH ROW EXECUTE FUNCTION "public"."update_updated_at_col"();


--
-- Name: goods_receipt_items trg_pdv_stock_receipt; Type: TRIGGER; Schema: public; Owner: -
--

CREATE OR REPLACE TRIGGER "trg_pdv_stock_receipt" AFTER INSERT ON "public"."goods_receipt_items" FOR EACH ROW EXECUTE FUNCTION "public"."pdv_update_stock_on_receipt"();


--
-- Name: pdv_invoice_items trg_pdv_stock_sale; Type: TRIGGER; Schema: public; Owner: -
--

CREATE OR REPLACE TRIGGER "trg_pdv_stock_sale" AFTER INSERT ON "public"."pdv_invoice_items" FOR EACH ROW EXECUTE FUNCTION "public"."pdv_update_stock_on_sale"();


--
-- Name: products trg_products_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE OR REPLACE TRIGGER "trg_products_updated_at" BEFORE UPDATE ON "public"."products" FOR EACH ROW EXECUTE FUNCTION "public"."update_updated_at"();


--
-- Name: profiles trg_profiles_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE OR REPLACE TRIGGER "trg_profiles_updated_at" BEFORE UPDATE ON "public"."profiles" FOR EACH ROW EXECUTE FUNCTION "public"."update_updated_at"();


--
-- Name: store_settings trg_store_settings_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE OR REPLACE TRIGGER "trg_store_settings_updated_at" BEFORE UPDATE ON "public"."store_settings" FOR EACH ROW EXECUTE FUNCTION "public"."update_updated_at"();


--
-- Name: suppliers trg_suppliers_upd; Type: TRIGGER; Schema: public; Owner: -
--

CREATE OR REPLACE TRIGGER "trg_suppliers_upd" BEFORE UPDATE ON "public"."suppliers" FOR EACH ROW EXECUTE FUNCTION "public"."update_updated_at_col"();


--
-- Name: accounting_accounts accounting_accounts_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'accounting_accounts_parent_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'accounting_accounts'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."accounting_accounts"
    ADD CONSTRAINT "accounting_accounts_parent_id_fkey" FOREIGN KEY ("parent_id") REFERENCES "public"."accounting_accounts"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: accounting_accounts accounting_accounts_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'accounting_accounts_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'accounting_accounts'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."accounting_accounts"
    ADD CONSTRAINT "accounting_accounts_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: appointments appointments_resource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'appointments_resource_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'appointments'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."appointments"
    ADD CONSTRAINT "appointments_resource_id_fkey" FOREIGN KEY ("resource_id") REFERENCES "public"."bookable_resources"("id") ON DELETE SET NULL;
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: appointments appointments_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'appointments_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'appointments'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."appointments"
    ADD CONSTRAINT "appointments_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE;
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'audit_logs_user_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'audit_logs'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."audit_logs"
    ADD CONSTRAINT "audit_logs_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: bank_statements bank_statements_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'bank_statements_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'bank_statements'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."bank_statements"
    ADD CONSTRAINT "bank_statements_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: bank_statements bank_statements_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'bank_statements_transaction_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'bank_statements'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."bank_statements"
    ADD CONSTRAINT "bank_statements_transaction_id_fkey" FOREIGN KEY ("transaction_id") REFERENCES "public"."transactions"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: banners banners_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'banners_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'banners'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."banners"
    ADD CONSTRAINT "banners_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: bill_installments bill_installments_bill_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'bill_installments_bill_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'bill_installments'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."bill_installments"
    ADD CONSTRAINT "bill_installments_bill_id_fkey" FOREIGN KEY ("bill_id") REFERENCES "public"."bills"("id") ON DELETE CASCADE;
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: bill_installments bill_installments_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'bill_installments_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'bill_installments'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."bill_installments"
    ADD CONSTRAINT "bill_installments_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: bills bills_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'bills_created_by_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'bills'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."bills"
    ADD CONSTRAINT "bills_created_by_fkey" FOREIGN KEY ("created_by") REFERENCES "public"."profiles"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: bills bills_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'bills_customer_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'bills'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."bills"
    ADD CONSTRAINT "bills_customer_id_fkey" FOREIGN KEY ("customer_id") REFERENCES "public"."customers"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: bills bills_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'bills_invoice_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'bills'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."bills"
    ADD CONSTRAINT "bills_invoice_id_fkey" FOREIGN KEY ("invoice_id") REFERENCES "public"."pdv_invoices"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: bills bills_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'bills_supplier_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'bills'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."bills"
    ADD CONSTRAINT "bills_supplier_id_fkey" FOREIGN KEY ("supplier_id") REFERENCES "public"."suppliers"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: bills bills_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'bills_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'bills'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."bills"
    ADD CONSTRAINT "bills_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: bookable_resources bookable_resources_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'bookable_resources_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'bookable_resources'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."bookable_resources"
    ADD CONSTRAINT "bookable_resources_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE;
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: branches branches_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'branches_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'branches'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."branches"
    ADD CONSTRAINT "branches_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: cash_registers cash_registers_operator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'cash_registers_operator_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'cash_registers'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."cash_registers"
    ADD CONSTRAINT "cash_registers_operator_id_fkey" FOREIGN KEY ("operator_id") REFERENCES "public"."profiles"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: cash_registers cash_registers_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'cash_registers_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'cash_registers'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."cash_registers"
    ADD CONSTRAINT "cash_registers_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: categories categories_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'categories_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'categories'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."categories"
    ADD CONSTRAINT "categories_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: chat_messages chat_messages_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'chat_messages_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'chat_messages'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."chat_messages"
    ADD CONSTRAINT "chat_messages_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: chat_messages chat_messages_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'chat_messages_user_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'chat_messages'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."chat_messages"
    ADD CONSTRAINT "chat_messages_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."profiles"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: commissions commissions_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'commissions_invoice_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'commissions'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."commissions"
    ADD CONSTRAINT "commissions_invoice_id_fkey" FOREIGN KEY ("invoice_id") REFERENCES "public"."pdv_invoices"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: commissions commissions_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'commissions_profile_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'commissions'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."commissions"
    ADD CONSTRAINT "commissions_profile_id_fkey" FOREIGN KEY ("profile_id") REFERENCES "public"."profiles"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: commissions commissions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'commissions_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'commissions'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."commissions"
    ADD CONSTRAINT "commissions_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: company company_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'company_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'company'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."company"
    ADD CONSTRAINT "company_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: coupon_usages coupon_usages_coupon_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'coupon_usages_coupon_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'coupon_usages'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."coupon_usages"
    ADD CONSTRAINT "coupon_usages_coupon_id_fkey" FOREIGN KEY ("coupon_id") REFERENCES "public"."coupons"("id") ON DELETE CASCADE;
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: coupon_usages coupon_usages_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'coupon_usages_order_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'coupon_usages'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."coupon_usages"
    ADD CONSTRAINT "coupon_usages_order_id_fkey" FOREIGN KEY ("order_id") REFERENCES "public"."orders"("id") ON DELETE SET NULL;
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: coupon_usages coupon_usages_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'coupon_usages_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'coupon_usages'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."coupon_usages"
    ADD CONSTRAINT "coupon_usages_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: coupon_usages coupon_usages_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'coupon_usages_user_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'coupon_usages'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."coupon_usages"
    ADD CONSTRAINT "coupon_usages_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE SET NULL;
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: coupons coupons_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'coupons_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'coupons'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."coupons"
    ADD CONSTRAINT "coupons_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: crm_notes crm_notes_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'crm_notes_author_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'crm_notes'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."crm_notes"
    ADD CONSTRAINT "crm_notes_author_id_fkey" FOREIGN KEY ("author_id") REFERENCES "auth"."users"("id") ON DELETE SET NULL;
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: crm_notes crm_notes_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'crm_notes_customer_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'crm_notes'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."crm_notes"
    ADD CONSTRAINT "crm_notes_customer_id_fkey" FOREIGN KEY ("customer_id") REFERENCES "public"."customers"("id") ON DELETE CASCADE;
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: crm_notes crm_notes_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'crm_notes_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'crm_notes'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."crm_notes"
    ADD CONSTRAINT "crm_notes_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: customers customers_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'customers_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'customers'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."customers"
    ADD CONSTRAINT "customers_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: deliveries deliveries_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'deliveries_created_by_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'deliveries'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."deliveries"
    ADD CONSTRAINT "deliveries_created_by_fkey" FOREIGN KEY ("created_by") REFERENCES "public"."profiles"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: deliveries deliveries_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'deliveries_customer_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'deliveries'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."deliveries"
    ADD CONSTRAINT "deliveries_customer_id_fkey" FOREIGN KEY ("customer_id") REFERENCES "public"."customers"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: deliveries deliveries_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'deliveries_invoice_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'deliveries'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."deliveries"
    ADD CONSTRAINT "deliveries_invoice_id_fkey" FOREIGN KEY ("invoice_id") REFERENCES "public"."pdv_invoices"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: deliveries deliveries_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'deliveries_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'deliveries'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."deliveries"
    ADD CONSTRAINT "deliveries_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: employees employees_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'employees_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'employees'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."employees"
    ADD CONSTRAINT "employees_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE;
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: fiscal_config fiscal_config_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'fiscal_config_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'fiscal_config'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."fiscal_config"
    ADD CONSTRAINT "fiscal_config_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: goods_receipt_items goods_receipt_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'goods_receipt_items_product_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'goods_receipt_items'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."goods_receipt_items"
    ADD CONSTRAINT "goods_receipt_items_product_id_fkey" FOREIGN KEY ("product_id") REFERENCES "public"."pdv_products"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: goods_receipt_items goods_receipt_items_receipt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'goods_receipt_items_receipt_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'goods_receipt_items'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."goods_receipt_items"
    ADD CONSTRAINT "goods_receipt_items_receipt_id_fkey" FOREIGN KEY ("receipt_id") REFERENCES "public"."goods_receipts"("id") ON DELETE CASCADE;
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: goods_receipts goods_receipts_received_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'goods_receipts_received_by_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'goods_receipts'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."goods_receipts"
    ADD CONSTRAINT "goods_receipts_received_by_fkey" FOREIGN KEY ("received_by") REFERENCES "public"."profiles"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: goods_receipts goods_receipts_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'goods_receipts_supplier_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'goods_receipts'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."goods_receipts"
    ADD CONSTRAINT "goods_receipts_supplier_id_fkey" FOREIGN KEY ("supplier_id") REFERENCES "public"."suppliers"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: goods_receipts goods_receipts_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'goods_receipts_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'goods_receipts'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."goods_receipts"
    ADD CONSTRAINT "goods_receipts_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: loyalty_config loyalty_config_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'loyalty_config_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'loyalty_config'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."loyalty_config"
    ADD CONSTRAINT "loyalty_config_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: loyalty_transactions loyalty_transactions_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'loyalty_transactions_customer_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'loyalty_transactions'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."loyalty_transactions"
    ADD CONSTRAINT "loyalty_transactions_customer_id_fkey" FOREIGN KEY ("customer_id") REFERENCES "public"."customers"("id") ON DELETE CASCADE;
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: loyalty_transactions loyalty_transactions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'loyalty_transactions_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'loyalty_transactions'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."loyalty_transactions"
    ADD CONSTRAINT "loyalty_transactions_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: marketplace_listings marketplace_listings_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'marketplace_listings_product_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'marketplace_listings'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."marketplace_listings"
    ADD CONSTRAINT "marketplace_listings_product_id_fkey" FOREIGN KEY ("product_id") REFERENCES "public"."pdv_products"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: marketplace_listings marketplace_listings_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'marketplace_listings_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'marketplace_listings'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."marketplace_listings"
    ADD CONSTRAINT "marketplace_listings_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: online_order_items online_order_items_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'online_order_items_order_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'online_order_items'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."online_order_items"
    ADD CONSTRAINT "online_order_items_order_id_fkey" FOREIGN KEY ("order_id") REFERENCES "public"."online_orders"("id") ON DELETE CASCADE;
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: online_order_items online_order_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'online_order_items_product_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'online_order_items'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."online_order_items"
    ADD CONSTRAINT "online_order_items_product_id_fkey" FOREIGN KEY ("product_id") REFERENCES "public"."pdv_products"("id") ON DELETE RESTRICT;
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: online_orders online_orders_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'online_orders_customer_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'online_orders'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."online_orders"
    ADD CONSTRAINT "online_orders_customer_id_fkey" FOREIGN KEY ("customer_id") REFERENCES "public"."customers"("id") ON DELETE SET NULL;
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: online_orders online_orders_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'online_orders_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'online_orders'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."online_orders"
    ADD CONSTRAINT "online_orders_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: orders orders_coupon_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'orders_coupon_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'orders'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."orders"
    ADD CONSTRAINT "orders_coupon_id_fkey" FOREIGN KEY ("coupon_id") REFERENCES "public"."coupons"("id") ON DELETE SET NULL;
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: orders orders_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'orders_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'orders'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."orders"
    ADD CONSTRAINT "orders_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: orders orders_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'orders_user_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'orders'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."orders"
    ADD CONSTRAINT "orders_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."profiles"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: payment_gateways payment_gateways_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'payment_gateways_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'payment_gateways'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."payment_gateways"
    ADD CONSTRAINT "payment_gateways_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: payroll_entries payroll_entries_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'payroll_entries_employee_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'payroll_entries'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."payroll_entries"
    ADD CONSTRAINT "payroll_entries_employee_id_fkey" FOREIGN KEY ("employee_id") REFERENCES "public"."employees"("id") ON DELETE CASCADE;
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: payroll_entries payroll_entries_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'payroll_entries_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'payroll_entries'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."payroll_entries"
    ADD CONSTRAINT "payroll_entries_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE;
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_categories pdv_categories_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'pdv_categories_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_categories'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."pdv_categories"
    ADD CONSTRAINT "pdv_categories_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_certificates pdv_certificates_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'pdv_certificates_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_certificates'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."pdv_certificates"
    ADD CONSTRAINT "pdv_certificates_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_cupom_contingencia pdv_cupom_contingencia_cupom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'pdv_cupom_contingencia_cupom_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_cupom_contingencia'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."pdv_cupom_contingencia"
    ADD CONSTRAINT "pdv_cupom_contingencia_cupom_id_fkey" FOREIGN KEY ("cupom_id") REFERENCES "public"."pdv_cupons"("id") ON DELETE SET NULL;
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_cupom_items pdv_cupom_items_cupom_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'pdv_cupom_items_cupom_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_cupom_items'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."pdv_cupom_items"
    ADD CONSTRAINT "pdv_cupom_items_cupom_id_fkey" FOREIGN KEY ("cupom_id") REFERENCES "public"."pdv_cupons"("id") ON DELETE CASCADE;
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_cupom_items pdv_cupom_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'pdv_cupom_items_product_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_cupom_items'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."pdv_cupom_items"
    ADD CONSTRAINT "pdv_cupom_items_product_id_fkey" FOREIGN KEY ("product_id") REFERENCES "public"."pdv_products"("id") ON DELETE SET NULL;
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_cupons pdv_cupons_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'pdv_cupons_invoice_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_cupons'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."pdv_cupons"
    ADD CONSTRAINT "pdv_cupons_invoice_id_fkey" FOREIGN KEY ("invoice_id") REFERENCES "public"."pdv_invoices"("id") ON DELETE SET NULL;
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_cupons pdv_cupons_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'pdv_cupons_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_cupons'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."pdv_cupons"
    ADD CONSTRAINT "pdv_cupons_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_fiscal_config pdv_fiscal_config_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'pdv_fiscal_config_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_fiscal_config'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."pdv_fiscal_config"
    ADD CONSTRAINT "pdv_fiscal_config_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_invoice_items pdv_invoice_items_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'pdv_invoice_items_invoice_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_invoice_items'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."pdv_invoice_items"
    ADD CONSTRAINT "pdv_invoice_items_invoice_id_fkey" FOREIGN KEY ("invoice_id") REFERENCES "public"."pdv_invoices"("id") ON DELETE CASCADE;
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_invoice_items pdv_invoice_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'pdv_invoice_items_product_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_invoice_items'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."pdv_invoice_items"
    ADD CONSTRAINT "pdv_invoice_items_product_id_fkey" FOREIGN KEY ("product_id") REFERENCES "public"."pdv_products"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_invoices pdv_invoices_cancelled_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'pdv_invoices_cancelled_by_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_invoices'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."pdv_invoices"
    ADD CONSTRAINT "pdv_invoices_cancelled_by_fkey" FOREIGN KEY ("cancelled_by") REFERENCES "public"."profiles"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_invoices pdv_invoices_cash_register_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'pdv_invoices_cash_register_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_invoices'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."pdv_invoices"
    ADD CONSTRAINT "pdv_invoices_cash_register_id_fkey" FOREIGN KEY ("cash_register_id") REFERENCES "public"."cash_registers"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_invoices pdv_invoices_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'pdv_invoices_created_by_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_invoices'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."pdv_invoices"
    ADD CONSTRAINT "pdv_invoices_created_by_fkey" FOREIGN KEY ("created_by") REFERENCES "public"."profiles"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_invoices pdv_invoices_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'pdv_invoices_customer_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_invoices'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."pdv_invoices"
    ADD CONSTRAINT "pdv_invoices_customer_id_fkey" FOREIGN KEY ("customer_id") REFERENCES "public"."customers"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_invoices pdv_invoices_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'pdv_invoices_supplier_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_invoices'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."pdv_invoices"
    ADD CONSTRAINT "pdv_invoices_supplier_id_fkey" FOREIGN KEY ("supplier_id") REFERENCES "public"."suppliers"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_invoices pdv_invoices_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'pdv_invoices_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_invoices'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."pdv_invoices"
    ADD CONSTRAINT "pdv_invoices_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_products pdv_products_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'pdv_products_category_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_products'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."pdv_products"
    ADD CONSTRAINT "pdv_products_category_id_fkey" FOREIGN KEY ("category_id") REFERENCES "public"."pdv_categories"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_products pdv_products_site_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'pdv_products_site_product_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_products'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."pdv_products"
    ADD CONSTRAINT "pdv_products_site_product_id_fkey" FOREIGN KEY ("site_product_id") REFERENCES "public"."products"("id") ON DELETE SET NULL;
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_products pdv_products_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'pdv_products_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_products'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."pdv_products"
    ADD CONSTRAINT "pdv_products_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_stock_movements pdv_stock_movements_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'pdv_stock_movements_created_by_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_stock_movements'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."pdv_stock_movements"
    ADD CONSTRAINT "pdv_stock_movements_created_by_fkey" FOREIGN KEY ("created_by") REFERENCES "public"."profiles"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_stock_movements pdv_stock_movements_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'pdv_stock_movements_product_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_stock_movements'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."pdv_stock_movements"
    ADD CONSTRAINT "pdv_stock_movements_product_id_fkey" FOREIGN KEY ("product_id") REFERENCES "public"."pdv_products"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: product_batches product_batches_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'product_batches_product_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'product_batches'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."product_batches"
    ADD CONSTRAINT "product_batches_product_id_fkey" FOREIGN KEY ("product_id") REFERENCES "public"."pdv_products"("id") ON DELETE CASCADE;
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: product_batches product_batches_receipt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'product_batches_receipt_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'product_batches'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."product_batches"
    ADD CONSTRAINT "product_batches_receipt_id_fkey" FOREIGN KEY ("receipt_id") REFERENCES "public"."goods_receipts"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: product_batches product_batches_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'product_batches_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'product_batches'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."product_batches"
    ADD CONSTRAINT "product_batches_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: product_variants product_variants_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'product_variants_product_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'product_variants'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."product_variants"
    ADD CONSTRAINT "product_variants_product_id_fkey" FOREIGN KEY ("product_id") REFERENCES "public"."pdv_products"("id") ON DELETE CASCADE;
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: product_variants product_variants_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'product_variants_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'product_variants'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."product_variants"
    ADD CONSTRAINT "product_variants_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: products products_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'products_category_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'products'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."products"
    ADD CONSTRAINT "products_category_id_fkey" FOREIGN KEY ("category_id") REFERENCES "public"."categories"("id") ON DELETE SET NULL;
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: products products_pdv_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'products_pdv_product_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'products'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."products"
    ADD CONSTRAINT "products_pdv_product_id_fkey" FOREIGN KEY ("pdv_product_id") REFERENCES "public"."pdv_products"("id") ON DELETE SET NULL;
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: products products_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'products_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'products'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."products"
    ADD CONSTRAINT "products_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: profiles profiles_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'profiles_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'profiles'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."profiles"
    ADD CONSTRAINT "profiles_id_fkey" FOREIGN KEY ("id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: profiles profiles_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'profiles_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'profiles'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."profiles"
    ADD CONSTRAINT "profiles_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: promotions promotions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'promotions_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'promotions'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."promotions"
    ADD CONSTRAINT "promotions_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: referrals referrals_referred_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'referrals_referred_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'referrals'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."referrals"
    ADD CONSTRAINT "referrals_referred_id_fkey" FOREIGN KEY ("referred_id") REFERENCES "public"."customers"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: referrals referrals_referrer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'referrals_referrer_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'referrals'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."referrals"
    ADD CONSTRAINT "referrals_referrer_id_fkey" FOREIGN KEY ("referrer_id") REFERENCES "public"."customers"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: referrals referrals_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'referrals_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'referrals'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."referrals"
    ADD CONSTRAINT "referrals_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: return_items return_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'return_items_product_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'return_items'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."return_items"
    ADD CONSTRAINT "return_items_product_id_fkey" FOREIGN KEY ("product_id") REFERENCES "public"."pdv_products"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: return_items return_items_return_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'return_items_return_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'return_items'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."return_items"
    ADD CONSTRAINT "return_items_return_id_fkey" FOREIGN KEY ("return_id") REFERENCES "public"."returns"("id") ON DELETE CASCADE;
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: returns returns_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'returns_customer_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'returns'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."returns"
    ADD CONSTRAINT "returns_customer_id_fkey" FOREIGN KEY ("customer_id") REFERENCES "public"."customers"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: returns returns_original_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'returns_original_invoice_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'returns'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."returns"
    ADD CONSTRAINT "returns_original_invoice_id_fkey" FOREIGN KEY ("original_invoice_id") REFERENCES "public"."pdv_invoices"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: returns returns_processed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'returns_processed_by_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'returns'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."returns"
    ADD CONSTRAINT "returns_processed_by_fkey" FOREIGN KEY ("processed_by") REFERENCES "public"."profiles"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: returns returns_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'returns_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'returns'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."returns"
    ADD CONSTRAINT "returns_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: seller_commissions_config seller_commissions_config_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'seller_commissions_config_profile_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'seller_commissions_config'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."seller_commissions_config"
    ADD CONSTRAINT "seller_commissions_config_profile_id_fkey" FOREIGN KEY ("profile_id") REFERENCES "public"."profiles"("id") ON DELETE CASCADE;
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: seller_commissions_config seller_commissions_config_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'seller_commissions_config_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'seller_commissions_config'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."seller_commissions_config"
    ADD CONSTRAINT "seller_commissions_config_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: shipping_methods shipping_methods_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'shipping_methods_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'shipping_methods'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."shipping_methods"
    ADD CONSTRAINT "shipping_methods_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE;
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: stock_movements stock_movements_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'stock_movements_created_by_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'stock_movements'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."stock_movements"
    ADD CONSTRAINT "stock_movements_created_by_fkey" FOREIGN KEY ("created_by") REFERENCES "public"."profiles"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: stock_movements stock_movements_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'stock_movements_product_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'stock_movements'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."stock_movements"
    ADD CONSTRAINT "stock_movements_product_id_fkey" FOREIGN KEY ("product_id") REFERENCES "public"."products"("id") ON DELETE CASCADE;
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: stock_movements stock_movements_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'stock_movements_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'stock_movements'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."stock_movements"
    ADD CONSTRAINT "stock_movements_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: stock_transfer_items stock_transfer_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'stock_transfer_items_product_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'stock_transfer_items'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."stock_transfer_items"
    ADD CONSTRAINT "stock_transfer_items_product_id_fkey" FOREIGN KEY ("product_id") REFERENCES "public"."pdv_products"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: stock_transfer_items stock_transfer_items_transfer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'stock_transfer_items_transfer_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'stock_transfer_items'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."stock_transfer_items"
    ADD CONSTRAINT "stock_transfer_items_transfer_id_fkey" FOREIGN KEY ("transfer_id") REFERENCES "public"."stock_transfers"("id") ON DELETE CASCADE;
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: stock_transfers stock_transfers_from_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'stock_transfers_from_branch_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'stock_transfers'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."stock_transfers"
    ADD CONSTRAINT "stock_transfers_from_branch_id_fkey" FOREIGN KEY ("from_branch_id") REFERENCES "public"."branches"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: stock_transfers stock_transfers_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'stock_transfers_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'stock_transfers'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."stock_transfers"
    ADD CONSTRAINT "stock_transfers_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: stock_transfers stock_transfers_to_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'stock_transfers_to_branch_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'stock_transfers'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."stock_transfers"
    ADD CONSTRAINT "stock_transfers_to_branch_id_fkey" FOREIGN KEY ("to_branch_id") REFERENCES "public"."branches"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: stock_transfers stock_transfers_transferred_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'stock_transfers_transferred_by_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'stock_transfers'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."stock_transfers"
    ADD CONSTRAINT "stock_transfers_transferred_by_fkey" FOREIGN KEY ("transferred_by") REFERENCES "public"."profiles"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: store_settings store_settings_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'store_settings_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'store_settings'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."store_settings"
    ADD CONSTRAINT "store_settings_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: subscriptions subscriptions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'subscriptions_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'subscriptions'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."subscriptions"
    ADD CONSTRAINT "subscriptions_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: suppliers suppliers_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'suppliers_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'suppliers'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."suppliers"
    ADD CONSTRAINT "suppliers_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: theme_settings theme_settings_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'theme_settings_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'theme_settings'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."theme_settings"
    ADD CONSTRAINT "theme_settings_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: time_records time_records_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'time_records_employee_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'time_records'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."time_records"
    ADD CONSTRAINT "time_records_employee_id_fkey" FOREIGN KEY ("employee_id") REFERENCES "public"."employees"("id") ON DELETE CASCADE;
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: time_records time_records_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'time_records_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'time_records'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."time_records"
    ADD CONSTRAINT "time_records_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE CASCADE;
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: transactions transactions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'transactions_created_by_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'transactions'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."transactions"
    ADD CONSTRAINT "transactions_created_by_fkey" FOREIGN KEY ("created_by") REFERENCES "public"."profiles"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: transactions transactions_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'transactions_invoice_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'transactions'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."transactions"
    ADD CONSTRAINT "transactions_invoice_id_fkey" FOREIGN KEY ("invoice_id") REFERENCES "public"."pdv_invoices"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: transactions transactions_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'transactions_supplier_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'transactions'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."transactions"
    ADD CONSTRAINT "transactions_supplier_id_fkey" FOREIGN KEY ("supplier_id") REFERENCES "public"."suppliers"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: transactions transactions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'transactions_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'transactions'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."transactions"
    ADD CONSTRAINT "transactions_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: user_permissions user_permissions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'user_permissions_user_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'user_permissions'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."user_permissions"
    ADD CONSTRAINT "user_permissions_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: warranties warranties_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'warranties_customer_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'warranties'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."warranties"
    ADD CONSTRAINT "warranties_customer_id_fkey" FOREIGN KEY ("customer_id") REFERENCES "public"."customers"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: warranties warranties_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'warranties_invoice_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'warranties'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."warranties"
    ADD CONSTRAINT "warranties_invoice_id_fkey" FOREIGN KEY ("invoice_id") REFERENCES "public"."pdv_invoices"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: warranties warranties_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'warranties_product_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'warranties'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."warranties"
    ADD CONSTRAINT "warranties_product_id_fkey" FOREIGN KEY ("product_id") REFERENCES "public"."pdv_products"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: warranties warranties_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'warranties_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'warranties'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."warranties"
    ADD CONSTRAINT "warranties_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: wishlist wishlist_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'wishlist_product_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'wishlist'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."wishlist"
    ADD CONSTRAINT "wishlist_product_id_fkey" FOREIGN KEY ("product_id") REFERENCES "public"."products"("id") ON DELETE CASCADE;
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: wishlist wishlist_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'wishlist_tenant_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'wishlist'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."wishlist"
    ADD CONSTRAINT "wishlist_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id");
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: wishlist wishlist_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint con
    JOIN pg_class c ON c.oid = con.conrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE con.conname = 'wishlist_user_id_fkey'
      AND n.nspname = 'public'
      AND c.relname = 'wishlist'
  ) THEN
    EXECUTE $pg_schema_sql$
ALTER TABLE ONLY "public"."wishlist"
    ADD CONSTRAINT "wishlist_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."profiles"("id") ON DELETE CASCADE;
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: subscriptions Admin can update subscriptions; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Admin can update subscriptions'
      AND n.nspname = 'public'
      AND c.relname = 'subscriptions'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Admin can update subscriptions" ON "public"."subscriptions" TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"public"."user_role"))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"public"."user_role")))));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: shipping_methods Admin gerencia métodos de envio; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Admin gerencia métodos de envio'
      AND n.nspname = 'public'
      AND c.relname = 'shipping_methods'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Admin gerencia métodos de envio" ON "public"."shipping_methods" USING ((("public"."get_current_tenant_id"() = "tenant_id") OR ("tenant_id" IS NULL))) WITH CHECK ((("public"."get_current_tenant_id"() = "tenant_id") OR ("tenant_id" IS NULL)));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: user_permissions Admins can manage all permissions; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Admins can manage all permissions'
      AND n.nspname = 'public'
      AND c.relname = 'user_permissions'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Admins can manage all permissions" ON "public"."user_permissions" TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"public"."user_role")))));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_certificates Admins can manage certificates; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Admins can manage certificates'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_certificates'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Admins can manage certificates" ON "public"."pdv_certificates" TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = ANY (ARRAY['admin'::"public"."user_role", 'gestor'::"public"."user_role"]))))));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_cupom_contingencia Admins can manage contingencia; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Admins can manage contingencia'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_cupom_contingencia'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Admins can manage contingencia" ON "public"."pdv_cupom_contingencia" TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = ANY (ARRAY['admin'::"public"."user_role", 'gestor'::"public"."user_role"]))))));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_cupom_items Admins can manage cupom items; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Admins can manage cupom items'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_cupom_items'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Admins can manage cupom items" ON "public"."pdv_cupom_items" TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = ANY (ARRAY['admin'::"public"."user_role", 'gestor'::"public"."user_role"]))))));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_cupons Admins can manage cupons; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Admins can manage cupons'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_cupons'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Admins can manage cupons" ON "public"."pdv_cupons" TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = ANY (ARRAY['admin'::"public"."user_role", 'gestor'::"public"."user_role"]))))));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_fiscal_config Admins can manage fiscal config; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Admins can manage fiscal config'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_fiscal_config'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Admins can manage fiscal config" ON "public"."pdv_fiscal_config" TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = ANY (ARRAY['admin'::"public"."user_role", 'gestor'::"public"."user_role"]))))));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_payment_methods Admins can manage payment methods; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Admins can manage payment methods'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_payment_methods'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Admins can manage payment methods" ON "public"."pdv_payment_methods" TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = ANY (ARRAY['admin'::"public"."user_role", 'gestor'::"public"."user_role"]))))));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: profiles Admins full access profiles; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Admins full access profiles'
      AND n.nspname = 'public'
      AND c.relname = 'profiles'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Admins full access profiles" ON "public"."profiles" TO "authenticated" USING (("public"."get_user_role"("auth"."uid"()) = 'admin'::"public"."user_role"));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: chat_messages Admins insert messages; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Admins insert messages'
      AND n.nspname = 'public'
      AND c.relname = 'chat_messages'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Admins insert messages" ON "public"."chat_messages" FOR INSERT TO "authenticated" WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"public"."user_role")))));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: categories Admins manage categories; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Admins manage categories'
      AND n.nspname = 'public'
      AND c.relname = 'categories'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Admins manage categories" ON "public"."categories" TO "authenticated" USING (("public"."get_user_role"("auth"."uid"()) = 'admin'::"public"."user_role"));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: products Admins manage products; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Admins manage products'
      AND n.nspname = 'public'
      AND c.relname = 'products'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Admins manage products" ON "public"."products" TO "authenticated" USING (("public"."get_user_role"("auth"."uid"()) = 'admin'::"public"."user_role"));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: stock_movements Admins manage stock movements; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Admins manage stock movements'
      AND n.nspname = 'public'
      AND c.relname = 'stock_movements'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Admins manage stock movements" ON "public"."stock_movements" TO "authenticated" USING (("public"."get_user_role"("auth"."uid"()) = 'admin'::"public"."user_role"));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: store_settings Admins manage store settings; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Admins manage store settings'
      AND n.nspname = 'public'
      AND c.relname = 'store_settings'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Admins manage store settings" ON "public"."store_settings" TO "authenticated" USING (("public"."get_user_role"("auth"."uid"()) = 'admin'::"public"."user_role"));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: chat_messages Admins update chat messages; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Admins update chat messages'
      AND n.nspname = 'public'
      AND c.relname = 'chat_messages'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Admins update chat messages" ON "public"."chat_messages" FOR UPDATE TO "authenticated" USING (("public"."get_user_role"("auth"."uid"()) = 'admin'::"public"."user_role"));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: orders Admins update orders; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Admins update orders'
      AND n.nspname = 'public'
      AND c.relname = 'orders'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Admins update orders" ON "public"."orders" FOR UPDATE TO "authenticated" USING (("public"."get_user_role"("auth"."uid"()) = 'admin'::"public"."user_role"));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: chat_messages Admins view all messages; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Admins view all messages'
      AND n.nspname = 'public'
      AND c.relname = 'chat_messages'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Admins view all messages" ON "public"."chat_messages" FOR SELECT TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"public"."user_role")))));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: orders Admins view all orders; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Admins view all orders'
      AND n.nspname = 'public'
      AND c.relname = 'orders'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Admins view all orders" ON "public"."orders" FOR SELECT TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"public"."user_role")))));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: subscriptions Allow select for everyone; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Allow select for everyone'
      AND n.nspname = 'public'
      AND c.relname = 'subscriptions'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Allow select for everyone" ON "public"."subscriptions" FOR SELECT USING (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: orders Anyone can create orders; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Anyone can create orders'
      AND n.nspname = 'public'
      AND c.relname = 'orders'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Anyone can create orders" ON "public"."orders" FOR INSERT WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: categories Anyone can view active categories; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Anyone can view active categories'
      AND n.nspname = 'public'
      AND c.relname = 'categories'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Anyone can view active categories" ON "public"."categories" FOR SELECT USING ((("is_active" = true) OR ("public"."get_user_role"("auth"."uid"()) = 'admin'::"public"."user_role")));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: products Anyone can view available products; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Anyone can view available products'
      AND n.nspname = 'public'
      AND c.relname = 'products'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Anyone can view available products" ON "public"."products" FOR SELECT USING ((("is_available" = true) OR ("public"."get_user_role"("auth"."uid"()) = 'admin'::"public"."user_role")));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_certificates Anyone can view certificates; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Anyone can view certificates'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_certificates'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Anyone can view certificates" ON "public"."pdv_certificates" FOR SELECT TO "authenticated" USING (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_cupom_contingencia Anyone can view contingencia; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Anyone can view contingencia'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_cupom_contingencia'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Anyone can view contingencia" ON "public"."pdv_cupom_contingencia" FOR SELECT TO "authenticated" USING (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_cupom_items Anyone can view cupom items; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Anyone can view cupom items'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_cupom_items'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Anyone can view cupom items" ON "public"."pdv_cupom_items" FOR SELECT TO "authenticated" USING (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_cupons Anyone can view cupons; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Anyone can view cupons'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_cupons'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Anyone can view cupons" ON "public"."pdv_cupons" FOR SELECT TO "authenticated" USING (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_fiscal_config Anyone can view fiscal config; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Anyone can view fiscal config'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_fiscal_config'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Anyone can view fiscal config" ON "public"."pdv_fiscal_config" FOR SELECT TO "authenticated" USING (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_payment_methods Anyone can view payment methods; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Anyone can view payment methods'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_payment_methods'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Anyone can view payment methods" ON "public"."pdv_payment_methods" FOR SELECT TO "authenticated" USING (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: store_settings Anyone can view store settings; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Anyone can view store settings'
      AND n.nspname = 'public'
      AND c.relname = 'store_settings'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Anyone can view store settings" ON "public"."store_settings" FOR SELECT USING (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: audit_logs Auditoria visível para usuários autenticados; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Auditoria visível para usuários autenticados'
      AND n.nspname = 'public'
      AND c.relname = 'audit_logs'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Auditoria visível para usuários autenticados" ON "public"."audit_logs" FOR SELECT TO "authenticated" USING (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: banners Banners tenant isolation; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Banners tenant isolation'
      AND n.nspname = 'public'
      AND c.relname = 'banners'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Banners tenant isolation" ON "public"."banners" TO "authenticated" USING ((("tenant_id" = "public"."get_current_tenant_id"()) OR "public"."is_super_admin"())) WITH CHECK ((("tenant_id" = "public"."get_current_tenant_id"()) OR "public"."is_super_admin"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: categories Categories tenant isolation; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Categories tenant isolation'
      AND n.nspname = 'public'
      AND c.relname = 'categories'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Categories tenant isolation" ON "public"."categories" TO "authenticated" USING ((("tenant_id" = "public"."get_current_tenant_id"()) OR "public"."is_super_admin"())) WITH CHECK ((("tenant_id" = "public"."get_current_tenant_id"()) OR "public"."is_super_admin"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: coupons Coupons tenant isolation; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Coupons tenant isolation'
      AND n.nspname = 'public'
      AND c.relname = 'coupons'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Coupons tenant isolation" ON "public"."coupons" TO "authenticated" USING ((("tenant_id" = "public"."get_current_tenant_id"()) OR "public"."is_super_admin"())) WITH CHECK ((("tenant_id" = "public"."get_current_tenant_id"()) OR "public"."is_super_admin"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: customers Customers tenant isolation; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Customers tenant isolation'
      AND n.nspname = 'public'
      AND c.relname = 'customers'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Customers tenant isolation" ON "public"."customers" TO "authenticated" USING ((("tenant_id" = "public"."get_current_tenant_id"()) OR "public"."is_super_admin"())) WITH CHECK ((("tenant_id" = "public"."get_current_tenant_id"()) OR "public"."is_super_admin"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: payment_gateways Gateways tenant isolation; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Gateways tenant isolation'
      AND n.nspname = 'public'
      AND c.relname = 'payment_gateways'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Gateways tenant isolation" ON "public"."payment_gateways" TO "authenticated" USING ((("tenant_id" = "public"."get_current_tenant_id"()) OR "public"."is_super_admin"())) WITH CHECK ((("tenant_id" = "public"."get_current_tenant_id"()) OR "public"."is_super_admin"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: shipping_methods Leitura pública de métodos de envio; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Leitura pública de métodos de envio'
      AND n.nspname = 'public'
      AND c.relname = 'shipping_methods'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Leitura pública de métodos de envio" ON "public"."shipping_methods" FOR SELECT USING (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: orders Orders tenant isolation; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Orders tenant isolation'
      AND n.nspname = 'public'
      AND c.relname = 'orders'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Orders tenant isolation" ON "public"."orders" TO "authenticated" USING ((("tenant_id" = "public"."get_current_tenant_id"()) OR "public"."is_super_admin"())) WITH CHECK ((("tenant_id" = "public"."get_current_tenant_id"()) OR "public"."is_super_admin"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_categories PDV categories tenant isolation; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'PDV categories tenant isolation'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_categories'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "PDV categories tenant isolation" ON "public"."pdv_categories" TO "authenticated" USING ((("tenant_id" = "public"."get_current_tenant_id"()) OR "public"."is_super_admin"())) WITH CHECK ((("tenant_id" = "public"."get_current_tenant_id"()) OR "public"."is_super_admin"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_products PDV products tenant isolation; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'PDV products tenant isolation'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_products'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "PDV products tenant isolation" ON "public"."pdv_products" TO "authenticated" USING ((("tenant_id" = "public"."get_current_tenant_id"()) OR "public"."is_super_admin"())) WITH CHECK ((("tenant_id" = "public"."get_current_tenant_id"()) OR "public"."is_super_admin"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: products Products tenant isolation; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Products tenant isolation'
      AND n.nspname = 'public'
      AND c.relname = 'products'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Products tenant isolation" ON "public"."products" TO "authenticated" USING ((("tenant_id" = "public"."get_current_tenant_id"()) OR "public"."is_super_admin"())) WITH CHECK ((("tenant_id" = "public"."get_current_tenant_id"()) OR "public"."is_super_admin"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: profiles Profiles tenant isolation; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Profiles tenant isolation'
      AND n.nspname = 'public'
      AND c.relname = 'profiles'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Profiles tenant isolation" ON "public"."profiles" TO "authenticated" USING ((("tenant_id" = "public"."get_current_tenant_id"()) OR "public"."is_super_admin"())) WITH CHECK ((("tenant_id" = "public"."get_current_tenant_id"()) OR "public"."is_super_admin"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: orders Service role all orders; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Service role all orders'
      AND n.nspname = 'public'
      AND c.relname = 'orders'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Service role all orders" ON "public"."orders" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: stock_movements Service role manage stock; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Service role manage stock'
      AND n.nspname = 'public'
      AND c.relname = 'stock_movements'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Service role manage stock" ON "public"."stock_movements" USING ((("auth"."jwt"() ->> 'role'::"text") = 'service_role'::"text"));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: stock_movements Stock movements tenant isolation; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Stock movements tenant isolation'
      AND n.nspname = 'public'
      AND c.relname = 'stock_movements'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Stock movements tenant isolation" ON "public"."stock_movements" TO "authenticated" USING ((("tenant_id" = "public"."get_current_tenant_id"()) OR "public"."is_super_admin"())) WITH CHECK ((("tenant_id" = "public"."get_current_tenant_id"()) OR "public"."is_super_admin"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: store_settings Store settings tenant isolation; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Store settings tenant isolation'
      AND n.nspname = 'public'
      AND c.relname = 'store_settings'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Store settings tenant isolation" ON "public"."store_settings" TO "authenticated" USING ((("tenant_id" = "public"."get_current_tenant_id"()) OR "public"."is_super_admin"())) WITH CHECK ((("tenant_id" = "public"."get_current_tenant_id"()) OR "public"."is_super_admin"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: tenants Users can update own tenant; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Users can update own tenant'
      AND n.nspname = 'public'
      AND c.relname = 'tenants'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Users can update own tenant" ON "public"."tenants" FOR UPDATE TO "authenticated" USING (("id" = "public"."get_current_tenant_id"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: user_permissions Users can view own permissions; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Users can view own permissions'
      AND n.nspname = 'public'
      AND c.relname = 'user_permissions'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Users can view own permissions" ON "public"."user_permissions" FOR SELECT TO "authenticated" USING (("user_id" = "auth"."uid"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: chat_messages Users insert messages; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Users insert messages'
      AND n.nspname = 'public'
      AND c.relname = 'chat_messages'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Users insert messages" ON "public"."chat_messages" FOR INSERT TO "authenticated" WITH CHECK ((("user_id" = "auth"."uid"()) OR ("public"."get_user_role"("auth"."uid"()) = 'admin'::"public"."user_role")));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: orders Users insert own orders; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Users insert own orders'
      AND n.nspname = 'public'
      AND c.relname = 'orders'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Users insert own orders" ON "public"."orders" FOR INSERT TO "authenticated" WITH CHECK (("auth"."uid"() = "user_id"));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: wishlist Users manage own wishlist; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Users manage own wishlist'
      AND n.nspname = 'public'
      AND c.relname = 'wishlist'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Users manage own wishlist" ON "public"."wishlist" TO "authenticated" USING (("auth"."uid"() = "user_id"));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: profiles Users update own profile; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Users update own profile'
      AND n.nspname = 'public'
      AND c.relname = 'profiles'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Users update own profile" ON "public"."profiles" FOR UPDATE TO "authenticated" USING (("auth"."uid"() = "id")) WITH CHECK ((NOT ("role" IS DISTINCT FROM "public"."get_user_role"("auth"."uid"()))));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: chat_messages Users view own conversations; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Users view own conversations'
      AND n.nspname = 'public'
      AND c.relname = 'chat_messages'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Users view own conversations" ON "public"."chat_messages" FOR SELECT TO "authenticated" USING ((("user_id" = "auth"."uid"()) OR ("public"."get_user_role"("auth"."uid"()) = 'admin'::"public"."user_role")));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: orders Users view own orders; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Users view own orders'
      AND n.nspname = 'public'
      AND c.relname = 'orders'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Users view own orders" ON "public"."orders" FOR SELECT TO "authenticated" USING ((("auth"."uid"() = "user_id") OR ("public"."get_user_role"("auth"."uid"()) = 'admin'::"public"."user_role")));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: profiles Users view own profile; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Users view own profile'
      AND n.nspname = 'public'
      AND c.relname = 'profiles'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Users view own profile" ON "public"."profiles" FOR SELECT TO "authenticated" USING (("auth"."uid"() = "id"));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: audit_logs Usuários autenticados podem inserir auditoria; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Usuários autenticados podem inserir auditoria'
      AND n.nspname = 'public'
      AND c.relname = 'audit_logs'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "Usuários autenticados podem inserir auditoria" ON "public"."audit_logs" FOR INSERT TO "authenticated" WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: tenants View active tenants; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'View active tenants'
      AND n.nspname = 'public'
      AND c.relname = 'tenants'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "View active tenants" ON "public"."tenants" FOR SELECT TO "authenticated" USING (("status" = 'active'::"text"));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: label_config admin_all_label_config; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'admin_all_label_config'
      AND n.nspname = 'public'
      AND c.relname = 'label_config'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "admin_all_label_config" ON "public"."label_config" USING ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = ANY (ARRAY['admin'::"public"."user_role", 'gestor'::"public"."user_role"]))))));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: appointments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."appointments" ENABLE ROW LEVEL SECURITY;

--
-- Name: appointments appointments_delete; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'appointments_delete'
      AND n.nspname = 'public'
      AND c.relname = 'appointments'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "appointments_delete" ON "public"."appointments" FOR DELETE USING (("tenant_id" = "public"."get_current_tenant_id"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: appointments appointments_insert; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'appointments_insert'
      AND n.nspname = 'public'
      AND c.relname = 'appointments'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "appointments_insert" ON "public"."appointments" FOR INSERT WITH CHECK (("tenant_id" = "public"."get_current_tenant_id"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: appointments appointments_select; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'appointments_select'
      AND n.nspname = 'public'
      AND c.relname = 'appointments'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "appointments_select" ON "public"."appointments" FOR SELECT USING (("tenant_id" = "public"."get_current_tenant_id"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: appointments appointments_update; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'appointments_update'
      AND n.nspname = 'public'
      AND c.relname = 'appointments'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "appointments_update" ON "public"."appointments" FOR UPDATE USING (("tenant_id" = "public"."get_current_tenant_id"())) WITH CHECK (("tenant_id" = "public"."get_current_tenant_id"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: audit_logs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."audit_logs" ENABLE ROW LEVEL SECURITY;

--
-- Name: banners; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."banners" ENABLE ROW LEVEL SECURITY;

--
-- Name: banners banners_admin_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'banners_admin_all'
      AND n.nspname = 'public'
      AND c.relname = 'banners'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "banners_admin_all" ON "public"."banners" TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"public"."user_role"))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"public"."user_role")))));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: banners banners_public_read; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'banners_public_read'
      AND n.nspname = 'public'
      AND c.relname = 'banners'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "banners_public_read" ON "public"."banners" FOR SELECT USING (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: bill_installments bill_inst_auth; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'bill_inst_auth'
      AND n.nspname = 'public'
      AND c.relname = 'bill_installments'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "bill_inst_auth" ON "public"."bill_installments" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: bill_installments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."bill_installments" ENABLE ROW LEVEL SECURITY;

--
-- Name: bookable_resources; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."bookable_resources" ENABLE ROW LEVEL SECURITY;

--
-- Name: cash_registers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."cash_registers" ENABLE ROW LEVEL SECURITY;

--
-- Name: categories; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."categories" ENABLE ROW LEVEL SECURITY;

--
-- Name: chat_messages; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."chat_messages" ENABLE ROW LEVEL SECURITY;

--
-- Name: company; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."company" ENABLE ROW LEVEL SECURITY;

--
-- Name: coupon_usages; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."coupon_usages" ENABLE ROW LEVEL SECURITY;

--
-- Name: coupon_usages coupon_usages_admin_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'coupon_usages_admin_all'
      AND n.nspname = 'public'
      AND c.relname = 'coupon_usages'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "coupon_usages_admin_all" ON "public"."coupon_usages" TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"public"."user_role"))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"public"."user_role")))));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: coupon_usages coupon_usages_own_read; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'coupon_usages_own_read'
      AND n.nspname = 'public'
      AND c.relname = 'coupon_usages'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "coupon_usages_own_read" ON "public"."coupon_usages" FOR SELECT TO "authenticated" USING (("user_id" = "auth"."uid"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: coupons; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."coupons" ENABLE ROW LEVEL SECURITY;

--
-- Name: coupons coupons_admin_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'coupons_admin_all'
      AND n.nspname = 'public'
      AND c.relname = 'coupons'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "coupons_admin_all" ON "public"."coupons" TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"public"."user_role"))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"public"."user_role")))));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: coupons coupons_public_read; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'coupons_public_read'
      AND n.nspname = 'public'
      AND c.relname = 'coupons'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "coupons_public_read" ON "public"."coupons" FOR SELECT USING (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: crm_notes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."crm_notes" ENABLE ROW LEVEL SECURITY;

--
-- Name: crm_notes crm_notes_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'crm_notes_all'
      AND n.nspname = 'public'
      AND c.relname = 'crm_notes'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "crm_notes_all" ON "public"."crm_notes" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: customers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."customers" ENABLE ROW LEVEL SECURITY;

--
-- Name: monthly_cycles cycles_auth; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'cycles_auth'
      AND n.nspname = 'public'
      AND c.relname = 'monthly_cycles'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "cycles_auth" ON "public"."monthly_cycles" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: employees; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."employees" ENABLE ROW LEVEL SECURITY;

--
-- Name: employees employees_delete; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'employees_delete'
      AND n.nspname = 'public'
      AND c.relname = 'employees'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "employees_delete" ON "public"."employees" FOR DELETE USING (("tenant_id" = "public"."get_current_tenant_id"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: employees employees_insert; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'employees_insert'
      AND n.nspname = 'public'
      AND c.relname = 'employees'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "employees_insert" ON "public"."employees" FOR INSERT WITH CHECK (("tenant_id" = "public"."get_current_tenant_id"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: employees employees_select; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'employees_select'
      AND n.nspname = 'public'
      AND c.relname = 'employees'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "employees_select" ON "public"."employees" FOR SELECT USING (("tenant_id" = "public"."get_current_tenant_id"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: employees employees_update; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'employees_update'
      AND n.nspname = 'public'
      AND c.relname = 'employees'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "employees_update" ON "public"."employees" FOR UPDATE USING (("tenant_id" = "public"."get_current_tenant_id"())) WITH CHECK (("tenant_id" = "public"."get_current_tenant_id"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: payment_gateways gateways_admin_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'gateways_admin_all'
      AND n.nspname = 'public'
      AND c.relname = 'payment_gateways'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "gateways_admin_all" ON "public"."payment_gateways" TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"public"."user_role"))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"public"."user_role")))));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: payment_gateways gateways_public_read; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'gateways_public_read'
      AND n.nspname = 'public'
      AND c.relname = 'payment_gateways'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "gateways_public_read" ON "public"."payment_gateways" FOR SELECT USING (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: goods_receipt_items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."goods_receipt_items" ENABLE ROW LEVEL SECURITY;

--
-- Name: goods_receipts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."goods_receipts" ENABLE ROW LEVEL SECURITY;

--
-- Name: inauguration_banner; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."inauguration_banner" ENABLE ROW LEVEL SECURITY;

--
-- Name: inauguration_banner inauguration_banner_admin_write; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'inauguration_banner_admin_write'
      AND n.nspname = 'public'
      AND c.relname = 'inauguration_banner'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "inauguration_banner_admin_write" ON "public"."inauguration_banner" USING ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"public"."user_role")))));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: inauguration_banner inauguration_banner_public_read; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'inauguration_banner_public_read'
      AND n.nspname = 'public'
      AND c.relname = 'inauguration_banner'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "inauguration_banner_public_read" ON "public"."inauguration_banner" FOR SELECT USING (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: label_config; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."label_config" ENABLE ROW LEVEL SECURITY;

--
-- Name: monthly_cycles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."monthly_cycles" ENABLE ROW LEVEL SECURITY;

--
-- Name: notification_settings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."notification_settings" ENABLE ROW LEVEL SECURITY;

--
-- Name: notification_settings notification_settings_admin_write; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'notification_settings_admin_write'
      AND n.nspname = 'public'
      AND c.relname = 'notification_settings'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "notification_settings_admin_write" ON "public"."notification_settings" USING ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"public"."user_role")))));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: notification_settings notification_settings_public_read; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'notification_settings_public_read'
      AND n.nspname = 'public'
      AND c.relname = 'notification_settings'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "notification_settings_public_read" ON "public"."notification_settings" FOR SELECT USING (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: online_order_items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."online_order_items" ENABLE ROW LEVEL SECURITY;

--
-- Name: online_order_items online_order_items_auth; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'online_order_items_auth'
      AND n.nspname = 'public'
      AND c.relname = 'online_order_items'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "online_order_items_auth" ON "public"."online_order_items" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: online_orders; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."online_orders" ENABLE ROW LEVEL SECURITY;

--
-- Name: online_orders online_orders_auth; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'online_orders_auth'
      AND n.nspname = 'public'
      AND c.relname = 'online_orders'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "online_orders_auth" ON "public"."online_orders" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: banners open_auth_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'open_auth_all'
      AND n.nspname = 'public'
      AND c.relname = 'banners'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "open_auth_all" ON "public"."banners" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: cash_registers open_auth_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'open_auth_all'
      AND n.nspname = 'public'
      AND c.relname = 'cash_registers'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "open_auth_all" ON "public"."cash_registers" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: categories open_auth_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'open_auth_all'
      AND n.nspname = 'public'
      AND c.relname = 'categories'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "open_auth_all" ON "public"."categories" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: chat_messages open_auth_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'open_auth_all'
      AND n.nspname = 'public'
      AND c.relname = 'chat_messages'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "open_auth_all" ON "public"."chat_messages" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: company open_auth_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'open_auth_all'
      AND n.nspname = 'public'
      AND c.relname = 'company'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "open_auth_all" ON "public"."company" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: coupon_usages open_auth_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'open_auth_all'
      AND n.nspname = 'public'
      AND c.relname = 'coupon_usages'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "open_auth_all" ON "public"."coupon_usages" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: coupons open_auth_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'open_auth_all'
      AND n.nspname = 'public'
      AND c.relname = 'coupons'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "open_auth_all" ON "public"."coupons" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: crm_notes open_auth_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'open_auth_all'
      AND n.nspname = 'public'
      AND c.relname = 'crm_notes'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "open_auth_all" ON "public"."crm_notes" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: customers open_auth_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'open_auth_all'
      AND n.nspname = 'public'
      AND c.relname = 'customers'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "open_auth_all" ON "public"."customers" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: goods_receipt_items open_auth_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'open_auth_all'
      AND n.nspname = 'public'
      AND c.relname = 'goods_receipt_items'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "open_auth_all" ON "public"."goods_receipt_items" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: goods_receipts open_auth_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'open_auth_all'
      AND n.nspname = 'public'
      AND c.relname = 'goods_receipts'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "open_auth_all" ON "public"."goods_receipts" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: online_order_items open_auth_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'open_auth_all'
      AND n.nspname = 'public'
      AND c.relname = 'online_order_items'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "open_auth_all" ON "public"."online_order_items" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: online_orders open_auth_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'open_auth_all'
      AND n.nspname = 'public'
      AND c.relname = 'online_orders'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "open_auth_all" ON "public"."online_orders" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: orders open_auth_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'open_auth_all'
      AND n.nspname = 'public'
      AND c.relname = 'orders'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "open_auth_all" ON "public"."orders" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: payment_gateways open_auth_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'open_auth_all'
      AND n.nspname = 'public'
      AND c.relname = 'payment_gateways'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "open_auth_all" ON "public"."payment_gateways" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_categories open_auth_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'open_auth_all'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_categories'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "open_auth_all" ON "public"."pdv_categories" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_certificates open_auth_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'open_auth_all'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_certificates'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "open_auth_all" ON "public"."pdv_certificates" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_cupom_contingencia open_auth_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'open_auth_all'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_cupom_contingencia'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "open_auth_all" ON "public"."pdv_cupom_contingencia" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_cupom_items open_auth_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'open_auth_all'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_cupom_items'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "open_auth_all" ON "public"."pdv_cupom_items" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_cupons open_auth_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'open_auth_all'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_cupons'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "open_auth_all" ON "public"."pdv_cupons" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_fiscal_config open_auth_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'open_auth_all'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_fiscal_config'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "open_auth_all" ON "public"."pdv_fiscal_config" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_invoice_items open_auth_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'open_auth_all'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_invoice_items'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "open_auth_all" ON "public"."pdv_invoice_items" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_invoices open_auth_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'open_auth_all'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_invoices'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "open_auth_all" ON "public"."pdv_invoices" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_payment_methods open_auth_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'open_auth_all'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_payment_methods'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "open_auth_all" ON "public"."pdv_payment_methods" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_products open_auth_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'open_auth_all'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_products'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "open_auth_all" ON "public"."pdv_products" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_stock_movements open_auth_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'open_auth_all'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_stock_movements'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "open_auth_all" ON "public"."pdv_stock_movements" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: products open_auth_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'open_auth_all'
      AND n.nspname = 'public'
      AND c.relname = 'products'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "open_auth_all" ON "public"."products" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: profiles open_auth_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'open_auth_all'
      AND n.nspname = 'public'
      AND c.relname = 'profiles'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "open_auth_all" ON "public"."profiles" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: promotions open_auth_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'open_auth_all'
      AND n.nspname = 'public'
      AND c.relname = 'promotions'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "open_auth_all" ON "public"."promotions" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: return_items open_auth_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'open_auth_all'
      AND n.nspname = 'public'
      AND c.relname = 'return_items'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "open_auth_all" ON "public"."return_items" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: returns open_auth_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'open_auth_all'
      AND n.nspname = 'public'
      AND c.relname = 'returns'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "open_auth_all" ON "public"."returns" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: stock_movements open_auth_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'open_auth_all'
      AND n.nspname = 'public'
      AND c.relname = 'stock_movements'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "open_auth_all" ON "public"."stock_movements" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: store_settings open_auth_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'open_auth_all'
      AND n.nspname = 'public'
      AND c.relname = 'store_settings'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "open_auth_all" ON "public"."store_settings" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: subscriptions open_auth_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'open_auth_all'
      AND n.nspname = 'public'
      AND c.relname = 'subscriptions'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "open_auth_all" ON "public"."subscriptions" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: suppliers open_auth_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'open_auth_all'
      AND n.nspname = 'public'
      AND c.relname = 'suppliers'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "open_auth_all" ON "public"."suppliers" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: theme_settings open_auth_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'open_auth_all'
      AND n.nspname = 'public'
      AND c.relname = 'theme_settings'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "open_auth_all" ON "public"."theme_settings" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: transactions open_auth_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'open_auth_all'
      AND n.nspname = 'public'
      AND c.relname = 'transactions'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "open_auth_all" ON "public"."transactions" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: warranties open_auth_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'open_auth_all'
      AND n.nspname = 'public'
      AND c.relname = 'warranties'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "open_auth_all" ON "public"."warranties" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: wishlist open_auth_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'open_auth_all'
      AND n.nspname = 'public'
      AND c.relname = 'wishlist'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "open_auth_all" ON "public"."wishlist" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: orders; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."orders" ENABLE ROW LEVEL SECURITY;

--
-- Name: payment_gateways; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."payment_gateways" ENABLE ROW LEVEL SECURITY;

--
-- Name: payroll_entries payroll_delete; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'payroll_delete'
      AND n.nspname = 'public'
      AND c.relname = 'payroll_entries'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "payroll_delete" ON "public"."payroll_entries" FOR DELETE USING (("tenant_id" = "public"."get_current_tenant_id"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: payroll_entries; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."payroll_entries" ENABLE ROW LEVEL SECURITY;

--
-- Name: payroll_entries payroll_insert; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'payroll_insert'
      AND n.nspname = 'public'
      AND c.relname = 'payroll_entries'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "payroll_insert" ON "public"."payroll_entries" FOR INSERT WITH CHECK (("tenant_id" = "public"."get_current_tenant_id"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: payroll_entries payroll_select; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'payroll_select'
      AND n.nspname = 'public'
      AND c.relname = 'payroll_entries'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "payroll_select" ON "public"."payroll_entries" FOR SELECT USING (("tenant_id" = "public"."get_current_tenant_id"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: payroll_entries payroll_update; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'payroll_update'
      AND n.nspname = 'public'
      AND c.relname = 'payroll_entries'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "payroll_update" ON "public"."payroll_entries" FOR UPDATE USING (("tenant_id" = "public"."get_current_tenant_id"())) WITH CHECK (("tenant_id" = "public"."get_current_tenant_id"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_categories pdv_admin_delete_categories; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'pdv_admin_delete_categories'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_categories'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "pdv_admin_delete_categories" ON "public"."pdv_categories" FOR DELETE TO "authenticated" USING ("public"."is_pdv_admin"("auth"."uid"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_categories pdv_admin_update_categories; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'pdv_admin_update_categories'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_categories'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "pdv_admin_update_categories" ON "public"."pdv_categories" FOR UPDATE TO "authenticated" USING (("public"."get_pdv_user_role"("auth"."uid"()) = ANY (ARRAY['admin'::"public"."user_role", 'gestor'::"public"."user_role"])));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: company pdv_admin_update_company; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'pdv_admin_update_company'
      AND n.nspname = 'public'
      AND c.relname = 'company'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "pdv_admin_update_company" ON "public"."company" FOR UPDATE TO "authenticated" USING ("public"."is_pdv_admin"("auth"."uid"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_categories pdv_admin_write_categories; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'pdv_admin_write_categories'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_categories'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "pdv_admin_write_categories" ON "public"."pdv_categories" FOR INSERT TO "authenticated" WITH CHECK (("public"."get_pdv_user_role"("auth"."uid"()) = ANY (ARRAY['admin'::"public"."user_role", 'gestor'::"public"."user_role"])));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: company pdv_admin_write_company; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'pdv_admin_write_company'
      AND n.nspname = 'public'
      AND c.relname = 'company'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "pdv_admin_write_company" ON "public"."company" FOR INSERT TO "authenticated" WITH CHECK ("public"."is_pdv_admin"("auth"."uid"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_categories; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."pdv_categories" ENABLE ROW LEVEL SECURITY;

--
-- Name: pdv_certificates; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."pdv_certificates" ENABLE ROW LEVEL SECURITY;

--
-- Name: pdv_cupom_contingencia; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."pdv_cupom_contingencia" ENABLE ROW LEVEL SECURITY;

--
-- Name: pdv_cupom_items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."pdv_cupom_items" ENABLE ROW LEVEL SECURITY;

--
-- Name: pdv_cupons; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."pdv_cupons" ENABLE ROW LEVEL SECURITY;

--
-- Name: pdv_fiscal_config; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."pdv_fiscal_config" ENABLE ROW LEVEL SECURITY;

--
-- Name: pdv_invoice_items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."pdv_invoice_items" ENABLE ROW LEVEL SECURITY;

--
-- Name: pdv_invoices; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."pdv_invoices" ENABLE ROW LEVEL SECURITY;

--
-- Name: pdv_payment_methods; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."pdv_payment_methods" ENABLE ROW LEVEL SECURITY;

--
-- Name: pdv_products; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."pdv_products" ENABLE ROW LEVEL SECURITY;

--
-- Name: cash_registers pdv_staff_all_cash; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'pdv_staff_all_cash'
      AND n.nspname = 'public'
      AND c.relname = 'cash_registers'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "pdv_staff_all_cash" ON "public"."cash_registers" TO "authenticated" USING ("public"."is_pdv_staff"("auth"."uid"())) WITH CHECK ("public"."is_pdv_staff"("auth"."uid"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: customers pdv_staff_all_customers; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'pdv_staff_all_customers'
      AND n.nspname = 'public'
      AND c.relname = 'customers'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "pdv_staff_all_customers" ON "public"."customers" TO "authenticated" USING ("public"."is_pdv_staff"("auth"."uid"())) WITH CHECK ("public"."is_pdv_staff"("auth"."uid"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_invoice_items pdv_staff_all_invoice_items; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'pdv_staff_all_invoice_items'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_invoice_items'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "pdv_staff_all_invoice_items" ON "public"."pdv_invoice_items" TO "authenticated" USING ("public"."is_pdv_staff"("auth"."uid"())) WITH CHECK ("public"."is_pdv_staff"("auth"."uid"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_invoices pdv_staff_all_invoices; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'pdv_staff_all_invoices'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_invoices'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "pdv_staff_all_invoices" ON "public"."pdv_invoices" TO "authenticated" USING ("public"."is_pdv_staff"("auth"."uid"())) WITH CHECK ("public"."is_pdv_staff"("auth"."uid"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_products pdv_staff_all_products; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'pdv_staff_all_products'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_products'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "pdv_staff_all_products" ON "public"."pdv_products" TO "authenticated" USING ("public"."is_pdv_staff"("auth"."uid"())) WITH CHECK ("public"."is_pdv_staff"("auth"."uid"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: goods_receipt_items pdv_staff_all_receipt_items; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'pdv_staff_all_receipt_items'
      AND n.nspname = 'public'
      AND c.relname = 'goods_receipt_items'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "pdv_staff_all_receipt_items" ON "public"."goods_receipt_items" TO "authenticated" USING ("public"."is_pdv_staff"("auth"."uid"())) WITH CHECK ("public"."is_pdv_staff"("auth"."uid"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: goods_receipts pdv_staff_all_receipts; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'pdv_staff_all_receipts'
      AND n.nspname = 'public'
      AND c.relname = 'goods_receipts'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "pdv_staff_all_receipts" ON "public"."goods_receipts" TO "authenticated" USING ("public"."is_pdv_staff"("auth"."uid"())) WITH CHECK ("public"."is_pdv_staff"("auth"."uid"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_stock_movements pdv_staff_all_stock_mov; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'pdv_staff_all_stock_mov'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_stock_movements'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "pdv_staff_all_stock_mov" ON "public"."pdv_stock_movements" TO "authenticated" USING ("public"."is_pdv_staff"("auth"."uid"())) WITH CHECK ("public"."is_pdv_staff"("auth"."uid"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: suppliers pdv_staff_all_suppliers; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'pdv_staff_all_suppliers'
      AND n.nspname = 'public'
      AND c.relname = 'suppliers'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "pdv_staff_all_suppliers" ON "public"."suppliers" TO "authenticated" USING ("public"."is_pdv_staff"("auth"."uid"())) WITH CHECK ("public"."is_pdv_staff"("auth"."uid"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: transactions pdv_staff_all_transactions; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'pdv_staff_all_transactions'
      AND n.nspname = 'public'
      AND c.relname = 'transactions'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "pdv_staff_all_transactions" ON "public"."transactions" TO "authenticated" USING ("public"."is_pdv_staff"("auth"."uid"())) WITH CHECK ("public"."is_pdv_staff"("auth"."uid"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_categories pdv_staff_read_categories; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'pdv_staff_read_categories'
      AND n.nspname = 'public'
      AND c.relname = 'pdv_categories'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "pdv_staff_read_categories" ON "public"."pdv_categories" FOR SELECT TO "authenticated" USING ("public"."is_pdv_staff"("auth"."uid"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: company pdv_staff_read_company; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'pdv_staff_read_company'
      AND n.nspname = 'public'
      AND c.relname = 'company'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "pdv_staff_read_company" ON "public"."company" FOR SELECT TO "authenticated" USING ("public"."is_pdv_staff"("auth"."uid"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: pdv_stock_movements; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."pdv_stock_movements" ENABLE ROW LEVEL SECURITY;

--
-- Name: products; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."products" ENABLE ROW LEVEL SECURITY;

--
-- Name: profiles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."profiles" ENABLE ROW LEVEL SECURITY;

--
-- Name: promotions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."promotions" ENABLE ROW LEVEL SECURITY;

--
-- Name: promotions promotions_admin_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'promotions_admin_all'
      AND n.nspname = 'public'
      AND c.relname = 'promotions'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "promotions_admin_all" ON "public"."promotions" TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"public"."user_role"))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"public"."user_role")))));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: promotions promotions_public_read; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'promotions_public_read'
      AND n.nspname = 'public'
      AND c.relname = 'promotions'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "promotions_public_read" ON "public"."promotions" FOR SELECT USING (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: bookable_resources resources_delete; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'resources_delete'
      AND n.nspname = 'public'
      AND c.relname = 'bookable_resources'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "resources_delete" ON "public"."bookable_resources" FOR DELETE USING (("tenant_id" = "public"."get_current_tenant_id"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: bookable_resources resources_insert; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'resources_insert'
      AND n.nspname = 'public'
      AND c.relname = 'bookable_resources'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "resources_insert" ON "public"."bookable_resources" FOR INSERT WITH CHECK (("tenant_id" = "public"."get_current_tenant_id"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: bookable_resources resources_select; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'resources_select'
      AND n.nspname = 'public'
      AND c.relname = 'bookable_resources'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "resources_select" ON "public"."bookable_resources" FOR SELECT USING (("tenant_id" = "public"."get_current_tenant_id"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: bookable_resources resources_update; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'resources_update'
      AND n.nspname = 'public'
      AND c.relname = 'bookable_resources'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "resources_update" ON "public"."bookable_resources" FOR UPDATE USING (("tenant_id" = "public"."get_current_tenant_id"())) WITH CHECK (("tenant_id" = "public"."get_current_tenant_id"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: return_items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."return_items" ENABLE ROW LEVEL SECURITY;

--
-- Name: return_items return_items_auth; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'return_items_auth'
      AND n.nspname = 'public'
      AND c.relname = 'return_items'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "return_items_auth" ON "public"."return_items" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: returns; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."returns" ENABLE ROW LEVEL SECURITY;

--
-- Name: returns returns_auth; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'returns_auth'
      AND n.nspname = 'public'
      AND c.relname = 'returns'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "returns_auth" ON "public"."returns" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: shipping_methods; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."shipping_methods" ENABLE ROW LEVEL SECURITY;

--
-- Name: site_coupon_config; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."site_coupon_config" ENABLE ROW LEVEL SECURITY;

--
-- Name: site_coupon_config site_coupon_config_admin_write; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'site_coupon_config_admin_write'
      AND n.nspname = 'public'
      AND c.relname = 'site_coupon_config'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "site_coupon_config_admin_write" ON "public"."site_coupon_config" USING ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"public"."user_role")))));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: site_coupon_config site_coupon_config_public_read; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'site_coupon_config_public_read'
      AND n.nspname = 'public'
      AND c.relname = 'site_coupon_config'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "site_coupon_config_public_read" ON "public"."site_coupon_config" FOR SELECT USING (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: stock_movements; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."stock_movements" ENABLE ROW LEVEL SECURITY;

--
-- Name: store_settings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."store_settings" ENABLE ROW LEVEL SECURITY;

--
-- Name: subscriptions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."subscriptions" ENABLE ROW LEVEL SECURITY;

--
-- Name: suppliers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."suppliers" ENABLE ROW LEVEL SECURITY;

--
-- Name: theme_settings theme_admin_all; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'theme_admin_all'
      AND n.nspname = 'public'
      AND c.relname = 'theme_settings'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "theme_admin_all" ON "public"."theme_settings" TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"public"."user_role"))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = "auth"."uid"()) AND ("profiles"."role" = 'admin'::"public"."user_role")))));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: theme_settings theme_public_read; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'theme_public_read'
      AND n.nspname = 'public'
      AND c.relname = 'theme_settings'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "theme_public_read" ON "public"."theme_settings" FOR SELECT USING (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: theme_settings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."theme_settings" ENABLE ROW LEVEL SECURITY;

--
-- Name: time_records; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."time_records" ENABLE ROW LEVEL SECURITY;

--
-- Name: time_records time_records_delete; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'time_records_delete'
      AND n.nspname = 'public'
      AND c.relname = 'time_records'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "time_records_delete" ON "public"."time_records" FOR DELETE USING (("tenant_id" = "public"."get_current_tenant_id"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: time_records time_records_insert; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'time_records_insert'
      AND n.nspname = 'public'
      AND c.relname = 'time_records'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "time_records_insert" ON "public"."time_records" FOR INSERT WITH CHECK (("tenant_id" = "public"."get_current_tenant_id"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: time_records time_records_select; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'time_records_select'
      AND n.nspname = 'public'
      AND c.relname = 'time_records'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "time_records_select" ON "public"."time_records" FOR SELECT USING (("tenant_id" = "public"."get_current_tenant_id"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: time_records time_records_update; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'time_records_update'
      AND n.nspname = 'public'
      AND c.relname = 'time_records'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "time_records_update" ON "public"."time_records" FOR UPDATE USING (("tenant_id" = "public"."get_current_tenant_id"())) WITH CHECK (("tenant_id" = "public"."get_current_tenant_id"()));
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: transactions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."transactions" ENABLE ROW LEVEL SECURITY;

--
-- Name: user_permissions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."user_permissions" ENABLE ROW LEVEL SECURITY;

--
-- Name: warranties; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."warranties" ENABLE ROW LEVEL SECURITY;

--
-- Name: warranties warranties_auth; Type: POLICY; Schema: public; Owner: -
--

DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'warranties_auth'
      AND n.nspname = 'public'
      AND c.relname = 'warranties'
  ) THEN
    EXECUTE $pg_schema_sql$
CREATE POLICY "warranties_auth" ON "public"."warranties" TO "authenticated" USING (true) WITH CHECK (true);
$pg_schema_sql$;
  END IF;
END
$pg_schema_restore$;


--
-- Name: wishlist; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."wishlist" ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--




-- ============================================================
-- SECTION: DIFF FILTER OBJECTS
-- ============================================================
-- Objects that match diff-filter.json but cannot be represented
-- precisely by pg_dump --filter.

-- auth.users trigger: on_auth_user_created
DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger t
    JOIN pg_class c ON c.oid = t.tgrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE NOT t.tgisinternal
      AND t.tgname = 'on_auth_user_created'
      AND n.nspname = 'auth'
      AND c.relname = 'users'
  ) THEN
    EXECUTE 'CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();';
  END IF;
END
$pg_schema_restore$;
-- policy: "Admin pode deletar imagens" on storage.objects
DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Admin pode deletar imagens'
      AND n.nspname = 'storage'
      AND c.relname = 'objects'
  ) THEN
    EXECUTE 'CREATE POLICY "Admin pode deletar imagens" ON storage.objects AS PERMISSIVE FOR DELETE TO authenticated USING (((bucket_id = ''store-images''::text) AND (( SELECT profiles.role
   FROM public.profiles
  WHERE (profiles.id = auth.uid())) = ''admin''::public.user_role)));';
  END IF;
END
$pg_schema_restore$;
-- policy: "Admin pode fazer upload" on storage.objects
DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Admin pode fazer upload'
      AND n.nspname = 'storage'
      AND c.relname = 'objects'
  ) THEN
    EXECUTE 'CREATE POLICY "Admin pode fazer upload" ON storage.objects AS PERMISSIVE FOR INSERT TO authenticated WITH CHECK (((bucket_id = ''store-images''::text) AND (( SELECT profiles.role
   FROM public.profiles
  WHERE (profiles.id = auth.uid())) = ''admin''::public.user_role)));';
  END IF;
END
$pg_schema_restore$;
-- policy: "Allow Update Product Images" on storage.objects
DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Allow Update Product Images'
      AND n.nspname = 'storage'
      AND c.relname = 'objects'
  ) THEN
    EXECUTE 'CREATE POLICY "Allow Update Product Images" ON storage.objects AS PERMISSIVE FOR UPDATE TO PUBLIC USING ((bucket_id = ''product-images''::text));';
  END IF;
END
$pg_schema_restore$;
-- policy: "Allow Upload Product Images" on storage.objects
DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Allow Upload Product Images'
      AND n.nspname = 'storage'
      AND c.relname = 'objects'
  ) THEN
    EXECUTE 'CREATE POLICY "Allow Upload Product Images" ON storage.objects AS PERMISSIVE FOR INSERT TO PUBLIC WITH CHECK ((bucket_id = ''product-images''::text));';
  END IF;
END
$pg_schema_restore$;
-- policy: "Allow authenticated reads" on storage.objects
DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Allow authenticated reads'
      AND n.nspname = 'storage'
      AND c.relname = 'objects'
  ) THEN
    EXECUTE 'CREATE POLICY "Allow authenticated reads" ON storage.objects AS PERMISSIVE FOR SELECT TO authenticated USING ((bucket_id = ''invoices''::text));';
  END IF;
END
$pg_schema_restore$;
-- policy: "Allow authenticated uploads" on storage.objects
DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Allow authenticated uploads'
      AND n.nspname = 'storage'
      AND c.relname = 'objects'
  ) THEN
    EXECUTE 'CREATE POLICY "Allow authenticated uploads" ON storage.objects AS PERMISSIVE FOR INSERT TO authenticated WITH CHECK ((bucket_id = ''invoices''::text));';
  END IF;
END
$pg_schema_restore$;
-- policy: "Allow service role all" on storage.objects
DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Allow service role all'
      AND n.nspname = 'storage'
      AND c.relname = 'objects'
  ) THEN
    EXECUTE 'CREATE POLICY "Allow service role all" ON storage.objects AS PERMISSIVE FOR ALL TO service_role USING ((bucket_id = ''invoices''::text)) WITH CHECK ((bucket_id = ''invoices''::text));';
  END IF;
END
$pg_schema_restore$;
-- policy: "Imagens publicas para leitura" on storage.objects
DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Imagens publicas para leitura'
      AND n.nspname = 'storage'
      AND c.relname = 'objects'
  ) THEN
    EXECUTE 'CREATE POLICY "Imagens publicas para leitura" ON storage.objects AS PERMISSIVE FOR SELECT TO PUBLIC USING ((bucket_id = ''store-images''::text));';
  END IF;
END
$pg_schema_restore$;
-- policy: "Public Read Product Images" on storage.objects
DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'Public Read Product Images'
      AND n.nspname = 'storage'
      AND c.relname = 'objects'
  ) THEN
    EXECUTE 'CREATE POLICY "Public Read Product Images" ON storage.objects AS PERMISSIVE FOR SELECT TO PUBLIC USING ((bucket_id = ''product-images''::text));';
  END IF;
END
$pg_schema_restore$;
-- policy: company_assets_delete on storage.objects
DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'company_assets_delete'
      AND n.nspname = 'storage'
      AND c.relname = 'objects'
  ) THEN
    EXECUTE 'CREATE POLICY company_assets_delete ON storage.objects AS PERMISSIVE FOR DELETE TO PUBLIC USING (((bucket_id = ''company-assets''::text) AND (EXISTS ( SELECT 1
   FROM public.profiles
  WHERE ((profiles.id = auth.uid()) AND (profiles.role = ANY (ARRAY[''admin''::public.user_role, ''gestor''::public.user_role])))))));';
  END IF;
END
$pg_schema_restore$;
-- policy: company_assets_public_read on storage.objects
DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'company_assets_public_read'
      AND n.nspname = 'storage'
      AND c.relname = 'objects'
  ) THEN
    EXECUTE 'CREATE POLICY company_assets_public_read ON storage.objects AS PERMISSIVE FOR SELECT TO PUBLIC USING ((bucket_id = ''company-assets''::text));';
  END IF;
END
$pg_schema_restore$;
-- policy: company_assets_update on storage.objects
DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'company_assets_update'
      AND n.nspname = 'storage'
      AND c.relname = 'objects'
  ) THEN
    EXECUTE 'CREATE POLICY company_assets_update ON storage.objects AS PERMISSIVE FOR UPDATE TO PUBLIC USING (((bucket_id = ''company-assets''::text) AND (EXISTS ( SELECT 1
   FROM public.profiles
  WHERE ((profiles.id = auth.uid()) AND (profiles.role = ANY (ARRAY[''admin''::public.user_role, ''gestor''::public.user_role])))))));';
  END IF;
END
$pg_schema_restore$;
-- policy: company_assets_upload on storage.objects
DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'company_assets_upload'
      AND n.nspname = 'storage'
      AND c.relname = 'objects'
  ) THEN
    EXECUTE 'CREATE POLICY company_assets_upload ON storage.objects AS PERMISSIVE FOR INSERT TO PUBLIC WITH CHECK (((bucket_id = ''company-assets''::text) AND (EXISTS ( SELECT 1
   FROM public.profiles
  WHERE ((profiles.id = auth.uid()) AND (profiles.role = ANY (ARRAY[''admin''::public.user_role, ''gestor''::public.user_role])))))));';
  END IF;
END
$pg_schema_restore$;
-- policy: invoices_delete on storage.objects
DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'invoices_delete'
      AND n.nspname = 'storage'
      AND c.relname = 'objects'
  ) THEN
    EXECUTE 'CREATE POLICY invoices_delete ON storage.objects AS PERMISSIVE FOR DELETE TO PUBLIC USING (((bucket_id = ''invoices''::text) AND (EXISTS ( SELECT 1
   FROM public.profiles
  WHERE ((profiles.id = auth.uid()) AND (profiles.role = ANY (ARRAY[''admin''::public.user_role, ''gestor''::public.user_role, ''operador''::public.user_role])))))));';
  END IF;
END
$pg_schema_restore$;
-- policy: invoices_read on storage.objects
DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'invoices_read'
      AND n.nspname = 'storage'
      AND c.relname = 'objects'
  ) THEN
    EXECUTE 'CREATE POLICY invoices_read ON storage.objects AS PERMISSIVE FOR SELECT TO PUBLIC USING (((bucket_id = ''invoices''::text) AND (EXISTS ( SELECT 1
   FROM public.profiles
  WHERE ((profiles.id = auth.uid()) AND (profiles.role = ANY (ARRAY[''admin''::public.user_role, ''gestor''::public.user_role, ''operador''::public.user_role])))))));';
  END IF;
END
$pg_schema_restore$;
-- policy: invoices_upload on storage.objects
DO $pg_schema_restore$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy pol
    JOIN pg_class c ON c.oid = pol.polrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE pol.polname = 'invoices_upload'
      AND n.nspname = 'storage'
      AND c.relname = 'objects'
  ) THEN
    EXECUTE 'CREATE POLICY invoices_upload ON storage.objects AS PERMISSIVE FOR INSERT TO PUBLIC WITH CHECK (((bucket_id = ''invoices''::text) AND (EXISTS ( SELECT 1
   FROM public.profiles
  WHERE ((profiles.id = auth.uid()) AND (profiles.role = ANY (ARRAY[''admin''::public.user_role, ''gestor''::public.user_role, ''operador''::public.user_role])))))));';
  END IF;
END
$pg_schema_restore$;
-- publication table: supabase_realtime -> public.banners
DO $pg_schema_restore$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_publication WHERE pubname = 'supabase_realtime') AND NOT EXISTS (
    SELECT 1 FROM pg_publication_rel pr
    JOIN pg_publication p ON p.oid = pr.prpubid
    WHERE p.pubname = 'supabase_realtime'
      AND pr.prrelid = to_regclass('public.banners')
  ) THEN
    EXECUTE 'ALTER PUBLICATION supabase_realtime ADD TABLE public.banners;';
  END IF;
END
$pg_schema_restore$;
-- publication table: supabase_realtime -> public.bill_installments
DO $pg_schema_restore$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_publication WHERE pubname = 'supabase_realtime') AND NOT EXISTS (
    SELECT 1 FROM pg_publication_rel pr
    JOIN pg_publication p ON p.oid = pr.prpubid
    WHERE p.pubname = 'supabase_realtime'
      AND pr.prrelid = to_regclass('public.bill_installments')
  ) THEN
    EXECUTE 'ALTER PUBLICATION supabase_realtime ADD TABLE public.bill_installments;';
  END IF;
END
$pg_schema_restore$;
-- publication table: supabase_realtime -> public.chat_messages
DO $pg_schema_restore$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_publication WHERE pubname = 'supabase_realtime') AND NOT EXISTS (
    SELECT 1 FROM pg_publication_rel pr
    JOIN pg_publication p ON p.oid = pr.prpubid
    WHERE p.pubname = 'supabase_realtime'
      AND pr.prrelid = to_regclass('public.chat_messages')
  ) THEN
    EXECUTE 'ALTER PUBLICATION supabase_realtime ADD TABLE public.chat_messages;';
  END IF;
END
$pg_schema_restore$;
-- publication table: supabase_realtime -> public.coupon_usages
DO $pg_schema_restore$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_publication WHERE pubname = 'supabase_realtime') AND NOT EXISTS (
    SELECT 1 FROM pg_publication_rel pr
    JOIN pg_publication p ON p.oid = pr.prpubid
    WHERE p.pubname = 'supabase_realtime'
      AND pr.prrelid = to_regclass('public.coupon_usages')
  ) THEN
    EXECUTE 'ALTER PUBLICATION supabase_realtime ADD TABLE public.coupon_usages;';
  END IF;
END
$pg_schema_restore$;
-- publication table: supabase_realtime -> public.coupons
DO $pg_schema_restore$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_publication WHERE pubname = 'supabase_realtime') AND NOT EXISTS (
    SELECT 1 FROM pg_publication_rel pr
    JOIN pg_publication p ON p.oid = pr.prpubid
    WHERE p.pubname = 'supabase_realtime'
      AND pr.prrelid = to_regclass('public.coupons')
  ) THEN
    EXECUTE 'ALTER PUBLICATION supabase_realtime ADD TABLE public.coupons;';
  END IF;
END
$pg_schema_restore$;
-- publication table: supabase_realtime -> public.deliveries
DO $pg_schema_restore$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_publication WHERE pubname = 'supabase_realtime') AND NOT EXISTS (
    SELECT 1 FROM pg_publication_rel pr
    JOIN pg_publication p ON p.oid = pr.prpubid
    WHERE p.pubname = 'supabase_realtime'
      AND pr.prrelid = to_regclass('public.deliveries')
  ) THEN
    EXECUTE 'ALTER PUBLICATION supabase_realtime ADD TABLE public.deliveries;';
  END IF;
END
$pg_schema_restore$;
-- publication table: supabase_realtime -> public.online_orders
DO $pg_schema_restore$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_publication WHERE pubname = 'supabase_realtime') AND NOT EXISTS (
    SELECT 1 FROM pg_publication_rel pr
    JOIN pg_publication p ON p.oid = pr.prpubid
    WHERE p.pubname = 'supabase_realtime'
      AND pr.prrelid = to_regclass('public.online_orders')
  ) THEN
    EXECUTE 'ALTER PUBLICATION supabase_realtime ADD TABLE public.online_orders;';
  END IF;
END
$pg_schema_restore$;
-- publication table: supabase_realtime -> public.orders
DO $pg_schema_restore$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_publication WHERE pubname = 'supabase_realtime') AND NOT EXISTS (
    SELECT 1 FROM pg_publication_rel pr
    JOIN pg_publication p ON p.oid = pr.prpubid
    WHERE p.pubname = 'supabase_realtime'
      AND pr.prrelid = to_regclass('public.orders')
  ) THEN
    EXECUTE 'ALTER PUBLICATION supabase_realtime ADD TABLE public.orders;';
  END IF;
END
$pg_schema_restore$;
-- publication table: supabase_realtime -> public.promotions
DO $pg_schema_restore$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_publication WHERE pubname = 'supabase_realtime') AND NOT EXISTS (
    SELECT 1 FROM pg_publication_rel pr
    JOIN pg_publication p ON p.oid = pr.prpubid
    WHERE p.pubname = 'supabase_realtime'
      AND pr.prrelid = to_regclass('public.promotions')
  ) THEN
    EXECUTE 'ALTER PUBLICATION supabase_realtime ADD TABLE public.promotions;';
  END IF;
END
$pg_schema_restore$;
-- publication table: supabase_realtime -> public.returns
DO $pg_schema_restore$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_publication WHERE pubname = 'supabase_realtime') AND NOT EXISTS (
    SELECT 1 FROM pg_publication_rel pr
    JOIN pg_publication p ON p.oid = pr.prpubid
    WHERE p.pubname = 'supabase_realtime'
      AND pr.prrelid = to_regclass('public.returns')
  ) THEN
    EXECUTE 'ALTER PUBLICATION supabase_realtime ADD TABLE public.returns;';
  END IF;
END
$pg_schema_restore$;
-- publication table: supabase_realtime -> public.theme_settings
DO $pg_schema_restore$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_publication WHERE pubname = 'supabase_realtime') AND NOT EXISTS (
    SELECT 1 FROM pg_publication_rel pr
    JOIN pg_publication p ON p.oid = pr.prpubid
    WHERE p.pubname = 'supabase_realtime'
      AND pr.prrelid = to_regclass('public.theme_settings')
  ) THEN
    EXECUTE 'ALTER PUBLICATION supabase_realtime ADD TABLE public.theme_settings;';
  END IF;
END
$pg_schema_restore$;

-- ============================================================
-- SECTION: STORAGE BUCKETS DATA
-- ============================================================

INSERT INTO "storage"."buckets" ("id", "name", "owner", "created_at", "updated_at", "public", "avif_autodetection", "file_size_limit", "allowed_mime_types", "owner_id", "type") VALUES ('company-assets', 'company-assets', NULL, '2026-08-21 20:55:13.354222+00', '2026-08-21 20:55:13.354222+00', 'true', 'false', '2097152', '{image/png,image/jpeg,image/jpg,image/webp,image/svg+xml}', NULL, 'STANDARD') ON CONFLICT ("id") DO UPDATE SET "name" = EXCLUDED."name", "owner" = EXCLUDED."owner", "created_at" = EXCLUDED."created_at", "updated_at" = EXCLUDED."updated_at", "public" = EXCLUDED."public", "avif_autodetection" = EXCLUDED."avif_autodetection", "file_size_limit" = EXCLUDED."file_size_limit", "allowed_mime_types" = EXCLUDED."allowed_mime_types", "owner_id" = EXCLUDED."owner_id", "type" = EXCLUDED."type";
INSERT INTO "storage"."buckets" ("id", "name", "owner", "created_at", "updated_at", "public", "avif_autodetection", "file_size_limit", "allowed_mime_types", "owner_id", "type") VALUES ('invoices', 'invoices', NULL, '2026-06-08 01:21:07.430636+00', '2026-06-08 01:21:07.430636+00', 'true', 'false', NULL, NULL, NULL, 'STANDARD') ON CONFLICT ("id") DO UPDATE SET "name" = EXCLUDED."name", "owner" = EXCLUDED."owner", "created_at" = EXCLUDED."created_at", "updated_at" = EXCLUDED."updated_at", "public" = EXCLUDED."public", "avif_autodetection" = EXCLUDED."avif_autodetection", "file_size_limit" = EXCLUDED."file_size_limit", "allowed_mime_types" = EXCLUDED."allowed_mime_types", "owner_id" = EXCLUDED."owner_id", "type" = EXCLUDED."type";
INSERT INTO "storage"."buckets" ("id", "name", "owner", "created_at", "updated_at", "public", "avif_autodetection", "file_size_limit", "allowed_mime_types", "owner_id", "type") VALUES ('product-images', 'product-images', NULL, '2026-11-05 12:50:29.727171+00', '2026-11-05 12:50:29.727171+00', 'true', 'false', '52428800', '{image/jpeg,image/png,image/webp,image/gif}', NULL, 'STANDARD') ON CONFLICT ("id") DO UPDATE SET "name" = EXCLUDED."name", "owner" = EXCLUDED."owner", "created_at" = EXCLUDED."created_at", "updated_at" = EXCLUDED."updated_at", "public" = EXCLUDED."public", "avif_autodetection" = EXCLUDED."avif_autodetection", "file_size_limit" = EXCLUDED."file_size_limit", "allowed_mime_types" = EXCLUDED."allowed_mime_types", "owner_id" = EXCLUDED."owner_id", "type" = EXCLUDED."type";
INSERT INTO "storage"."buckets" ("id", "name", "owner", "created_at", "updated_at", "public", "avif_autodetection", "file_size_limit", "allowed_mime_types", "owner_id", "type") VALUES ('store-images', 'store-images', NULL, '2026-05-21 12:11:05.16982+00', '2026-05-21 12:11:05.16982+00', 'true', 'false', '5242880', '{image/jpeg,image/jpg,image/png,image/webp,image/gif,image/svg+xml}', NULL, 'STANDARD') ON CONFLICT ("id") DO UPDATE SET "name" = EXCLUDED."name", "owner" = EXCLUDED."owner", "created_at" = EXCLUDED."created_at", "updated_at" = EXCLUDED."updated_at", "public" = EXCLUDED."public", "avif_autodetection" = EXCLUDED."avif_autodetection", "file_size_limit" = EXCLUDED."file_size_limit", "allowed_mime_types" = EXCLUDED."allowed_mime_types", "owner_id" = EXCLUDED."owner_id", "type" = EXCLUDED."type";

-- ============================================================
-- SECTION: CRON JOBS
-- ============================================================
-- 用户自定义 pg_cron 任务。

